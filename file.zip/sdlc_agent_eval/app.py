import os
os.environ.setdefault("LITELLM_LOCAL_MODEL_COST_MAP", "True")
os.environ.setdefault("AIDER_ANALYTICS_DISABLE", "true")
os.environ.setdefault("AIDER_CHECK_UPDATE", "false")
os.environ.setdefault("DEEPEVAL_TELEMETRY_OPT_OUT", "YES")

import uuid
import streamlit as st
from core.config_loader import load_config, save_config
from core.ollama_manager import ensure_ollama_ready, list_local_models
from core.graph import build_sdlc_graph
from pathlib import Path
import streamlit.components.v1 as components

st.set_page_config(page_title="Agentic SDLC Pipeline", layout="wide")
st.title("Agentic AI-Driven SDLC Automation Pipeline")

cfg = load_config()

def new_thread_cfg() -> dict:
    return {"configurable": {"thread_id": f"sdlc_{uuid.uuid4().hex}"}, "recursion_limit": 300}

with st.sidebar:
    st.header("Runtime & Model Config")
    base_url = st.text_input("Ollama Base URL", value=cfg["ollama"]["base_url"])

    available_models = list_local_models(base_url)
    default_model = cfg["ollama"]["model"]
    if default_model not in available_models:
        available_models.insert(0, default_model)

    selected_model = st.selectbox("Model (localhost:11434)", options=available_models, index=0)
    custom_model = st.text_input("Or type model to auto-pull", value="")
    final_model = custom_model.strip() if custom_model.strip() else selected_model

    num_ctx = st.select_slider(
        "Context Window (num_ctx)",
        options=[4096, 8192, 16384, 32768, 65536],
        value=int(cfg["ollama"]["num_ctx"]),
    )
    temperature = st.slider("Temperature", 0.0, 1.0, float(cfg["ollama"]["temperature"]), 0.05)
    reasoning = st.selectbox("Reasoning Effort", ["low", "medium", "high"], index=1)
    max_iter = st.number_input("Max Loop Iterations", min_value=1, max_value=10, value=int(cfg["workflow"]["max_iterations"]))
    project_path = st.text_input("Target Project Path", value=cfg["workflow"]["project_path"])

    if st.button("Save Config & Connect Ollama"):
        cfg["ollama"]["base_url"] = base_url
        cfg["ollama"]["model"] = final_model
        cfg["ollama"]["num_ctx"] = num_ctx
        cfg["ollama"]["temperature"] = temperature
        cfg["ollama"]["reasoning_effort"] = reasoning
        cfg["workflow"]["max_iterations"] = max_iter
        cfg["workflow"]["project_path"] = project_path
        save_config(cfg)
        ok, status_msg = ensure_ollama_ready(cfg)
        if ok:
            st.success(status_msg)
        else:
            st.error(status_msg)

if "graph" not in st.session_state:
    st.session_state.graph = build_sdlc_graph()
    st.session_state.thread_cfg = new_thread_cfg()
    st.session_state.paused_for_human = False

def run_graph(payload):
    with st.status("Running pipeline...", expanded=True) as status:
        for update in st.session_state.graph.stream(payload, st.session_state.thread_cfg, stream_mode="updates"):
            if not isinstance(update, dict):
                continue
            for out in update.values():
                if isinstance(out, dict) and out.get("logs"):
                    st.text(out["logs"][-1])
        status.update(label="Paused or finished", state="complete")

col1, col2 = st.columns(2)
with col1:
    req_context = st.text_area("Project Requirements / Context", "Python repository using pytest.")
with col2:
    user_input = st.text_area("User Input (Edit / Add / Modify)", "Add input validation and unit tests.")

if st.button("Start SDLC Pipeline", type="primary"):
    ok, msg = ensure_ollama_ready(cfg)
    if not ok:
        st.error(msg)
    else:
        initial_state = {
            "project_path": cfg["workflow"]["project_path"],
            "manifest_path": cfg["workflow"]["manifest_path"],
            "issue_json_path": cfg["workflow"]["issue_json_path"],
            "project_requirements": req_context,
            "user_input": user_input,
            "manifest_data": {},
            "task_stack": [],
            "current_task": None,
            "iteration_count": 0,
            "max_iterations": int(cfg["workflow"]["max_iterations"]),
            "last_editor_diff": "",
            "reviewer_feedback": "",
            "task_completed": False,
            "human_decision": None,
            "logs": [],
            "force_reanalyze": False,
            "planned_tasks": [],
            "task_results": [],
            "tool_trace": [],
            "active_sec": 0.0,
            "eval_summary": {},
            "stalled": False,
        }
        st.session_state.thread_cfg = new_thread_cfg()
        run_graph(initial_state)
        st.rerun()

state_snapshot = st.session_state.graph.get_state(st.session_state.thread_cfg)
if state_snapshot and state_snapshot.values:
    vals = state_snapshot.values

    st.subheader("Execution Logs")
    for log in vals.get("logs", []):
        st.text(log)

    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Task Stack")
        st.json(vals.get("task_stack", []))
    with c2:
        st.subheader("Last Aider Git Diff & Review")
        st.code(vals.get("last_editor_diff", "No diff yet"), language="diff")
        if vals.get("reviewer_feedback"):
            st.info(f"Reviewer Feedback: {vals['reviewer_feedback']}")

    ev = vals.get("eval_summary")
    if ev:
        st.subheader("Evaluation (DeepEval Agentic Matrix)")
        st.caption(f"Run #{ev['runs_tracked']} | {ev['run_dir']}")
        st.dataframe(
            [
                {
                    "Metric": n,
                    "Score": d["score"],
                    "Threshold": d["threshold"],
                    "Band": d["band"],
                    "Status": "PASS" if d["passed"] else "FAIL",
                    "Reason": str(d.get("reason", ""))[:200],
                }
                for n, d in ev["agentic_metrics"].items()
            ],
            use_container_width=True,
        )

    if "human_gate" in state_snapshot.next:
        st.warning("Iteration threshold reached! Issue saved to issue.json. Human decision required:")
        hint = st.text_input("Optional hint for Aider Editor if retrying:")
        b1, b2, b3 = st.columns(3)

        if b1.button("No (Work on it - Retry)"):
            base = vals.get("reviewer_feedback", "").split("\nHuman Hint:")[0]
            updated_feedback = base + (f"\nHuman Hint: {hint}" if hint else "")
            st.session_state.graph.update_state(
                st.session_state.thread_cfg,
                {"human_decision": "work_on_it", "iteration_count": 0, "stalled": False, "reviewer_feedback": updated_feedback},
            )
            run_graph(None)
            st.rerun()

        if b2.button("Yes (Proceed / Skip Task)"):
            st.session_state.graph.update_state(st.session_state.thread_cfg, {"human_decision": "proceed"})
            run_graph(None)
            st.rerun()

        if b3.button("Abort (End Cycle)"):
            st.session_state.graph.update_state(st.session_state.thread_cfg, {"human_decision": "abort"})
            run_graph(None)
            st.rerun()

ev_cfg = cfg.get("evaluation", {})
html_file = Path(ev_cfg.get("html_path", "./workspace_state/benchmark_history.html"))
jsonl_file = Path(ev_cfg.get("history_path", "./workspace_state/benchmark_history.jsonl"))
if html_file.exists():
    with st.expander("Benchmark History (JSONL / HTML)", expanded=False):
        components.html(html_file.read_text(encoding="utf-8"), height=750, scrolling=True)
        d1, d2 = st.columns(2)
        d1.download_button("Download HTML", html_file.read_bytes(), file_name=html_file.name, mime="text/html")
        if jsonl_file.exists():
            d2.download_button("Download JSONL", jsonl_file.read_bytes(), file_name=jsonl_file.name, mime="application/jsonl")