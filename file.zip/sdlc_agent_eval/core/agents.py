import json
import subprocess
from pathlib import Path
from langchain_ollama import ChatOllama
from langchain_core.messages import SystemMessage, HumanMessage
from core.state import AgentState, TaskPlan, ReviewResult
from core.config_loader import load_config
from core.aider_bridge import build_aider_repomap_manifest, run_aider_editor
from core.safety import safe_target_files, parse_verification_cmd, truncate
from core.gitutil import ensure_git_repo, working_diff, stage_all, snapshot, snapshot_diff
from core.evaluation import build_trace_entry, build_task_result, evaluate_run, eval_cfg
from core.benchmark import persist
import sys


def get_dynamic_llm(cfg: dict) -> ChatOllama:
    return ChatOllama(
        model=cfg["ollama"]["model"],
        base_url=cfg["ollama"]["base_url"],
        num_ctx=int(cfg["ollama"]["num_ctx"]),
        temperature=float(cfg["ollama"]["temperature"]),
    )

def invoke_structured(llm, messages, retries: int = 2):
    for _ in range(retries + 1):
        try:
            out = llm.invoke(messages)
            if out is not None:
                return out
        except Exception:
            continue
    return None

def analyzer_node(state: AgentState) -> dict:
    cfg = load_config()
    ensure_git_repo(cfg["workflow"]["project_path"])
    manifest_file = Path(cfg["workflow"]["manifest_path"])
    if manifest_file.exists() and not state.get("force_reanalyze", False):
        manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
        msg = "Loaded existing manifest.json."
    else:
        manifest = build_aider_repomap_manifest(cfg)
        msg = "Generated new manifest.json using Aider RepoMap (Tree-sitter)."
    return {"manifest_data": manifest, "logs": state.get("logs", []) + [f"[Analyser] {msg}"]}

def planner_node(state: AgentState) -> dict:
    cfg = load_config()
    llm = get_dynamic_llm(cfg).with_structured_output(TaskPlan)
    reasoning = cfg["ollama"].get("reasoning_effort", "medium")

    manifest = dict(state["manifest_data"])
    manifest["file_list"] = manifest.get("file_list", [])[:300]

    sys_prompt = (
        f"Reasoning: {reasoning}\n"
        "You are the Requirements + Planning Agent. Review the Aider Repository Map and break the user request "
        "into an ordered list of atomic coding tasks. target_files must be relative paths inside the repository. "
        "verification_cmd must be a single command without pipes or shell operators (e.g. pytest tests/test_x.py)."
        " A task's verification_cmd may only reference files that exist once that task is complete; "
        "if it needs a file created by a later task, use `python -m py_compile <file>` instead."
    )
    user_prompt = (
        f"Project Context:\n{state['project_requirements']}\n\n"
        f"Aider RepoMap & File Manifest:\n{truncate(json.dumps(manifest, indent=2), 40000)}\n\n"
        f"User Request:\n{state['user_input']}"
    )

    plan = invoke_structured(llm, [SystemMessage(content=sys_prompt), HumanMessage(content=user_prompt)])
    if plan is None or not plan.tasks:
        return {
            "task_stack": [],
            "planned_tasks": [],
            "logs": state.get("logs", []) + ["[Planner] Failed to produce a valid plan."],
        }

    root = cfg["workflow"]["project_path"]
    stack = []
    for t in plan.tasks:
        d = t.model_dump()
        d["target_files"] = safe_target_files(root, d["target_files"])
        if d["target_files"]:
            stack.append(d)
    return {
        "task_stack": stack,
        "planned_tasks": [dict(t) for t in stack],
        "task_results": [],
        "tool_trace": [],
        "total_iterations": 0,
        "logs": state.get("logs", []) + [f"[Planner] Created {len(stack)} tasks in Task Stack."],
    }

def pop_next_task_node(state: AgentState) -> dict:
    current = state["task_stack"][0]
    return {
        "current_task": current,
        "iteration_count": 0,
        "task_attempts": 0,
        "task_completed": False,
        "reviewer_feedback": "",
        "last_editor_diff": "",
        "last_verification": "none",
        "human_decision": None,
        "logs": state.get("logs", []) + [f"[Task Stack] Active: {current['task_id']} - {current['title']}"],
        "stalled": False,
    }

def editor_node(state: AgentState) -> dict:
    cfg = load_config()
    task = state["current_task"]
    iteration = state["iteration_count"] + 1
    root = cfg["workflow"]["project_path"]
    files = task["target_files"]
    action = "edit" if all((Path(root) / f).exists() for f in files) else "create"
    prev_diff = state.get("last_editor_diff", "")
    before = snapshot(root, files)

    info = {"edited": [], "errors": [], "reply": "", "format": ""}
    err = ""
    try:
        info = run_aider_editor(
            cfg=cfg,
            target_files=files,
            instructions=task["instructions"],
            reviewer_feedback=state.get("reviewer_feedback", ""),
        )
    except Exception as e:
        err = str(e)

    diff = working_diff(root)
    if not diff.strip():
        diff = snapshot_diff(root, before, files)
    changed = bool(diff.strip()) and diff != prev_diff
    stalled = bool(prev_diff.strip()) and diff == prev_diff
    status = "failed" if err else "applied" if changed else "no_change"
    error = err or "; ".join(info["errors"])[:500]

    log = f"[Editor (Aider)] Iteration {iteration} on {task['task_id']}: {status} (format={info['format']}, edited={info['edited']})"
    if error:
        log += f" | {error[:200]}"
    elif status == "no_change" and info["reply"]:
        log += f" | reply: {info['reply'][:200]}"

    trace = list(state.get("tool_trace", [])) + [{
        "step": f"editor_{iteration}",
        "task_id": task["task_id"],
        "action": action,
        "tool": "aider_edit" if action == "edit" else "aider_create",
        "status": status,
        "error": error,
        "arguments": {
            "file": files[0],
            "files": files,
            "edit_format": info["format"] or cfg["aider"].get("edit_format", "diff"),
        },
    }]
    return {
        "iteration_count": iteration,
        "last_editor_diff": diff,
        "stalled": stalled,
        "tool_trace": trace,
        "logs": state.get("logs", []) + [log],
    }

def read_targets(root: str, files: list, limit: int) -> str:
    out, used = [], 0
    for f in files:
        try:
            text = (Path(root) / f).read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        text = text[: max(limit - used, 0)]
        used += len(text)
        out.append(f"--- {f} ---\n{text}")
    return "\n".join(out)

def reviewer_node(state: AgentState) -> dict:
    cfg = load_config()
    wf = cfg["workflow"]
    task = state["current_task"]
    root = wf["project_path"]
    max_diff = int(wf.get("max_diff_chars", 24000))
    max_out = int(wf.get("max_output_chars", 8000))
    max_file = int(wf.get("max_file_chars", 12000))
    timeout = int(wf.get("verification_timeout", 120))
    veto = bool(wf.get("reviewer_llm_veto", False))
    diff = state["last_editor_diff"]
    prev_feedback = state.get("reviewer_feedback", "")
    stalled = bool(state.get("stalled", False))
    logs = state.get("logs", [])
    last = (state.get("tool_trace") or [{}])[-1]
    files = task["target_files"]

    def reject(fb: str) -> dict:
        return {
            "task_completed": False,
            "reviewer_feedback": fb,
            "stalled": stalled,
            "logs": logs + [f"[Reviewer] Passed=False | {fb[:300]}"],
        }

    if not diff.strip():
        fb = "Editor produced no file changes. Apply the required edits to the target files."
        if last.get("error"):
            fb = f"Editor failed: {last['error'][:500]}"
        return reject(fb)

    if all((Path(root) / f).exists() and (Path(root) / f).stat().st_size == 0 for f in files):
        return reject("Target files are empty. Write the implementation into: " + ", ".join(files))

    sc = static_check(root, files)
    if sc != "ok":
        return reject(f"Syntax error: {sc}")

    cmd_output = "No verification command specified."
    exit_code = None
    cmd = (task.get("verification_cmd") or "").strip()
    if cmd:
        parts = parse_verification_cmd(cmd)
        if parts is None:
            cmd_output = f"Verification command rejected by allowlist: {cmd}"
        else:
            head = Path(parts[0]).name
            if head in {"python", "python3"}:
                parts = [sys.executable] + parts[1:]
            elif head == "pytest":
                parts = [sys.executable, "-m", "pytest"] + parts[1:]
            try:
                proc = subprocess.run(parts, cwd=root, capture_output=True, text=True, timeout=timeout)
                exit_code = proc.returncode
                cmd_output = f"Exit Code: {exit_code}\nSTDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}"
            except subprocess.TimeoutExpired:
                exit_code = -1
                cmd_output = f"Verification command timed out after {timeout}s."
            except FileNotFoundError as e:
                exit_code = -1
                cmd_output = f"Verification command not found: {e}"

    review = None
    if exit_code != 0 or veto:
        llm = get_dynamic_llm(cfg).with_structured_output(ReviewResult)
        sys_prompt = (
            f"Reasoning: {cfg['ollama'].get('reasoning_effort', 'medium')}\n"
            "You are the Reviewer Agent. Judge ONLY whether the target files satisfy the task instructions. "
            "Treat the static check and verification output as ground truth about execution. "
            "Do not request style changes, extra features, extra tests, docs, or work outside this task. "
            "List in blocking_issues only concrete defects that leave the task requirements unmet, each as one short "
            "actionable sentence naming the file/function. If previous issues are listed, check whether each is fixed "
            "in the current files and do not repeat fixed ones. If nothing blocks, set passed=True and blocking_issues=[]."
        )
        prev_block = (
            f"Previously reported issues (check if fixed):\n{truncate(prev_feedback, 1500)}\n\n"
            if prev_feedback.strip() else ""
        )
        user_prompt = (
            f"Task: {task['instructions']}\n\n"
            f"{prev_block}"
            f"Current target files:\n{read_targets(root, files, max_file)}\n\n"
            f"Git Diff:\n{truncate(diff, max_diff)}\n\n"
            f"Static check: {sc}\n\n"
            f"Verification Output:\n{truncate(cmd_output, max_out)}"
        )
        review = invoke_structured(llm, [SystemMessage(content=sys_prompt), HumanMessage(content=user_prompt)])

    issues = [i.strip() for i in (review.blocking_issues if review else []) if i and i.strip()]

    if exit_code not in (None, 0):
        passed = False
    elif exit_code == 0 and not veto:
        passed = True
    elif review is None:
        passed = exit_code == 0
    else:
        passed = review.passed or not issues
    if not passed and stalled and exit_code == 0:
        passed = True

    notes = "\n".join(f"{i}. {t}" for i, t in enumerate(issues, 1))
    if passed:
        feedback = notes
    else:
        fb_parts = []
        if notes:
            fb_parts.append(notes)
        elif review and review.feedback.strip():
            fb_parts.append(review.feedback.strip())
        if exit_code not in (None, 0):
            fb_parts.append(f"Verification failed (exit {exit_code}):\n{cmd_output[-1500:]}")
        elif review is None:
            fb_parts.append("Reviewer produced no valid result and no verification passed.")
        feedback = truncate("\n".join(fb_parts), 3000)

    return {
        "task_completed": passed,
        "reviewer_feedback": feedback,
        "stalled": stalled and not passed,
        "logs": logs + [f"[Reviewer] Passed={passed} | exit={exit_code} | {feedback[:300]}"],
    }


def complete_task_node(state: AgentState) -> dict:
    cfg = load_config()
    stack = list(state["task_stack"])
    done = stack.pop(0)
    status = "passed" if state.get("task_completed") else "skipped"
    result = build_task_result(
        done,
        state.get("last_editor_diff", ""),
        status,
        state.get("task_attempts", 0),
        state.get("last_verification", "none"),
    )
    stage_all(cfg["workflow"]["project_path"])
    manifest = build_aider_repomap_manifest(cfg)
    return {
        "task_stack": stack,
        "current_task": None,
        "manifest_data": manifest,
        "task_results": state.get("task_results", []) + [result],
        "logs": state.get("logs", []) + [f"[Task Stack] Completed & popped {done['task_id']} ({status})."],
    }

def save_issue_node(state: AgentState) -> dict:
    cfg = load_config()
    issue_file = Path(cfg["workflow"]["issue_json_path"])
    issue_file.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "task": state["current_task"],
        "iterations": state["iteration_count"],
        "reviewer_feedback": state["reviewer_feedback"],
        "last_diff": state["last_editor_diff"],
    }
    issue_file.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return {"logs": state.get("logs", []) + ["[Escalation] Saved issue.json. Waiting for Human Decision..."]}

def evaluator_node(state: AgentState) -> dict:
    cfg = load_config()
    logs = state.get("logs", [])
    if not eval_cfg(cfg)["enabled"]:
        return {"logs": logs + ["[Evaluator] Disabled in config."]}
    if not state.get("planned_tasks"):
        return {"logs": logs + ["[Evaluator] No planned tasks; evaluation skipped."]}

    results = list(state.get("task_results", []))
    cur = state.get("current_task")
    if cur and all(r["id"] != cur["task_id"] for r in results):
        results.append(build_task_result(
            cur,
            state.get("last_editor_diff", ""),
            "failed",
            state.get("task_attempts", 0),
            state.get("last_verification", "none"),
        ))
    st = dict(state)
    st["task_results"] = results

    try:
        payload = evaluate_run(st, cfg)
        record, run_dir = persist(cfg, st, payload)
    except Exception as e:
        return {"task_results": results, "logs": logs + [f"[Evaluator] Failed: {e}"]}

    ov = payload["overall"]
    return {
        "task_results": results,
        "eval_summary": {
            "run_dir": run_dir,
            "overall": ov,
            "agentic_metrics": payload["agentic_metrics"],
        },
        "logs": logs + [
            f"[Evaluator] tasks={ov['tasks_passed']} | deepeval_avg={ov.get('deepeval_avg_score')} | "
            f"agentic_avg={ov['agentic_deepeval_avg']} | report={run_dir}"
        ],
    }