import shlex
from pathlib import Path

ALLOWED_CMDS = {"pytest", "python", "python3", "ruff", "flake8", "mypy", "make", "npm"}
BLOCKED = (";", "&&", "||", "|", ">", "<", "`", "$(")

def safe_target_files(project_root: str, files: list[str]) -> list[str]:
    root = Path(project_root).resolve()
    out = []
    for f in files:
        p = (root / f).resolve()
        if root in p.parents and ".git" not in p.relative_to(root).parts:
            out.append(str(p.relative_to(root)).replace("\\", "/"))
    return out

def parse_verification_cmd(cmd: str):
    if any(t in cmd for t in BLOCKED):
        return None
    try:
        parts = shlex.split(cmd)
    except ValueError:
        return None
    if not parts or Path(parts[0]).name not in ALLOWED_CMDS:
        return None
    if Path(parts[0]).name in {"python", "python3"} and "-c" in parts:
        return None
    return parts

def truncate(text: str, max_chars: int) -> str:
    if len(text) <= max_chars:
        return text
    h = max_chars // 2
    return text[:h] + "\n...[truncated]...\n" + text[-h:]