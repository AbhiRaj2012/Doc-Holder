import subprocess
import difflib
from pathlib import Path

EXCLUDE = ":(exclude).aider*"

def git(cwd, *args):
    return subprocess.run(["git", *args], cwd=str(cwd), capture_output=True, text=True)

def ensure_git_repo(project_path: str) -> None:
    root = Path(project_path).resolve()
    root.mkdir(parents=True, exist_ok=True)
    top = git(root, "rev-parse", "--show-toplevel")
    if top.returncode != 0 or Path(top.stdout.strip()).resolve() != root:
        git(root, "init")
        git(root, "add", "-A", "--", ".", EXCLUDE)
        git(root, "-c", "user.name=sdlc", "-c", "user.email=sdlc@local",
            "commit", "-m", "baseline", "--allow-empty")

def working_diff(project_path: str) -> str:
    git(project_path, "add", "-N", "--", ".", EXCLUDE)
    return git(project_path, "diff", "--", ".", EXCLUDE).stdout

def stage_all(project_path: str) -> None:
    git(project_path, "add", "-A", "--", ".", EXCLUDE)

def snapshot(project_path: str, files: list) -> dict:
    root = Path(project_path).resolve()
    out = {}
    for f in files:
        try:
            out[f] = (root / f).read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            out[f] = None
    return out

def snapshot_diff(project_path: str, before: dict, files: list) -> str:
    after = snapshot(project_path, files)
    chunks = []
    for f in files:
        b, a = before.get(f), after.get(f)
        if a is not None and a != b:
            chunks.append("".join(difflib.unified_diff((b or "").splitlines(True), a.splitlines(True), f"a/{f}", f"b/{f}")))
    return "".join(chunks)