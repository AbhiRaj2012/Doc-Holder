import json
from pathlib import Path
from langchain_ollama import ChatOllama
from langchain_core.messages import SystemMessage, HumanMessage
from core.state import AgentState, TaskPlan, ReviewResult
from core.config_loader import load_config
from core.aider_bridge import build_aider_repomap_manifest, run_aider_editor
from core.safety import safe_target_files, parse_verification_cmd, truncate
from core.gitutil import ensure_git_repo, working_diff, stage_all, has_real_changes
from core.review_utils import (
    read_targets, files_view, syntax_errors, run_verification, validate_issues, issue_signature, format_feedback,
)
from core.evaluation import build_trace_entry, build_task_result, evaluate_run, eval_cfg
from core.benchmark import persist

def get_dynamic_llm(cfg: dict) -> ChatOllama:
    return ChatOllama(
        model=cfg["ollama"]["model"],
        base_url=cfg["ollama"]["base_url"],
        num_ctx=int(cfg["ollama"]["num_ctx"]),
        temperature=float(cfg["ollama"]["temperature"]),
    )

def invoke_structured(llm, messages, retries: int = 2):
    for _ in range(retries + 1):
        try:
            out = llm.invoke(messages)
            if out is not None:
                return out
        except Exception:
            continue
    return None

def analyzer_node(state: AgentState) -> dict:
    cfg = load_config()
    ensure_git_repo(cfg["workflow"]["project_path"])
    manifest_file = Path(cfg["workflow"]["manifest_path"])
    if manifest_file.exists() and not state.get("force_reanalyze", False):
        manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
        msg = "Loaded existing manifest.json."
    else:
        manifest = build_aider_repomap_manifest(cfg)
        msg = "Generated new manifest.json using Aider RepoMap (Tree-sitter)."
    return {"manifest_data": manifest, "logs": state.get("logs", []) + [f"[Analyser] {msg}"]}

def planner_node(state: AgentState) -> dict:
    cfg = load_config()
    llm = get_dynamic_llm(cfg).with_structured_output(TaskPlan)
    reasoning = cfg["ollama"].get("reasoning_effort", "medium")

    manifest = dict(state["manifest_data"])
    manifest["file_list"] = manifest.get("file_list", [])[:300]

    sys_prompt = (
        f"Reasoning: {reasoning}\n"
        "You are the Requirements + Planning Agent. Review the Aider Repository Map and break the user request "
        "into an ordered list of atomic coding tasks. target_files must be relative paths inside the repository. "
        "verification_cmd must be a single command without pipes or shell operators (e.g. pytest tests/test_x.py)."
    )
    user_prompt = (
        f"Project Context:\n{state['project_requirements']}\n\n"
        f"Aider RepoMap & File Manifest:\n{truncate(json.dumps(manifest, indent=2), 40000)}\n\n"
        f"User Request:\n{state['user_input']}"
    )

    plan = invoke_structured(llm, [SystemMessage(content=sys_prompt), HumanMessage(content=user_prompt)])
    if plan is None or not plan.tasks:
        return {
            "task_stack": [],
            "planned_tasks": [],
            "logs": state.get("logs", []) + ["[Planner] Failed to produce a valid plan."],
        }

    root = cfg["workflow"]["project_path"]
    stack = []
    for t in plan.tasks:
        d = t.model_dump()
        d["target_files"] = safe_target_files(root, d["target_files"])
        if d["target_files"]:
            stack.append(d)
    return {
        "task_stack": stack,
        "planned_tasks": [dict(t) for t in stack],
        "task_results": [],
        "tool_trace": [],
        "total_iterations": 0,
        "logs": state.get("logs", []) + [f"[Planner] Created {len(stack)} tasks in Task Stack."],
    }

def pop_next_task_node(state: AgentState) -> dict:
    current = state["task_stack"][0]
    return {
        "current_task": current,
        "iteration_count": 0,
        "task_attempts": 0,
        "task_completed": False,
        "reviewer_feedback": "",
        "last_editor_diff": "",
        "last_verification": "none",
        "editor_changed": True,
        "editor_note": "",
        "stalled": False,
        "prev_issue_sig": "",
        "human_decision": None,
        "logs": state.get("logs", []) + [f"[Task Stack] Active: {current['task_id']} - {current['title']}"],
    }

def _whole_fits(cfg: dict, root: str, files: list) -> bool:
    limit = int(cfg["aider"].get("whole_max_chars", 24000))
    total = 0
    for f in files:
        p = Path(root).resolve() / f
        if p.is_file():
            total += p.stat().st_size
    return total <= limit

def _attempt(cfg, task, feedback, fmt, root):
    try:
        res = run_aider_editor(cfg, task["target_files"], task["instructions"], feedback, edit_format=fmt)
        return res, working_diff(root, res["edited"]), None
    except Exception as e:
        return None, working_diff(root), str(e)

def editor_node(state: AgentState) -> dict:
    cfg = load_config()
    task = state["current_task"]
    iteration = state["iteration_count"] + 1
    attempt = state.get("task_attempts", 0) + 1
    root = cfg["workflow"]["project_path"]
    feedback = state.get("reviewer_feedback", "")
    primary = cfg["aider"].get("edit_format", "diff")
    fallback = cfg["aider"].get("fallback_edit_format", "whole")

    before = working_diff(root)
    res, diff, error = _attempt(cfg, task, feedback, primary, root)
    used = primary
    if diff == before and fallback and fallback != primary and _whole_fits(cfg, root, task["target_files"]):
        hint = (feedback + "\n" if feedback else "") + "Your previous reply applied no edit. Output the COMPLETE updated file(s) in the required format."
        res2, diff2, error2 = _attempt(cfg, task, hint, fallback, root)
        if res2 is not None:
            res, diff, error, used = res2, diff2, error2, fallback
        elif diff2 != before:
            diff = diff2

    changed = diff != before
    parts = []
    if error:
        parts.append(error)
    if res:
        parts += [e.strip() for e in res["errors"][-3:] if e.strip()]
        if not changed and res["response"].strip():
            parts.append("reply excerpt: " + res["response"][:300].replace("\n", " "))
    note = " | ".join(parts)[:900] if not changed else ""

    edited = ",".join(res["edited"]) if res and res["edited"] else "-"
    if changed:
        log = f"[Editor (Aider)] Iteration {iteration} on {task['task_id']}: changed [{edited}] (format={used})."
    else:
        log = f"[Editor (Aider)] Iteration {iteration} on {task['task_id']}: NO CHANGE (format={used}). {note[:300]}"

    entry = build_trace_entry(
        task, attempt, diff if changed else "", error or (None if changed else "no change this iteration")
    )
    return {
        "iteration_count": iteration,
        "task_attempts": attempt,
        "total_iterations": state.get("total_iterations", 0) + 1,
        "tool_trace": state.get("tool_trace", []) + [entry],
        "last_editor_diff": diff,
        "editor_changed": changed,
        "editor_note": note,
        "stalled": False,
        "logs": state.get("logs", []) + [log],
    }

def reviewer_node(state: AgentState) -> dict:
    cfg = load_config()
    task = state["current_task"]
    root = cfg["workflow"]["project_path"]
    max_diff = int(cfg["workflow"].get("max_diff_chars", 24000))
    max_out = int(cfg["workflow"].get("max_output_chars", 8000))
    timeout = int(cfg["workflow"].get("verification_timeout", 120))
    diff = state["last_editor_diff"]
    attempts = state.get("task_attempts", 0)
    logs = state.get("logs", [])

    if not has_real_changes(diff):
        note = state.get("editor_note", "")
        fb = "Editor produced no file changes." + (f" Aider reported: {note}." if note else "") + \
            " Apply the required edits to the target files using the required edit format."
        return {
            "task_completed": False,
            "reviewer_feedback": fb,
            "last_verification": "no changes",
            "stalled": attempts > 1,
            "logs": logs + [f"[Reviewer] Passed=False | {fb[:300]}"],
        }

    if attempts > 1 and not state.get("editor_changed", True):
        return {
            "task_completed": False,
            "stalled": True,
            "logs": logs + ["[Reviewer] Passed=False | Editor made no change after feedback; escalating."],
        }

    files_text = read_targets(root, task["target_files"])
    syntax = syntax_errors(files_text)
    verification = run_verification(root, (task.get("verification_cmd") or "").strip(), parse_verification_cmd, timeout, max_out)

    issues, dropped, summary = [], 0, ""
    review_ok = True
    if not syntax and verification["status"] != "fail":
        llm = get_dynamic_llm(cfg).with_structured_output(ReviewResult)
        prev = state.get("reviewer_feedback", "") if attempts > 1 else ""
        sys_prompt = (
            f"Reasoning: {cfg['ollama'].get('reasoning_effort', 'medium')}\n"
            "You are a strict-but-fair code reviewer. Judge ONLY against the TASK. "
            "Report an issue only if it is BLOCKING: a concrete bug, import/syntax error, broken existing behavior, "
            "or an explicit task requirement that is missing. Do NOT report style, naming, docs, extra tests, "
            "optimizations or anything outside the task. Every issue needs `evidence`: for a defect, one line copied "
            "verbatim from the file; for a missing item, the exact identifier that should exist. "
            "If the task is satisfied, return an empty issues list. "
            "If previous feedback is given, only check whether those items are now fixed; add new issues only for "
            "bugs introduced by the latest edit."
        )
        user_prompt = (
            f"TASK:\n{task['instructions']}\n\n"
            f"TARGET FILES (current content):\n{files_view(files_text, max_diff)}\n\n"
            f"CHANGES (git diff):\n{truncate(diff, max_diff // 2)}\n\n"
            f"VERIFICATION ({verification['status']}: {verification['label']}):\n{truncate(verification['output'], max_out)}\n\n"
            + (f"PREVIOUS FEEDBACK:\n{prev}\n" if prev else "")
        )
        review = invoke_structured(llm, [SystemMessage(content=sys_prompt), HumanMessage(content=user_prompt)])
        if review is None:
            review_ok = False
        else:
            summary = review.summary
            issues, dropped = validate_issues(review.issues, files_text)

    passed = not syntax and not issues and verification["status"] != "fail" and (review_ok or verification["status"] == "pass")
    if passed:
        feedback = summary or "Accepted."
        if not review_ok:
            feedback = "Reviewer unavailable; accepted on passing verification."
        if dropped:
            feedback += f" ({dropped} unverifiable objection(s) ignored.)"
    elif not review_ok and not syntax and verification["status"] != "fail":
        feedback = "Reviewer produced no valid result and verification was inconclusive."
    else:
        feedback = format_feedback(issues, verification, syntax, max_out)

    sig = "" if passed else issue_signature(issues, verification, syntax)
    stalled = (not passed) and attempts > 1 and bool(sig) and sig == state.get("prev_issue_sig", "")
    return {
        "task_completed": passed,
        "reviewer_feedback": feedback,
        "last_verification": verification["label"] if verification["status"] != "none" else "no command",
        "prev_issue_sig": sig,
        "stalled": stalled,
        "logs": logs + [f"[Reviewer] Passed={passed} | verification={verification['status']} | issues={len(issues)} dropped={dropped} stalled={stalled} | {feedback[:240]}"],
    }

def complete_task_node(state: AgentState) -> dict:
    cfg = load_config()
    stack = list(state["task_stack"])
    done = stack.pop(0)
    status = "passed" if state.get("task_completed") else "skipped"
    result = build_task_result(
        done,
        state.get("last_editor_diff", ""),
        status,
        state.get("task_attempts", 0),
        state.get("last_verification", "none"),
    )
    stage_all(cfg["workflow"]["project_path"])
    manifest = build_aider_repomap_manifest(cfg)
    return {
        "task_stack": stack,
        "current_task": None,
        "manifest_data": manifest,
        "task_results": state.get("task_results", []) + [result],
        "logs": state.get("logs", []) + [f"[Task Stack] Completed & popped {done['task_id']} ({status})."],
    }

def save_issue_node(state: AgentState) -> dict:
    cfg = load_config()
    issue_file = Path(cfg["workflow"]["issue_json_path"])
    issue_file.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "task": state["current_task"],
        "iterations": state["iteration_count"],
        "reviewer_feedback": state["reviewer_feedback"],
        "last_diff": state["last_editor_diff"],
    }
    issue_file.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return {"logs": state.get("logs", []) + ["[Escalation] Saved issue.json. Waiting for Human Decision..."]}

def evaluator_node(state: AgentState) -> dict:
    cfg = load_config()
    logs = state.get("logs", [])
    if not eval_cfg(cfg)["enabled"]:
        return {"logs": logs + ["[Evaluator] Disabled in config."]}
    if not state.get("planned_tasks"):
        return {"logs": logs + ["[Evaluator] No planned tasks; evaluation skipped."]}

    results = list(state.get("task_results", []))
    cur = state.get("current_task")
    if cur and all(r["id"] != cur["task_id"] for r in results):
        results.append(build_task_result(
            cur,
            state.get("last_editor_diff", ""),
            "failed",
            state.get("task_attempts", 0),
            state.get("last_verification", "none"),
        ))
    st = dict(state)
    st["task_results"] = results

    try:
        payload = evaluate_run(st, cfg)
        record, run_dir = persist(cfg, st, payload)
    except Exception as e:
        return {"task_results": results, "logs": logs + [f"[Evaluator] Failed: {e}"]}

    ov = payload["overall"]
    return {
        "task_results": results,
        "eval_summary": {
            "run_dir": run_dir,
            "overall": ov,
            "agentic_metrics": payload["agentic_metrics"],
        },
        "logs": logs + [
            f"[Evaluator] tasks={ov['tasks_passed']} | deepeval_avg={ov.get('deepeval_avg_score')} | "
            f"agentic_avg={ov['agentic_deepeval_avg']} | report={run_dir}"
        ],
    }
