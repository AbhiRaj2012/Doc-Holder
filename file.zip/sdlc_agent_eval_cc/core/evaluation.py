import os
import re
import json
import time
import functools
from pathlib import Path
from typing import Optional
from langchain_ollama import ChatOllama

os.environ.setdefault("DEEPEVAL_TELEMETRY_OPT_OUT", "YES")
try:
    from deepeval.models.base_model import DeepEvalBaseLLM
    from deepeval.metrics import GEval
    from deepeval.test_case import LLMTestCase, LLMTestCaseParams
    DEEPEVAL_AVAILABLE = True
except Exception:
    DeepEvalBaseLLM = object
    DEEPEVAL_AVAILABLE = False

EVAL_DEFAULTS = {
    "enabled": True,
    "deepeval_enabled": True,
    "num_predict": 4096,
    "max_files": 8,
    "max_file_chars": 6000,
    "output_dir": "./workspace_state/eval",
    "history_path": "./workspace_state/benchmark_history.jsonl",
    "history_html_path": "./workspace_state/benchmark_history.html",
}

AGENTIC_METRIC_SPECS = {
    "Plan Quality": {
        "key": "plan_quality", "bad_max": 0.59, "good_min": 0.80, "threshold": 0.70,
        "bad_label": "0 - 0.59", "good_label": "0.80 - 1.0",
        "criteria": (
            "Evaluate the quality, granularity, logical ordering, and completeness of the execution plan "
            "in ACTUAL_OUTPUT against the user request and repository manifest in INPUT. "
            "Check if tasks are properly scoped (one logical unit per task), ordered so dependencies "
            "are created before use, have meaningful verification commands, and cover the full user "
            "requirement without redundant steps."
        ),
    },
    "Plan Adherence": {
        "key": "plan_adherence", "bad_max": 0.59, "good_min": 0.80, "threshold": 0.70,
        "bad_label": "0 - 0.59", "good_label": "0.80 - 1.0",
        "criteria": (
            "Evaluate how strictly the executed tasks, file modifications, and diffs in ACTUAL_OUTPUT "
            "adhered to the planned tasks and instructions specified in INPUT. Penalize skipped tasks, "
            "unauthorized out-of-scope file modifications, or deviations from planned target files."
        ),
    },
    "Tool Correctness": {
        "key": "tool_correctness", "bad_max": 0.69, "good_min": 0.90, "threshold": 0.70,
        "bad_label": "0 - 0.69", "good_label": "0.90 - 1.0",
        "criteria": (
            "Evaluate whether the correct editing action (Aider diff edit of an existing file vs creation of a "
            "new file) and verification tools were selected and applied in ACTUAL_OUTPUT given the file "
            "existence state and task requirements in INPUT."
        ),
    },
    "Argument Correctness": {
        "key": "argument_correctness", "bad_max": 0.69, "good_min": 0.90, "threshold": 0.70,
        "bad_label": "0 - 0.69", "good_label": "0.90 - 1.0",
        "criteria": (
            "Evaluate the accuracy of tool arguments in ACTUAL_OUTPUT against INPUT: valid relative file paths, "
            "changed files limited to the planned target files, and syntactically valid resulting code."
        ),
    },
    "Step Efficiency": {
        "key": "step_efficiency", "bad_max": 0.69, "good_min": 0.85, "threshold": 0.70,
        "bad_label": "0 - 0.69", "good_label": "0.85 - 1.0",
        "criteria": (
            "Evaluate the execution efficiency in ACTUAL_OUTPUT based on total iterations, retry attempts, "
            "and failed edits relative to total tasks in INPUT. First-try passes with minimal diff overhead "
            "and zero redundant retries should score highest (0.85 - 1.0)."
        ),
    },
    "Task Completion": {
        "key": "task_completion", "bad_max": 0.69, "good_min": 0.90, "threshold": 0.70,
        "bad_label": "0 - 0.69", "good_label": "0.90 - 1.0",
        "criteria": (
            "Evaluate whether the final code changes and task outcomes in ACTUAL_OUTPUT completely, "
            "accurately, and functionally fulfill the original user request in INPUT, with all tasks passing "
            "review and no remaining syntax errors, TODOs, or broken references."
        ),
    },
}

_DIFF_RE = re.compile(r"^diff --git a/(.+?) b/(.+)$", re.M)


def eval_cfg(cfg: dict) -> dict:
    return {**EVAL_DEFAULTS, **(cfg.get("eval") or {})}


def strip_think(text: str) -> str:
    return re.sub(r"<think>.*?</think>", "", text or "", flags=re.S).strip()


class OllamaEvalModel(DeepEvalBaseLLM):
    def __init__(self, chat_model, name):
        self._chat = chat_model
        self._name = name

    def load_model(self):
        return self._chat

    def generate(self, prompt: str) -> str:
        return strip_think(self._chat.invoke(prompt).content)

    async def a_generate(self, prompt: str) -> str:
        return self.generate(prompt)

    def get_model_name(self) -> str:
        return self._name


def make_judge(cfg: dict) -> "OllamaEvalModel":
    chat = ChatOllama(
        model=cfg["ollama"]["model"],
        base_url=cfg["ollama"]["base_url"],
        num_ctx=int(cfg["ollama"]["num_ctx"]),
        temperature=float(cfg["ollama"]["temperature"]),
        num_predict=int(eval_cfg(cfg)["num_predict"]),
    )
    return OllamaEvalModel(chat, cfg["ollama"]["model"])


def timed_node(fn):
    @functools.wraps(fn)
    def wrapper(state):
        t0 = time.perf_counter()
        out = dict(fn(state) or {})
        out["elapsed_sec"] = round(float(state.get("elapsed_sec", 0.0)) + time.perf_counter() - t0, 3)
        return out
    return wrapper


def diff_files(diff: str) -> list:
    out = []
    for m in _DIFF_RE.finditer(diff or ""):
        p = m.group(2).strip()
        if not Path(p).name.startswith(".aider") and p not in out:
            out.append(p)
    return out


def _tool_for(diff: str) -> str:
    return "aider_create_file" if "new file mode" in (diff or "") else "aider_diff_edit"


def build_trace_entry(task: dict, iteration: int, diff: str, error: Optional[str] = None) -> dict:
    changed = diff_files(diff)
    applied = not error and "\n@@" in ("\n" + (diff or ""))
    return {
        "step": f"editor_{task['task_id']}_{iteration}",
        "tool": _tool_for(diff),
        "status": "applied" if applied else "failed",
        "arguments": {
            "file": (task.get("target_files") or [""])[0],
            "files": list(task.get("target_files", [])),
            "changed_files": changed,
        },
        "error": error or ("" if applied else "no file changes"),
    }


def build_task_result(task: dict, diff: str, status: str, attempts: int, verification: str) -> dict:
    files = list(task.get("target_files", []))
    return {
        "id": task["task_id"],
        "title": task.get("title", ""),
        "file": files[0] if files else "",
        "files": files,
        "action": "create" if "new file mode" in (diff or "") else "edit",
        "tool": _tool_for(diff),
        "arguments": {"file": files[0] if files else "", "files": files, "changed_files": diff_files(diff)},
        "status": status,
        "attempts": max(int(attempts), 1),
        "static_check": verification,
        "diff": (diff or "")[:4000],
    }


def classify_metric_score(metric_name: str, score: Optional[float]) -> dict:
    spec = AGENTIC_METRIC_SPECS[metric_name]
    base = {
        "threshold": spec["threshold"],
        "bad_range": spec["bad_label"],
        "good_range": spec["good_label"],
    }
    if score is None:
        return {"score": None, "passed": False, "band": "N/A", **base}
    s = round(float(score), 2)
    if s <= spec["bad_max"]:
        band = "Bad"
    elif s >= spec["good_min"]:
        band = "Good"
    else:
        band = "Moderate"
    return {"score": s, "passed": s >= spec["threshold"], "band": band, **base}


def deterministic_fallbacks(planned: list, results: list, trace: list, total_iterations: int) -> dict:
    n = max(len(planned), 1)
    valid = sum(
        1 for t in planned
        if t.get("target_files") and len(t.get("instructions", "")) >= 10 and t.get("verification_cmd")
    )
    plan_quality = round(min(1.0, valid / n), 2)

    pmap = {t["task_id"]: t for t in planned}
    adhered = 0
    for r in results:
        p = pmap.get(r["id"])
        if p and r["status"] == "passed" and set(r.get("arguments", {}).get("changed_files", [])) <= set(p["target_files"]):
            adhered += 1
    plan_adherence = round(adhered / n, 2)

    et = [t for t in trace if str(t.get("step", "")).startswith("editor_")]
    if et:
        tool_ok = sum(1 for t in et if t.get("tool") in ("aider_diff_edit", "aider_create_file") and t.get("status") == "applied")
        arg_ok = sum(
            1 for t in et
            if t.get("status") == "applied"
            and t["arguments"].get("file")
            and set(t["arguments"].get("changed_files", [])) <= set(t["arguments"].get("files", []))
        )
        tool_correctness = round(tool_ok / len(et), 2)
        argument_correctness = round(arg_ok / len(et), 2)
    else:
        tool_correctness = argument_correctness = 0.0

    attempts = sum(r.get("attempts", 1) for r in results) or max(total_iterations, 1)
    step_efficiency = round(max(0.0, min(1.0, n / max(attempts, n))), 2)
    passed = sum(1 for r in results if r.get("status") == "passed")
    task_completion = round(passed / n, 2)

    return {
        "Plan Quality": (plan_quality, "Deterministic fallback: ratio of well-formed, scoped tasks in plan."),
        "Plan Adherence": (plan_adherence, "Deterministic fallback: ratio of planned tasks passed with edits confined to target files."),
        "Tool Correctness": (tool_correctness, "Deterministic fallback: ratio of editor iterations that applied a valid file change."),
        "Argument Correctness": (argument_correctness, "Deterministic fallback: ratio of editor iterations with valid file arguments within scope."),
        "Step Efficiency": (step_efficiency, f"Deterministic fallback: {n} planned task(s) completed in {attempts} attempt(s)."),
        "Task Completion": (task_completion, f"Deterministic fallback: {passed}/{n} tasks passed review."),
    }


def _file_metrics(judge) -> list:
    return [
        GEval(
            name="Correctness",
            criteria=(
                "The ACTUAL_OUTPUT is a source file after an automated edit. Using the user request, manifest and plan "
                "given in INPUT as ground truth: do all referenced identifiers, imports, ids and function calls exist "
                "and match the manifest/project conventions? Does each changed function's logic plausibly fulfil the "
                "request? Flag any obvious runtime or syntax bug."
            ),
            evaluation_params=[LLMTestCaseParams.INPUT, LLMTestCaseParams.ACTUAL_OUTPUT],
            model=judge, threshold=0.70, async_mode=False,
        ),
        GEval(
            name="Completeness",
            criteria=(
                "Using the user request and plan given in INPUT as the spec, does ACTUAL_OUTPUT implement "
                "every requested change for this file with real logic, not a TODO or empty stub?"
            ),
            evaluation_params=[LLMTestCaseParams.INPUT, LLMTestCaseParams.ACTUAL_OUTPUT],
            model=judge, threshold=0.70, async_mode=False,
        ),
    ]


def _agentic_metrics(judge) -> dict:
    return {
        name: GEval(
            name=name,
            criteria=spec["criteria"],
            evaluation_params=[LLMTestCaseParams.INPUT, LLMTestCaseParams.ACTUAL_OUTPUT],
            model=judge, threshold=spec["threshold"], async_mode=False,
        )
        for name, spec in AGENTIC_METRIC_SPECS.items()
    }


def _score_file(code: str, context: str, metrics: list) -> Optional[dict]:
    if not metrics or not code.strip():
        return None
    case = LLMTestCase(input=context, actual_output=code)
    out = {}
    for m in metrics:
        try:
            m.measure(case)
            out[m.name] = {"score": round(m.score, 2) if m.score is not None else None, "reason": m.reason}
        except Exception as e:
            out[m.name] = {"score": None, "reason": f"DeepEval metric failed: {e}"}
    return out


def _evaluate_agentic(state: dict, planned: list, results: list, trace: list, judge, use_de: bool) -> dict:
    manifest = state.get("manifest_data", {})
    fb = deterministic_fallbacks(planned, results, trace, int(state.get("total_iterations", 0)))
    input_payload = json.dumps(
        {
            "user_request": state.get("user_input", ""),
            "project_requirements": state.get("project_requirements", ""),
            "manifest_summary": {
                "file_count": len(manifest.get("file_list", [])),
                "repo_map_excerpt": str(manifest.get("aider_repo_map", ""))[:1500],
            },
            "planned_tasks": planned,
        },
        indent=2,
    )[:5000]
    actual_payload = json.dumps(
        {
            "total_iterations": state.get("total_iterations", 0),
            "task_results": [
                {
                    "id": r["id"], "files": r["files"], "action": r["action"], "tool": r["tool"],
                    "arguments": r["arguments"], "status": r["status"], "attempts": r["attempts"],
                    "verification": r["static_check"], "diff_excerpt": r.get("diff", "")[:600],
                }
                for r in results
            ],
            "tool_trace": trace[:25],
        },
        indent=2,
    )[:6000]

    scores = {}
    metrics = _agentic_metrics(judge) if use_de else {}
    case = LLMTestCase(input=input_payload, actual_output=actual_payload) if use_de else None
    for name in AGENTIC_METRIC_SPECS:
        raw, reason = fb[name]
        if use_de:
            try:
                metrics[name].measure(case)
                if metrics[name].score is not None:
                    raw = round(metrics[name].score, 2)
                    reason = metrics[name].reason or reason
            except Exception as e:
                reason = f"{reason} (DeepEval fallback due to: {e})"
        meta = classify_metric_score(name, raw)
        meta["reason"] = reason
        scores[name] = meta
    return scores


def custom_score(attempts: int) -> float:
    return round(max(0.25, 1.0 - 0.25 * (attempts - 1)), 2)


def evaluate_run(state: dict, cfg: dict) -> dict:
    ev = eval_cfg(cfg)
    use_de = DEEPEVAL_AVAILABLE and bool(ev["deepeval_enabled"])
    planned = state.get("planned_tasks", [])
    results = state.get("task_results", [])
    trace = state.get("tool_trace", [])
    total_tasks = len(planned)
    total_time = round(float(state.get("elapsed_sec", 0.0)), 2)
    root = Path(cfg["workflow"]["project_path"]).resolve()
    manifest = state.get("manifest_data", {})

    context = (
        f"USER REQUEST:\n{state.get('user_input', '')}\n\n"
        f"PROJECT CONTEXT:\n{state.get('project_requirements', '')}\n\n"
        f"REPO MAP:\n{str(manifest.get('aider_repo_map', ''))[:2500]}\n\n"
        f"PLAN:\n{json.dumps(planned, indent=2)[:3000]}"
    )

    judge = make_judge(cfg) if use_de else None
    file_metrics = _file_metrics(judge) if use_de else []

    file_tasks: dict = {}
    for r in results:
        if r["status"] == "passed":
            for f in r["files"]:
                file_tasks.setdefault(f, []).append(r)

    report = {}
    for filename, rs in list(file_tasks.items())[: int(ev["max_files"])]:
        try:
            code = (root / filename).read_text(encoding="utf-8", errors="replace")
        except OSError:
            code = ""
        scores = [custom_score(r["attempts"]) for r in rs]
        report[filename] = {
            "tasks": len(rs),
            "attempts": sum(r["attempts"] for r in rs),
            "custom_score": round(sum(scores) / len(scores), 2),
            "deepeval": _score_file(code[: int(ev["max_file_chars"])], context, file_metrics),
        }

    agentic = _evaluate_agentic(state, planned, results, trace, judge, use_de)
    agentic_vals = [m["score"] for m in agentic.values() if m["score"] is not None]
    agentic_avg = round(sum(agentic_vals) / len(agentic_vals), 2) if agentic_vals else None

    tasks_passed = sum(1 for r in results if r["status"] == "passed")
    custom_vals = [f["custom_score"] for f in report.values()]
    overall = {
        "tasks_passed": f"{tasks_passed}/{total_tasks}",
        "tasks_skipped": sum(1 for r in results if r["status"] == "skipped"),
        "tasks_failed": sum(1 for r in results if r["status"] == "failed"),
        "deepeval_available": use_de,
        "custom_score_avg": round(sum(custom_vals) / len(custom_vals), 2) if custom_vals else 0.0,
        "total_tasks": total_tasks,
        "total_iterations": int(state.get("total_iterations", 0)),
        "total_time_sec": total_time,
        "time_per_task_sec": round(total_time / total_tasks, 2) if total_tasks else 0.0,
        "agentic_deepeval_avg": agentic_avg,
    }
    for name, spec in AGENTIC_METRIC_SPECS.items():
        overall[spec["key"]] = agentic[name]["score"]

    file_vals = [
        m["score"] for f in report.values() if f.get("deepeval")
        for m in f["deepeval"].values() if m and m.get("score") is not None
    ]
    combined = file_vals + agentic_vals
    if combined:
        overall["deepeval_avg_score"] = round(sum(combined) / len(combined), 2)

    return {
        "overall": overall,
        "agentic_metrics": agentic,
        "files": report,
        "tasks": results,
        "tool_trace": trace,
    }
