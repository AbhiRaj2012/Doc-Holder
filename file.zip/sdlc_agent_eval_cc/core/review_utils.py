import re
import hashlib
import subprocess
from pathlib import Path
from core.safety import truncate

def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", s or "").strip()

def read_targets(root: str, files: list) -> dict:
    base = Path(root).resolve()
    out = {}
    for f in files:
        p = base / f
        if p.is_file():
            out[f] = p.read_text(encoding="utf-8", errors="replace")
    return out

def files_view(files_text: dict, limit: int) -> str:
    if not files_text:
        return "(no target file content)"
    per = max(limit // len(files_text), 2000)
    return "\n\n".join(f"=== {f} ===\n{truncate(t, per)}" for f, t in files_text.items())

def syntax_errors(files_text: dict) -> list:
    errs = []
    for f, t in files_text.items():
        if f.endswith(".py"):
            try:
                compile(t, f, "exec")
            except (SyntaxError, ValueError) as e:
                errs.append(f"{f}:{getattr(e, 'lineno', '?')}: {getattr(e, 'msg', e)}")
    return errs

def _env_missing(output: str, root: str) -> bool:
    mods = set(re.findall(r"No module named '([\w\.]+)'", output))
    if not mods:
        return False
    r = Path(root).resolve()
    for m in mods:
        top = m.split(".")[0]
        if any((r / p).exists() for p in (top, f"{top}.py", f"src/{top}", f"src/{top}.py")):
            return False
    return True

def run_verification(root: str, cmd: str, parse, timeout: int, max_out: int) -> dict:
    if not cmd:
        return {"status": "none", "label": "no command", "output": "No verification command specified."}
    parts = parse(cmd)
    if parts is None:
        return {"status": "inconclusive", "label": "rejected", "output": f"Command rejected by allowlist: {cmd}"}
    try:
        proc = subprocess.run(
            parts, cwd=root, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout
        )
    except subprocess.TimeoutExpired:
        return {"status": "fail", "label": "timeout", "output": f"Verification command timed out after {timeout}s."}
    except FileNotFoundError as e:
        return {"status": "inconclusive", "label": "not found", "output": f"Verification command not found: {e}"}
    rc = proc.returncode
    out = truncate(f"Exit Code: {rc}\nSTDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}", max_out)
    if rc == 0:
        return {"status": "pass", "label": "exit 0", "output": out}
    is_pytest = Path(parts[0]).name == "pytest" or "pytest" in parts[:3]
    if is_pytest and rc in (4, 5):
        return {"status": "inconclusive", "label": f"pytest exit {rc}", "output": out}
    if _env_missing(proc.stdout + proc.stderr, root):
        return {"status": "inconclusive", "label": "missing third-party module", "output": out}
    return {"status": "fail", "label": f"exit {rc}", "output": out}

def validate_issues(issues: list, files_text: dict) -> tuple:
    allt = _norm(" ".join(files_text.values()))
    valid, dropped = [], 0
    for i in issues:
        ev = _norm(i.evidence)
        if not ev:
            dropped += 1
            continue
        hay = _norm(files_text.get(i.file, "")) or allt
        ok = (ev in hay) if i.kind == "defect" else (ev not in allt)
        if ok:
            valid.append(i)
        else:
            dropped += 1
    return valid, dropped

def issue_signature(issues: list, verification: dict, syntax: list) -> str:
    keys = sorted(f"{i.file}:{_norm(i.evidence)[:80]}" for i in issues)
    keys += sorted(syntax)
    if verification["status"] == "fail":
        keys.append("V:" + _norm(verification["output"])[-200:])
    return hashlib.sha1("|".join(keys).encode("utf-8")).hexdigest() if keys else ""

def format_feedback(issues: list, verification: dict, syntax: list, max_out: int) -> str:
    lines = ["Files already contain your previous edits. Fix ONLY the blocking items below; do not rewrite or redo working code."]
    n = 0
    for s in syntax:
        n += 1
        lines.append(f"{n}. Syntax error: {s}")
    if verification["status"] == "fail":
        n += 1
        lines.append(f"{n}. Verification failed ({verification['label']}). Output tail:\n{verification['output'][-min(max_out, 2000):]}")
    for i in issues:
        n += 1
        lines.append(f"{n}. [{i.file}] {i.problem} Fix: {i.fix} (evidence: `{i.evidence.strip()[:160]}`)")
    return "\n".join(lines)
