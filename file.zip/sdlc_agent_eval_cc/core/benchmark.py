import json
from html import escape
from pathlib import Path
from datetime import datetime
from typing import Optional
from core.evaluation import AGENTIC_METRIC_SPECS, classify_metric_score, eval_cfg

SERIES = [
    ("deepeval_avg_score", "DeepEval Avg", "#2563eb"),
    ("custom_score_avg", "Custom Avg", "#16a34a"),
    ("plan_quality", "Plan Quality", "#9333ea"),
    ("plan_adherence", "Plan Adherence", "#db2777"),
    ("tool_correctness", "Tool Correctness", "#ea580c"),
    ("argument_correctness", "Arg Correctness", "#0891b2"),
    ("step_efficiency", "Step Efficiency", "#4f46e5"),
    ("task_completion", "Task Completion", "#059669"),
]


def load_history(path: Path) -> list:
    if not path.exists():
        return []
    out = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return out


def append_record(path: Path, record: dict) -> list:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")
    return load_history(path)


def render_markdown(overall: dict, agentic: dict, report: dict) -> str:
    lines = ["# Evaluation Report", "", f"**Custom score avg:** {overall['custom_score_avg']} / 1.0"]
    if overall.get("deepeval_avg_score") is not None:
        lines.append(f"**DeepEval score avg:** {overall['deepeval_avg_score']} / 1.0")
    if overall.get("agentic_deepeval_avg") is not None:
        lines.append(f"**Agentic DeepEval avg:** {overall['agentic_deepeval_avg']} / 1.0")
    lines += [
        f"**Tasks passed:** {overall['tasks_passed']} (skipped {overall['tasks_skipped']}, failed {overall['tasks_failed']})",
        f"**Total iterations:** {overall['total_iterations']}",
        f"**Total time taken:** {overall['total_time_sec']} s",
        f"**Total tasks:** {overall['total_tasks']}",
        f"**Time per task:** {overall['time_per_task_sec']} s/task",
        "",
        "## Agentic Workflow Evaluation Matrix (DeepEval)",
        "",
        "| Metric | Score | Threshold | Bad Range | Good Range | Status | Band | Reason |",
        "| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :--- |",
    ]
    for name, d in agentic.items():
        sc = d["score"] if d["score"] is not None else "n/a"
        reason = str(d.get("reason", "")).replace("\n", " ").replace("|", "/")[:160]
        lines.append(
            f"| **{name}** | {sc} | {d['threshold']:.2f} | {d['bad_range']} | {d['good_range']} | "
            f"{'PASS' if d['passed'] else 'FAIL'} | {d['band']} | {reason} |"
        )
    lines.append("")
    for fn, d in report.items():
        lines.append(f"## {fn}")
        lines.append(f"- Tasks: {d['tasks']} | Attempts: {d['attempts']} | Custom score: {d['custom_score']}")
        for name, res in (d.get("deepeval") or {}).items():
            s = res["score"] if res["score"] is not None else "n/a"
            lines.append(f"  - **{name}**: {s} — {res['reason']}")
        lines.append("")
    return "\n".join(lines)


def render_svg(records: list) -> str:
    W, H, PAD = 920, 300, 48
    n = len(records)
    if n == 0:
        return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="120">'
                f'<text x="20" y="60" font-family="sans-serif" font-size="13">No runs tracked yet.</text></svg>')

    def xf(i):
        return PAD + (i / max(n - 1, 1)) * (W - 2 * PAD)

    def yf(s):
        return H - PAD - s * (H - 2 * PAD)

    lines, legend = [], []
    for idx, (key, label, color) in enumerate(SERIES):
        pts = [(i, r.get(key)) for i, r in enumerate(records) if r.get(key) is not None]
        avg = ""
        if pts:
            poly = " ".join(f"{xf(i):.1f},{yf(s):.1f}" for i, s in pts)
            dots = "".join(
                f'<circle cx="{xf(i):.1f}" cy="{yf(s):.1f}" r="3" fill="{color}"><title>Run {i + 1} {label}: {s:.2f}</title></circle>'
                for i, s in pts
            )
            lines.append(f'<polyline points="{poly}" fill="none" stroke="{color}" stroke-width="2"/>{dots}')
            avg = f" ({sum(s for _, s in pts) / len(pts):.2f})"
        lx, ly = PAD + (idx % 4) * 210, 14 + (idx // 4) * 16
        legend.append(
            f'<circle cx="{lx}" cy="{ly}" r="4" fill="{color}"/>'
            f'<text x="{lx + 8}" y="{ly + 4}" font-size="10.5" fill="#374151">{label}{avg}</text>'
        )
    grid = "".join(
        f'<line x1="{PAD}" y1="{yf(g):.1f}" x2="{W - PAD}" y2="{yf(g):.1f}" stroke="#e5e7eb" stroke-width="1"/>'
        f'<text x="6" y="{yf(g) + 4:.1f}" font-size="10" fill="#6b7280">{g:.2f}</text>'
        for g in (0.0, 0.25, 0.5, 0.70, 0.85, 1.0)
    )
    ty = yf(0.70)
    thr = (
        f'<line x1="{PAD}" y1="{ty:.1f}" x2="{W - PAD}" y2="{ty:.1f}" stroke="#dc2626" stroke-width="1.2" stroke-dasharray="4,4"/>'
        f'<text x="{W - PAD - 85}" y="{ty - 4:.1f}" font-size="10" fill="#dc2626">Threshold 0.70</text>'
    )
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" font-family="sans-serif">'
        f'<rect width="{W}" height="{H}" fill="white"/>{grid}{thr}{"".join(lines)}{"".join(legend)}'
        f'<text x="{PAD}" y="{H - 10}" font-size="11" fill="#374151">Run 1</text>'
        f'<text x="{W - PAD - 40}" y="{H - 10}" font-size="11" fill="#374151">Run {n}</text></svg>'
    )


def _cell(name: str, val: Optional[float]) -> str:
    if val is None:
        return "<td>n/a</td>"
    info = classify_metric_score(name, val)
    if info["band"] == "Good":
        bg, fg = "#dcfce7", "#166534"
    elif info["passed"]:
        bg, fg = "#fef9c3", "#854d0e"
    else:
        bg, fg = "#fee2e2", "#991b1b"
    return (
        f'<td style="background:{bg};color:{fg};font-weight:600;" '
        f'title="{name}: {info["band"]} (Threshold {info["threshold"]:.2f}, Good {info["good_range"]}, Bad {info["bad_range"]})">'
        f'{val:.2f} <span style="font-size:10px;font-weight:400;">({info["band"]})</span></td>'
    )


def render_html(records: list) -> str:
    def avg(key):
        v = [r[key] for r in records if r.get(key) is not None]
        return round(sum(v) / len(v), 2) if v else "n/a"

    spec_rows = "".join(
        f"<tr><td><b>{n}</b></td><td style='color:#991b1b;background:#fef2f2;'>{s['bad_label']}</td>"
        f"<td style='color:#166534;background:#f0fdf4;'>{s['good_label']}</td>"
        f"<td><b>{s['threshold']:.2f}</b></td><td><b>{avg(s['key'])}</b></td></tr>"
        for n, s in AGENTIC_METRIC_SPECS.items()
    )

    rows = []
    for i, r in enumerate(records):
        c = r.get("llm_config", {})
        cells = "".join(_cell(n, r.get(s["key"])) for n, s in AGENTIC_METRIC_SPECS.items())
        rows.append(
            f"<tr><td>{i + 1}</td><td>{escape(str(r.get('timestamp', '')))}</td>"
            f"<td>{escape(str(c.get('model', '')))}</td><td>{c.get('num_ctx', '')}</td>"
            f"<td>{escape(str(r.get('request', ''))[:55])}</td>"
            f"<td>{r.get('tasks_passed', '')}</td><td>{r.get('total_tasks', 'n/a')}</td>"
            f"<td>{r.get('total_iterations', 'n/a')}</td>"
            f"<td>{r.get('total_time_sec', 'n/a')}</td><td>{r.get('time_per_task_sec', 'n/a')}</td>"
            f"<td>{r.get('custom_score_avg', 'n/a')}</td><td>{r.get('deepeval_avg_score', 'n/a')}</td>{cells}</tr>"
        )

    latest = ""
    if records:
        last = records[-1]
        lr = "".join(
            f"<tr><td><b>{n}</b></td><td>{'PASS' if d.get('passed') else 'FAIL'}</td><td>{d.get('band')}</td>"
            f"<td>{d.get('score')}</td><td>{escape(str(d.get('reason', ''))[:400])}</td></tr>"
            for n, d in (last.get("agentic_metrics") or {}).items()
        )
        latest = (
            f"<h3>Latest Run — Metric Reasons (Run {len(records)})</h3>"
            f"<table><tr><th>Metric</th><th>Status</th><th>Band</th><th>Score</th><th>Reason</th></tr>{lr}</table>"
        )

    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>SDLC Pipeline — Benchmark History</title>
<style>
body {{ font-family: system-ui, sans-serif; margin: 2rem; color: #111827; max-width: 1500px; }}
table {{ border-collapse: collapse; margin-top: 1rem; width: 100%; }}
th, td {{ border: 1px solid #e5e7eb; padding: 6px 8px; text-align: left; font-size: 12.5px; }}
th {{ background: #f9fafb; }}
.matrix-table {{ width: auto; min-width: 640px; margin-bottom: 1.5rem; }}
.summary-bar {{ background: #f8fafc; border: 1px solid #e2e8f0; padding: 10px 14px; border-radius: 6px; font-size: 13px; line-height: 1.6; }}
</style></head>
<body>
<h1>Benchmark History &amp; DeepEval Agentic Matrix</h1>
<div class="summary-bar">
<b>{len(records)}</b> run(s) tracked —
All-time avg custom score: <b>{avg('custom_score_avg')}</b> &nbsp;|&nbsp;
All-time avg DeepEval score: <b>{avg('deepeval_avg_score')}</b> &nbsp;|&nbsp;
All-time avg time/task: <b>{avg('time_per_task_sec')} s</b>
</div>
<h3>DeepEval Agentic Evaluation Reference Matrix</h3>
<table class="matrix-table">
<tr><th>Metric</th><th>Bad Range</th><th>Good Range</th><th>Threshold</th><th>All-Time Avg</th></tr>
{spec_rows}
</table>
{render_svg(records)}
{latest}
<h3>All Runs</h3>
<table>
<tr><th>#</th><th>Timestamp</th><th>Model</th><th>num_ctx</th><th>Request</th>
<th>Tasks passed</th><th>Total tasks</th><th>Iterations</th><th>Total time (s)</th><th>Time/task (s)</th>
<th>Custom avg</th><th>DeepEval avg</th>
<th>Plan Quality</th><th>Plan Adherence</th><th>Tool Correctness</th>
<th>Argument Correctness</th><th>Step Efficiency</th><th>Task Completion</th></tr>
{"".join(rows)}
</table>
</body></html>"""


def persist(cfg: dict, state: dict, payload: dict) -> tuple:
    ev = eval_cfg(cfg)
    overall, agentic, report = payload["overall"], payload["agentic_metrics"], payload["files"]
    run_id = state.get("run_id") or datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = Path(ev["output_dir"]).resolve() / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    record = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "run_id": run_id,
        "run_dir": str(run_dir),
        "request": str(state.get("user_input", ""))[:200],
        "llm_config": {
            "model": cfg["ollama"]["model"],
            "num_ctx": cfg["ollama"]["num_ctx"],
            "temperature": cfg["ollama"]["temperature"],
            "reasoning_effort": cfg["ollama"].get("reasoning_effort"),
        },
        "tasks_passed": overall["tasks_passed"],
        "tasks_skipped": overall["tasks_skipped"],
        "tasks_failed": overall["tasks_failed"],
        "total_tasks": overall["total_tasks"],
        "total_iterations": overall["total_iterations"],
        "total_time_sec": overall["total_time_sec"],
        "time_per_task_sec": overall["time_per_task_sec"],
        "custom_score_avg": overall["custom_score_avg"],
        "deepeval_available": overall["deepeval_available"],
        "deepeval_avg_score": overall.get("deepeval_avg_score"),
        "agentic_deepeval_avg": overall["agentic_deepeval_avg"],
        **{s["key"]: overall.get(s["key"]) for s in AGENTIC_METRIC_SPECS.values()},
        "agentic_metrics": agentic,
        "per_file": {fn: {"tasks": d["tasks"], "attempts": d["attempts"], "deepeval": d.get("deepeval")} for fn, d in report.items()},
    }

    history = append_record(Path(ev["history_path"]).resolve(), record)
    html_report = render_html(history)
    hp = Path(ev["history_html_path"]).resolve()
    hp.parent.mkdir(parents=True, exist_ok=True)
    hp.write_text(html_report, encoding="utf-8")
    (run_dir / "evaluation.html").write_text(html_report, encoding="utf-8")
    (run_dir / "evaluation.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    (run_dir / "evaluation.md").write_text(render_markdown(overall, agentic, report), encoding="utf-8")
    return record, str(run_dir)
