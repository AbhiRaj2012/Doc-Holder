from typing import TypedDict, List, Optional, Literal
from pydantic import BaseModel, Field

class TaskItem(BaseModel):
    task_id: str = Field(description="Unique ID, e.g., TASK-1")
    title: str = Field(description="Short title of the atomic task")
    target_files: List[str] = Field(description="Relative file paths to modify or create")
    instructions: str = Field(description="Detailed implementation instructions")
    verification_cmd: str = Field(description="Command to verify task, e.g., pytest tests/test_api.py")

class TaskPlan(BaseModel):
    tasks: List[TaskItem] = Field(description="Ordered list of tasks from first to last")

class ReviewIssue(BaseModel):
    file: str = Field(description="Relative path of the file containing the problem")
    kind: Literal["defect", "missing"] = Field(description="defect: wrong code present. missing: required code absent")
    evidence: str = Field(description="defect: one exact line copied verbatim from the file (no line numbers). missing: the exact identifier or phrase that should exist but does not")
    problem: str = Field(description="One sentence: why this blocks the task")
    fix: str = Field(description="One sentence: the concrete change needed")

class ReviewResult(BaseModel):
    summary: str = Field(description="One sentence verdict")
    issues: List[ReviewIssue] = Field(default_factory=list, description="BLOCKING issues only. Empty list if the task requirements are met")

class AgentState(TypedDict):
    project_path: str
    manifest_path: str
    issue_json_path: str
    user_input: str
    project_requirements: str
    force_reanalyze: bool

    manifest_data: dict

    task_stack: List[dict]
    current_task: Optional[dict]

    iteration_count: int
    max_iterations: int
    last_editor_diff: str
    reviewer_feedback: str
    task_completed: bool
    last_verification: str
    editor_changed: bool
    editor_note: str
    stalled: bool
    prev_issue_sig: str

    logs: List[str]

    human_decision: Optional[Literal["proceed", "work_on_it", "abort"]]

    run_id: str
    elapsed_sec: float
    task_attempts: int
    total_iterations: int
    planned_tasks: List[dict]
    task_results: List[dict]
    tool_trace: List[dict]
    eval_summary: dict
