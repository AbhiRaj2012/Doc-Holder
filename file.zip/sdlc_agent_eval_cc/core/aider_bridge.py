import os
import json
from pathlib import Path
from aider.io import InputOutput
from aider.models import Model, register_models
from aider.repomap import RepoMap
from aider.coders import Coder

IGNORE_DIRS = {".git", "__pycache__", "node_modules", ".venv", "venv", "dist", "build", ".pytest_cache"}
IGNORE_EXT = {".pyc", ".png", ".jpg", ".jpeg", ".gif", ".zip", ".bin", ".so", ".db", ".sqlite"}

class CaptureIO(InputOutput):
    def __init__(self, *args, **kwargs):
        self.captured = []
        super().__init__(*args, **kwargs)

    def tool_error(self, message="", *args, **kwargs):
        self.captured.append(str(message))
        return super().tool_error(message, *args, **kwargs)

    def tool_warning(self, message="", *args, **kwargs):
        self.captured.append(str(message))
        return super().tool_warning(message, *args, **kwargs)

def get_all_repo_files(project_root: Path) -> list[str]:
    files = []
    for root, dirs, filenames in os.walk(project_root):
        dirs[:] = [d for d in dirs if d not in IGNORE_DIRS]
        for fname in filenames:
            if fname.startswith(".aider") or Path(fname).suffix.lower() in IGNORE_EXT:
                continue
            files.append(str((Path(root) / fname).resolve()))
    return files

def _prepare_model(cfg: dict, edit_format: str | None = None) -> Model:
    os.environ["OLLAMA_API_BASE"] = cfg["ollama"]["base_url"]
    register_models([str(Path(cfg["workflow"]["aider_settings_path"]).resolve())])
    name = f"ollama_chat/{cfg['ollama']['model']}"
    return Model(
        name,
        weak_model=name,
        editor_model=name,
        editor_edit_format=edit_format or cfg["aider"].get("edit_format", "diff"),
    )

def build_aider_repomap_manifest(cfg: dict) -> dict:
    project_root = Path(cfg["workflow"]["project_path"]).resolve()
    manifest_path = Path(cfg["workflow"]["manifest_path"]).resolve()
    main_model = _prepare_model(cfg)
    io = InputOutput(yes=True, pretty=False)

    repo_map = RepoMap(
        map_tokens=int(cfg["aider"]["map_tokens"]),
        root=str(project_root),
        main_model=main_model,
        io=io,
    )

    all_files = get_all_repo_files(project_root)
    ranked = repo_map.get_repo_map(chat_files=[], other_files=all_files) or "Empty RepoMap"

    manifest = {
        "project_root": str(project_root),
        "file_list": [str(Path(f).relative_to(project_root)).replace("\\", "/") for f in all_files],
        "aider_repo_map": ranked,
    }

    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest

def run_aider_editor(
    cfg: dict,
    target_files: list[str],
    instructions: str,
    reviewer_feedback: str = "",
    edit_format: str | None = None,
) -> dict:
    project_root = Path(cfg["workflow"]["project_path"]).resolve()
    fmt = edit_format or cfg["aider"].get("edit_format", "diff")
    main_model = _prepare_model(cfg, fmt)

    state_dir = Path(cfg["workflow"]["manifest_path"]).resolve().parent
    state_dir.mkdir(parents=True, exist_ok=True)
    io = CaptureIO(
        yes=True,
        pretty=False,
        chat_history_file=str(state_dir / "aider.chat.history.md"),
        input_history_file=str(state_dir / "aider.input.history"),
    )

    prompt = (
        f"Reasoning: {cfg['ollama'].get('reasoning_effort', 'medium')}\n"
        f"Edit ONLY these files: {', '.join(target_files)}\n"
        "Apply the changes using the required edit format. Never put code outside edit blocks, never ask questions.\n"
        f"TASK INSTRUCTIONS:\n{instructions}\n"
    )
    if reviewer_feedback:
        prompt += f"\nREVIEWER FEEDBACK:\n{reviewer_feedback}\n"

    prev_cwd = os.getcwd()
    try:
        os.chdir(project_root)
        coder = Coder.create(
            main_model=main_model,
            edit_format=fmt,
            io=io,
            fnames=[str((project_root / f).resolve()) for f in target_files],
            auto_commits=cfg["aider"].get("auto_commits", False),
            dirty_commits=cfg["aider"].get("dirty_commits", False),
            map_tokens=int(cfg["aider"].get("map_tokens", 2048)),
            stream=False,
        )
        response = coder.run(with_message=prompt)
        edited = sorted(str(f) for f in getattr(coder, "aider_edited_files", set()) or set())
    finally:
        os.chdir(prev_cwd)

    return {"response": str(response or ""), "edited": edited, "errors": list(io.captured), "edit_format": fmt}
