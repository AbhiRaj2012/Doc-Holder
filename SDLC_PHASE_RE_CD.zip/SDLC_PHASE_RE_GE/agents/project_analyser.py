import os
import networkx as nx
import tree_sitter_c as tsc
import tree_sitter_cpp as tscpp
import tree_sitter_javascript as tsjs
import tree_sitter_java as tsjava
import tree_sitter_python as tspy
from tree_sitter import Language, Parser
from typing import Dict, Any

# LangChain Ollama import for local A-SDLC execution
from langchain_ollama import ChatOllama

LANGUAGES = {
    ".c": Language(tsc.language()),
    ".cpp": Language(tscpp.language()),
    ".h": Language(tscpp.language()),
    ".js": Language(tsjs.language()),
    ".java": Language(tsjava.language()),
    ".py": Language(tspy.language()),
}


def get_parser(ext: str) -> Parser:
    parser = Parser()
    if ext in LANGUAGES:
        parser.language = LANGUAGES[ext]
        return parser
    return None


def extract_ast_entities(node, source_bytes, parent_id, G, file_path):
    """
    Recursively walks the AST to extract classes and functions,
    linking them to their parent file or class node.
    """
    # Common Tree-Sitter node types for classes and functions
    target_types = {
        "class": {"class_definition", "class_specifier", "class_declaration"},
        "function": {"function_definition", "method_declaration", "function_declaration", "method_definition"}
    }

    def get_identifier(n):
        """Extracts the exact name of the class/function from source code."""
        for child in n.children:
            if child.type in {"identifier", "name"}:
                return source_bytes[child.start_byte:child.end_byte].decode('utf8')
        return "anonymous"

    for child in node.children:
        entity_type = None
        if child.type in target_types["class"]:
            entity_type = "class"
        elif child.type in target_types["function"]:
            entity_type = "function"

        if entity_type:
            entity_name = get_identifier(child)
            # Create a unique node ID (e.g., "path/to/file.py::ClassName")
            node_id = f"{parent_id}::{entity_name}"

            # 1. Add the extracted class/function to the Knowledge Graph
            G.add_node(
                node_id,
                type=entity_type,
                name=entity_name,
                file=file_path
            )
            # 2. Link it to its parent (File or parent Class) using a DEFINES edge
            G.add_edge(parent_id, node_id, relationship="DEFINES")

            # 3. Recurse inside to find nested methods/classes
            extract_ast_entities(child, source_bytes, node_id, G, file_path)
        else:
            # Continue searching down the tree if it's not a target node
            extract_ast_entities(child, source_bytes, parent_id, G, file_path)


def project_analyser(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    LangGraph node that parses a repository and builds an AST-based Knowledge Graph.
    """
    raw_path = state.get("project_address", "./")
    project_path = raw_path.strip('\"\'')

    graph_output_path = state.get("graph_output_path", "hskg_graph.graphml")

    # Initialize the structural graph
    G = nx.DiGraph()

    if not os.path.exists(project_path):
        print(f"\n[ERROR] Directory not found: {project_path}")
        return {
            "graph_output_path": graph_output_path,
            "parsed_nodes_count": 0,
            "analyzer_status": "Failed: Path Not Found"
        }

    # Traverse the repository and parse files
    for root, _, files in os.walk(project_path):
        for file in files:
            ext = os.path.splitext(file)[1].lower()
            if ext in LANGUAGES:
                file_path = os.path.join(root, file)

                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        source_code = f.read()
                        source_bytes = bytes(source_code, "utf8")

                    parser = get_parser(ext)
                    tree = parser.parse(source_bytes)

                    # 1. Add the root File node
                    G.add_node(
                        file_path,
                        type="file",
                        language=ext.replace(".", ""),
                        ast_root_type=tree.root_node.type
                    )

                    # 2. Trigger the deep AST traversal for this file
                    extract_ast_entities(
                        node=tree.root_node,
                        source_bytes=source_bytes,
                        parent_id=file_path,
                        G=G,
                        file_path=file_path
                    )

                except Exception as e:
                    print(f"Error parsing {file_path}: {e}")

    # Ensure output directory exists before saving
    output_dir = os.path.dirname(graph_output_path)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    # Save the graph for future nodes (Editor/Reviewer)
    nx.write_graphml(G, graph_output_path)
    print(f"[Project Analyser] Graph saved to {graph_output_path} with {G.number_of_nodes()} total entities mapped.")

    # Initialize local Ollama instance for downstream synthesis
    llm = ChatOllama(
        base_url="http://localhost:11343",
        model="gemma4:e2b",
        temperature=0.1
    )

    # Update the LangGraph state
    return {
        "graph_output_path": graph_output_path,
        "parsed_nodes_count": G.number_of_nodes(),
        "analyzer_status": "Complete"
    }