import os
from typing import TypedDict
from langgraph.graph import StateGraph, END

# Import your node (Note: Rename your file to remove the space for a clean import)
from agents.project_analyser import project_analyser


# 1. Define the LangGraph State
class AgentState(TypedDict, total=False):
    project_path: str
    graph_output_path: str
    graph_path: str
    parsed_nodes_count: int
    parsed_files_count: int
    graph_edges_count: int
    language_stats: dict
    analyzer_status: str


# 2. Build the Graph
workflow = StateGraph(AgentState)

# Add nodes
workflow.add_node("analyzer", project_analyser)
# Future nodes go here:
# workflow.add_node("scoper", scoper_node)
# workflow.add_node("architect", architect_node)

# Define edges
workflow.set_entry_point("analyzer")
workflow.add_edge("analyzer", END)
# Future edges: workflow.add_edge("analyzer", "scoper"), etc.

# Compile
app = workflow.compile()

if __name__ == "__main__":
    # 3. Simple Terminal Input
    target_repo = input("Enter the absolute project path to analyze: ").strip()

    # 4. Set Output to 'core' directory
    core_dir = os.path.join(os.getcwd(), "core_files")
    os.makedirs(core_dir, exist_ok=True)  # Creates 'core' if it doesn't exist
    graph_path = os.path.join(core_dir, "hskg_graph.graphml")

    # 5. Trigger the Graph
    initial_state = {
        "project_path": target_repo,
        "graph_output_path": graph_path
    }

    print(f"\nStarting pipeline for: {target_repo}")
    final_state = app.invoke(initial_state)

    print("\n[Pipeline Complete]")
    print(f"Total Nodes Parsed: {final_state.get('parsed_nodes_count')}")
    print(f"Graph Saved To: {final_state.get('graph_output_path')}")