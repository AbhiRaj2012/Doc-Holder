import os
import posixpath
from collections import Counter, defaultdict
from typing import Any, Dict, List, Optional, Tuple

import networkx as nx
import tree_sitter_c as tsc
import tree_sitter_cpp as tscpp
import tree_sitter_java as tsjava
import tree_sitter_javascript as tsjs
import tree_sitter_python as tspy
from tree_sitter import Language, Parser

# ---------------------------------------------------------------- languages
PARSERS = {
    "c": Parser(Language(tsc.language())),
    "cpp": Parser(Language(tscpp.language())),
    "javascript": Parser(Language(tsjs.language())),
    "java": Parser(Language(tsjava.language())),
    "python": Parser(Language(tspy.language())),
}
EXT_LANG = {
    ".c": "c",
    ".cpp": "cpp", ".cc": "cpp", ".cxx": "cpp", ".hpp": "cpp", ".hh": "cpp",
    ".js": "javascript", ".jsx": "javascript", ".mjs": "javascript", ".cjs": "javascript",
    ".java": "java",
    ".py": "python",
}
CPP_ONLY = {".cpp", ".cc", ".cxx", ".hpp", ".hh"}
SKIP_DIRS = {
    "node_modules", "venv", ".venv", "env", "__pycache__", "build", "dist",
    "target", "out", "site-packages", "bin", "obj",
}
MAX_BYTES = 1_000_000

DEF_TYPES = {
    "python": {"function_definition": "Function", "class_definition": "Class"},
    "javascript": {
        "function_declaration": "Function", "generator_function_declaration": "Function",
        "class_declaration": "Class", "method_definition": "Method",
    },
    "java": {
        "class_declaration": "Class", "record_declaration": "Class",
        "interface_declaration": "Interface", "enum_declaration": "Enum",
        "method_declaration": "Method", "constructor_declaration": "Method",
    },
    "c": {
        "function_definition": "Function", "struct_specifier": "Class",
        "union_specifier": "Class", "enum_specifier": "Enum",
    },
    "cpp": {
        "function_definition": "Function", "class_specifier": "Class",
        "struct_specifier": "Class", "union_specifier": "Class", "enum_specifier": "Enum",
    },
}
BODY_REQUIRED = {"struct_specifier", "union_specifier", "enum_specifier", "class_specifier"}
CALL_FIELD = {
    "python": {"call": "function"},
    "javascript": {"call_expression": "function"},
    "java": {"method_invocation": "name"},
    "c": {"call_expression": "function"},
    "cpp": {"call_expression": "function"},
}
IMPORT_TYPES = {
    "python": {"import_statement", "import_from_statement"},
    "javascript": {"import_statement"},
    "java": {"import_declaration"},
    "c": {"preproc_include"},
    "cpp": {"preproc_include"},
}
CLASS_KINDS = {"Class", "Interface", "Enum"}
IDENT = {"identifier", "field_identifier", "property_identifier", "type_identifier", "namespace_identifier"}
C_LEAF = {"identifier", "field_identifier", "qualified_identifier", "destructor_name", "operator_name"}
JS_FUNC_VALUES = {"arrow_function", "function_expression", "function", "generator_function"}


# ------------------------------------------------------------------ helpers
def _txt(n) -> str:
    return n.text.decode("utf8", "replace")


def _callee(n) -> Optional[str]:
    if n is None:
        return None
    if n.type in IDENT:
        return _txt(n)
    for f in ("attribute", "property", "field", "name"):
        c = n.child_by_field_name(f)
        if c is not None:
            return _callee(c)
    return None


def _type_names(n) -> List[str]:
    out, st = [], [n]
    while st:
        x = st.pop()
        if x.type == "type_arguments":
            continue
        if x.type == "type_identifier":
            out.append(_txt(x))
            continue
        st.extend(reversed(x.named_children))
    return out


def _c_def(node) -> Optional[Tuple[str, str, Optional[str]]]:
    d = node.child_by_field_name("declarator")
    while d is not None and d.type not in C_LEAF:
        nxt = d.child_by_field_name("declarator")
        if nxt is None and d.named_children:
            nxt = d.named_children[0]
        d = nxt
    if d is None:
        return None
    name, owner = _txt(d), None
    if "::" in name:
        owner, name = name.rsplit("::", 1)
        owner = owner.split("::")[-1]
    return "Function", name, owner


def _definition(lang: str, node) -> Optional[Tuple[str, str, Optional[str]]]:
    t = node.type
    if lang == "javascript" and t == "variable_declarator":
        v, n = node.child_by_field_name("value"), node.child_by_field_name("name")
        if v is not None and n is not None and n.type == "identifier" and v.type in JS_FUNC_VALUES:
            return "Function", _txt(n), None
        return None
    kind = DEF_TYPES[lang].get(t)
    if kind is None:
        return None
    if t in BODY_REQUIRED and node.child_by_field_name("body") is None:
        return None
    if t == "function_definition" and lang in ("c", "cpp"):
        return _c_def(node)
    n = node.child_by_field_name("name")
    return (kind, _txt(n), None) if n is not None else None


def _signature(node) -> str:
    body = node.child_by_field_name("body")
    end = body.start_byte if body is not None else node.end_byte
    raw = node.text[: max(end - node.start_byte, 0)].decode("utf8", "replace")
    return " ".join(raw.split())[:200]


def _bases(lang: str, node) -> List[Tuple[str, str]]:
    out: List[Tuple[str, str]] = []
    if lang == "python":
        a = node.child_by_field_name("superclasses")
        for c in (a.named_children if a is not None else []):
            if c.type == "keyword_argument":
                continue
            n = _callee(c)
            if n:
                out.append((n, "INHERITS"))
    elif lang == "javascript":
        for c in node.named_children:
            if c.type == "class_heritage":
                for e in c.named_children:
                    n = _callee(e)
                    if n:
                        out.append((n, "INHERITS"))
    elif lang == "java":
        kinds = {"superclass": "INHERITS", "super_interfaces": "IMPLEMENTS", "extends_interfaces": "INHERITS"}
        for c in node.named_children:
            if c.type in kinds:
                out += [(n, kinds[c.type]) for n in _type_names(c)]
    elif lang == "cpp":
        for c in node.named_children:
            if c.type == "base_class_clause":
                for e in c.named_children:
                    n = _callee(e)
                    if n:
                        out.append((n, "INHERITS"))
    return out


def _import_specs(lang: str, node) -> List[str]:
    if lang == "python":
        if node.type == "import_from_statement":
            m = node.child_by_field_name("module_name")
            spec = _txt(m) if m is not None else ""
            if spec.strip("."):
                return [spec]
            return [_txt(n.child_by_field_name("name") if n.type == "aliased_import" else n)
                    for n in node.children_by_field_name("name")]
        out = []
        for c in node.named_children:
            n = c.child_by_field_name("name") if c.type == "aliased_import" else c
            if n is not None:
                out.append(_txt(n))
        return out
    if lang == "javascript":
        s = node.child_by_field_name("source")
        return [_txt(s).strip("'\"`")] if s is not None else []
    if lang == "java":
        for c in node.named_children:
            if c.type in ("scoped_identifier", "identifier"):
                return [_txt(c)]
        return []
    p = node.child_by_field_name("path")
    return [_txt(p).strip('<>"')] if p is not None else []


# --------------------------------------------------------------- extraction
def _extract(G: nx.DiGraph, rel: str, lang: str, data: bytes, pend: Dict[str, list]) -> None:
    tree = PARSERS[lang].parse(data)
    calls, imports = CALL_FIELD[lang], IMPORT_TYPES[lang]
    scope: List[Tuple[str, str, str]] = []  # (node_id, kind, qualified_name)
    stack: List[Tuple[str, Any]] = [("v", tree.root_node)]

    while stack:
        tag, node = stack.pop()
        if tag == "p":
            scope.pop()
            continue
        t = node.type
        caller = scope[-1][0] if scope else rel

        if t in imports:
            for s in _import_specs(lang, node):
                if s:
                    pend["imports"].append((rel, s))
        elif t in calls:
            fn = node.child_by_field_name(calls[t])
            name = fn.text.decode("utf8", "replace") if fn is not None and lang == "java" else _callee(fn)
            if lang == "javascript" and name == "require":
                args = node.child_by_field_name("arguments")
                if args is not None and args.named_children and args.named_children[0].type == "string":
                    pend["imports"].append((rel, _txt(args.named_children[0]).strip("'\"`")))
            elif name:
                pend["calls"].append((caller, name, rel))

        d = _definition(lang, node)
        if d:
            kind, name, owner = d
            parent = scope[-1] if scope else None
            in_class = parent is not None and parent[1] in CLASS_KINDS
            if kind == "Function" and (in_class or owner):
                kind = "Method"
            qn = (parent[2] + "." if parent else "") + (owner + "." if owner else "") + name
            nid = f"{rel}::{qn}"
            if nid in G:
                nid = f"{nid}@{node.start_point[0] + 1}"
            G.add_node(
                nid, type=kind, name=name, qualified_name=qn, file=rel, language=lang,
                start_line=node.start_point[0] + 1, end_line=node.end_point[0] + 1,
                signature=_signature(node),
            )
            if parent is None or owner:
                G.add_edge(rel, nid, type="DEFINES")
            elif in_class and kind == "Method":
                G.add_edge(parent[0], nid, type="DEFINES_METHOD")
            else:
                G.add_edge(parent[0], nid, type="DEFINES")
            if owner:
                pend["owners"].append((nid, owner, rel))
            if kind in CLASS_KINDS:
                for bname, etype in _bases(lang, node):
                    pend["bases"].append((nid, bname, etype, rel))
            scope.append((nid, kind, qn))
            stack.append(("p", None))

        stack.extend(("v", c) for c in reversed(node.named_children))


# --------------------------------------------------------------- resolution
def _resolve_import(lang: str, spec: str, src: str, files: set, sfx: Dict[str, List[str]]) -> Optional[str]:
    d = posixpath.dirname(src)
    if lang == "javascript":
        if not spec.startswith("."):
            return None
        base = posixpath.normpath(posixpath.join(d, spec))
        for ext in ("", ".js", ".jsx", ".mjs", ".cjs", "/index.js", "/index.jsx"):
            if base + ext in files:
                return base + ext
        return None
    if lang == "python":
        s = spec.lstrip(".").replace(".", "/")
        cands = [s + ".py", s + "/__init__.py"] if s else []
    elif lang == "java":
        cands = [spec.replace(".", "/") + ".java"]
    else:
        local = posixpath.normpath(posixpath.join(d, spec))
        if local in files:
            return local
        cands = [spec]
    for c in cands:
        hits = sfx.get(c)
        if hits:
            return max(hits, key=lambda p: len(os.path.commonprefix([p, src])))
    return None


def _pick(name: str, rel: str, table: Dict[str, List[str]], G: nx.DiGraph,
          imported: Dict[str, set]) -> Optional[Tuple[str, float]]:
    c = table.get(name)
    if not c:
        return None
    same = [i for i in c if G.nodes[i]["file"] == rel]
    if same:
        return same[0], 0.95
    imp = [i for i in c if G.nodes[i]["file"] in imported[rel]]
    if imp:
        return imp[0], 0.90
    if len(c) == 1:
        return c[0], 0.75
    return max(c, key=lambda i: len(os.path.commonprefix([G.nodes[i]["file"], rel]))), 0.50


def _link(G: nx.DiGraph, a: str, b: str, etype: str, conf: float) -> None:
    if a == b:
        return
    if G.has_edge(a, b) and G[a][b].get("type") == etype:
        G[a][b]["confidence"] = max(G[a][b].get("confidence", 0.0), conf)
    elif not G.has_edge(a, b):
        G.add_edge(a, b, type=etype, confidence=conf)


# --------------------------------------------------------------------- node
def project_analyser(state: Dict[str, Any]) -> Dict[str, Any]:
    root = os.path.abspath(state.get("project_path", "./"))
    out_path = state.get("graph_output_path", "hskg_graph.graphml")

    found: List[Tuple[str, str]] = []
    for cur, dirs, fnames in os.walk(root):
        dirs[:] = [d for d in dirs if not d.startswith(".") and d not in SKIP_DIRS]
        for f in fnames:
            ext = os.path.splitext(f)[1].lower()
            if ext in EXT_LANG or ext == ".h":
                rel = os.path.relpath(os.path.join(cur, f), root).replace(os.sep, "/")
                found.append((rel, ext))

    header_lang = "cpp" if any(e in CPP_ONLY for _, e in found) else "c"
    G = nx.DiGraph()
    pid = "project:" + (os.path.basename(root) or root)
    G.add_node(pid, type="Project", name=os.path.basename(root), path=root)

    pend: Dict[str, list] = {"imports": [], "calls": [], "bases": [], "owners": []}
    files, sfx = set(), defaultdict(list)
    lang_count: Counter = Counter()

    for rel, ext in found:
        lang = header_lang if ext == ".h" else EXT_LANG[ext]
        abs_path = os.path.join(root, *rel.split("/"))
        try:
            if os.path.getsize(abs_path) > MAX_BYTES:
                continue
            with open(abs_path, "rb") as fh:
                data = fh.read()

            parent, cur = pid, ""
            for part in rel.split("/")[:-1]:
                cur = f"{cur}/{part}" if cur else part
                did = "dir:" + cur
                if did not in G:
                    G.add_node(did, type="Folder", name=part, path=cur)
                    G.add_edge(parent, did, type="CONTAINS")
                parent = did

            G.add_node(
                rel, type="File", name=posixpath.basename(rel), path=rel, language=lang,
                extension=ext, loc=data.count(b"\n") + 1, size=len(data),
            )
            G.add_edge(parent, rel, type="CONTAINS")
            files.add(rel)
            lang_count[lang] += 1
            parts = rel.split("/")
            for i in range(len(parts)):
                sfx["/".join(parts[i:])].append(rel)

            _extract(G, rel, lang, data, pend)
        except Exception as e:
            print(f"[Project Analyser] Error parsing {rel}: {e}")

    # imports
    imported: Dict[str, set] = defaultdict(set)
    for src, spec in pend["imports"]:
        tgt = _resolve_import(G.nodes[src]["language"], spec, src, files, sfx)
        if tgt and tgt != src:
            G.add_edge(src, tgt, type="IMPORTS", resolved=True)
            imported[src].add(tgt)
        else:
            mid = "module:" + spec
            if mid not in G:
                G.add_node(mid, type="Module", name=spec, external=True)
            G.add_edge(src, mid, type="IMPORTS", resolved=False)

    # symbol tables
    by_name: Dict[str, List[str]] = defaultdict(list)
    by_class: Dict[str, List[str]] = defaultdict(list)
    for nid, a in G.nodes(data=True):
        if a.get("type") in {"Function", "Method"} | CLASS_KINDS:
            by_name[a["name"]].append(nid)
        if a.get("type") in CLASS_KINDS:
            by_class[a["name"]].append(nid)

    for cid, bname, etype, rel in pend["bases"]:
        r = _pick(bname, rel, by_class, G, imported)
        if r:
            _link(G, cid, r[0], etype, r[1])

    for mid, owner, rel in pend["owners"]:
        r = _pick(owner, rel, by_class, G, imported)
        if r:
            _link(G, r[0], mid, "DEFINES_METHOD", r[1])

    for caller, name, rel in pend["calls"]:
        r = _pick(name, rel, by_name, G, imported)
        if r:
            _link(G, caller, r[0], "CALLS", r[1])

    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    nx.write_graphml(G, out_path)

    type_count = Counter(a.get("type") for _, a in G.nodes(data=True))
    print(
        f"[Project Analyser] Graph saved to {out_path} | nodes={G.number_of_nodes()} "
        f"edges={G.number_of_edges()} | files by language={dict(lang_count)} | {dict(type_count)}"
    )

    return {
        "graph_path": out_path,
        "graph_output_path": out_path,
        "parsed_nodes_count": G.number_of_nodes(),
        "parsed_files_count": len(files),
        "graph_edges_count": G.number_of_edges(),
        "language_stats": dict(lang_count),
        "analyzer_status": "Complete",
    }