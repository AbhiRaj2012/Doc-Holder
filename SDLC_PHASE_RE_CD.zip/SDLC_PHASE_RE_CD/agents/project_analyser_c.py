"""project_analyser: builds a tree-sitter knowledge graph of a project and saves it to SQLite.

pip install tree-sitter tree-sitter-language-pack networkx langgraph
"""
import hashlib
import json
import os
import posixpath
import re
import sqlite3
import sys
import threading
from concurrent.futures import ThreadPoolExecutor
from typing import TypedDict, List, Tuple

import networkx as nx
from langgraph.graph import END, START, StateGraph
from tree_sitter_language_pack import get_parser

MAX_PARSE_BYTES = 1_000_000
SKIP_DIRS = {"node_modules", "__pycache__", "venv", "env", "build", "dist", "target", "vendor", "out", "bin", "obj"}

class ProcessResult(TypedDict, total=False):
    rel: str
    lang: str
    size: int
    hash: str
    parsed: int
    nodes: List[Tuple[str, str, str, str, str, int, int, str]]
    edges: List[Tuple[str, str, str]]
    calls: List[Tuple[str, str, int]]
    inherits: List[Tuple[str, str]]
    imports: List[str]
    error: str


EXT_LANG = {
    ".py": "python", ".js": "javascript", ".jsx": "javascript", ".mjs": "javascript", ".cjs": "javascript",
    ".ts": "typescript", ".tsx": "tsx", ".java": "java", ".c": "c", ".h": "c",
    ".cpp": "cpp", ".cc": "cpp", ".cxx": "cpp", ".hpp": "cpp", ".hh": "cpp", ".hxx": "cpp",
    ".cs": "csharp", ".go": "go", ".rs": "rust", ".rb": "ruby", ".php": "php",
    ".html": "html", ".css": "css", ".json": "json", ".md": "markdown", ".yml": "yaml", ".yaml": "yaml",
    ".toml": "toml", ".xml": "xml", ".sql": "sql", ".sh": "bash", ".txt": "text",
}
KNOWN_EXTS = set(EXT_LANG)

IDENT = {"identifier", "type_identifier", "field_identifier", "property_identifier",
         "name", "constant", "namespace_identifier"}
INHERIT_FIELDS = ("superclasses", "superclass", "interfaces")
INHERIT_NODES = {"class_heritage", "base_class_clause", "base_list", "extends_interfaces",
                 "super_interfaces", "base_clause", "class_interface_clause"}
FUNC_VALUES = {"arrow_function", "function_expression", "function", "generator_function"}

_JS = dict(
    defs={"function_declaration": "Function", "generator_function_declaration": "Function",
          "class_declaration": "Class", "abstract_class_declaration": "Class",
          "method_definition": "Function", "variable_declarator": "Function",
          "interface_declaration": "Interface", "enum_declaration": "Enum", "type_alias_declaration": "Type"},
    calls={"call_expression": "function", "new_expression": "constructor"},
    imports={"import_statement"},
    import_re=r"""['"]([^'"]+)['"]""",
    import_calls={"require"},
)
_C = dict(
    defs={"function_definition": "Function", "struct_specifier": "Class",
          "union_specifier": "Class", "enum_specifier": "Enum"},
    calls={"call_expression": "function"},
    imports={"preproc_include"},
    import_re=r'#\s*include\s*[<"]([^>"]+)[>"]',
)
LANGS = {
    "python": dict(
        defs={"function_definition": "Function", "class_definition": "Class"},
        calls={"call": "function"},
        imports={"import_statement", "import_from_statement"},
        import_re=r"(?:from|import)\s+(\.*[\w.]+|\.+)",
    ),
    "javascript": _JS, "typescript": _JS, "tsx": _JS,
    "java": dict(
        defs={"class_declaration": "Class", "record_declaration": "Class", "interface_declaration": "Interface",
              "enum_declaration": "Enum", "method_declaration": "Function", "constructor_declaration": "Function"},
        calls={"method_invocation": None, "object_creation_expression": "type"},
        imports={"import_declaration"},
        import_re=r"import\s+(?:static\s+)?([\w.]+)",
    ),
    "c": _C,
    "cpp": dict(
        defs={**_C["defs"], "class_specifier": "Class", "namespace_definition": "Module"},
        calls={"call_expression": "function", "new_expression": "type"},
        imports={"preproc_include"},
        import_re=_C["import_re"],
    ),
    "csharp": dict(
        defs={"class_declaration": "Class", "struct_declaration": "Class", "record_declaration": "Class",
              "interface_declaration": "Interface", "enum_declaration": "Enum", "method_declaration": "Function",
              "constructor_declaration": "Function", "local_function_statement": "Function",
              "namespace_declaration": "Module"},
        calls={"invocation_expression": "function", "object_creation_expression": "type"},
        imports={"using_directive"},
        import_re=r"using\s+(?:static\s+)?(?:\w+\s*=\s*)?([\w.]+)",
    ),
    "go": dict(
        defs={"function_declaration": "Function", "method_declaration": "Method", "type_spec": "Type"},
        calls={"call_expression": "function"},
        imports={"import_spec"},
        import_re=r'"([^"]+)"',
    ),
    "rust": dict(
        defs={"function_item": "Function", "struct_item": "Class", "enum_item": "Enum",
              "trait_item": "Interface", "mod_item": "Module"},
        calls={"call_expression": "function"},
        imports={"use_declaration"},
        import_re=r"use\s+([\w:]+)",
    ),
    "ruby": dict(
        defs={"method": "Function", "singleton_method": "Function", "class": "Class", "module": "Module"},
        calls={"call": None},
        imports=set(),
        import_re=r"""['"]([^'"]+)['"]""",
        import_calls={"require", "require_relative", "load"},
    ),
    "php": dict(
        defs={"function_definition": "Function", "method_declaration": "Function", "class_declaration": "Class",
              "interface_declaration": "Interface", "trait_declaration": "Class", "enum_declaration": "Enum"},
        calls={"function_call_expression": "function", "member_call_expression": None,
               "scoped_call_expression": None},
        imports={"namespace_use_declaration"},
        import_re=r"use\s+(?:function\s+|const\s+)?([\w\\]+)",
    ),
}

_tls = threading.local()


def parser(lang):
    p = getattr(_tls, lang, None)
    if p is None:
        p = get_parser(lang)
        setattr(_tls, lang, p)
    return p


def callee_name(n):
    if n is None:
        return None
    if n.type in IDENT:
        return n.text.decode(errors="replace")
    for f in ("name", "field", "property", "attribute", "method", "function"):
        c = n.child_by_field_name(f)
        if c is not None:
            return callee_name(c)
    return None


def def_name(n):
    c = n.child_by_field_name("name")
    if c is None:
        c = n.child_by_field_name("declarator")
        while c is not None and c.type not in IDENT:
            nxt = c.child_by_field_name("declarator") or c.child_by_field_name("name")
            if nxt is None:
                break
            c = nxt
    return callee_name(c)


def definition(n, defs, owner_label):
    label = defs.get(n.type)
    if label is None:
        return None
    if n.type.endswith("_specifier") and n.child_by_field_name("body") is None:
        return None
    if n.type == "variable_declarator":
        v = n.child_by_field_name("value")
        if v is None or v.type not in FUNC_VALUES:
            return None
    if n.type == "type_spec":
        k = n.child_by_field_name("type")
        label = {"struct_type": "Class", "interface_type": "Interface"}.get(k.type if k else "", "Type")
    name = def_name(n)
    if not name:
        return None
    if label == "Function" and owner_label in ("Class", "Interface"):
        label = "Method"
    return label, name


def bases(n):
    roots = [n.child_by_field_name(f) for f in INHERIT_FIELDS]
    roots += [c for c in n.children if c.type in INHERIT_NODES]
    out, st = [], [r for r in roots if r is not None]
    while st:
        x = st.pop()
        if x.type in ("identifier", "type_identifier", "name"):
            out.append(x.text.decode(errors="replace"))
        else:
            st.extend(x.children)
    return out


def signature(src, n):
    return src[n.start_byte:min(n.end_byte, n.start_byte + 300)].split(b"\n")[0].decode(errors="replace").strip()[:200]


def find_imports(cfg, text):
    return [m.strip() for m in re.findall(cfg["import_re"], text) if m.strip()]


def extract(rel, lang, src):
    cfg = LANGS[lang]
    root = parser(lang).parse(src).root_node
    nodes, edges, calls, inherits, imports = [], [], [], [], []
    seen = {rel}
    stack = [(root, rel, "File", rel)]
    while stack:
        n, owner, olabel, caller = stack.pop()
        d = definition(n, cfg["defs"], olabel)
        if d:
            label, name = d
            qn = f"{owner}::{name}"
            if qn in seen:
                qn = f"{qn}#{n.start_point[0] + 1}"
            seen.add(qn)
            nodes.append((qn, label, name, rel, lang, n.start_point[0] + 1, n.end_point[0] + 1, signature(src, n)))
            edges.append((owner, qn, "DEFINES_METHOD" if label == "Method" else "DEFINES"))
            if label in ("Class", "Interface"):
                inherits.extend((qn, b) for b in bases(n))
            owner, olabel = qn, label
            if label in ("Function", "Method"):
                caller = qn
        if n.type in cfg["calls"]:
            spec = cfg["calls"][n.type]
            name = callee_name(n if spec is None else n.child_by_field_name(spec))
            if name:
                if name in cfg.get("import_calls", ()):
                    imports.extend(find_imports(cfg, n.text.decode(errors="replace")))
                else:
                    calls.append((caller, name, n.start_point[0] + 1))
        if n.type in cfg["imports"]:
            imports.extend(find_imports(cfg, n.text.decode(errors="replace")))
        for ch in reversed(n.children):
            stack.append((ch, owner, olabel, caller))
    return nodes, edges, calls, inherits, imports


def scan(root):
    out = []
    for d, dirs, fs in os.walk(root):
        dirs[:] = [x for x in dirs if x not in SKIP_DIRS and not x.startswith(".")]
        for f in fs:
            ext = os.path.splitext(f)[1].lower()
            rel = os.path.relpath(os.path.join(d, f), root).replace(os.sep, "/")
            out.append((rel, EXT_LANG.get(ext, "other")))
    return out


def process_file(root: str, item: tuple[str, str]) -> ProcessResult:
    rel, lang = item
    with open(os.path.join(root, rel), "rb") as fh:
        src = fh.read()

    # Initialize the result dictionary
    res: ProcessResult = dict(rel=rel, lang=lang, size=len(src), hash=hashlib.blake2b(src, digest_size=8).hexdigest(),
                              parsed=0, nodes=[], edges=[], calls=[], inherits=[], imports=[])

    if lang in LANGS and len(src) <= MAX_PARSE_BYTES:
        try:
            res["nodes"], res["edges"], res["calls"], res["inherits"], res["imports"] = extract(rel, lang, src)
            res["parsed"] = 1
        except Exception as e:
            res["error"] = str(e)
    return res


def candidates(spec, rel):
    s = spec.strip().replace("\\", "/")
    d = posixpath.dirname(rel)
    if s.startswith(("./", "../")):
        out = [posixpath.normpath(posixpath.join(d, s))]
    elif s.startswith("."):
        dots = len(s) - len(s.lstrip("."))
        base = d
        for _ in range(dots - 1):
            base = posixpath.dirname(base)
        out = [posixpath.normpath(posixpath.join(base, s.lstrip(".").replace(".", "/")))]
    else:
        s = re.sub(r"^(crate|self|super)::", "", s).replace("::", "/").strip(".*/")
        if "/" not in s and posixpath.splitext(s)[1] not in KNOWN_EXTS:
            s = s.replace(".", "/")
        out = [s] + ([posixpath.dirname(s)] if "/" in s else [])
    res = []
    for c in out:
        base, ext = posixpath.splitext(c)
        c = base if ext in KNOWN_EXTS else c
        if c not in ("", "."):
            res.append(c)
    return res


def resolve_import(spec, rel, by_stem):
    for c in candidates(spec, rel):
        for f, v in by_stem.get(posixpath.basename(c), ()):
            if f != rel and (v == c or v.endswith("/" + c)):
                return f
    return None


def pick(cands, file, imported):
    hit = [c for c in cands if c[1] in imported]
    if 0 < len(hit) <= 3:
        return [(c, 0.95) for c in hit]
    same = [c for c in cands if c[1] == file]
    if same:
        return [(same[0], 0.90)]
    if len(cands) == 1:
        return [(cands[0], 0.75)]
    if not cands:
        return []
    fdir = posixpath.dirname(file).split("/")
    best = max(cands, key=lambda c: len(os.path.commonprefix([posixpath.dirname(c[1]).split("/"), fdir])))
    return [(best, 0.55)]


SCHEMA = """
CREATE TABLE nodes(id INTEGER PRIMARY KEY, label TEXT, name TEXT, qname TEXT UNIQUE, file TEXT,
                   language TEXT, start_line INT, end_line INT, signature TEXT);
CREATE TABLE edges(src INT, dst INT, type TEXT, confidence REAL);
CREATE TABLE files(path TEXT PRIMARY KEY, language TEXT, parsed INT, size INT, hash TEXT, imports TEXT);
CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT);
"""


def build_graph(project_address, graph_path="project_graph.db"):
    root = os.path.abspath(project_address)
    if not os.path.isdir(root):
        raise FileNotFoundError(root)
    with ThreadPoolExecutor(os.cpu_count() or 4) as ex:
        results = list(ex.map(lambda it: process_file(root, it), scan(root)))

    nodes, edges = {}, []
    nodes["project:"] = ("Project", os.path.basename(root), "project:", None, None, None, None, None)
    by_stem, registry, file_lang = {}, {}, {}
    for r in results:
        rel, lang = r["rel"], r["lang"]
        file_lang[rel] = lang
        nodes[rel] = ("File", posixpath.basename(rel), rel, rel, lang, 1, None, None)
        parent = posixpath.dirname(rel)
        parent_qn = f"dir:{parent}" if parent else "project:"
        edges.append((parent_qn, rel, "CONTAINS_FILE", 1.0))
        while parent:
            up = posixpath.dirname(parent)
            qn = f"dir:{parent}"
            if qn not in nodes:
                nodes[qn] = ("Folder", posixpath.basename(parent), qn, parent, None, None, None, None)
                edges.append((f"dir:{up}" if up else "project:", qn, "CONTAINS_FOLDER", 1.0))
            parent = up
        for qn, label, name, f, lg, s, e, sig in r["nodes"]:
            nodes[qn] = (label, name, qn, f, lg, s, e, sig)
            if label != "Module":
                registry.setdefault((lg, name), []).append((qn, f, label))
        edges.extend((a, b, t, 1.0) for a, b, t in r["edges"])
        if r["parsed"]:
            base = posixpath.splitext(rel)[0]
            variants = [base] + ([posixpath.dirname(base)] if posixpath.basename(base) in ("index", "__init__", "mod") else [])
            for v in variants:
                if v:
                    by_stem.setdefault(posixpath.basename(v), []).append((rel, v))

    file_imports = {}
    for r in results:
        targets = {resolve_import(s, r["rel"], by_stem) for s in r["imports"]} - {None}
        file_imports[r["rel"]] = targets
        edges.extend((r["rel"], t, "IMPORTS", 1.0) for t in targets)

    best = {}
    for r in results:
        rel, lang = r["rel"], r["lang"]
        imported = file_imports[rel]
        for caller, name, _ in r["calls"]:
            cands = [(q, f) for q, f, _l in registry.get((lang, name), [])]
            for (qn, _f), conf in pick(cands, rel, imported):
                if qn != caller:
                    key = (caller, qn)
                    best[key] = max(best.get(key, 0), conf)
        for cls, base in r["inherits"]:
            cands = [(q, f) for q, f, l in registry.get((lang, base), []) if l in ("Class", "Interface")]
            for (qn, _f), conf in pick(cands, rel, imported):
                if qn != cls:
                    edges.append((cls, qn, "INHERITS", conf))
    edges.extend((a, b, "CALLS", c) for (a, b), c in best.items())

    g = nx.Graph()
    g.add_edges_from((a, b) for (a, b) in best)
    communities = [c for c in nx.community.louvain_communities(g, seed=42) if len(c) > 1] if g.number_of_edges() else []
    for i, members in enumerate(communities):
        qn = f"community:{i}"
        nodes[qn] = ("Community", f"community_{i}", qn, None, None, None, None, None)
        edges.extend((m, qn, "MEMBER_OF", 1.0) for m in members)

    if os.path.exists(graph_path):
        os.remove(graph_path)
    con = sqlite3.connect(graph_path)
    con.executescript(SCHEMA)
    ids = {}
    for i, (qn, row) in enumerate(nodes.items(), 1):
        ids[qn] = i
        con.execute("INSERT INTO nodes VALUES(?,?,?,?,?,?,?,?,?)", (i, row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7]))
    con.executemany("INSERT INTO edges VALUES(?,?,?,?)",
                    [(ids[a], ids[b], t, c) for a, b, t, c in edges if a in ids and b in ids])
    con.executemany("INSERT INTO files VALUES(?,?,?,?,?,?)",
                    [(r["rel"], r["lang"], r["parsed"], r["size"], r["hash"], json.dumps(sorted(file_imports[r["rel"]]))) for r in results])
    con.executemany("INSERT INTO meta VALUES(?,?)", [("project_root", root), ("graph_version", "1")])
    con.execute("CREATE INDEX idx_nodes_name ON nodes(name)")
    con.execute("CREATE INDEX idx_nodes_file ON nodes(file)")
    con.execute("CREATE INDEX idx_nodes_label ON nodes(label)")
    con.execute("CREATE INDEX idx_edges_src ON edges(src, type)")
    con.execute("CREATE INDEX idx_edges_dst ON edges(dst, type)")
    con.commit()
    stats = {
        "files": len(results),
        "parsed_files": sum(r["parsed"] for r in results),
        "languages": {l: sum(1 for v in file_lang.values() if v == l) for l in sorted(set(file_lang.values()))},
        "nodes": con.execute("SELECT COUNT(*) FROM nodes").fetchone()[0],
        "edges": con.execute("SELECT COUNT(*) FROM edges").fetchone()[0],
        "errors": {r["rel"]: r["error"] for r in results if "error" in r},
    }
    con.close()
    return stats


class WorkflowState(TypedDict, total=False):
    project_address: str
    graph_path: str
    graph_stats: dict


def project_analyser(state: WorkflowState) -> dict:
    graph_path = os.path.abspath(state.get("graph_path") or "project_graph.db")
    return {"graph_path": graph_path, "graph_stats": build_graph(state["project_address"], graph_path)}


def make_workflow():
    wf = StateGraph(WorkflowState)
    wf.add_node("project_analyser", project_analyser)
    wf.add_edge(START, "project_analyser")
    wf.add_edge("project_analyser", END)
    return wf.compile()


if __name__ == "__main__":
    # Fallback to the current directory if no arguments are passed from the IDE
    if len(sys.argv) < 2:
        print("Warning: No project address provided. Defaulting to current directory ('.').")
        project_address = "."
    else:
        project_address = sys.argv[1]

    graph_path = sys.argv[2] if len(sys.argv) > 2 else "project_graph.db"

    out = make_workflow().invoke({
        "project_address": project_address,
        "graph_path": graph_path
    })

    print(json.dumps(out["graph_stats"], indent=2))