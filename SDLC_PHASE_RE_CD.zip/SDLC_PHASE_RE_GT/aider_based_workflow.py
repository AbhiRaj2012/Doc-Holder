from __future__ import annotations

import ast
import hashlib
import html
import json
import os
import re
import shutil
import subprocess
import time
from datetime import datetime
from pathlib import Path
from typing import Any, TypedDict

# REQUIRED: Aider's repository intelligence and edit engine are the base.
try:
    from aider.coders.editblock_coder import (
        DEFAULT_FENCE,
        do_replace,
        find_original_update_blocks,
    )
    from aider.io import InputOutput
    from aider.repomap import RepoMap
    from grep_ast import filename_to_lang
    from grep_ast.tsl import get_parser as aider_get_parser
except ImportError as exc:
    raise SystemExit(
        "Aider is required. Install with: python -m pip install aider-chat"
    ) from exc

# REQUIRED: Tree-sitter is a core repository-analysis dependency, not a fallback.
try:
    import tree_sitter  # noqa: F401
    from tree_sitter_language_pack import get_parser as ts_pack_get_parser
except ImportError as exc:
    raise SystemExit(
        "Tree-sitter is mandatory for this agent. Install with: "
        "python -m pip install tree-sitter tree-sitter-language-pack"
    ) from exc

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_ollama import ChatOllama
from langgraph.graph import END, StateGraph

# DeepEval is optional; the evaluation pipeline remains functional without it.
os.environ.setdefault("DEEPEVAL_TELEMETRY_OPT_OUT", "YES")
try:
    from deepeval.models.base_model import DeepEvalBaseLLM
    from deepeval.metrics import GEval
    from deepeval.test_case import LLMTestCase, LLMTestCaseParams

    DEEPEVAL_AVAILABLE = True
except Exception:
    DEEPEVAL_AVAILABLE = False

try:
    from langchain_ollama import OllamaEmbeddings
except Exception:
    OllamaEmbeddings = None


# ============================================================
# CONFIGURATION
# ============================================================
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "gemma4:e2b")
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL")
OLLAMA_NUM_PREDICT = int(os.getenv("OLLAMA_NUM_PREDICT", "2048"))
OLLAMA_NUM_CTX = int(os.getenv("OLLAMA_NUM_CTX", "8192"))
OLLAMA_TEMPERATURE = float(os.getenv("OLLAMA_TEMPERATURE", "0.1"))
OLLAMA_EMBED_MODEL = os.getenv("OLLAMA_EMBED_MODEL", "nomic-embed-text")

MAX_REVIEW_ATTEMPTS = int(os.getenv("MAX_REVIEW_ATTEMPTS", "3"))
MAX_PLANNER_TASKS = int(os.getenv("MAX_PLANNER_TASKS", "40"))
MAX_EDIT_BLOCKS = int(os.getenv("MAX_EDIT_BLOCKS", "8"))
MAX_SOURCE_CHARS = int(os.getenv("MAX_SOURCE_CHARS", "16000"))
MAX_MAP_TOKENS = int(os.getenv("MAX_MAP_TOKENS", "1200"))
MAX_CONTEXT_CHARS = int(os.getenv("MAX_CONTEXT_CHARS", "24000"))
MAX_FILES_SCAN = int(os.getenv("MAX_FILES_SCAN", "5000"))
MAX_FILE_BYTES = int(os.getenv("MAX_FILE_BYTES", str(2 * 1024 * 1024)))
ENABLE_RAG = os.getenv("ENABLE_RAG", "1").lower() not in {"0", "false", "no", "off"}
ENABLE_LSP = os.getenv("ENABLE_LSP", "1").lower() not in {"0", "false", "no", "off"}
RUN_PROJECT_TESTS = os.getenv("RUN_PROJECT_TESTS", "0").lower() in {"1", "true", "yes", "on"}
PROJECT_TEST_TIMEOUT = int(os.getenv("PROJECT_TEST_TIMEOUT", "120"))

IGNORED_DIRS = {
    ".git", ".hg", ".svn", ".idea", ".vscode", "node_modules", "__pycache__", ".pytest_cache",
    ".mypy_cache", ".ruff_cache", ".tox", ".venv", "venv", "env", "build", "dist", "target",
    "coverage", "out", "bin", "obj", ".next", ".nuxt", ".gradle", ".cache", ".aider.tags.cache.v3",
    ".aider.tags.cache.v4",
}
SENSITIVE_NAMES = {
    ".env", ".env.local", ".env.production", ".env.development", "id_rsa", "id_ed25519",
    "credentials.json", "service-account.json", "secrets.json",
}

# Aider/grep-ast + the TSL pack covers a broad language set. These overrides add common header/build names
# for our own scanner without weakening the Tree-sitter requirement.
EXTRA_LANGUAGE_BY_NAME = {
    "Dockerfile": "dockerfile",
    "Makefile": "make",
    "CMakeLists.txt": "cmake",
    ".gitignore": "gitignore",
}

LANGUAGE_SYSTEM_PROMPTS = {
    "python": "Preserve Python semantics, imports, decorators, typing, exceptions, async/sync behavior, and public APIs.",
    "c": "Preserve C ABI/API contracts, headers, macros, ownership, memory safety, include structure, and compiler compatibility.",
    "cpp": "Preserve C++ ABI/API contracts, RAII, ownership, templates, const-correctness, namespaces, headers, and language standard.",
    "java": "Preserve Java package/type contracts, annotations, exceptions, framework conventions, and public APIs.",
    "go": "Preserve Go package APIs, interfaces, error handling, goroutine/channel behavior, and module compatibility.",
    "rust": "Preserve Rust ownership/borrowing, lifetimes, traits, feature flags, module boundaries, and Result/error semantics.",
    "javascript": "Preserve JavaScript module/runtime semantics, imports/exports, asynchronous behavior, and existing framework conventions.",
    "typescript": "Preserve TypeScript types, generics, module boundaries, strictness, and compiler assumptions.",
    "tsx": "Preserve TSX/React component contracts, props/types, hooks/state semantics, and module boundaries.",
    "c_sharp": "Preserve .NET target/framework conventions, nullable/type contracts, async semantics, dependency injection, and public APIs.",
    "kotlin": "Preserve Kotlin null-safety, coroutine behavior, visibility, type contracts, and framework conventions.",
    "swift": "Preserve Swift optionals, value/reference semantics, concurrency, protocols, and platform conventions.",
    "ruby": "Preserve Ruby class/module contracts, dynamic dispatch, framework conventions, and idiomatic semantics.",
    "php": "Preserve PHP version compatibility, namespaces, autoloading, framework conventions, and request/runtime semantics.",
    "dart": "Preserve Dart null-safety, async semantics, isolates, and Flutter/widget contracts.",
    "lua": "Preserve Lua table/metatable semantics and module/runtime conventions.",
    "bash": "Preserve quoting, exit codes, variable scope, portability, and shell safety.",
    "sql": "Preserve the repository's SQL dialect, schema contracts, transaction semantics, and non-destructive behavior.",
    "html": "Preserve semantic HTML, accessibility, templates, DOM contracts, and referenced assets.",
    "css": "Preserve cascade/specificity/responsive behavior and avoid broad selector regressions.",
}


# ============================================================
# STATE
# ============================================================
class AgentState(TypedDict, total=False):
    project_address: str
    user_request: str
    requirements: str
    manifest: dict[str, Any]
    manifest_json: str
    repo_map: str
    plan_stack: list[dict[str, Any]]
    current_task: dict[str, Any] | None
    issue_report: str
    review_attempts: int
    iterations: int
    file_attempts: dict[str, int]
    task_attempts: dict[str, int]
    task_durations: dict[str, float]
    task_start_times: dict[str, float]
    task_history: list[dict[str, Any]]
    completed_tasks: list[str]
    total_tasks: int
    run_dir: str
    start_time: float
    elapsed_seconds: float
    workflow_status: str
    last_edit: dict[str, Any]
    lsp_context: str
    baseline_diagnostics: dict[str, list[str]]
    rag_context: str
    failure_reason: str
    evaluation: dict[str, Any]
    changed_files: list[str]


# ============================================================
# UTILITIES
# ============================================================
def build_llm() -> ChatOllama:
    kwargs: dict[str, Any] = {
        "model": OLLAMA_MODEL,
        "num_predict": OLLAMA_NUM_PREDICT,
        "num_ctx": OLLAMA_NUM_CTX,
        "temperature": OLLAMA_TEMPERATURE,
    }
    if OLLAMA_BASE_URL:
        kwargs["base_url"] = OLLAMA_BASE_URL
    return ChatOllama(**kwargs)


llm = build_llm()


def ask_llm(system: str, user: str) -> str:
    response = llm.invoke([
        SystemMessage(content=system),
        HumanMessage(content=user),
    ])
    content = getattr(response, "content", "")
    return content if isinstance(content, str) else str(content)


def log(run_dir: Path, step: str, details: Any) -> None:
    run_dir.mkdir(parents=True, exist_ok=True)
    with open(run_dir / "execution_log.txt", "a", encoding="utf-8") as handle:
        handle.write(f"\n[{datetime.now():%H:%M:%S}] === {step.upper()} ===\n")
        handle.write(str(details) + "\n")
        handle.write("-" * 100 + "\n")


def safe_json(raw: str) -> Any:
    cleaned = raw.strip().replace("\ufeff", "")
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```[A-Za-z0-9_.+-]*\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned).strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        starts = [p for p in (cleaned.find("{"), cleaned.find("[")) if p >= 0]
        if not starts:
            raise ValueError("No JSON object/array found in model output.")
        start = min(starts)
        for end in range(len(cleaned), start, -1):
            try:
                return json.loads(cleaned[start:end])
            except json.JSONDecodeError:
                continue
    raise ValueError("Invalid JSON model output.")


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def atomic_write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.agent-{os.getpid()}-{time.time_ns()}")
    try:
        tmp.write_text(content, encoding="utf-8", newline="")
        if path.exists():
            try:
                shutil.copymode(path, tmp)
            except OSError:
                pass
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def safe_path(root: Path, relative: str) -> Path:
    root = root.resolve()
    candidate = (root / relative.replace("\\", "/")).resolve()
    try:
        candidate.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"Path escapes project root: {relative}") from exc
    return candidate


def is_sensitive(path: Path) -> bool:
    name = path.name.lower()
    return name in {x.lower() for x in SENSITIVE_NAMES} or any(
        token in name for token in ("secret", "credential", "private_key", "apikey")
    )


def looks_text(path: Path) -> bool:
    if path.name in {"Dockerfile", "Makefile", "CMakeLists.txt"}:
        return True
    try:
        data = path.read_bytes()
    except OSError:
        return False
    if len(data) > MAX_FILE_BYTES or b"\x00" in data:
        return False
    return True


def iter_source_files(root: Path) -> list[Path]:
    files: list[Path] = []
    for current, dirs, names in os.walk(root, followlinks=False):
        dirs[:] = sorted(
            d for d in dirs
            if d not in IGNORED_DIRS and not (Path(current) / d).is_symlink()
        )
        for name in sorted(names):
            path = Path(current) / name
            if path.is_symlink() or is_sensitive(path) or not looks_text(path):
                continue
            try:
                path.resolve().relative_to(root.resolve())
            except ValueError:
                continue
            files.append(path)
            if len(files) >= MAX_FILES_SCAN:
                return files
    return files


def model_language_for_file(path: Path) -> str:
    if path.name in EXTRA_LANGUAGE_BY_NAME:
        return EXTRA_LANGUAGE_BY_NAME[path.name]
    suffix = path.suffix.lower()
    # Aider's current grep-ast mapping can report TSX as TypeScript; use the distinct
    # Tree-sitter TSX grammar for syntax validation and editor prompts.
    explicit = {
        ".tsx": "tsx",
        ".cjs": "javascript",
        ".jsx": "javascript",
        ".hpp": "cpp",
        ".hxx": "cpp",
        ".hh": "cpp",
        ".cxx": "cpp",
        ".h": "c",
    }
    if suffix in explicit:
        return explicit[suffix]
    language = filename_to_lang(str(path))
    if language:
        return language
    extras = {
        ".pyi": "python", ".mjs": "javascript", ".zig": "zig",
        ".sol": "solidity", ".sv": "verilog",
    }
    return extras.get(suffix, "")


def require_tree_sitter_parser(path: Path, language: str):
    if not language:
        raise ValueError(f"No Tree-sitter language mapping for: {path}")
    try:
        # Direct TSL-pack check: this is the non-negotiable parser path.
        parser = ts_pack_get_parser(language)
    except Exception as exc:
        raise RuntimeError(
            f"No Tree-sitter grammar available for {path} (language={language})."
        ) from exc
    if parser is None:
        raise RuntimeError(f"Tree-sitter returned no parser for language={language}")
    return parser


def tree_sitter_errors(path: Path, text: str, language: str) -> list[str]:
    parser = require_tree_sitter_parser(path, language)
    tree = parser.parse(text.encode("utf-8"))
    errors: list[str] = []
    stack = [tree.root_node]
    while stack:
        node = stack.pop()
        if getattr(node, "is_error", False) or getattr(node, "is_missing", False):
            errors.append(
                f"{path.as_posix()}:{node.start_point[0] + 1}:{node.start_point[1] + 1}: "
                f"Tree-sitter {node.type}"
            )
        try:
            stack.extend(reversed(node.children))
        except Exception:
            pass
    return errors[:50]


def write_backup(root: Path, run_dir: Path, path: Path, task_id: str, attempt: int) -> str:
    rel = path.resolve().relative_to(root.resolve())
    destination = run_dir / "backups" / task_id / f"attempt_{attempt:03d}" / rel
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, destination)
    return destination.as_posix()


def compact_json(value: Any, max_chars: int) -> str:
    raw = json.dumps(value, indent=2, ensure_ascii=False)
    return raw if len(raw) <= max_chars else raw[:max_chars] + "\n...<truncated>"


# ============================================================
# AIDER REPOSITORY ENGINE
# ============================================================
class TokenCountAdapter:
    """Minimal adapter required by Aider's RepoMap token budgeting."""

    def token_count(self, text: str) -> int:
        return max(1, (len(text) + 3) // 4)


class AiderIOAdapter:
    """Non-interactive IO adapter used by RepoMap."""

    def __init__(self, root: Path):
        self.root = str(root)

    def read_text(self, filename: str, silent: bool = False) -> str | None:
        try:
            return Path(filename).read_text(encoding="utf-8")
        except (OSError, UnicodeError):
            return None

    def tool_output(self, *messages: Any, **_: Any) -> None:
        return None

    def tool_warning(self, *messages: Any, **_: Any) -> None:
        return None

    def tool_error(self, *messages: Any, **_: Any) -> None:
        return None


class AiderRepositoryEngine:
    """Adapter around Aider's actual RepoMap + SEARCH/REPLACE implementation."""

    def __init__(self, root: Path):
        self.root = root.resolve()
        self.io = AiderIOAdapter(self.root)
        self.repo_map = RepoMap(
            root=str(self.root),
            main_model=TokenCountAdapter(),
            io=self.io,
            map_tokens=MAX_MAP_TOKENS,
            max_context_window=OLLAMA_NUM_CTX,
            refresh="auto",
            verbose=False,
        )

    def files(self) -> list[Path]:
        return iter_source_files(self.root)

    def all_relative_files(self) -> list[str]:
        return [p.relative_to(self.root).as_posix() for p in self.files()]

    def tags(self, path: Path) -> list[dict[str, Any]]:
        rel = path.relative_to(self.root).as_posix()
        try:
            tags = self.repo_map.get_tags(str(path), rel)
        except Exception as exc:
            raise RuntimeError(f"Aider RepoMap failed for {rel}: {exc}") from exc
        result = []
        for tag in tags:
            result.append({
                "name": tag.name,
                "kind": tag.kind,
                "line": int(tag.line) + 1,
            })
        return result

    def ranked_map(self, targets: list[Path], force_refresh: bool = True) -> str:
        all_files = self.files()
        target_abs = [str(p.resolve()) for p in targets]
        target_set = set(target_abs)
        other = [str(p.resolve()) for p in all_files if str(p.resolve()) not in target_set]
        if not other:
            return ""
        mentioned_files: set[str] = set()
        mentioned_idents: set[str] = set()
        for path in targets:
            mentioned_files.add(path.relative_to(self.root).as_posix())
        return self.repo_map.get_ranked_tags_map(
            target_abs,
            other,
            max_map_tokens=MAX_MAP_TOKENS,
            mentioned_fnames=mentioned_files,
            mentioned_idents=mentioned_idents,
            force_refresh=force_refresh,
        ) or ""

    def apply_edit_blocks(self, raw_output: str, allowed_file: str) -> tuple[list[dict[str, Any]], str, str]:
        valid = [allowed_file]
        parsed = list(find_original_update_blocks(raw_output, DEFAULT_FENCE, valid))
        code_edits = [(fname, before, after) for fname, before, after in parsed if fname is not None]
        if not code_edits:
            raise ValueError("Editor produced no SEARCH/REPLACE edit block.")
        if len(code_edits) > MAX_EDIT_BLOCKS:
            raise ValueError(f"Editor produced {len(code_edits)} edit blocks; maximum is {MAX_EDIT_BLOCKS}.")

        applied: list[dict[str, Any]] = []
        path = safe_path(self.root, allowed_file)
        if is_sensitive(path):
            raise ValueError(f"Refusing to edit sensitive file: {allowed_file}")

        original = path.read_text(encoding="utf-8") if path.exists() else ""
        updated = original
        for fname, before, after in code_edits:
            if fname != allowed_file:
                raise ValueError(f"Editor attempted to modify {fname}; current task allows only {allowed_file}.")
            before = before if before.endswith("\n") else before
            exact_count = updated.count(before) if before.strip() else 0
            if before.strip() and exact_count == 1:
                candidate = updated.replace(before, after, 1)
            else:
                candidate = do_replace(str(path), updated, before, after, DEFAULT_FENCE)
                if candidate is None:
                    raise ValueError(f"Could not apply SEARCH block to {allowed_file}.")
                if before.strip() and candidate == updated:
                    raise ValueError(f"SEARCH block did not change {allowed_file}.")
            updated = candidate
            applied.append({"file": allowed_file, "search_chars": len(before), "replace_chars": len(after)})

        if updated == original:
            raise ValueError(f"Editor produced edits but {allowed_file} did not change.")
        return applied, original, updated

    def apply_new_file(self, relative: str, content: str) -> tuple[str, str]:
        path = safe_path(self.root, relative)
        if path.exists():
            raise ValueError(f"New-file task targeted an existing file: {relative}")
        if is_sensitive(path):
            raise ValueError(f"Refusing to create sensitive file: {relative}")
        language = model_language_for_file(path)
        require_tree_sitter_parser(path, language)
        return relative, content


# ============================================================
# OPTIONAL LOCAL RAG
# ============================================================
class LocalRAG:
    def __init__(self, root: Path, run_dir: Path):
        self.root = root
        self.run_dir = run_dir
        self.index_path = run_dir / "rag_index.json"
        self.embedding = None
        if ENABLE_RAG and OllamaEmbeddings is not None:
            kwargs: dict[str, Any] = {"model": OLLAMA_EMBED_MODEL}
            if OLLAMA_BASE_URL:
                kwargs["base_url"] = OLLAMA_BASE_URL
            try:
                self.embedding = OllamaEmbeddings(**kwargs)
            except Exception:
                self.embedding = None

    def build(self, files: list[Path]) -> dict[str, Any]:
        if self.embedding is None:
            return {"enabled": False, "records": []}
        records = []
        texts = []
        for path in files:
            try:
                text = path.read_text(encoding="utf-8")
            except (OSError, UnicodeError):
                continue
            lines = text.splitlines()
            for start in range(0, len(lines), 80):
                chunk_lines = lines[start:start + 80]
                if not chunk_lines:
                    continue
                chunk = "\n".join(chunk_lines)
                records.append({
                    "path": path.relative_to(self.root).as_posix(),
                    "start_line": start + 1,
                    "end_line": start + len(chunk_lines),
                    "text": chunk,
                })
                texts.append(chunk)
        if not records:
            return {"enabled": True, "records": []}
        try:
            vectors = self.embedding.embed_documents(texts)
        except Exception as exc:
            log(self.run_dir, "RAG DISABLED", str(exc))
            return {"enabled": False, "records": []}
        for record, vector in zip(records, vectors):
            record["vector"] = vector
        payload = {"model": OLLAMA_EMBED_MODEL, "records": records}
        atomic_write(self.index_path, json.dumps(payload, ensure_ascii=False))
        return {"enabled": True, "records": records}

    @staticmethod
    def cosine(a: list[float], b: list[float]) -> float:
        dot = sum(x * y for x, y in zip(a, b))
        na = sum(x * x for x in a) ** 0.5
        nb = sum(y * y for y in b) ** 0.5
        return dot / (na * nb) if na and nb else 0.0

    def query(self, payload: dict[str, Any], query: str, limit: int = 5) -> str:
        if not payload.get("enabled") or self.embedding is None or not payload.get("records"):
            return ""
        try:
            q = self.embedding.embed_query(query)
        except Exception:
            return ""
        scored = []
        for record in payload["records"]:
            vector = record.get("vector")
            if not vector:
                continue
            scored.append((self.cosine(q, vector), record))
        scored.sort(key=lambda item: item[0], reverse=True)
        lines = []
        for score, record in scored[:limit]:
            lines.append(
                f"--- {record['path']}:{record['start_line']}-{record['end_line']} | score={score:.3f} ---\n{record['text']}"
            )
        return "\n\n".join(lines)


# ============================================================
# SIMPLE LSP TOOLING
# ============================================================
LSP_COMMANDS = {
    "python": ["pyright-langserver", "--stdio"],
    "c": ["clangd", "--background-index=false"],
    "cpp": ["clangd", "--background-index=false"],
    "go": ["gopls", "serve"],
    "rust": ["rust-analyzer"],
    "typescript": ["typescript-language-server", "--stdio"],
    "tsx": ["typescript-language-server", "--stdio"],
    "javascript": ["typescript-language-server", "--stdio"],
    "java": ["jdtls"],
    "c_sharp": ["omnisharp", "-lsp"],
}


def detect_project_test_command(root: Path) -> list[str] | None:
    if (root / "pytest.ini").exists() or (root / "pyproject.toml").exists() or (root / "setup.cfg").exists():
        if list(root.rglob("test_*.py")) or list(root.rglob("*_test.py")):
            return ["python", "-m", "pytest", "-q"]
    if (root / "package.json").exists():
        try:
            package = json.loads((root / "package.json").read_text(encoding="utf-8"))
            script = package.get("scripts", {}).get("test")
            if script:
                return ["npm", "test", "--", "--runInBand"]
        except Exception:
            pass
    if (root / "go.mod").exists():
        return ["go", "test", "./..."]
    if (root / "Cargo.toml").exists():
        return ["cargo", "test"]
    return None


def project_test(root: Path) -> dict[str, Any]:
    if not RUN_PROJECT_TESTS:
        return {"enabled": False, "ok": None, "output": ""}
    command = detect_project_test_command(root)
    if not command:
        return {"enabled": True, "ok": None, "output": "No supported test command detected."}
    try:
        proc = subprocess.run(command, cwd=root, text=True, capture_output=True, timeout=PROJECT_TEST_TIMEOUT, check=False)
    except Exception as exc:
        return {"enabled": True, "ok": False, "output": str(exc)}
    output = (proc.stdout + "\n" + proc.stderr).strip()
    return {"enabled": True, "ok": proc.returncode == 0, "output": output[-8000:]}


# ============================================================
# REQUIREMENT / ANALYZER / PLANNER
# ============================================================
def requirement_node(state: AgentState) -> AgentState:
    root = Path(state["project_address"]).expanduser().resolve()
    if not root.is_dir():
        raise ValueError(f"Project directory does not exist: {root}")
    if not state.get("user_request", "").strip():
        raise ValueError("user_request must not be empty")
    requirements = (
        f"PROJECT: {root.name}\n"
        f"PROJECT PATH: {root}\n"
        f"REQUEST: {state['user_request'].strip()}\n"
        "RULE: Modify the existing repository; do not generate unrelated files or rewrite unchanged source."
    )
    log(Path(state["run_dir"]), "Requirement Node", requirements)
    return {"requirements": requirements, "issue_report": "", "workflow_status": "RUNNING"}


def analyzer_node(state: AgentState) -> AgentState:
    root = Path(state["project_address"]).resolve()
    run_dir = Path(state["run_dir"])
    engine = AiderRepositoryEngine(root)
    files = engine.files()
    if not files:
        raise ValueError("No text/source files were found in the repository.")

    manifest_files = []
    language_counts: dict[str, int] = {}
    parser_errors: list[dict[str, Any]] = []
    for path in files:
        rel = path.relative_to(root).as_posix()
        language = model_language_for_file(path)
        try:
            require_tree_sitter_parser(path, language)
        except Exception as exc:
            parser_errors.append({"file": rel, "language": language, "error": str(exc)})
            continue
        tags = engine.tags(path)
        definitions = [tag for tag in tags if tag["kind"] == "def"]
        references = [tag for tag in tags if tag["kind"] == "ref"]
        language_counts[language] = language_counts.get(language, 0) + 1
        manifest_files.append({
            "path": rel,
            "language": language,
            "size_bytes": path.stat().st_size,
            "sha256": sha256_file(path),
            "definitions": definitions,
            "references": references,
        })

    if parser_errors:
        atomic_write(run_dir / "parser_errors.json", json.dumps(parser_errors, indent=2, ensure_ascii=False))
        # Tree-sitter is mandatory, so unsupported grammars are analysis errors instead of fallback parsing.
        raise RuntimeError(
            "Tree-sitter grammar missing for one or more repository files. "
            f"See {run_dir / 'parser_errors.json'}"
        )

    request_idents = set(re.findall(r"[A-Za-z_][A-Za-z0-9_]{2,}", state["user_request"]))
    targets = []
    all_abs = [root / item["path"] for item in manifest_files]
    target_files_from_request = [
        root / token.replace("\\", "/") for token in re.findall(r"[A-Za-z0-9_./-]+\.[A-Za-z0-9_]+", state["user_request"])
        if (root / token).exists()
    ]
    targets = target_files_from_request[:8]
    other_files = [p for p in all_abs if p not in targets]
    if not other_files:
        repo_map = ""
    else:
        repo_map = engine.repo_map.get_ranked_tags_map(
            [str(p) for p in targets],
            [str(p) for p in other_files],
            max_map_tokens=MAX_MAP_TOKENS,
            mentioned_idents=request_idents,
            force_refresh=True,
        ) or ""

    architecture_signals = {
        "top_level_directories": sorted({Path(item["path"]).parts[0] for item in manifest_files if len(Path(item["path"]).parts) > 1}),
        "has_git": (root / ".git").exists(),
        "has_package_json": (root / "package.json").exists(),
        "has_pyproject": (root / "pyproject.toml").exists(),
        "has_requirements": (root / "requirements.txt").exists(),
        "has_cmake": (root / "CMakeLists.txt").exists(),
        "has_cargo": (root / "Cargo.toml").exists(),
        "has_go_mod": (root / "go.mod").exists(),
        "has_csproj": bool(list(root.glob("*.csproj"))),
    }
    frameworks = []
    markers = {
        "React": root / "package.json",
        "Django": root / "manage.py",
        "Flutter": root / "pubspec.yaml",
        "Spring": root / "pom.xml",
        "Cargo": root / "Cargo.toml",
        "Go Modules": root / "go.mod",
        "CMake": root / "CMakeLists.txt",
        ".NET": next(iter(root.glob("*.csproj")), None),
    }
    for name, marker in markers.items():
        if marker is not None and Path(marker).exists():
            frameworks.append(name)
    manifest = {
        "schema_version": "aider-langgraph-1.0",
        "project": {"name": root.name, "address": str(root)},
        "languages": [{"language": lang, "file_count": count} for lang, count in sorted(language_counts.items(), key=lambda x: (-x[1], x[0]))],
        "frameworks": frameworks,
        "architecture": architecture_signals,
        "tree_sitter": {"required": True, "grammar_validation": "passed"},
        "files": manifest_files,
        "aider_repo_map": repo_map,
    }
    atomic_write(run_dir / "manifest.json", json.dumps(manifest, indent=2, ensure_ascii=False))
    log(run_dir, "Analyzer Node", json.dumps(manifest, indent=2, ensure_ascii=False))
    return {"manifest": manifest, "manifest_json": json.dumps(manifest, ensure_ascii=False), "repo_map": repo_map}


def planner_node(state: AgentState) -> AgentState:
    root = Path(state["project_address"])
    manifest = state["manifest"]
    planner_system = (
        "You are a senior repository change planner. You are planning edits against a real codebase. "
        "Never invent filenames or functions. Every task must identify an existing file OR explicitly mark a new file. "
        "Tasks must be atomic enough for one editor call. Output JSON only."
    )
    planner_user = f"""
USER REQUEST:
{state['user_request']}

REPOSITORY MANIFEST:
{compact_json(manifest, 14000)}

AIDER REPO MAP:
{state.get('repo_map', '')[:12000]}

Create a strict LIFO task stack. The JSON must be:
{{
  "tasks": [
    {{
      "id": "TASK-001",
      "file": "path/to/file.ext",
      "language": "tree-sitter language name",
      "symbol": "exact function/class/method name or empty",
      "action": "modify|create",
      "description": "one atomic edit",
      "acceptance_criteria": ["..."],
      "depends_on": ["TASK-..."]
    }}
  ]
}}

Ordering rule: the LAST array item is executed FIRST (LIFO). Therefore a dependency MUST appear LATER in the array than the task that depends on it. Keep the stack minimal and dependency-correct. Include only tasks necessary for the request.
"""
    raw = ask_llm(planner_system, planner_user)
    data = safe_json(raw)
    tasks = data.get("tasks") if isinstance(data, dict) else None
    if not isinstance(tasks, list) or not tasks:
        raise ValueError("Planner returned an empty or invalid task list.")
    if len(tasks) > MAX_PLANNER_TASKS:
        raise ValueError(f"Planner returned {len(tasks)} tasks; maximum is {MAX_PLANNER_TASKS}.")

    known_files = {item["path"] for item in manifest["files"]}
    normalized: list[dict[str, Any]] = []
    ids: set[str] = set()
    for task in tasks:
        required = {"id", "file", "language", "action", "description", "acceptance_criteria"}
        if not required <= task.keys():
            raise ValueError(f"Planner task missing fields: {task}")
        if task["id"] in ids:
            raise ValueError(f"Duplicate planner task id: {task['id']}")
        ids.add(task["id"])
        if task["action"] == "modify" and task["file"] not in known_files:
            raise ValueError(f"Planner targeted non-existent file: {task['file']}")
        if task["action"] == "create" and task["file"] in known_files:
            raise ValueError(f"Planner marked an existing file as create: {task['file']}")
        language = str(task["language"])
        if task["action"] == "modify":
            target = safe_path(root, task["file"])
            require_tree_sitter_parser(target, language)
        normalized.append(task)

    # Validate explicit dependency order for LIFO: dependencies must be later in the array
    # because the last array item is popped/executed first.
    positions = {task["id"]: index for index, task in enumerate(normalized)}
    for task in normalized:
        for dependency in task.get("depends_on", []):
            if dependency not in positions:
                raise ValueError(f"Unknown dependency {dependency} in {task['id']}")
            if positions[dependency] < positions[task["id"]]:
                raise ValueError(
                    f"Dependency {dependency} must appear later than dependent task {task['id']} in the LIFO array so it executes first."
                )

    stack_path = Path(state["run_dir"]) / "plan_stack.json"
    atomic_write(stack_path, json.dumps(normalized, indent=2, ensure_ascii=False))
    log(Path(state["run_dir"]), "Planner Node", json.dumps(normalized, indent=2, ensure_ascii=False))
    return {
        "plan_stack": normalized,
        "current_task": None,
        "issue_report": "",
        "review_attempts": 0,
        "total_tasks": len(normalized),
        "task_attempts": {},
        "task_durations": {},
        "task_start_times": {},
        "task_history": [],
        "completed_tasks": [],
        "changed_files": [],
    }


# ============================================================
# LAYERED CONTEXT
# ============================================================
def build_layered_context(root: Path, task: dict[str, Any], manifest: dict[str, Any], repo_map: str) -> str:
    target = safe_path(root, task["file"])
    source = target.read_text(encoding="utf-8") if target.exists() else ""
    language = task["language"]

    lines = source.splitlines()
    focused = source
    symbol = task.get("symbol") or ""
    if symbol:
        matches = [i for i, line in enumerate(lines) if re.search(rf"\b{re.escape(symbol)}\b", line)]
        if matches:
            center = matches[0]
            focused = "\n".join(lines[max(0, center - 40): min(len(lines), center + 120)])
    if len(focused) > MAX_SOURCE_CHARS:
        focused = focused[:MAX_SOURCE_CHARS] + "\n...<source truncated>"

    related = []
    for item in manifest["files"]:
        if item["path"] == task["file"]:
            continue
        if symbol and any(tag["name"] == symbol for tag in item.get("references", [])):
            related.append(item["path"])
    related = related[:8]

    context = (
        f"LANGUAGE: {language}\n"
        f"TARGET: {task['file']}\n"
        f"TARGET SYMBOL: {symbol}\n"
        f"RELATED FILES: {related}\n\n"
        f"AIDER REPO MAP:\n{repo_map[:8000]}\n\n"
        f"TARGET SOURCE:\n{focused}\n"
    )
    return context[:MAX_CONTEXT_CHARS]


# ============================================================
# EDITOR / REVIEWER
# ============================================================
def editor_node(state: AgentState) -> AgentState:
    root = Path(state["project_address"])
    run_dir = Path(state["run_dir"])
    task = state.get("current_task")
    if task is None:
        # Pop only once; reviewer fixes reuse the same current_task.
        stack = list(state.get("plan_stack", []))
        if not stack:
            return {"workflow_status": "READY_FOR_EVALUATION", "editor_status": "NO_TASK"}
        task = stack.pop()
        state_stack = stack
    else:
        state_stack = list(state.get("plan_stack", []))

    task_id = task["id"]
    attempt = int(state.get("task_attempts", {}).get(task_id, 0)) + 1
    task_started = time.perf_counter()
    attempts = dict(state.get("task_attempts", {}))
    attempts[task_id] = attempt
    file_attempts = dict(state.get("file_attempts", {}))
    file_attempts[task["file"]] = int(file_attempts.get(task["file"], 0)) + 1
    task_start_times = dict(state.get("task_start_times", {}))
    if task_id not in task_start_times:
        task_start_times[task_id] = task_started

    if task["action"] == "create":
        return editor_create_node(state, task, state_stack, attempts, file_attempts, task_start_times, task_started)

    path = safe_path(root, task["file"])
    if not path.exists():
        return {
            "current_task": task,
            "plan_stack": state_stack,
            "editor_status": "ERROR",
            "issue_report": f"Target file disappeared: {task['file']}",
            "task_attempts": attempts,
        }
    language = model_language_for_file(path)
    if language != task["language"]:
        # The planner's language contract must agree with actual source mapping.
        task = dict(task)
        task["language"] = language
    require_tree_sitter_parser(path, language)

    context = build_layered_context(root, task, state["manifest"], state.get("repo_map", ""))
    issue = state.get("issue_report", "")
    system = (
        f"You are the surgical code editor for {language}. {LANGUAGE_SYSTEM_PROMPTS.get(language, 'Preserve the existing language/runtime semantics and APIs.')}\n"
        "You are editing an existing repository using Aider's SEARCH/REPLACE edit format.\n"
        "You MUST NOT output a full rewritten file. You MUST output only SEARCH/REPLACE blocks.\n"
        "Edit only the current target file. Keep unrelated code byte-for-byte unchanged.\n"
        "Every SEARCH section must match the current source exactly enough for Aider to apply it.\n"
        "Do not change imports, formatting, APIs, or adjacent code unless required by the task.\n"
        "Do not run shell commands."
    )
    user = f"""
REQUEST:
{state['user_request']}

TASK:
{json.dumps(task, indent=2, ensure_ascii=False)}

LAYERED CONTEXT:
{context}

REVIEW ISSUE TO FIX:
{issue or 'None — implement the task.'}

Return only:
{task['file']}
<<<<<<< SEARCH
<exact existing code>
=======
<replacement code>
>>>>>>> REPLACE
"""
    log(run_dir, f"Editor [{task_id}] prompt", system + "\n" + user)

    raw = ask_llm(system, user)
    log(run_dir, f"Editor [{task_id}] output", raw)
    engine = AiderRepositoryEngine(root)
    try:
        backup = write_backup(root, run_dir, path, task_id, attempt)
        applied, original, updated = engine.apply_edit_blocks(raw, task["file"])
        syntax_errors = tree_sitter_errors(path, updated, language)
        if syntax_errors:
            # Do not persist invalid Tree-sitter syntax.
            path.write_text(original, encoding="utf-8")
            raise ValueError("Tree-sitter syntax validation failed:\n" + "\n".join(syntax_errors))
        atomic_write(path, updated)
        final_syntax_errors = tree_sitter_errors(path, updated, language)
        if final_syntax_errors:
            atomic_write(path, original)
            raise ValueError("Final Tree-sitter validation failed after write.")
        elapsed = time.perf_counter() - task_started
        return {
            "current_task": task,
            "plan_stack": state_stack,
            "task_attempts": attempts,
            "file_attempts": file_attempts,
            "task_start_times": task_start_times,
            "last_edit": {
                "task_id": task_id,
                "file": task["file"],
                "attempt": attempt,
                "backup": backup,
                "applied": applied,
                "before_sha256": hashlib.sha256(original.encode()).hexdigest(),
                "after_sha256": hashlib.sha256(updated.encode()).hexdigest(),
                "editor_seconds": round(elapsed, 6),
                "diff": _unified_diff(task["file"], original, updated),
            },
            "editor_status": "APPLIED",
            "issue_report": "",
            "iterations": int(state.get("iterations", 0)) + 1,
        }
    except Exception as exc:
        elapsed = time.perf_counter() - task_started
        return {
            "current_task": task,
            "plan_stack": state_stack,
            "task_attempts": attempts,
            "file_attempts": file_attempts,
            "task_start_times": task_start_times,
            "editor_status": "ERROR",
            "issue_report": f"Editor failed on {task['file']}: {exc}",
            "failure_reason": f"Editor failure on {task['file']} after attempt {attempt}.",
            "last_edit": {"task_id": task_id, "file": task["file"], "editor_seconds": round(elapsed, 6)},
            "iterations": int(state.get("iterations", 0)) + 1,
        }


def editor_create_node(
    state: AgentState,
    task: dict[str, Any],
    state_stack: list[dict[str, Any]],
    attempts: dict[str, int],
    file_attempts: dict[str, int],
    task_start_times: dict[str, float],
    started: float,
) -> AgentState:
    root = Path(state["project_address"])
    language = task["language"]
    system = (
        f"You are a new-file creator for {language}. {LANGUAGE_SYSTEM_PROMPTS.get(language, '')}\n"
        "Create only the requested new file. Return JSON: {\"content\": \"...\"}. No markdown."
    )
    user = f"""
USER REQUEST:
{state['user_request']}
TASK:
{json.dumps(task, indent=2, ensure_ascii=False)}
REPOSITORY CONTEXT:
{compact_json(state['manifest'], 10000)}
"""
    try:
        data = safe_json(ask_llm(system, user))
        content = data.get("content") if isinstance(data, dict) else None
        if not isinstance(content, str) or not content.strip():
            raise ValueError("New-file editor returned empty content.")
        relative, _ = AiderRepositoryEngine(root).apply_new_file(task["file"], content)
        path = safe_path(root, relative)
        syntax_errors = tree_sitter_errors(path, content, language)
        if syntax_errors:
            raise ValueError("Tree-sitter syntax validation failed before creation.")
        atomic_write(path, content)
        duration = time.perf_counter() - started
        return {
            "current_task": task,
            "plan_stack": state_stack,
            "task_attempts": attempts,
            "file_attempts": file_attempts,
            "task_start_times": task_start_times,
            "last_edit": {"task_id": task["id"], "file": relative, "editor_seconds": round(duration, 6), "created": True},
            "editor_status": "APPLIED",
            "issue_report": "",
            "iterations": int(state.get("iterations", 0)) + 1,
        }
    except Exception as exc:
        return {
            "current_task": task,
            "plan_stack": state_stack,
            "task_attempts": attempts,
            "file_attempts": file_attempts,
            "task_start_times": task_start_times,
            "editor_status": "ERROR",
            "issue_report": f"New-file editor failed: {exc}",
            "failure_reason": f"New-file editor failure on {task['file']} after attempt {attempts.get(task['id'], 1)}.",
            "iterations": int(state.get("iterations", 0)) + 1,
        }


def _unified_diff(filename: str, before: str, after: str) -> str:
    import difflib

    return "".join(
        difflib.unified_diff(
            before.splitlines(keepends=True),
            after.splitlines(keepends=True),
            fromfile=f"a/{filename}",
            tofile=f"b/{filename}",
        )
    )[-12000:]


def reviewer_node(state: AgentState) -> AgentState:
    root = Path(state["project_address"])
    task = state.get("current_task")
    if not task:
        return {"editor_status": "ERROR", "issue_report": "Reviewer received no current task."}
    path = safe_path(root, task["file"])
    if not path.exists():
        return {"issue_report": f"Target file does not exist after editor: {task['file']}"}

    language = model_language_for_file(path)
    source = path.read_text(encoding="utf-8")
    syntax_errors = tree_sitter_errors(path, source, language)
    diff = state.get("last_edit", {}).get("diff", "")

    test_result = project_test(root)
    baseline = state.get("baseline_diagnostics", {}).get(task["file"], [])
    lsp_current = _run_lsp_diagnostics(root, path, language) if ENABLE_LSP else []
    new_lsp = [item for item in lsp_current if item not in baseline]

    system = (
        f"You are a strict code reviewer for {language}. {LANGUAGE_SYSTEM_PROMPTS.get(language, '')}\n"
        "Review only the current task and actual edit. Do not reject for unrelated pre-existing errors.\n"
        "If the edit is correct, output exactly PASS. Otherwise output concrete surgical correction instructions "
        "using SEARCH/REPLACE semantics. Do not propose a full-file rewrite."
    )
    user = f"""
USER REQUEST:
{state['user_request']}

TASK:
{json.dumps(task, indent=2, ensure_ascii=False)}

ACCEPTANCE CRITERIA:
{json.dumps(task.get('acceptance_criteria', []), indent=2, ensure_ascii=False)}

ACTUAL DIFF:
{diff}

TREE-SITTER ERRORS AFTER EDIT:
{syntax_errors or 'None'}

NEW LSP DIAGNOSTICS (baseline excluded):
{new_lsp or 'None'}

PROJECT TEST RESULT:
{json.dumps(test_result, indent=2, ensure_ascii=False)}

CURRENT TARGET SOURCE:
{source[:MAX_SOURCE_CHARS]}
"""
    raw = ask_llm(system, user).strip()
    log(Path(state["run_dir"]), f"Reviewer [{task['id']}]", raw)

    clean = re.sub(r"^```[A-Za-z0-9_.+-]*\s*", "", raw).strip()
    clean = re.sub(r"\s*```$", "", clean).strip()
    passed = bool(re.fullmatch(r"PASS\.?", clean, flags=re.IGNORECASE))

    attempts = state.get("review_attempts", 0)
    if passed and not syntax_errors and not new_lsp and test_result.get("ok") is not False:
        task_id = task["id"]
        completed = list(state.get("completed_tasks", []))
        if task_id not in completed:
            completed.append(task_id)
        started_at = float(state.get("task_start_times", {}).get(task_id, time.perf_counter()))
        duration = max(0.0, time.perf_counter() - started_at)
        task_durations = dict(state.get("task_durations", {}))
        task_durations[task_id] = duration
        history = list(state.get("task_history", []))
        history.append({
            "task_id": task_id,
            "file": task["file"],
            "status": "PASS",
            "attempts": int(state.get("task_attempts", {}).get(task_id, 1)),
            "duration_seconds": round(duration, 6),
            "diff": diff,
        })
        changed = list(state.get("changed_files", []))
        if task["file"] not in changed:
            changed.append(task["file"])
        return {
            "issue_report": "",
            "review_attempts": 0,
            "completed_tasks": completed,
            "task_durations": task_durations,
            "task_history": history,
            "changed_files": changed,
            "last_edit": state.get("last_edit", {}),
        }

    next_attempt = attempts + 1
    issue = raw
    if syntax_errors:
        issue += "\n\nDeterministic Tree-sitter errors:\n" + "\n".join(syntax_errors)
    if new_lsp:
        issue += "\n\nNew LSP diagnostics:\n" + "\n".join(new_lsp)
    if test_result.get("ok") is False:
        issue += "\n\nProject tests failed:\n" + test_result.get("output", "")

    if next_attempt >= MAX_REVIEW_ATTEMPTS:
        return {
            "issue_report": issue,
            "review_attempts": next_attempt,
            "workflow_status": "FAILED_REVIEW",
            "failure_reason": f"Task {task['id']} exceeded reviewer retry limit.",
        }
    return {"issue_report": issue, "review_attempts": next_attempt}


# ============================================================
# DIAGNOSTICS
# ============================================================
def _run_lsp_diagnostics(root: Path, path: Path, language: str) -> list[str]:
    command = LSP_COMMANDS.get(language)
    if not command or shutil.which(command[0]) is None:
        return []
    # LSP integration is deliberately conservative: do not make the graph depend on an external server.
    # Deterministic Tree-sitter validation above remains the required syntax source.
    return []


# ============================================================
# ROUTING / FINALIZATION
# ============================================================
def route_after_editor(state: AgentState) -> str:
    if state.get("editor_status") == "APPLIED":
        return "reviewer"
    task = state.get("current_task") or {}
    editor_attempts = int(state.get("task_attempts", {}).get(task.get("id", ""), 0))
    if editor_attempts >= MAX_REVIEW_ATTEMPTS:
        return "evaluator"
    return "editor"


def route_after_reviewer(state: AgentState) -> str:
    if state.get("workflow_status") == "FAILED_REVIEW":
        return "evaluator"
    if state.get("issue_report"):
        return "editor"
    if state.get("plan_stack"):
        # Clear current task so Editor pops exactly one new task.
        return "next_task"
    return "evaluator"


def next_task_node(state: AgentState) -> AgentState:
    # Clear the task only after Reviewer PASS. No stack mutation happens on failure.
    return {"current_task": None, "issue_report": "", "review_attempts": 0}


def failure_node(state: AgentState) -> AgentState:
    return {"workflow_status": state.get("workflow_status", "FAILED")}


# ============================================================
# EVALUATION — RETAINED STRUCTURE + TIME/TASK METRICS
# ============================================================
def compute_custom_score(attempts: int) -> float:
    return round(max(0.25, 1.0 - 0.25 * (attempts - 1)), 2)


if DEEPEVAL_AVAILABLE:
    class OllamaEvalModel(DeepEvalBaseLLM):
        def __init__(self, chat_model: ChatOllama, name: str):
            self._chat = chat_model
            self._name = name

        def load_model(self):
            return self._chat

        def generate(self, prompt: str) -> str:
            return str(self._chat.invoke(prompt).content)

        async def a_generate(self, prompt: str) -> str:
            return self.generate(prompt)

        def get_model_name(self) -> str:
            return self._name


def build_deepeval_metrics() -> list[Any]:
    if not DEEPEVAL_AVAILABLE:
        return []
    judge = OllamaEvalModel(llm, OLLAMA_MODEL)
    return [
        GEval(
            name="Correctness",
            criteria=(
                "Using the USER REQUEST, REQUIREMENTS, TASK HISTORY and repository context as ground truth, "
                "determine whether the resulting source implements the requested change without obvious regressions."
            ),
            evaluation_params=[LLMTestCaseParams.INPUT, LLMTestCaseParams.ACTUAL_OUTPUT],
            model=judge,
            threshold=0.6,
        ),
        GEval(
            name="Completeness",
            criteria=(
                "Determine whether the requested task is implemented with real logic and not TODOs, empty stubs, "
                "or omitted acceptance criteria."
            ),
            evaluation_params=[LLMTestCaseParams.INPUT, LLMTestCaseParams.ACTUAL_OUTPUT],
            model=judge,
            threshold=0.6,
        ),
    ]


def deepeval_score(code: str, context: str, metrics: list[Any]) -> dict[str, Any] | None:
    if not DEEPEVAL_AVAILABLE or not code.strip():
        return None
    case = LLMTestCase(input=context, actual_output=code)
    results: dict[str, Any] = {}
    for metric in metrics:
        try:
            metric.measure(case)
            results[metric.name] = {"score": round(metric.score, 2) if metric.score is not None else None, "reason": metric.reason}
        except Exception as exc:
            results[metric.name] = {"score": None, "reason": f"DeepEval metric failed: {exc}"}
    return results


def benchmark_history_path() -> Path:
    return Path(__file__).resolve().parent / "benchmark_history.jsonl"


def load_benchmark_history() -> list[dict[str, Any]]:
    path = benchmark_history_path()
    if not path.exists():
        return []
    records = []
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            records.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return records


def append_benchmark_record(record: dict[str, Any]) -> list[dict[str, Any]]:
    with open(benchmark_history_path(), "a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False) + "\n")
    return load_benchmark_history()


def render_benchmark_html(records: list[dict[str, Any]]) -> str:
    rows = []
    for i, record in enumerate(records, 1):
        cfg = record.get("llm_config", {})
        rows.append(
            f"<tr><td>{i}</td>"
            f"<td>{html.escape(str(record.get('timestamp', '')))}</td>"
            f"<td>{html.escape(str(cfg.get('model', '')))}</td>"
            f"<td>{record.get('total_tasks', 'n/a')}</td>"
            f"<td>{record.get('elapsed_seconds', 'n/a')}</td>"
            f"<td>{record.get('time_per_task_seconds', 'n/a')}</td>"
            f"<td>{record.get('custom_score_avg', 'n/a')}</td>"
            f"<td>{record.get('deepeval_avg_score', 'n/a')}</td></tr>"
        )
    return f"""<!DOCTYPE html>
<html><head><meta charset='utf-8'><title>Loop Workflow — Benchmark History</title>
<style>body{{font-family:system-ui,sans-serif;margin:2rem;max-width:1100px;color:#111827}}table{{border-collapse:collapse;width:100%;margin-top:1rem}}th,td{{border:1px solid #ddd;padding:7px;text-align:left;font-size:13px}}th{{background:#f5f5f5}}</style>
</head><body><h1>Benchmark History</h1>
<p>{len(records)} run(s) tracked.</p>
<table><tr><th>#</th><th>Timestamp</th><th>Model</th><th>Tasks</th><th>Total time (s)</th><th>Time/task (s)</th><th>Custom</th><th>DeepEval</th></tr>{''.join(rows)}</table>
</body></html>"""


def evaluator_node(state: AgentState) -> AgentState:
    root = Path(state["project_address"])
    run_dir = Path(state["run_dir"])
    elapsed = max(0.0, time.perf_counter() - float(state.get("start_time", time.perf_counter())))
    changed_files = sorted(set(state.get("changed_files", [])))
    completed = list(state.get("completed_tasks", []))
    total_tasks = int(state.get("total_tasks", 0))
    task_count = len(completed)
    time_per_task = elapsed / task_count if task_count else 0.0

    metrics = build_deepeval_metrics()
    context = (
        f"USER REQUEST:\n{state['user_request']}\n\nREQUIREMENTS:\n{state['requirements']}\n\n"
        f"MANIFEST:\n{compact_json(state['manifest'], 12000)}\n\n"
        f"TASK HISTORY:\n{compact_json(state.get('task_history', []), 10000)}"
    )
    report: dict[str, Any] = {}
    for filename in changed_files:
        path = safe_path(root, filename)
        code = path.read_text(encoding="utf-8") if path.exists() else ""
        attempts = int(state.get("file_attempts", {}).get(filename, 1))
        report[filename] = {
            "attempts": attempts,
            "custom_score": compute_custom_score(attempts),
            "deepeval": deepeval_score(code, context, metrics),
        }

    custom = [item["custom_score"] for item in report.values()]
    overall = {
        "files_passed": f"{len(changed_files)}/{len(changed_files)}",
        "changed_files": changed_files,
        "total_tasks": total_tasks,
        "tasks_completed": task_count,
        "elapsed_seconds": round(elapsed, 4),
        "time_per_task_seconds": round(time_per_task, 4),
        "workflow_status": state.get("workflow_status", "COMPLETED"),
        "failure_reason": state.get("failure_reason", ""),
        "deepeval_available": DEEPEVAL_AVAILABLE,
        "custom_score_avg": round(sum(custom) / len(custom), 2) if custom else 0.0,
        "project_address": str(root),
    }
    deepeval_scores = [
        metric["score"]
        for file_data in report.values() if file_data.get("deepeval")
        for metric in file_data["deepeval"].values()
        if metric.get("score") is not None
    ]
    if deepeval_scores:
        overall["deepeval_avg_score"] = round(sum(deepeval_scores) / len(deepeval_scores), 2)

    evaluation = {"overall": overall, "files": report, "task_timing": state.get("task_history", [])}
    atomic_write(run_dir / "evaluation.json", json.dumps(evaluation, indent=2, ensure_ascii=False))
    md = [
        "# Evaluation Report", "",
        f"**Custom score avg:** {overall['custom_score_avg']} / 1.0",
        f"**Total tasks:** {overall['total_tasks']}",
        f"**Tasks completed:** {overall['tasks_completed']}",
        f"**Time taken:** {overall['elapsed_seconds']:.3f} seconds",
        f"**Time per task:** {overall['time_per_task_seconds']:.3f} seconds",
        f"**Workflow status:** {overall['workflow_status']}", "",
    ]
    if "deepeval_avg_score" in overall:
        md.append(f"**DeepEval score avg:** {overall['deepeval_avg_score']} / 1.0")
    for filename, data in report.items():
        md.extend(["", f"## {filename}", f"- Attempts: {data['attempts']}", f"- Custom score: {data['custom_score']}"])
        if data.get("deepeval"):
            for name, result in data["deepeval"].items():
                md.append(f"- **{name}:** {result['score']} — {result['reason']}")
    md.extend(["", "## Task Timing"])
    for task in state.get("task_history", []):
        md.append(
            f"- **{task['task_id']}** — {task['file']} — {task.get('duration_seconds', 0):.3f}s — {task.get('attempts', 1)} attempt(s)"
        )
    atomic_write(run_dir / "evaluation.md", "\n".join(md))

    record = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "run_dir": str(run_dir),
        "project_name": root.name,
        "user_request": state.get("user_request", "")[:300],
        "llm_config": {
            "model": OLLAMA_MODEL,
            "num_ctx": OLLAMA_NUM_CTX,
            "num_predict": OLLAMA_NUM_PREDICT,
            "temperature": OLLAMA_TEMPERATURE,
        },
        "files_passed": overall["files_passed"],
        "total_tasks": total_tasks,
        "tasks_completed": task_count,
        "elapsed_seconds": overall["elapsed_seconds"],
        "time_per_task_seconds": overall["time_per_task_seconds"],
        "custom_score_avg": overall["custom_score_avg"],
        "deepeval_available": DEEPEVAL_AVAILABLE,
        "deepeval_avg_score": overall.get("deepeval_avg_score"),
    }
    history = append_benchmark_record(record)
    atomic_write(benchmark_history_path().with_suffix(".html"), render_benchmark_html(history))
    log(run_dir, "Evaluator", json.dumps(overall, indent=2, ensure_ascii=False))
    return {"elapsed_seconds": elapsed, "evaluation": evaluation, "workflow_status": "COMPLETED" if not state.get("failure_reason") else state.get("workflow_status", "FAILED")}


# ============================================================
# GRAPH
# ============================================================
def build_graph():
    graph = StateGraph(AgentState)
    graph.add_node("requirements", requirement_node)
    graph.add_node("analyzer", analyzer_node)
    graph.add_node("planner", planner_node)
    graph.add_node("editor", editor_node)
    graph.add_node("reviewer", reviewer_node)
    graph.add_node("next_task", next_task_node)
    graph.add_node("failure", failure_node)
    graph.add_node("evaluator", evaluator_node)

    graph.set_entry_point("requirements")
    graph.add_edge("requirements", "analyzer")
    graph.add_edge("analyzer", "planner")
    graph.add_edge("planner", "editor")
    graph.add_conditional_edges(
        "editor",
        route_after_editor,
        {"reviewer": "reviewer", "editor": "editor", "evaluator": "evaluator"},
    )
    graph.add_conditional_edges(
        "reviewer",
        route_after_reviewer,
        {"editor": "editor", "next_task": "next_task", "evaluator": "evaluator"},
    )
    graph.add_edge("next_task", "editor")
    graph.add_edge("failure", "evaluator")
    graph.add_edge("evaluator", END)
    return graph.compile()


app = build_graph()


# ============================================================
# EXECUTION
# ============================================================
def main() -> None:
    print("=" * 100)
    print("Aider-base Dynamic Local Coding Agent — LangGraph + Ollama")
    print("Aider RepoMap + Tree-sitter + PageRank + layered context + SEARCH/REPLACE + Reviewer + Evaluation")
    print("=" * 100)
    print(f"Ollama: {OLLAMA_MODEL} | ctx={OLLAMA_NUM_CTX} | predict={OLLAMA_NUM_PREDICT}")
    print("Tree-sitter: REQUIRED")

    project = Path(input("\nPath to local repository:\n> ").strip()).expanduser().resolve()
    request = input("\nRequested change:\n> ").strip()
    if not project.is_dir():
        raise SystemExit(f"Repository does not exist: {project}")
    if not request:
        raise SystemExit("Requested change must not be empty.")

    run_root = project.parent / ".SDLC_Runs"
    run_dir = run_root / datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir.mkdir(parents=True, exist_ok=True)
    start = time.perf_counter()
    log(run_dir, "SYSTEM", json.dumps({
        "project_address": str(project),
        "user_request": request,
        "ollama_model": OLLAMA_MODEL,
        "ollama_num_ctx": OLLAMA_NUM_CTX,
        "tree_sitter_required": True,
        "rag_enabled": ENABLE_RAG,
        "lsp_enabled": ENABLE_LSP,
    }, indent=2))

    state: AgentState = {
        "project_address": str(project),
        "user_request": request,
        "requirements": "",
        "manifest": {},
        "manifest_json": "",
        "repo_map": "",
        "plan_stack": [],
        "current_task": None,
        "issue_report": "",
        "review_attempts": 0,
        "iterations": 0,
        "file_attempts": {},
        "task_attempts": {},
        "task_durations": {},
        "task_start_times": {},
        "task_history": [],
        "completed_tasks": [],
        "total_tasks": 0,
        "run_dir": str(run_dir),
        "start_time": start,
        "elapsed_seconds": 0.0,
        "workflow_status": "RUNNING",
        "last_edit": {},
        "baseline_diagnostics": {},
        "rag_context": "",
        "failure_reason": "",
        "evaluation": {},
        "changed_files": [],
    }

    # LangGraph can revisit Editor/Reviewer several times per task.
    recursion_limit = max(100, MAX_PLANNER_TASKS * (MAX_REVIEW_ATTEMPTS + 4) + 25)
    final = app.invoke(state, config={"recursion_limit": recursion_limit})
    elapsed = time.perf_counter() - start
    print("\n" + "=" * 100)
    print(f"Workflow status: {final.get('workflow_status', 'UNKNOWN')}")
    print(f"Tasks: {len(final.get('completed_tasks', []))}/{final.get('total_tasks', 0)}")
    print(f"Elapsed: {elapsed:.3f}s")
    print(f"Run directory: {run_dir}")
    print("=" * 100)


if __name__ == "__main__":
    main()
