PLAYBOOK feature:
- Follow the style, naming and structure of the surrounding code.
- Reuse existing helpers instead of adding new dependencies.
- Handle empty input and error cases the same way nearby code does.
