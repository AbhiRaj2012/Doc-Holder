Web: keep HTML tags balanced and valid, reuse existing class names and CSS variables, keep scripts free of inline handlers if the project avoids them, no external URLs or CDNs.
