Java: keep package and import lines correct, match access modifiers and naming of the class, declare checked exceptions, no new dependencies.
