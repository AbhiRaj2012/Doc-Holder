Python: 4-space indent, keep type hints and docstring style already used, no new third-party imports, keep imports at the top.
