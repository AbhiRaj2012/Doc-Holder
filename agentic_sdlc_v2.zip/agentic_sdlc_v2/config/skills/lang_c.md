C: keep declarations in headers and definitions in sources in sync, keep include guards, free what you allocate, check return values, no new dependencies.
