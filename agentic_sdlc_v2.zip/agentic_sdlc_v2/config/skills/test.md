PLAYBOOK test:
- Write tests that pin down the current or required behaviour with concrete inputs and expected outputs.
- Test through the public interface. No network, no real clock, no randomness.
- Each test must fail if the behaviour breaks.
