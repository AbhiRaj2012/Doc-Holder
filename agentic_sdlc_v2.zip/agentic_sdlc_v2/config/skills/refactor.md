PLAYBOOK refactor:
- Behaviour must not change. Existing tests must still pass unchanged.
- Move or rename in small steps and update every caller you can see.
