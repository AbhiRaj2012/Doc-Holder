JavaScript/TypeScript: match the module style (ESM or CommonJS) already used, keep semicolon and quote style, no new packages.
