PLAYBOOK bugfix:
- Find the root cause in the named code before editing. Fix the cause, not the symptom.
- Change as few lines as possible. Keep public signatures unchanged.
- If a failing test or error text is given, make exactly that pass without weakening it.
