C++: match the project's standard level, prefer RAII and references over raw owning pointers, keep header declarations and source definitions in sync, no new dependencies.
