PLAYBOOK scaffold:
- Create only the files named in the task, with minimal working content.
- Keep entry points runnable and imports resolvable.
- No placeholder bodies: every function you add must do real work.
