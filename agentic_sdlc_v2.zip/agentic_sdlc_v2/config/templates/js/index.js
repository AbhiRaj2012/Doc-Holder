'use strict';

function main() {
  console.log('ready');
}

main();
