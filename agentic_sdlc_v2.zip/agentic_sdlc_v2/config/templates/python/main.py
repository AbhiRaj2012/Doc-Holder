import sys


def main(argv: list[str] | None = None) -> int:
    args = sys.argv[1:] if argv is None else argv
    print("ready", *args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
