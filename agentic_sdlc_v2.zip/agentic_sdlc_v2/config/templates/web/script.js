'use strict';

document.addEventListener('DOMContentLoaded', () => {
  const app = document.getElementById('app');
  app.dataset.ready = 'true';
});
