Return the complete new content of every file you change, and nothing else.

Format (path on its own line, then the full file in one fenced block):
path/to/file.ext
```
<entire file content>
```

Rules:
- Include the whole file, unchanged parts too.
- Edit only the files listed under FILES TO EDIT.
