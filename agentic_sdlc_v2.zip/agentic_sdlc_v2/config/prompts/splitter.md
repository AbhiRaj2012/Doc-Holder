A development task was too large for the model's context budget. Split it into 2 to 4 smaller tasks that together achieve the same result.

Rules:
- Output JSON only, matching the schema.
- Each subtask targets a single file and, when useful, a single symbol (function, class, rule).
- Keep the parent's language and kind. Give every subtask its own 1 to 3 acceptance criteria.
- Order subtasks so each can be completed and verified before the next.
- Do not add work beyond the parent task.
