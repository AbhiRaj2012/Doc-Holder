TASK {{id}}: {{title}}
Language: {{language}}   Kind: {{kind}}

{{description}}

ACCEPTANCE CRITERIA:
{{criteria}}

{{scope}}
{{related}}
{{issues}}
{{edit_error}}
{{playbook}}
{{repo_slice}}
Make the smallest change that satisfies the criteria. Do not touch anything unrelated.
