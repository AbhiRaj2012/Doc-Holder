#!/usr/bin/env bash
# Run ONCE on a machine with internet, same OS/arch/Python as the air-gapped target.
# Produces deploy/wheelhouse, deploy/aider_wheelhouse, deploy/tiktoken_cache. Copy the whole project folder to the target.
set -euo pipefail
cd "$(dirname "$0")/.."
PY="${PYTHON:-python3.12}"
AIDER_VERSION="${AIDER_VERSION:-0.86.2}"

mkdir -p deploy/wheelhouse deploy/aider_wheelhouse deploy/tiktoken_cache
"$PY" -m pip download --dest deploy/wheelhouse pip setuptools wheel
"$PY" -m pip download --dest deploy/wheelhouse -r requirements.in
"$PY" -m pip download --dest deploy/aider_wheelhouse pip setuptools wheel "aider-chat==${AIDER_VERSION}"

"$PY" -m venv /tmp/sdlc_bundle_venv
/tmp/sdlc_bundle_venv/bin/pip install --no-index --find-links deploy/wheelhouse -r requirements.in
/tmp/sdlc_bundle_venv/bin/pip freeze > deploy/requirements.lock
TIKTOKEN_CACHE_DIR="$PWD/deploy/tiktoken_cache" DATA_GYM_CACHE_DIR="$PWD/deploy/tiktoken_cache" \
  /tmp/sdlc_bundle_venv/bin/python -c "import tiktoken; [tiktoken.get_encoding(n) for n in ('o200k_base','cl100k_base')]"
rm -rf /tmp/sdlc_bundle_venv
echo "bundle ready: $(du -sh deploy | cut -f1)"
echo "Toolchains (gcc/g++/make/cmake, JDK/maven/gradle, node/npm) are installed by the OS package manager; add the .deb/.rpm files you need to deploy/os_packages/."
