#!/usr/bin/env bash
# Run on the air-gapped machine. Never touches the network.
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT="$PWD"
PY="${PYTHON:-python3.12}"

[ -d deploy/wheelhouse ] || { echo "deploy/wheelhouse missing: run deploy/build_bundle.sh on a connected machine first" >&2; exit 1; }

if ls deploy/os_packages/*.deb >/dev/null 2>&1; then
  dpkg -i deploy/os_packages/*.deb || echo "warning: some OS packages failed to install" >&2
fi

"$PY" -m venv .venv
.venv/bin/pip install --no-index --find-links deploy/wheelhouse pip setuptools wheel
.venv/bin/pip install --no-index --find-links deploy/wheelhouse -r requirements.in
.venv/bin/pip install --no-index --no-deps -e .

if [ -d deploy/aider_wheelhouse ]; then
  "$PY" -m venv deploy/aider_venv
  deploy/aider_venv/bin/pip install --no-index --find-links deploy/aider_wheelhouse pip setuptools wheel
  deploy/aider_venv/bin/pip install --no-index --find-links deploy/aider_wheelhouse "aider-chat==${AIDER_VERSION:-0.86.2}"
  AIDER_BIN="$ROOT/deploy/aider_venv/bin/aider" .venv/bin/python - <<'PYEOF'
import os, re
from pathlib import Path
p = Path("config/settings.yaml")
text = p.read_text()
text = re.sub(r"(?m)^(  binary:).*$", lambda m: f"{m.group(1)} {os.environ['AIDER_BIN']}", text, count=1)
p.write_text(text)
PYEOF
fi

.venv/bin/python deploy/selftest.py
cat <<MSG

Installed. Start:
  .venv/bin/streamlit run sdlc/ui/streamlit_app.py --server.headless true --browser.gatherUsageStats false
  .venv/bin/python -m sdlc preflight
MSG
