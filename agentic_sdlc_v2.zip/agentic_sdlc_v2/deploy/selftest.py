from __future__ import annotations

import importlib
import json
import shutil
import socket
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

failures = 0


def check(ok: bool | None, text: str) -> None:
    global failures
    print(("[ok]   " if ok else "[warn] " if ok is None else "[FAIL] ") + text)
    failures += ok is False


for mod in ("langgraph", "langgraph.checkpoint.sqlite", "pydantic", "yaml", "httpx", "deepeval", "streamlit", "tiktoken"):
    try:
        importlib.import_module(mod)
        check(True, f"import {mod}")
    except Exception as exc:
        check(False, f"import {mod}: {exc}")

from sdlc.core import offline_env
from sdlc.core.config import load_settings

settings = load_settings()
offline_env.apply(settings.tiktoken_dir(), settings.ollama.base_url)
try:
    import tiktoken

    tiktoken.get_encoding("o200k_base")
    check(True, "tiktoken encoding loads from the local cache")
except Exception as exc:
    check(None, f"tiktoken cache unavailable, token counts fall back to estimates: {exc}")

try:
    offline_env.assert_local_url("http://example.com:11434")
    check(False, "non-local Ollama URL was accepted")
except Exception:
    check(True, "non-local Ollama URL is refused")

if offline_env.netns_available():
    probe = "import socket,sys\ntry:\n    socket.create_connection(('1.1.1.1',53),timeout=2)\nexcept OSError:\n    sys.exit(0)\nsys.exit(1)"
    r = subprocess.run([*offline_env.sandbox_prefix(True), sys.executable, "-c", probe], capture_output=True)
    check(r.returncode == 0, "sandbox (unshare -rn) blocks network access")
else:
    check(None, "unshare -rn unavailable: verify commands run without a network namespace")

for tool in ("git",):
    check(shutil.which(tool) is not None, f"{tool} installed")
for tool in ("gcc", "g++", "make", "javac", "mvn", "gradle", "node", "npm"):
    check(True if shutil.which(tool) else None, f"{tool} {'found' if shutil.which(tool) else 'not installed (only needed for projects in that language)'}")

aider = settings.aider.binary
check(True if (shutil.which(aider) or Path(aider).exists()) else None, f"aider binary: {aider}")

with tempfile.TemporaryDirectory() as td:
    from sdlc.adapters.git_ops import GitRepo

    g = GitRepo(Path(td))
    (Path(td) / "a.txt").write_text("x")
    try:
        g.ensure_repo()
        g.commit_all("selftest")
        check(True, "git commit works")
    except Exception as exc:
        check(False, f"git commit failed: {exc}")

print(json.dumps({"failures": failures}))
sys.exit(1 if failures else 0)
