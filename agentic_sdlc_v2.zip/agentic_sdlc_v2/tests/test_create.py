from __future__ import annotations

import json
from pathlib import Path

from sdlc.adapters.ollama_client import LLMResponse
from sdlc.cli import main as cli
from sdlc.core.config import load_settings
from sdlc.create import agents, checks
from sdlc.create.graph import make_runtime, run_create
from sdlc.create.project import new_project
from sdlc.create.schemas import Blueprint, FileSpec, Requirements, ReviewIssue, Verdict
from sdlc.evals.run_evals import evaluate_run_dir

from .helpers import FakeClient

REQ = Requirements(title="Calc", description="A calculator.", functional=["add two numbers", "print the result"])
CALC = "def add(a, b):\n    return a + b\n"
MAIN = "from calc import add\n\n\nif __name__ == '__main__':\n    print(add(2, 3))\n"


def bp(files=None, entry="main.py", lang="python"):
    return Blueprint(project_name="calc", language=lang, summary="adds numbers", entry=entry, files=files or [
        FileSpec(path="main.py", purpose="entry point", provides=["main"], depends_on=["calc.py"]),
        FileSpec(path="calc.py", purpose="math", provides=["add(a, b)"]),
    ])


class Fake(FakeClient):
    def __init__(self, files: dict[str, list[str]], **kw):
        super().__init__(**kw)
        self.files = {k: list(v) for k, v in files.items()}
        self.writes: list[str] = []

    def chat(self, node, messages, **kw):
        user = messages[-1]["content"]
        path = user.split("FILE TO WRITE: ", 1)[1].split("\n", 1)[0].strip()
        self.writes.append(path)
        q = self.files[path]
        text = q.pop(0) if len(q) > 1 else q[0]
        return LLMResponse(text=f"```\n{text}```", prompt_tokens=10, completion_tokens=10)


def env(tmp_path, fake):
    s = load_settings(overrides={"features": {"plan_approval": False}, "paths": {"projects_root": str(tmp_path / "projects"), "benchmark_dir": str(tmp_path / "bench")},
                                 "limits": {"max_iterations_per_task": 3}, "evals": {"llm_metrics": False}})
    project = new_project(s, "calc", "r1")
    return s, project, make_runtime(s, project, "r1", client=fake)


def events(rt):
    return [json.loads(x) for x in (rt.run_dir / "events.jsonl").read_text().splitlines()]


def test_normalise_orders_and_cleans():
    b, notes = agents.normalise(bp([
        FileSpec(path="./app/main.py", purpose="m", depends_on=["app/util.py", "missing.py"]),
        FileSpec(path="app\\util.py", purpose="u"), FileSpec(path="../x.py", purpose="bad"), FileSpec(path="app/util.py", purpose="dup"),
    ], entry="app/main.py"), 10)
    assert [f.path for f in b.files] == ["app/util.py", "app/main.py"] and b.files[1].depends_on == ["app/util.py"]
    assert b.entry == "app/main.py" and any("../x.py" in n for n in notes)


def test_python_project_completes_and_evaluates(tmp_path):
    fake = Fake({"main.py": [MAIN], "calc.py": [CALC]}, Requirements=REQ, Blueprint=bp(), Verdict=Verdict(passed=True))
    s, project, rt = env(tmp_path, fake)
    summary = run_create(rt, "a calculator")
    assert summary["final_status"] == "completed" and summary["verify_ok"] and summary["mode"] == "create"
    assert fake.writes == ["calc.py", "main.py"]
    assert (project.code / "main.py").read_text() == MAIN
    log = rt.git.run("log", "--oneline")
    assert "calc.py" in log and "main.py" in log
    types = [e["type"] for e in events(rt)]
    assert "plan_ready" in types and "verify" in types and types.count("task_end") == 2
    results, _ = evaluate_run_dir(s, rt.run_dir, log=lambda m: None)
    assert {r.name for r in results} >= {"plan_quality", "task_completion"} and (tmp_path / "bench" / "benchmark.jsonl").exists()


def test_syntax_error_retried_and_review_patch_applied(tmp_path):
    bad = "def add(a, b)\n    return a + b\n"
    wrong = "def add(a, b):\n    return a - b\n"
    verdicts = [Verdict(passed=False, issues=[ReviewIssue(problem="subtracts", find="a - b", replace="a + b")]), Verdict(passed=True)]
    fake = Fake({"main.py": [MAIN], "calc.py": [bad, wrong]}, Requirements=REQ, Blueprint=bp(), Verdict=verdicts)
    s, project, rt = env(tmp_path, fake)
    summary = run_create(rt, "a calculator")
    assert (project.code / "calc.py").read_text() == CALC
    assert fake.writes.count("calc.py") == 2 and summary["tasks_completed"] == 2
    assert summary["task_stats"]["T1"]["iterations"] == 2


def test_orphan_file_sends_entry_back_for_fix(tmp_path):
    lonely = "def add(a, b):\n    return a + b\n"
    first_main = "print('hi')\n"
    fake = Fake({"main.py": [first_main, MAIN], "calc.py": [lonely]}, Requirements=REQ, Blueprint=bp(), Verdict=Verdict(passed=True))
    s, project, rt = env(tmp_path, fake)
    summary = run_create(rt, "a calculator")
    v = [e for e in events(rt) if e["type"] == "verify"]
    assert not v[0]["ok"] and "never used" in v[0]["problems"]["main.py"][0] and v[-1]["ok"]
    assert summary["final_status"] == "completed" and fake.writes.count("main.py") == 2


def test_review_limit_keeps_file_and_reports(tmp_path):
    fake = Fake({"main.py": [MAIN], "calc.py": [CALC]}, Requirements=REQ, Blueprint=bp(),
                Verdict=Verdict(passed=False, issues=[ReviewIssue(problem="needs docstring")]))
    s, project, rt = env(tmp_path, fake)
    summary = run_create(rt, "a calculator")
    assert summary["final_status"] == "partial" and summary["tasks_skipped"] == 2
    assert (project.code / "calc.py").exists() and (rt.run_dir / "run_explanation.json").exists()


def test_web_project(tmp_path):
    files = [FileSpec(path="index.html", purpose="page", provides=["#out"], depends_on=["style.css", "script.js"]),
             FileSpec(path="style.css", purpose="style"), FileSpec(path="script.js", purpose="logic")]
    html = "<!DOCTYPE html>\n<html><head><link rel='stylesheet' href='style.css'></head><body><div id='out'></div><script src='script.js'></script></body></html>\n"
    fake = Fake({"index.html": [html], "style.css": ["body { margin: 0; }\n"], "script.js": ["document.getElementById('out').textContent = 'hi';\n"]},
                Requirements=REQ, Blueprint=bp(files, entry="index.html", lang="web"), Verdict=Verdict(passed=True))
    s, project, rt = env(tmp_path, fake)
    summary = run_create(rt, "a page")
    assert summary["final_status"] == "completed" and fake.writes[-1] == "index.html"
    assert checks.file_language("script.js", "web") == "web" and checks.file_language("a.h", "c") == "c"


def test_cli_create(tmp_path, monkeypatch):
    fake = Fake({"main.py": [MAIN], "calc.py": [CALC]}, Requirements=REQ, Blueprint=bp(), Verdict=Verdict(passed=True))
    s = load_settings(overrides={"features": {"plan_approval": False}, "paths": {"projects_root": str(tmp_path / "projects"), "benchmark_dir": str(tmp_path / "bench")}, "evals": {"llm_metrics": False}})
    cfg = tmp_path / "settings.json"
    cfg.write_text(s.model_dump_json())
    monkeypatch.setattr(cli, "make_create_runtime", lambda settings, project, run_id: make_runtime(settings, project, run_id, client=fake))
    lines: list[str] = []
    code = cli.main(["--config", str(cfg), "create", "--name", "calc", "--request", "a calculator", "--run-id", "r9"], out=lines.append, ask=lambda p: "")
    text = "\n".join(lines)
    assert code == 0 and "completed" in text and "task_completion" in text
    assert json.loads(next((tmp_path / "projects").rglob("eval_status.json")).read_text())["state"] == "done"


class Chunked(Fake):
    def chat(self, node, messages, **kw):
        user = messages[-1]["content"]
        path = user.split("FILE TO WRITE: ", 1)[1].split("\n", 1)[0].strip()
        self.writes.append(path)
        self.kw = kw
        if path != "calc.py":
            return LLMResponse(text=f"```\n{MAIN}```")
        if "cut off" not in user:
            return LLMResponse(text="```python\ndef add(a, b):\n", done_reason="length")
        return LLMResponse(text="```python\ndef add(a, b):\n    return a + b\n```")


def test_truncated_file_is_continued(tmp_path):
    fake = Chunked({}, Requirements=REQ, Blueprint=bp(), Verdict=Verdict(passed=True))
    s, project, rt = env(tmp_path, fake)
    summary = run_create(rt, "a calculator")
    assert (project.code / "calc.py").read_text() == CALC and summary["final_status"] == "completed"
    assert fake.writes.count("calc.py") == 2 and fake.kw.get("think") is False


def test_join_continuation_drops_overlap():
    assert agents.join_continuation("a\nb\nc\n", "```\nb\nc\nd\n```") == "a\nb\nc\nd\n"
    assert agents.extract_code("```js\nlet x = 1;\n") == "let x = 1;\n"


def test_same_problem_twice_stops_file(tmp_path):
    fake = Fake({"main.py": [MAIN], "calc.py": [CALC]}, Requirements=REQ, Blueprint=bp(),
                Verdict=Verdict(passed=False, issues=[ReviewIssue(problem="needs docstring")]))
    s, project, rt = env(tmp_path, fake)
    run_create(rt, "a calculator")
    assert fake.writes.count("calc.py") == 2 and any(e["type"] == "repeat_problem" for e in events(rt))


def test_identical_verify_problems_stop(tmp_path):
    fake = Fake({"main.py": ["print('hi')\n"], "calc.py": [CALC]}, Requirements=REQ, Blueprint=bp(), Verdict=Verdict(passed=True))
    s, project, rt = env(tmp_path, fake)
    summary = run_create(rt, "a calculator")
    rounds = [e for e in events(rt) if e["type"] == "verify"]
    assert len(rounds) == 2 and summary["final_status"] == "partial"


def test_duplicate_definition_rejected_then_fixed(tmp_path):
    dup = CALC + "\n\ndef add(a, b):\n    return 0\n"
    fake = Fake({"main.py": [MAIN], "calc.py": [dup, CALC]}, Requirements=REQ, Blueprint=bp(), Verdict=Verdict(passed=True))
    s, project, rt = env(tmp_path, fake)
    summary = run_create(rt, "a calculator")
    assert (project.code / "calc.py").read_text() == CALC and summary["final_status"] == "completed"
    assert any("DUPLICATE" in (e.get("feedback") or "") for e in events(rt) if e["type"] == "review")


def test_dependency_noted_not_failed(tmp_path):
    main = "import nopkg_zzz\nfrom calc import add\n\n\nif __name__ == '__main__':\n    print(add(2, 3))\n"
    fake = Fake({"main.py": [main], "calc.py": [CALC]}, Requirements=REQ, Blueprint=bp(), Verdict=Verdict(passed=True))
    s, project, rt = env(tmp_path, fake)
    summary = run_create(rt, "a calculator")
    assert summary["final_status"] == "completed" and "nopkg_zzz" in (project.code / "requirements.txt").read_text()


def test_cpp_template_fixed_build_file(tmp_path):
    main = "#include \"calc.h\"\n#include <iostream>\n\nint main()\n{\n    std::cout << add(1, 2) << std::endl;\n    return 0;\n}\n"
    hdr = "#pragma once\nint add(int a, int b);\n"
    impl = "#include \"calc.h\"\n\nint add(int a, int b)\n{\n    return a + b;\n}\n"
    files = [FileSpec(path="src/calc.h", purpose="decl", provides=["add"]), FileSpec(path="src/calc.cpp", purpose="impl", depends_on=["src/calc.h"]),
             FileSpec(path="src/main.cpp", purpose="entry", depends_on=["src/calc.h"])]
    fake = Fake({"src/main.cpp": [main], "src/calc.h": [hdr], "src/calc.cpp": [impl]}, Requirements=REQ,
                Blueprint=bp(files, entry="src/main.cpp", lang="cpp"), Verdict=Verdict(passed=True))
    s, project, rt = env(tmp_path, fake)
    summary = run_create(rt, "calc", "cpp")
    cm = (project.code / "CMakeLists.txt").read_text()
    assert "GLOB_RECURSE" in cm and "calc" in cm and "CMakeLists.txt" not in fake.writes
    assert any(t["target_files"] == ["CMakeLists.txt"] and t["status"] == "completed" for t in summary["tasks"])


def test_web_template_is_starting_point(tmp_path):
    files = [FileSpec(path="index.html", purpose="page", depends_on=["style.css", "script.js"]), FileSpec(path="style.css", purpose="style"), FileSpec(path="script.js", purpose="logic")]
    html = "<!DOCTYPE html>\n<html><head><link rel='stylesheet' href='style.css'></head><body><main id='app'></main><script src='script.js'></script></body></html>\n"
    fake = Fake({"index.html": [html], "style.css": ["#app { margin: 0; }\n"], "script.js": ["document.getElementById('app').textContent = 'hi';\n"]},
                Requirements=REQ, Blueprint=bp(files, entry="index.html", lang="web"), Verdict=Verdict(passed=True))
    seen = []
    orig = fake.chat

    def spy(node, messages, **kw):
        seen.append(messages[-1]["content"])
        return orig(node, messages, **kw)

    fake.chat = spy
    s, project, rt = env(tmp_path, fake)
    run_create(rt, "page", "web")
    assert any("STARTING POINT" in m and "DOMContentLoaded" in m for m in seen)
