from __future__ import annotations

import json

import httpx

from sdlc.adapters.ollama_client import OllamaClient
from sdlc.core.command_policy import CommandPolicy
from sdlc.core.config import load_settings
from sdlc.ui import live_model as lm

from .helpers import PY_FILES
from .test_graph import Env, client, calc, task_draft, write


def ev(seq, type_, **kw):
    return {"ts": 1000.0 + seq, "seq": seq, "type": type_, **kw}


def test_active_node_and_waiting_model():
    events = [ev(1, "node_start", node="plan"), ev(2, "node", node="plan", output={"tasks": ["T1: x"]}), ev(3, "node_start", node="edit", task_id="T1", iteration=2),
              ev(4, "llm_start", node="editor", model="m", prompt_tokens_est=900, effort="low")]
    snap = lm.snapshot(events, now=1010.0)
    assert snap["node"] == "edit" and snap["waiting_model"]["since"] == 6.0 and snap["task_id"] == "T1" and snap["iteration"] == 2
    events += [ev(5, "llm_call", node="editor", prompt_tokens=900, completion_tokens=50), ev(6, "node", node="edit")]
    snap = lm.snapshot(events, now=1012.0)
    assert snap["node"] == "" and snap["waiting_model"] is None and snap["tokens"] == 950
    assert lm.done_nodes(events) == {"plan", "edit"}
    assert "Edit code" in lm.strip_html("review", {"edit"})


def test_short_id_and_rows():
    assert lm.short_id("T1") == "T1" and lm.short_id("T1.2") == "T1.2"
    long = "T1" + ".1" * 40
    assert lm.short_id(long).startswith("T1.1…+") and len(lm.short_id(long)) < 20
    rows = lm.task_rows([{"id": "T0", "status": "completed", "title": "a"}, {"id": long, "status": "in_progress", "title": "b", "parent_id": "x"}])
    assert "hidden" in rows[0]["task"] and "in_progress" in rows[1]["status"]


def test_timeline_hides_noise():
    lines = lm.timeline([ev(1, "llm_call"), ev(2, "task_start", task_id="T1", title="t", source="task", action="start", shrink_level=0)])
    assert len(lines) == 1 and "start T1" in lines[0]


def test_reasoning_exhaustion_retry():
    calls = []

    def handler(req: httpx.Request) -> httpx.Response:
        body = json.loads(req.content)
        calls.append(body)
        if len(calls) == 1:
            return httpx.Response(200, json={"message": {"content": "", "thinking": "hmm" * 50}, "done_reason": "length", "eval_count": 100})
        return httpx.Response(200, json={"message": {"content": "done"}, "done_reason": "stop"})

    events, starts = [], []
    c = OllamaClient(load_settings(), transport=httpx.MockTransport(handler), on_call=events.append, on_start=starts.append)
    resp = c.chat("planner", [{"role": "user", "content": "x"}], max_tokens=1000)
    assert resp.text == "done" and not resp.truncated
    assert calls[1]["think"] == "low" and calls[1]["options"]["num_predict"] == 2000
    assert [e["retry"] for e in events] == [False, True] and len(starts) == 2 and events[0]["thinking_chars"] == 150


def test_not_a_check_verify_command(tmp_path):
    pol = CommandPolicy(tmp_path, "cpp")
    res = pol.check("cat src/a.h")
    assert not res.ok and res.kind == "not_a_check"
    r = pol.resolve_verify("cat src/a.h", None)
    assert r.command is None and not r.needs_human and r.source == "none"
    assert pol.resolve_verify("cat a.h", "make test").command == "make test"


def test_split_depth_guard_goes_to_gate(tmp_path):
    from sdlc.agents.splitter import SplitPlan, SubTask
    from sdlc.graph.human_gate import decision
    from .test_graph import truncated

    split = SplitPlan(subtasks=[
        SubTask(title="part one", target_files=["calc.py"], acceptance_criteria=["a"]),
        SubTask(title="part two", target_files=["calc.py"], acceptance_criteria=["b"]),
    ])
    env = Env(tmp_path, client(SplitPlan=split), lambda r: [truncated], overrides={"limits": {"max_split_depth": 1}})
    st = env.run()
    assert not st.done and st.interrupt["reason"] == "cannot_split"
    refused = [e for e in env.events() if e["type"] == "split_refused"]
    assert refused and refused[0]["task_id"] == "T1.1"
    assert sum(1 for e in env.events() if e["type"] == "task_split") == 1
    assert any(e["type"] == "node_start" for e in env.events()) and any(e["type"] == "node" and "output" in e for e in env.events())
    env.resume(decision("abort"))


def test_plan_uses_whole_format_for_missing_file(tmp_path):
    from sdlc.adapters.edit_types import EditRequest
    from sdlc.adapters.editor_backend import HybridEditor
    from sdlc.adapters.git_ops import GitRepo

    (tmp_path / "a.py").write_text("x = 1\n")
    ed = HybridEditor(load_settings(), None, GitRepo(tmp_path), use_aider=False)
    req = lambda f: EditRequest(repo=tmp_path, files=f, message="m", run_dir=tmp_path, tag="t")
    assert ed.plan(req(["new.py"]), 0) == ("native", "whole")
    assert ed.plan(req(["a.py"]), 0) == ("native", "diff")


def test_aider_without_tokens_is_disabled(tmp_path):
    from sdlc.adapters.edit_types import EditRequest
    from sdlc.adapters.editor_backend import HybridEditor
    from sdlc.adapters.git_ops import GitRepo
    from sdlc.core.schemas import EditResult

    (tmp_path / "a.py").write_text("x = 1\n")
    ed = HybridEditor(load_settings(), None, GitRepo(tmp_path), use_aider=False)
    ed.use_aider = True

    class Dead:
        def edit(self, req):
            return EditResult(ok=False, error="aider exited with code 1", stdout_tail="Traceback\nValueError: bad flag", edit_format="aider-diff")

    class Native:
        def edit(self, req):
            return EditResult(ok=True, edit_format="native-diff", tokens_in=5)

    ed.aider, ed.native = Dead(), Native()
    req = EditRequest(repo=tmp_path, files=["a.py"], message="m", run_dir=tmp_path, tag="t")
    ed.edit(req, 0)
    assert ed.just_disabled and not ed.use_aider and "bad flag" in ed.disabled_reason
    assert ed.plan(req, 0)[0] == "native"


def test_edit_ladder_suspends_once_then_gate(tmp_path):
    from sdlc.core.schemas import EditResult
    from sdlc.graph.human_gate import decision
    from .test_graph import Scripted

    def bad(repo):
        return EditResult(ok=False, error="no SEARCH/REPLACE blocks (or file sections) found in the model output", edit_format="native-diff")

    env = Env(tmp_path, client(), lambda r: [bad], overrides={"limits": {"max_iterations_per_task": 20}})
    st = env.run()
    assert not st.done and st.interrupt["reason"] == "suspend_limit"
    ev = env.events()
    assert sum(1 for e in ev if e["type"] == "task_suspended") == 1
    refused = [e for e in ev if e["type"] == "suspend_refused"]
    assert refused and "does not fix" in refused[0]["why"]
    calls = [e for e in ev if e["type"] == "tool_call" and e.get("tool") == "apply_edit"]
    assert calls and "no SEARCH/REPLACE" in calls[0]["error"]
    env.resume(decision("abort"))


def test_build_flags_and_baseline_gate(tmp_path):
    from sdlc.runners.c_cpp_runner import CCppRunner
    from sdlc.runners.base import Runner

    (tmp_path / "CMakeLists.txt").write_text("project(x)\n")
    (tmp_path / "a.cpp").write_text("int main(){}\n")
    r = CCppRunner(tmp_path)
    assert "$(nproc)" not in r.commands()["build"] and "{jobs}" in r.commands()["build"]
    assert "{jobs}" not in r.render(r.commands()["build"], [])


def test_run_all_ignores_preexisting_build_failure(tmp_path):
    from sdlc.runners.python_runner import PythonRunner

    (tmp_path / "a.py").write_text("x = 1\n")
    r = PythonRunner(tmp_path)
    r.commands = lambda: {"build": "python3 -c \"import sys; sys.exit(3)\""}  # type: ignore[method-assign]
    r.enabled = lambda kind: True  # type: ignore[method-assign]
    blocked = r.run_all(["a.py"])
    assert any(c.name == "build" and not c.ok for c in blocked)
    relaxed = r.run_all(["a.py"], ignore_build_failure="exit 3")
    build = next(c for c in relaxed if c.name == "build")
    assert build.ok and build.skipped and "already failed" in build.output_tail


def test_no_change_after_rejection_goes_to_gate(tmp_path):
    from sdlc.core.schemas import EditResult
    from sdlc.graph.human_gate import decision

    calls = {"n": 0}

    def act(repo):
        calls["n"] += 1
        if calls["n"] == 1:
            (repo / "calc.py").write_text("def add(a, b):\n    return a - b\n\n\nclass Calc:\n    def mul(self, a, b):\n        return a * b\n# touched\n")
            return EditResult(ok=True, files_changed=["calc.py"], blocks_applied=1, edit_format="native-diff")
        return EditResult(ok=True, files_changed=[], blocks_applied=1, edit_format="native-diff")

    env = Env(tmp_path, client(), lambda r: [act], overrides={"limits": {"max_iterations_per_task": 20}})
    st = env.run()
    assert not st.done and st.interrupt["reason"] == "no_progress"
    assert any(e["type"] == "no_change_loop" for e in env.events())
    env.resume(decision("abort"))


def test_editor_reasoning_off_sends_think_false():
    calls = []

    def handler(req: httpx.Request) -> httpx.Response:
        calls.append(json.loads(req.content))
        return httpx.Response(200, json={"message": {"content": "ok"}, "done_reason": "stop"})

    c = OllamaClient(load_settings(), transport=httpx.MockTransport(handler))
    c.chat("editor", [{"role": "user", "content": "x"}])
    assert calls[0]["think"] is False
