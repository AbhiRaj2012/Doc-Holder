from __future__ import annotations

from typing import Any

from sdlc.adapters.ollama_client import LLMResponse

PY_FILES = {
    "pyproject.toml": "[project]\nname='x'\ndependencies=['requests>=2']\n",
    "requirements.txt": "flask==2.0\n# c\n",
    "calc.py": "def add(a, b):\n    return a - b\n\n\nclass Calc:\n    def mul(self, a, b):\n        return a * b\n",
    "main.py": "from calc import add\n\n\ndef main():\n    print(add(1, 2))\n",
    "test_calc.py": "from calc import add\n\n\ndef test_add():\n    assert add(1, 2) == 3\n    assert add(-1, -2) == -3\n",
}


class FakeClient:
    def __init__(self, **responses: Any):
        self.responses = {k: list(v) if isinstance(v, list) else [v] for k, v in responses.items()}
        self.calls: list[tuple[str, list[dict[str, str]]]] = []

    def structured(self, node, messages, model_cls, **kw):
        self.calls.append((model_cls.__name__, messages))
        queue = self.responses[model_cls.__name__]
        item = queue.pop(0) if len(queue) > 1 else queue[0]
        if isinstance(item, Exception):
            raise item
        return item, LLMResponse(text="")


def fill(node: dict, root: dict, overrides: dict, key: str = "") -> Any:
    if "$ref" in node:
        node = root["$defs"][node["$ref"].split("/")[-1]]
    if "anyOf" in node:
        node = next((n for n in node["anyOf"] if n.get("type") != "null"), node["anyOf"][0])
        return fill(node, root, overrides, key)
    if "enum" in node:
        return node["enum"][0]
    kind = node.get("type")
    if key in overrides:
        return overrides[key]
    if kind == "object":
        return {k: fill(v, root, overrides, k) for k, v in node.get("properties", {}).items()}
    if kind == "array":
        return [fill(node.get("items", {"type": "string"}), root, overrides, key)]
    if kind == "string":
        return "step"
    if kind == "number":
        return 0.85
    if kind == "integer":
        return 1
    if kind == "boolean":
        return True
    return None


def make_schema_judge(overrides: dict | None = None, fail: bool = False):
    from deepeval.models import DeepEvalBaseLLM

    class SchemaJudge(DeepEvalBaseLLM):
        def __init__(self):
            self.overrides, self.fail, self.calls = overrides or {}, fail, []
            super().__init__("schema-judge")

        def load_model(self):
            return self

        def get_model_name(self, *a, **k):
            return "schema-judge"

        def generate(self, prompt, schema=None, **kw):
            self.calls.append(getattr(schema, "__name__", None))
            if self.fail:
                raise RuntimeError("judge down")
            if schema is None:
                return "ok"
            sc = schema.model_json_schema()
            return schema.model_validate(fill(sc, sc, self.overrides))

        async def a_generate(self, prompt, schema=None, **kw):
            return self.generate(prompt, schema=schema)

    return SchemaJudge()
