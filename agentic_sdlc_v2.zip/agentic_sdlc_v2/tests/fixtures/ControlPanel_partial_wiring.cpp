#include "ui/ControlPanel.h"
#include "scope/Units.h"
#include "signals/SignalRegistry.h"
#include <QCheckBox>
#include <QComboBox>
#include <QDoubleSpinBox>
#include <QFormLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QSignalBlocker>
#include <QSlider>
#include <QVBoxLayout>
#include <cmath>

namespace {
constexpr double kFreqMinLog = -1.0;
constexpr double kFreqMaxLog = 6.0;
constexpr int kSliderSteps = 1000;

QList<double> sequence125(double from, double to)
{
    QList<double> out;
    for (double decade = from; decade <= to * 1.0001; decade *= 10.0)
        for (double m : {1.0, 2.0, 5.0}) {
            const double v = decade * m;
            if (v <= to * 1.0001)
                out << v;
        }
    return out;
}

void fillCombo(QComboBox *combo, const QList<double> &values, const QString &unit, double select)
{
    for (double v : values)
        combo->addItem(Units::si(v, unit), v);
    int best = 0;
    for (int i = 0; i < combo->count(); ++i)
        if (std::fabs(combo->itemData(i).toDouble() - select) < std::fabs(combo->itemData(best).toDouble() - select))
            best = i;
    combo->setCurrentIndex(best);
}

QDoubleSpinBox *makeSpin(double min, double max, double value, int decimals, double step, const QString &suffix)
{
    auto *s = new QDoubleSpinBox;
    s->setRange(min, max);
    s->setDecimals(decimals);
    s->setSingleStep(step);
    s->setValue(value);
    s->setSuffix(suffix);
    s->setAccelerated(true);
    return s;
}
}

ControlPanel::ControlPanel(QWidget *parent)
    : QWidget(parent)
{
    setFixedWidth(310);
    auto *layout = new QVBoxLayout(this);
    layout->setContentsMargins(8, 8, 8, 8);
    layout->setSpacing(10);
    layout->addWidget(buildSignalGroup());
    layout->addWidget(buildParamGroup());
    layout->addWidget(buildDisplayGroup());
    layout->addStretch(1);
    layout->addWidget(buildRunGroup());
    onSignalChanged();
}

QWidget *ControlPanel::buildSignalGroup()
{
    auto *box = new QGroupBox(tr("Test Signal"));
    auto *l = new QVBoxLayout(box);
    m_signalCombo = new QComboBox;
    m_signalCombo->addItems(SignalRegistry::instance().names());
    l->addWidget(m_signalCombo);
    connect(m_signalCombo, &QComboBox::currentTextChanged, this, &ControlPanel::onSignalChanged);
    return box;
}

QWidget *ControlPanel::buildParamGroup()
{
    auto *box = new QGroupBox(tr("Signal Parameters"));
    auto *form = new QFormLayout(box);

    m_freq = makeSpin(std::pow(10.0, kFreqMinLog), std::pow(10.0, kFreqMaxLog), 1000.0, 3, 10.0, " Hz");
    m_freqSlider = new QSlider(Qt::Horizontal);
    m_freqSlider->setRange(0, kSliderSteps);

    m_amp = makeSpin(0.0, 100.0, 1.0, 3, 0.1, " V");
    m_offset = makeSpin(-50.0, 50.0, 0.0, 3, 0.1, " V");
    m_phase = makeSpin(-360.0, 360.0, 0.0, 1, 5.0, " °");
    m_duty = makeSpin(1.0, 99.0, 50.0, 1, 1.0, " %");
    m_dutyLabel = new QLabel(tr("Duty cycle"));
    m_dampingFactor = makeSpin(0.0, 1.0, 0.0, 3, 0.01, " ");

    syncSliderToFrequency(m_freq->value());

    form->addRow(tr("Frequency"), m_freq);
    form->addRow(QString(), m_freqSlider);
    form->addRow(tr("Amplitude"), m_amp);
    form->addRow(tr("DC Offset"), m_offset);
    form->addRow(tr("Phase"), m_phase);
    form->addRow(m_dutyLabel, m_duty);
    form->addRow(new QLabel(tr("Damping Factor")), m_dampingFactor);

    auto *autoBtn = new QPushButton(tr("Auto Scale"));
    form->addRow(QString(), autoBtn);
    connect(autoBtn, &QPushButton::clicked, this, &ControlPanel::autoScale);

    connect(m_freq, qOverload<double>(&QDoubleSpinBox::valueChanged), this, &ControlPanel::onFrequencySpin);
    connect(m_freqSlider, &QSlider::valueChanged, this, &ControlPanel::onFrequencySlider);
    for (auto *s : {m_amp, m_offset, m_phase, m_duty})
        connect(s, qOverload<double>(&QDoubleSpinBox::valueChanged), this, &ControlPanel::emitParams);
    return box;
}

QWidget *ControlPanel::buildDisplayGroup()
{
    auto *box = new QGroupBox(tr("Display / Trigger"));
    auto *form = new QFormLayout(box);

    m_timeDiv = new QComboBox;
    fillCombo(m_timeDiv, sequence125(1e-6, 1.0), "s", 200e-6);
    m_voltDiv = new QComboBox;
    fillCombo(m_voltDiv, sequence125(1e-3, 20.0), "V", 0.5);

    m_trigMode = new QComboBox;
    m_trigMode->addItem(tr("Rising Edge"), static_cast<int>(TriggerMode::RisingEdge));
    m_trigMode->addItem(tr("Period Sync"), static_cast<int>(TriggerMode::PeriodSync));
    m_trigMode->addItem(tr("Free Run (roll)"), static_cast<int>(TriggerMode::FreeRun));

    m_trigLevel = makeSpin(-50.0, 50.0, 0.0, 3, 0.05, " V");
    m_persistence = new QCheckBox(tr("Phosphor persistence"));
    m_persistence->setChecked(true);

    form->addRow(tr("Time / div"), m_timeDiv);
    form->addRow(tr("Volts / div"), m_voltDiv);
    form->addRow(tr("Trigger"), m_trigMode);
    form->addRow(tr("Trig level"), m_trigLevel);
    form->addRow(QString(), m_persistence);

    connect(m_timeDiv, qOverload<int>(&QComboBox::currentIndexChanged), this, &ControlPanel::emitDisplay);
    connect(m_voltDiv, qOverload<int>(&QComboBox::currentIndexChanged), this, &ControlPanel::emitDisplay);
    connect(m_trigMode, qOverload<int>(&QComboBox::currentIndexChanged), this, [this] {
        m_trigLevel->setEnabled(m_trigMode->currentData().toInt() == static_cast<int>(TriggerMode::RisingEdge));
        emitDisplay();
    });
    connect(m_trigLevel, qOverload<double>(&QDoubleSpinBox::valueChanged), this, &ControlPanel::emitDisplay);
    connect(m_persistence, &QCheckBox::toggled, this, &ControlPanel::emitDisplay);
    return box;
}

QWidget *ControlPanel::buildRunGroup()
{
    auto *w = new QWidget;
    auto *l = new QHBoxLayout(w);
    l->setContentsMargins(0, 0, 0, 0);
    m_runBtn = new QPushButton(tr("▶  RUN"));
    m_stopBtn = new QPushButton(tr("■  STOP"));
    m_runBtn->setObjectName("runButton");
    m_stopBtn->setObjectName("stopButton");
    m_runBtn->setMinimumHeight(42);
    m_stopBtn->setMinimumHeight(42);
    m_stopBtn->setEnabled(false);
    l->addWidget(m_runBtn);
    l->addWidget(m_stopBtn);
    connect(m_runBtn, &QPushButton::clicked, this, &ControlPanel::runRequested);
    connect(m_stopBtn, &QPushButton::clicked, this, &ControlPanel::stopRequested);
    return w;
}

void ControlPanel::setRunning(bool running)
{
    m_runBtn->setEnabled(!running);
    m_stopBtn->setEnabled(running);
}

QString ControlPanel::currentSignal() const
{
    return m_signalCombo->currentText();
}

SignalParams ControlPanel::params() const
{
    SignalParams p;
    p.frequency = m_freq->value();
    p.amplitude = m_amp->value();
    p.offset = m_offset->value();
    p.phaseDeg = m_phase->value();
    p.dutyCycle = m_duty->value() / 100.0;
    return p;
}

DisplaySettings ControlPanel::display() const
{
    DisplaySettings d;
    d.timePerDiv = m_timeDiv->currentData().toDouble();
    d.voltsPerDiv = m_voltDiv->currentData().toDouble();
    d.trigger = static_cast<TriggerMode>(m_trigMode->currentData().toInt());
    d.triggerLevel = m_trigLevel->value();
    d.persistence = m_persistence->isChecked();
    return d;
}

void ControlPanel::onSignalChanged()
{
    const SignalGenerator *g = SignalRegistry::instance().get(currentSignal());
    const bool duty = g && g->usesDutyCycle();
    m_duty->setVisible(duty);
    m_dutyLabel->setVisible(duty);
    emit signalSelected(currentSignal());
}

void ControlPanel::onFrequencySlider(int pos)
{
    const double logF = kFreqMinLog + (kFreqMaxLog - kFreqMinLog) * pos / kSliderSteps;
    const double hz = std::pow(10.0, logF);
    {
        QSignalBlocker block(m_freq);
        m_freq->setValue(hz);
    }
    emitParams();
}

void ControlPanel::onFrequencySpin(double hz)
{
    syncSliderToFrequency(hz);
    emitParams();
}

void ControlPanel::syncSliderToFrequency(double hz)
{
    const double logF = std::log10(std::max(hz, 1e-9));
    const int pos = static_cast<int>(std::lround((logF - kFreqMinLog) / (kFreqMaxLog - kFreqMinLog) * kSliderSteps));
    {
        QSignalBlocker block(m_freqSlider);
        m_freqSlider->setValue(pos);
    }
}

void ControlPanel::emitParams()
{
    emit paramsChanged(params());
}

void ControlPanel::emitDisplay()
{
    emit displayChanged(display());
}

void ControlPanel::autoScale()
{
    const SignalParams p = params();
    const double targetSpan = 2.5 / std::max(p.frequency, 1e-9);
    const double peak = std::max({std::fabs(p.offset + p.amplitude), std::fabs(p.offset - p.amplitude), 1e-3});
    const double targetVdiv = peak / 3.0;

    auto pickAtLeast = [](QComboBox *c, double target) {
        int idx = c->count() - 1;
        for (int i = 0; i < c->count(); ++i)
            if (c->itemData(i).toDouble() >= target) { idx = i; break; }
        return idx;
    };

    {
        QSignalBlocker b1(m_timeDiv), b2(m_voltDiv);
        m_timeDiv->setCurrentIndex(pickAtLeast(m_timeDiv, targetSpan / kDivX));
        m_voltDiv->setCurrentIndex(pickAtLeast(m_voltDiv, targetVdiv));
    }
    {
        QSignalBlocker b(m_trigLevel);
        m_trigLevel->setValue(p.offset);
    }
    emitDisplay();
}
