from __future__ import annotations

from pathlib import Path

from sdlc.agents.planner import PlanDraft
from sdlc.cli import main as cli
from sdlc.core.config import load_settings
from sdlc.create.graph import make_runtime, resume_create, run_create
from sdlc.create.project import new_project
from sdlc.create.schemas import Verdict
from sdlc.graph.builder import current_status
from sdlc.graph.human_gate import plan_decision
from sdlc.graph.runtime import build_runtime

from .test_create import CALC, MAIN, REQ, Fake, bp
from .test_graph import Env, calc, client, task_draft, write


def gated(tmp_path: Path, fake=None, actions=None) -> Env:
    return Env(tmp_path, fake or client([task_draft("T1"), task_draft("T2", title="more", deps=["T1"])]), lambda r: actions or [write("calc.py", calc())],
               overrides={"features": {"plan_approval": True}})


def test_edit_pauses_after_plan_and_approves(tmp_path: Path):
    env = gated(tmp_path)
    st = env.run()
    assert not st.done and st.interrupt["type"] == "approve_plan" and st.interrupt["mode"] == "edit"
    assert [t["id"] for t in st.interrupt["tasks"]] == ["T1", "T2"] and st.interrupt["tasks"][0]["acceptance_criteria"]
    assert "task_start" not in env.types() and env.code.joinpath("calc.py").read_text() != calc()
    st = env.resume(plan_decision("approve"))
    assert st.done and st.state["status"] == "completed"
    assert "plan_approved" in env.types() and env.code.joinpath("calc.py").read_text() == calc()


def test_edit_remove_task_strips_dependencies(tmp_path: Path):
    env = gated(tmp_path)
    env.run()
    st = env.resume(plan_decision("approve", remove=["T1"]))
    assert st.done and [t["id"] for t in st.state["tasks"]] == ["T2"] and st.state["tasks"][0]["depends_on"] == []
    approved = next(e for e in env.events() if e["type"] == "plan_approved")
    assert approved["removed"] == ["T1"] and approved["tasks"] == 1


def test_edit_revise_replans_with_feedback_then_approves(tmp_path: Path):
    second = PlanDraft(summary="v2", assumptions=[], tasks=[task_draft("T1", title="only fix add")])
    fake = client([task_draft("T1"), task_draft("T2", title="more", deps=["T1"])])
    fake.responses["PlanDraft"] = [fake.responses["PlanDraft"][0], second]
    env = gated(tmp_path, fake)
    st = env.run()
    st = env.resume(plan_decision("revise", "one task is enough"))
    assert not st.done and st.interrupt["type"] == "approve_plan" and st.interrupt["round"] == 1
    assert [t["id"] for t in st.interrupt["tasks"]] == ["T1"] and st.interrupt["summary"] == "v2"
    planner_calls = [m for name, m in fake.calls if name == "PlanDraft"]
    assert "one task is enough" in planner_calls[-1][-1]["content"]
    st = env.resume(plan_decision("approve"))
    assert st.done and st.state["status"] == "completed"


def test_edit_abort_stops_before_any_edit(tmp_path: Path):
    env = gated(tmp_path)
    env.run()
    st = env.resume(plan_decision("abort"))
    assert st.done and st.state["status"] == "aborted" and "task_start" not in env.types()


def test_edit_gate_survives_process_restart(tmp_path: Path):
    env = gated(tmp_path)
    env.run()
    env.open()
    st = current_status(env.app, env.run_id)
    assert st.interrupt and st.interrupt["type"] == "approve_plan"
    assert env.resume(plan_decision("approve")).done


def test_edit_gate_off_by_default_setting(tmp_path: Path):
    env = Env(tmp_path, client(), lambda r: [write("calc.py", calc())])
    st = env.run()
    assert st.done and "plan_decision" not in env.types()


def cenv(tmp_path: Path, fake, approval: bool = True):
    s = load_settings(overrides={"features": {"plan_approval": approval}, "paths": {"projects_root": str(tmp_path / "projects"), "benchmark_dir": str(tmp_path / "bench")},
                                 "limits": {"max_iterations_per_task": 3}, "evals": {"llm_metrics": False}})
    project = new_project(s, "calc", "r1")
    return s, project, make_runtime(s, project, "r1", client=fake)


def cfake(**kw):
    return Fake({"main.py": [MAIN], "calc.py": [CALC]}, Requirements=REQ, Blueprint=kw.pop("Blueprint", bp()), Verdict=Verdict(passed=True), **kw)


def test_create_pauses_before_writing_and_approves(tmp_path: Path):
    fake = cfake()
    s, project, rt = cenv(tmp_path, fake)
    from langgraph.checkpoint.memory import MemorySaver

    cp = MemorySaver()
    res = run_create(rt, "a calculator", "", cp)
    assert res["paused"] and res["interrupt"]["type"] == "approve_plan" and res["interrupt"]["mode"] == "create"
    assert [t["title"] for t in res["interrupt"]["tasks"]] == ["Create calc.py", "Create main.py"] and fake.writes == []
    res = resume_create(rt, cp, plan_decision("approve"))
    assert res["final_status"] == "completed" and fake.writes == ["calc.py", "main.py"]


def test_create_remove_file_updates_blueprint(tmp_path: Path):
    from langgraph.checkpoint.memory import MemorySaver

    from sdlc.create.schemas import FileSpec

    files = [FileSpec(path="main.py", purpose="entry", provides=["main"], depends_on=["calc.py"]), FileSpec(path="calc.py", purpose="math", provides=["add(a, b)"]),
             FileSpec(path="notes.txt", purpose="extra notes")]
    fake = Fake({"main.py": [MAIN], "calc.py": [CALC], "notes.txt": ["x\n"]}, Requirements=REQ, Blueprint=bp(files), Verdict=Verdict(passed=True))
    s, project, rt = cenv(tmp_path, fake)
    cp = MemorySaver()
    run_create(rt, "a calculator", "", cp)
    res = resume_create(rt, cp, plan_decision("approve", remove=["notes.txt", "main.py"]))
    assert "notes.txt" not in fake.writes and "main.py" in fake.writes and not (project.code / "notes.txt").exists()
    assert "notes.txt" not in (rt.run_dir / "blueprint.json").read_text() and res["final_status"] in ("completed", "partial")


def test_create_revise_regenerates_blueprint(tmp_path: Path):
    from langgraph.checkpoint.memory import MemorySaver

    from sdlc.create.schemas import FileSpec

    small = bp([FileSpec(path="main.py", purpose="entry with add inline", provides=["main"])])
    fake = cfake()
    fake.responses["Blueprint"] = [bp(), small]
    fake.files["main.py"] = [MAIN.replace("from calc import add\n\n\n", "def add(a, b):\n    return a + b\n\n\n")]
    s, project, rt = cenv(tmp_path, fake)
    cp = MemorySaver()
    res = run_create(rt, "a calculator", "", cp)
    res = resume_create(rt, cp, plan_decision("revise", "single file please"))
    assert res["paused"] and res["interrupt"]["round"] == 1 and [t["title"] for t in res["interrupt"]["tasks"]] == ["Create main.py"]
    bp_calls = [m for name, m in fake.calls if name == "Blueprint"]
    assert "single file please" in bp_calls[-1][-1]["content"] if bp_calls else True
    res = resume_create(rt, cp, plan_decision("approve"))
    assert res["final_status"] == "completed" and fake.writes == ["main.py"]


def test_create_abort(tmp_path: Path):
    from langgraph.checkpoint.memory import MemorySaver

    fake = cfake()
    s, project, rt = cenv(tmp_path, fake)
    cp = MemorySaver()
    run_create(rt, "a calculator", "", cp)
    res = resume_create(rt, cp, plan_decision("abort"))
    assert res["final_status"] == "aborted" and fake.writes == []


def test_cli_create_pause_then_resume(tmp_path: Path, monkeypatch):
    fake = cfake()
    s = load_settings(overrides={"features": {"plan_approval": True}, "paths": {"projects_root": str(tmp_path / "projects"), "benchmark_dir": str(tmp_path / "bench")},
                                 "evals": {"llm_metrics": False}})
    cfg = tmp_path / "settings.json"
    cfg.write_text(s.model_dump_json())
    monkeypatch.setattr(cli, "make_create_runtime", lambda settings, project, run_id: make_runtime(settings, project, run_id, client=fake))
    lines: list[str] = []
    code = cli.main(["--config", str(cfg), "create", "--name", "calc", "--request", "a calculator", "--run-id", "r7", "--non-interactive", "--no-eval"], out=lines.append, ask=lambda p: "")
    text = "\n".join(lines)
    assert code == 3 and "Blueprint awaiting approval" in text and "Create calc.py" in text and fake.writes == []
    lines.clear()
    cli.main(["--config", str(cfg), "status", "r7"], out=lines.append, ask=lambda p: "")
    assert '"type": "approve_plan"' in lines[0]
    lines.clear()
    code = cli.main(["--config", str(cfg), "resume", "r7", "--action", "approve", "--no-eval", "--non-interactive"], out=lines.append, ask=lambda p: "")
    assert code == 0 and "completed" in "\n".join(lines) and fake.writes == ["calc.py", "main.py"]


def test_cli_run_interactive_plan_prompts(tmp_path: Path, monkeypatch):
    env = gated(tmp_path)
    answers = iter(["m", "T1", "a"])
    monkeypatch.setattr(cli, "make_runtime", lambda settings, project, store, run_id, use_aider=True: env.rt)
    cfg = tmp_path / "settings.json"
    cfg.write_text(env.settings.model_dump_json())
    lines: list[str] = []
    code = cli.main(["--config", str(cfg), "run", str(tmp_path / "src"), "--name", "demo", "--requirements", "Fix add", "--run-id", "run1", "--no-eval", "--no-aider"],
                    out=lines.append, ask=lambda p: next(answers))
    text = "\n".join(lines)
    assert "Plan awaiting approval" in text and "T1  fix add" in text and code == 0


def test_ui_plan_panel_submits_decision(tmp_path: Path, monkeypatch):
    from streamlit.testing.v1 import AppTest

    from sdlc.ui import jobs

    sent: list[dict] = []
    info = {"type": "approve_plan", "mode": "edit", "round": 0, "summary": "two steps", "warnings": ["check names"], "requirements": "Fix add",
            "tasks": [{"id": "T1", "title": "fix add", "description": "d", "target_files": ["calc.py"], "acceptance_criteria": ["sum"], "verify_command": "pytest", "depends_on": []},
                      {"id": "T2", "title": "more", "description": "", "target_files": ["calc.py"], "acceptance_criteria": [], "verify_command": "", "depends_on": ["T1"]}]}
    monkeypatch.setattr(jobs, "pending_interrupt", lambda s, p, r: info)
    monkeypatch.setattr(jobs, "start_resume", lambda *a, **k: sent.append(k))
    from sdlc.ui import common

    monkeypatch.setattr(common, "project_of", lambda s, pid: None)

    def app() -> None:
        from sdlc.ui.views import p_gate

        p_gate.panel({"project": "demo", "run_id": "r1", "dir": None})

    at = AppTest.from_function(app).run()
    assert not at.exception
    assert any("Approve the plan" in s.value for s in at.subheader)
    at.multiselect[0].set_value(["T2"]).run()
    next(b for b in at.button if b.label == "Submit").click().run()
    assert sent and sent[0]["action"] == "approve" and sent[0]["remove"] == ["T2"]
