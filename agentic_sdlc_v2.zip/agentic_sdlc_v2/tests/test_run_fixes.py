from pathlib import Path

from sdlc.agents.analyser import looks_like_test
from sdlc.agents.targets import characterization_target
from sdlc.core.command_policy import CommandPolicy
from sdlc.core.schemas import Task
from sdlc.runners import parsers
from sdlc.runners.python_runner import PythonRunner


def _pkg(tmp: Path) -> Path:
    root = tmp / "App"
    (root / "pkg" / "signals").mkdir(parents=True)
    (root / "pkg" / "__init__.py").write_text("")
    (root / "pkg" / "signals" / "__init__.py").write_text("")
    (root / "pkg" / "signals" / "waves.py").write_text("def sine(t):\n    return t\n")
    (root / "main.py").write_text("def main():\n    return 0\n")
    return tmp


def test_characterization_moves_to_new_test_file_at_import_root(tmp_path):
    repo = _pkg(tmp_path)
    t = Task(id="T1", title="Characterize", description="", language="python", kind="test", target_files=["App/main.py"], acceptance_criteria=["x"])
    src, test = characterization_target(repo, t, ["App/pkg/signals/waves.py"], looks_like_test)
    assert src == "App/pkg/signals/waves.py"
    assert test == "App/test_waves.py"


def test_characterization_keeps_existing_test_target(tmp_path):
    repo = _pkg(tmp_path)
    t = Task(id="T1", title="c", description="", language="python", kind="test", target_files=["App/test_x.py"], acceptance_criteria=["x"])
    assert characterization_target(repo, t, [], looks_like_test)[1] == "App/test_x.py"


def test_policy_drops_print_only_steps(tmp_path):
    res = CommandPolicy(tmp_path, "python").check("python -m pytest -q && ls build")
    assert res.ok and "ls" not in res.command and "pytest" in res.command


def test_shell_missing_tool_is_not_a_gate(tmp_path):
    r = PythonRunner(tmp_path).run_kind("test", [], command="python3 -c \"import sys; print(\\\"'ls' is not recognized as an internal or external command,\\\"); sys.exit(1)\"")
    assert r.ok and r.skipped and "ls" in r.output_tail


def test_no_tests_ran_is_not_a_gate(tmp_path):
    (tmp_path / "m.py").write_text("x = 1\n")
    r = PythonRunner(tmp_path).run_all(["m.py"], verify_command="python3 -c \"import sys; print('no tests ran in 0.01s'); sys.exit(5)\"")
    assert r[-1].skipped


def test_warning_lines_are_not_failures():
    out = "C:\\x\\site-packages\\pytest_asyncio\\plugin.py:306: PytestDeprecationWarning: option\nE   AssertionError: 1 != 2\n"
    msgs = " ".join(f.message for f in parsers.pytest(out, "/r") or parsers.generic(out, "test"))
    assert "Warning" not in msgs and "AssertionError" in msgs


def test_python_test_in_unreachable_dir_is_flagged_and_package_not_external(tmp_path):
    from sdlc.core import guards
    repo = _pkg(tmp_path)
    text = "from pkg.signals.waves import sine\n"
    assert any("cannot be imported" in m for m in guards.unresolved_imports(repo, "App/tests/test_w.py", text))
    assert guards.unresolved_imports(repo, "App/test_w.py", text) == []
    assert guards.external_packages(repo, "App/tests/test_w.py", text) == []


def test_planner_moves_unreachable_python_test(tmp_path):
    repo = _pkg(tmp_path)
    t = Task(id="T1", title="c", description="", language="python", kind="test", target_files=["App/tests/test_w.py"], acceptance_criteria=["x"])
    assert characterization_target(repo, t, ["App/pkg/signals/waves.py"], looks_like_test) == ("App/pkg/signals/waves.py", "App/test_w.py")


def test_missing_include_suggests_declaring_header(tmp_path):
    from sdlc.core import guards
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "Waves.h").write_text("class CosineWave { public: double value(double t) const; };\n")
    msgs = guards.unresolved_imports(tmp_path, "test/t.cpp", '#include "cosine_wave.h"\nint main(){ CosineWave c; }\n')
    assert msgs and "src/Waves.h" in msgs[0] and "../src/Waves.h" in msgs[0]


def test_collection_error_is_not_masked_and_missing_package_is_skipped(tmp_path):
    (tmp_path / "m.py").write_text("x = 1\n")
    r = PythonRunner(tmp_path).run_all(["m.py"], verify_command="python3 -c \"import sys; print('collected 0 items / 1 error'); print(\\\"E   ModuleNotFoundError: No module named 'm'\\\"); sys.exit(2)\"")
    assert not r[-1].ok and "ModuleNotFoundError" in r[-1].failures[0].message
    r = PythonRunner(tmp_path).run_all(["m.py"], verify_command="python3 -c \"import sys; print(\\\"E   ModuleNotFoundError: No module named 'numpyx'\\\"); sys.exit(2)\"")
    assert r[-1].skipped and "numpyx" in r[-1].output_tail


def test_new_python_file_is_relocated_to_import_root(tmp_path):
    from sdlc.core import guards
    repo = _pkg(tmp_path)
    assert guards.relocation(repo, "test_w.py", "from pkg.signals.waves import sine\n") == "App/test_w.py"
    assert guards.relocation(repo, "App/test_w.py", "from pkg.signals.waves import sine\n") is None


def test_analysis_only_title_detected():
    from sdlc.agents.planner import ANALYSIS_ONLY
    assert ANALYSIS_ONLY.match("Analyze project structure for adding new signals")
    assert ANALYSIS_ONLY.match("Characterize existing signal behavior") is None
    assert ANALYSIS_ONLY.match("Review and update registry") is None


def test_new_field_next_to_existing_one_needs_wiring(tmp_path):
    from sdlc.agents.analogues import field_wiring
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "params.h").write_text("struct P {\n    double duty = 0.5;\n    double dampingFactor = 0.0;\n};\n")
    (tmp_path / "src" / "wave.cpp").write_text("double f(const P &p){ return p.dampingFactor + p.duty; }\n")
    (tmp_path / "src" / "panel.cpp").write_text("void g(P &p){ p.duty = 1; }\n")
    diff = "diff --git a/src/params.h b/src/params.h\n--- a/src/params.h\n+++ b/src/params.h\n@@ -1,3 +1,4 @@\n struct P {\n     double duty = 0.5;\n+    double dampingFactor = 0.0;\n };\n"
    found = field_wiring(tmp_path, diff, looks_like_test)
    assert found and found[0][1:3] == ("dampingFactor", "duty") and {t.file for t in found[0][3]} >= {"src/panel.cpp"}


def test_package_module_script_is_not_a_verify(tmp_path):
    (tmp_path / "pkg").mkdir()
    (tmp_path / "pkg" / "__init__.py").write_text("")
    (tmp_path / "pkg" / "m.py").write_text("from . import x\n")
    res = CommandPolicy(tmp_path, "python").check("python pkg/m.py")
    assert not res.ok and res.kind == "not_a_check"


def test_missing_python_module_tool_is_skipped(tmp_path):
    r = PythonRunner(tmp_path).run_kind("test", [], command="python3 -m nosuchtoolxyz")
    assert r.skipped and "nosuchtoolxyz" in r.output_tail


def test_task_label_shows_progress():
    from sdlc.ui.live_model import task_label
    tasks = [{"id": "T1", "status": "completed"}, {"id": "T2", "status": "in_progress"}, {"id": "T3", "status": "pending"}]
    assert task_label("T2", tasks, []) == "T2 (2 of 3)"


def test_python_imports_of_missing_names_and_modules_are_rejected_with_suggestion(tmp_path):
    from sdlc.core import guards
    repo = _pkg(tmp_path)
    (repo / "App" / "pkg" / "signals" / "waves.py").write_text("class SineWave:\n    pass\n\n\ndef sine(t):\n    return t\n")
    bad = "from pkg.signals.waves import SineWave, process_signal\nfrom main import SineWave as S\nfrom pkg.signal import SineWave as X\n"
    msgs = guards.unresolved_imports(repo, "App/test_w.py", bad)
    text = " ".join(msgs)
    assert "`process_signal` is not defined in App/pkg/signals/waves.py" in text and "does not exist anywhere" in text
    assert "`SineWave` is not defined in App/main.py; it is in App/pkg/signals/waves.py (from pkg.signals.waves import SineWave)" in text
    assert "no module pkg.signal" in text
    assert guards.unresolved_imports(repo, "App/test_w.py", "from pkg.signals.waves import SineWave, sine\nimport os\n") == []


def test_python_unknown_kwargs_and_attributes_of_local_classes(tmp_path):
    from sdlc.core import guards
    repo = _pkg(tmp_path)
    sig = repo / "App" / "pkg" / "signals"
    (sig / "base.py").write_text("from dataclasses import dataclass\n\n\n@dataclass\nclass Params:\n    frequency: float = 1.0\n    amplitude: float = 1.0\n")
    wave = "from .base import Params\n\n\nclass Damped:\n    def shape(self, t, params: Params):\n        return params.amplitude * params.damping\n"
    msgs = guards.unresolved_imports(repo, "App/pkg/signals/waves.py", wave)
    assert any("`params.damping`: Params has no attribute `damping`" in m for m in msgs)
    test = "from pkg.signals.base import Params\n\n\ndef test_x():\n    Params(frequency=2.0, damping_factor=0.5)\n"
    msgs = guards.unresolved_imports(repo, "App/test_w.py", test)
    assert any("`Params(...)` has no parameter `damping_factor`; it accepts: amplitude, frequency" in m for m in msgs)
    ok = "from pkg.signals.base import Params\n\n\ndef test_x():\n    Params(frequency=2.0)\n"
    assert guards.unresolved_imports(repo, "App/test_w.py", ok) == []


def test_mirror_gaps_find_missing_value_copy_and_signal_list():
    from sdlc.core import guards
    text = (Path(__file__).parent / "fixtures" / "ControlPanel_partial_wiring.cpp").read_text()
    gaps = " ".join(guards.mirror_gaps(text, "dutyCycle", "dampingFactor"))
    assert "p.dutyCycle = m_duty->value()" in gaps and "{m_amp, m_offset, m_phase, m_duty}" in gaps
    fixed = text.replace("for (auto *s : {m_amp, m_offset, m_phase, m_duty})", "for (auto *s : {m_amp, m_offset, m_phase, m_duty, m_dampingFactor})")
    fixed = fixed.replace("    p.dutyCycle = m_duty->value() / 100.0;\n", "    p.dutyCycle = m_duty->value() / 100.0;\n    p.dampingFactor = m_dampingFactor->value();\n")
    assert guards.mirror_gaps(fixed, "dutyCycle", "dampingFactor") == []


def test_placeholder_code_is_detected():
    from sdlc.core import guards
    new = "def f(p):\n    # we use a fixed decay for now\n    k = 0.95\n    return k\n"
    assert guards.placeholders("", new)
    assert guards.placeholders("", "def f(p):\n    return p.k * 2\n") == []


def test_mirror_gap_has_concrete_suggestion():
    from sdlc.core import guards
    text = (Path(__file__).parent / "fixtures" / "ControlPanel_partial_wiring.cpp").read_text()
    gaps = " ".join(guards.mirror_gaps(text, "dutyCycle", "dampingFactor"))
    assert "{m_amp, m_offset, m_phase, m_duty, m_dampingFactor}" in gaps and "p.dampingFactor = m_dampingFactor->value()" in gaps


def test_getattr_default_hides_missing_attribute(tmp_path):
    from sdlc.core import guards
    repo = _pkg(tmp_path)
    sig = repo / "App" / "pkg" / "signals"
    (sig / "base.py").write_text("from dataclasses import dataclass\n\n\n@dataclass\nclass Params:\n    amplitude: float = 1.0\n")
    code = "from .base import Params\n\n\ndef shape(pos, p: Params):\n    return getattr(p, 'damping', 0.0) * p.amplitude\n"
    assert any("hides a missing attribute" in m for m in guards.unresolved_imports(repo, "App/pkg/signals/waves.py", code))


def test_scope_extends_to_class_and_header_from_errors(tmp_path):
    from sdlc.agents.scope_hints import extra_targets
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "Params.h").write_text("struct SignalParams {\n    double duty = 0.5;\n};\n")
    (tmp_path / "src" / "Panel.h").write_text("class Panel {\n    int m_a = 0;\n};\n")
    (tmp_path / "src" / "Panel.cpp").write_text("#include \"Panel.h\"\n")
    err = "BUILD ..\\src\\Waves.cpp:35 - error: 'const struct SignalParams' has no member named 'damping'\nBUILD ..\\src\\Panel.cpp:12 - error: 'm_new' was not declared in this scope"
    files = [f for f, _ in extra_targets(tmp_path, err, ["src/Panel.cpp"])]
    assert files == ["src/Params.h", "src/Panel.h"]


def test_removed_member_field_still_used(tmp_path):
    from sdlc.core import guards
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "Panel.cpp").write_text("void f(){ m_timeDiv->show(); }\n")
    old = "class Panel {\n    QComboBox *m_timeDiv = nullptr;\n    int m_x = 0;\n};\n"
    new = "class Panel {\n    int m_x = 0;\n    double m_new = 0;\n};\n"
    (tmp_path / "src" / "Panel.h").write_text(new)
    msgs = guards.removed_fields(tmp_path, "src/Panel.h", old, new)
    assert msgs and "m_timeDiv" in msgs[0] and "src/Panel.cpp" in msgs[0]


def test_mirror_autofix_adds_list_member_and_value_copy():
    from sdlc.core import guards
    text = (Path(__file__).parent / "fixtures" / "ControlPanel_partial_wiring.cpp").read_text()
    fixed, lines = guards.mirror_autofix(text, "dutyCycle", "dampingFactor")
    assert "{m_amp, m_offset, m_phase, m_duty, m_dampingFactor}" in fixed
    assert "    p.dampingFactor = m_dampingFactor->value();\n" in fixed and "p.dutyCycle = m_duty->value() / 100.0;" in fixed
    assert guards.mirror_gaps(fixed, "dutyCycle", "dampingFactor") == []


def test_gtest_macros_are_not_duplicate_definitions():
    from sdlc.core import guards
    new = "#include <cassert>\nTEST(A, b) { }\nTEST(A, c) { }\n"
    assert guards.duplicate_definitions("test/t.cpp", "", new) == []


def test_self_attribute_of_project_class_must_exist(tmp_path):
    from sdlc.core import guards
    repo = _pkg(tmp_path)
    ui = repo / "App" / "pkg" / "ui"
    ui.mkdir()
    (ui / "__init__.py").write_text("")
    (ui / "panel.py").write_text("class Base:\n    pass\n\n\nclass Panel(Base):\n    changed = 1\n\n    def start(self):\n        return 1\n")
    code = "from .panel import Panel\n\n\nclass Win:\n    def __init__(self):\n        self.panel = Panel()\n        self.panel.changed\n        self.panel.start()\n        self.panel.dampingChanged\n"
    msgs = guards.unresolved_imports(repo, "App/pkg/ui/win.py", code)
    assert len(msgs) == 1 and "self.panel.dampingChanged" in msgs[0]


def test_web_contract_points_to_attribute_selector(tmp_path):
    from sdlc.core import guards
    (tmp_path / "index.html").write_text("<html><body></body></html>")
    (tmp_path / "styles.css").write_text("[data-theme='dark'] { color: white; }\n")
    msgs = guards.web_contract(tmp_path, "app.js", "document.body.classList.add('dark-mode');")
    assert "[data-theme='dark']" in msgs[0] and "setAttribute('data-theme', 'dark')" in msgs[0]


def test_pytest_warning_summary_is_not_the_failure():
    from sdlc.runners import parsers
    out = "FAILED x.py::t - AssertionError: bad\n=========== warnings summary ===========\nThe event loop scope for asynchronous fixtures will default\n-- Docs: https://x\n=========== 1 failed in 0.1s ===========\n"
    assert "event loop" not in " ".join(f.message for f in parsers.generic(out, "test"))


def test_request_language_overrides_dropdown():
    from sdlc.create.agents import request_languages
    req = "Create a Kanban app using pure HTML5, CSS3, and vanilla JavaScript.\n- index.html\n- styles.css\n- app.js"
    assert request_languages(req) == {"web"}
    assert "python" in request_languages("a Flask app in python with index.html templates")


def test_self_member_missing_on_project_class(tmp_path):
    from sdlc.core import guards
    (tmp_path / "ui").mkdir()
    (tmp_path / "ui" / "__init__.py").write_text("")
    (tmp_path / "ui" / "panel.py").write_text("class Panel:\n    changed = 1\n\n    def params(self):\n        return 1\n")
    code = "from ui.panel import Panel\n\n\nclass Win:\n    def __init__(self):\n        self.panel = Panel()\n        self.panel.changed\n        self.panel.dampingChanged\n"
    msgs = guards.unresolved_imports(tmp_path, "win.py", code)
    assert any("`self.panel.dampingChanged`" in m for m in msgs) and not any("`self.panel.changed`" in m for m in msgs)


def test_function_call_is_not_a_sibling_list():
    from sdlc.core import guards
    text = "class W:\n    def shape(self, pos, p):\n        return np.where(pos < p.duty_cycle, 1.0, -1.0)\n"
    assert guards.mirror_gaps(text, "duty_cycle", "damping_factor") == []


def test_unread_field_detected(tmp_path):
    from sdlc.agents.analogues import field_readers
    (tmp_path / "p.py").write_text("class P:\n    duty: float = 0.5\n    damping_factor: float = 0.0\n")
    (tmp_path / "w.py").write_text("def f(p):\n    return p.duty * 2\n")
    (tmp_path / "ui.py").write_text("def g(p, d):\n    p.damping_factor = d\n")
    assert field_readers(tmp_path, "damping_factor", looks_like_test) == []
    assert field_readers(tmp_path, "duty", looks_like_test) == ["w.py"]


def test_example_comment_is_placeholder():
    from sdlc.core import guards
    assert guards.placeholders("", "def s(pos):\n    # Example damping: sin(2*pi*pos) * exp(-pos)\n    return 1\n")


def test_removed_member_is_restored_in_place(tmp_path):
    from sdlc.core import guards
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "Panel.cpp").write_text("void f(){ m_timeDiv->show(); }\n")
    old = "class Panel {\n    QSpinBox *m_duty = nullptr;\n    QComboBox *m_timeDiv = nullptr;\n    int m_x = 0;\n};\n"
    new = "class Panel {\n    QSpinBox *m_duty = nullptr;\n    QSpinBox *m_damping = nullptr;\n    int m_x = 0;\n};\n"
    fixed, names = guards.restore_removed_fields(tmp_path, "src/Panel.h", old, new)
    assert names == ["m_timeDiv"] and "m_timeDiv" in fixed and "m_damping" in fixed
    assert guards.removed_fields(tmp_path, "src/Panel.h", old, fixed) == []


def test_wrong_language_content_detected():
    from sdlc.core import guards
    py = "import json\nfrom http.server import BaseHTTPRequestHandler\n\nclass H(BaseHTTPRequestHandler):\n    def do_GET(self):\n        pass\n"
    assert "Python" in guards.wrong_language("static/app.js", py)
    assert guards.wrong_language("static/app.js", "const a = 1;\nfunction f() {}\ndocument.body;\n") == ""


def test_template_references_follow_planned_names(tmp_path):
    from sdlc.create import templates
    from sdlc.create.schemas import Blueprint, FileSpec
    tpl = templates.load("web")
    bp = Blueprint(project_name="x", language="web", summary="s", entry="index.html",
                   files=[FileSpec(path="index.html", purpose="p"), FileSpec(path="styles.css", purpose="p"), FileSpec(path="app.js", purpose="p")])
    templates.write(tmp_path, bp, tpl, "x")
    html = (tmp_path / "index.html").read_text()
    assert "styles.css" in html and "app.js" in html and "style.css" not in html.replace("styles.css", "")


def test_join_continuation_drops_partial_line():
    from sdlc.create.agents import join_continuation
    assert join_continuation("a = 1\nb = 2\n", "b = 2\nc = 3\n") == "a = 1\nb = 2\nc = 3\n"
