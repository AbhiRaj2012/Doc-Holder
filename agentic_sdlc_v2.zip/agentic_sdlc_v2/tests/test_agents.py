from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest
from pydantic import ValidationError

from sdlc.adapters.git_ops import GitRepo
from sdlc.adapters.ollama_client import LLMError
from sdlc.agents.analyser import Analyser, manifest_text
from sdlc.agents.context import AgentContext
from sdlc.agents.critic import Critique, CritiqueIssue, PlanCritic
from sdlc.agents.editor import EditorAgent, EditOutcome, edit_findings, failures_after
from sdlc.agents.planner import PlanDraft, Planner, TaskDraft, VerifyFix, VerifyFixes, write_brief
from sdlc.agents.reviewer import ReviewDraft, ReviewerAgent
from sdlc.agents.splitter import SplitPlan, Splitter, SubTask, deterministic_split
from sdlc.core.config import load_settings
from sdlc.core.ledger import IssueLedger
from .helpers import PY_FILES, FakeClient
from sdlc.core.schemas import EditResult, Plan, SuspendReason, Task


def make_ctx(tmp_path: Path, client: Any = None, files: dict[str, str] | None = None) -> AgentContext:
    repo = tmp_path / "repo"
    repo.mkdir(exist_ok=True)
    for name, text in (files or {}).items():
        (repo / name).parent.mkdir(parents=True, exist_ok=True)
        (repo / name).write_text(text)
    git = GitRepo(repo)
    git.ensure_repo()
    run_dir = tmp_path / "run"
    run_dir.mkdir(exist_ok=True)
    return AgentContext(load_settings(), client or FakeClient(), repo, run_dir, git, IssueLedger(run_dir), "proj", "proj")


def task(**kw: Any) -> Task:
    base = dict(id="T1", title="fix add", description="add must return the sum", language="python", kind="bugfix",
                target_files=["calc.py"], acceptance_criteria=["add returns the sum", "negative numbers work"],
                verify_command="python3 -m pytest -x -q")
    base.update(kw)
    return Task(**base)


# ---------- analyser ----------
def test_analyser_manifest_and_incremental(tmp_path: Path):
    ctx = make_ctx(tmp_path, files=PY_FILES)
    an = Analyser(ctx.settings, ctx.repo, "proj", "proj")
    m = an.run()
    assert m.primary_language == "python" and m.has_tests and not m.is_empty
    assert m.dependencies["python"] == ["flask", "requests"] and "main.py" in m.entry_points
    calc = next(f for f in m.files if f.path == "calc.py")
    assert calc.symbols == ["add", "class Calc", "Calc.mul"] and "calc.py: add" in m.repo_map
    assert "test" in m.commands and "Existing tests: yes" in manifest_text(m, 2000)
    (ctx.repo / "calc.py").write_text("def add(a, b):\n    return a + b\n\n\ndef sub(a, b):\n    return a - b\n")
    m2 = an.refresh(m, ["calc.py", "gone.py"])
    assert next(f for f in m2.files if f.path == "calc.py").symbols == ["add", "sub"]
    assert next(f for f in m2.files if f.path == "main.py").sha256 == next(f for f in m.files if f.path == "main.py").sha256
    m3 = an.run(m2)
    assert [f.path for f in m3.files] == [f.path for f in m2.files]
    empty = tmp_path / "empty"
    empty.mkdir()
    assert Analyser(ctx.settings, empty, "p").run().is_empty


# ---------- planner ----------
def draft(**kw: Any) -> PlanDraft:
    t1 = TaskDraft(id="T1", title="fix add", description="d", language="js", kind="bugfix", target_files=["./calc.py"],
                   acceptance_criteria=["a"], verify_command="make test")
    t2 = TaskDraft(id="T2", title="more tests", description="d", language="python", kind="test", target_files=["test_calc.py", "../evil.py"],
                   acceptance_criteria=["b"], verify_command="", depends_on=["T1"])
    return PlanDraft(summary="s", assumptions=["x"], tasks=[t1, t2])


def test_planner_normalises_repairs_and_writes_brief(tmp_path: Path):
    client = FakeClient(PlanDraft=draft(), VerifyFixes=VerifyFixes(fixes=[VerifyFix(task_id="T1", verify_command="pytest -q")]))
    ctx = make_ctx(tmp_path, client, PY_FILES)
    m = Analyser(ctx.settings, ctx.repo, "proj").run()
    res = Planner(ctx).plan(m, "Fix the add function", "also keep API")
    t1, t2 = res.plan.tasks
    assert t1.language == "python" and t1.target_files == ["calc.py"]
    assert t1.verify_command == "python3 -m pytest -q" and t1.verify_source == "planner"
    assert t2.target_files == ["test_calc.py"] and t2.verify_source == "default" and t2.verify_command == m.commands["test"]
    assert not res.policy_events and any("language js -> python" in w for w in res.warnings)
    sys_msg, user_msg = client.calls[0][1][0]["content"], client.calls[0][1][1]["content"]
    assert "Add or update tests only" in sys_msg and "Fix the add function" in user_msg and "also keep API" in user_msg
    brief = write_brief(ctx.run_dir, "Fix the add function", res).read_text()
    assert "### T1: fix add" in brief and "python3 -m pytest -q" in brief and "## Assumptions" in brief


def test_planner_policy_fallback_without_repair_and_no_tests_rule(tmp_path: Path):
    client = FakeClient(PlanDraft=draft(), VerifyFixes=VerifyFixes(fixes=[]))
    ctx = make_ctx(tmp_path, client, {"calc.py": "def add(a, b):\n    return a - b\n"})
    m = Analyser(ctx.settings, ctx.repo, "proj").run()
    res = Planner(ctx).plan(m, "r")
    assert "characterization-test" in client.calls[0][1][0]["content"]
    assert res.plan.tasks[0].verify_source == "none" and res.plan.tasks[1].verify_command is None and res.policy_events[0]["executable"] == "make" and res.proposals == ["make"]


def test_plan_draft_validates_graph():
    t = lambda i, d: TaskDraft(id=i, title=i, description="d", language="python", acceptance_criteria=["x"], depends_on=d)  # noqa: E731
    with pytest.raises(ValidationError):
        PlanDraft(summary="s", tasks=[t("A", ["B"]), t("B", ["A"])])
    with pytest.raises(ValidationError):
        PlanDraft(summary="s", tasks=[t("A", ["Z"])])


# ---------- critic and splitter ----------
def test_critic(tmp_path: Path):
    verdict = Critique(ok=False, issues=[CritiqueIssue(task_id="T2", problem="too big", fix="split")], missing_requirements=["logging"])
    ctx = make_ctx(tmp_path, FakeClient(Critique=verdict), PY_FILES)
    out = PlanCritic(ctx).review("r", Plan(summary="s", tasks=[task(), task(id="T2", depends_on=["T1"])]))
    assert not out.ok and "T2: too big Fix: split" in out.as_text() and "MISSING REQUIREMENT: logging" in out.as_text()


def test_splitter_llm_and_fallbacks(tmp_path: Path):
    parent = task(target_files=["a.py", "b.py"]).model_dump(mode="json")
    split = SplitPlan(subtasks=[SubTask(title="one", target_files=["a.py", "zzz.py"], acceptance_criteria=["x"]),
                                SubTask(title="two", target_files=["b.py"], acceptance_criteria=["y"])])
    out = Splitter(make_ctx(tmp_path, FakeClient(SplitPlan=split), PY_FILES)).split(parent, None, "token_exhausted")
    assert [o["title"] for o in out] == ["one", "two"] and out[0]["target_files"] == ["a.py"] and out[1]["language"] == "python"
    fallback = Splitter(make_ctx(tmp_path, FakeClient(SplitPlan=LLMError("x")))).split(parent, None, "r")
    assert [o["target_files"] for o in fallback] == [["a.py"], ["b.py"]]
    assert len(deterministic_split(task(target_files=["a.py"], symbol_targets=["f", "g"]).model_dump(mode="json"))) == 2
    assert len(deterministic_split(task().model_dump(mode="json"))) == 2
    assert deterministic_split(task(acceptance_criteria=["only"]).model_dump(mode="json")) == []


# ---------- editor ----------
class FakeBackend:
    def __init__(self, repo: Path, action):
        self.repo, self.action, self.requests = repo, action, []

    def edit(self, req, failures=0):
        self.requests.append((req, failures))
        return self.action(self.repo)


def res(**kw: Any) -> EditResult:
    return EditResult(**{"ok": True, "files_changed": ["calc.py"], **kw})


def test_editor_outcomes(tmp_path: Path):
    ctx = make_ctx(tmp_path, files=PY_FILES)
    m = Analyser(ctx.settings, ctx.repo, "p").run()

    def good(repo):
        (repo / "calc.py").write_text(PY_FILES["calc.py"].replace("a - b", "a + b"))
        return res(blocks_applied=1)

    be = FakeBackend(ctx.repo, good)
    agent = EditorAgent(ctx, be)  # type: ignore[arg-type]
    out = agent.run(task(), 1, m)
    assert out.ok
    assert out.result.files_changed == ["calc.py"] and "+    return a + b" in out.result.diff and not out.counts_as_failure
    assert be.requests[0][0].read_files == ["test_calc.py"] and be.requests[0][0].tag == "T1-i1"
    ctx.git.commit_all("fixed")

    def broken(repo):
        (repo / "calc.py").write_text("def add(a, b)\n    return a + b\n")
        return res()

    out = EditorAgent(ctx, FakeBackend(ctx.repo, broken)).run(task(), 2, m)  # type: ignore[arg-type]
    assert not out.ok and out.failure_class == "syntax_after_edit" and out.counts_as_failure
    assert "def add(a, b):" in (ctx.repo / "calc.py").read_text() and "reverted" in out.feedback

    def wander(repo):
        (repo / "calc.py").write_text("def add(a, b):\n    return b + a\n\n\nclass Calc:\n    def mul(self, a, b):\n        return a * b\n")
        (repo / "main.py").write_text("print('x')\n")
        (repo / "newmod.py").write_text("X = 1\n")
        return res(files_changed=["calc.py", "main.py", "newmod.py"])

    out = EditorAgent(ctx, FakeBackend(ctx.repo, wander)).run(task(kind="feature"), 3, m)  # type: ignore[arg-type]
    assert out.ok and out.restored == ["main.py"] and sorted(out.result.files_changed) == ["calc.py", "newmod.py"]
    assert (ctx.repo / "main.py").read_text() == PY_FILES["main.py"] and "outside the task scope" in out.feedback
    ctx.git.commit_all("ok")

    for err, cls, suspend, counts in (
        ("SEARCH text not found in the file.", "not_found", None, True),
        ("output truncated (length limit reached)", "length", SuspendReason.TOKEN_EXHAUSTED, False),
        ("aider timed out after 900s", "timeout", SuspendReason.STEP_TIMEOUT, False),
    ):
        o = EditorAgent(ctx, FakeBackend(ctx.repo, lambda r, e=err: res(ok=False, files_changed=[], error=e, truncated="truncated" in e))).run(task(), 4, m)  # type: ignore[arg-type]
        assert (o.failure_class, o.suspend, o.counts_as_failure) == (cls, suspend, counts)
    assert edit_findings(o) and edit_findings(o)[0].kind == "edit"
    assert failures_after(1, EditOutcome(res(), False, counts_as_failure=True)) == 2
    assert failures_after(2, EditOutcome(res(), True)) == 0
    assert failures_after(2, EditOutcome(res(), True, feedback="partial")) == 2


def test_editor_message_and_focus(tmp_path: Path):
    ctx = make_ctx(tmp_path, files=PY_FILES)
    m = Analyser(ctx.settings, ctx.repo, "p").run()
    from sdlc.core.ledger import Finding
    ctx.ledger.ingest("T1", 1, [Finding(kind="test", message="assert 1 == 2", file="test_calc.py", symbol="test_add")])
    ctx.ledger.ingest("T1", 2, [])
    ctx.ledger.ingest("T1", 3, [Finding(kind="lint", message="unused import")])
    agent = EditorAgent(ctx, FakeBackend(ctx.repo, lambda r: res()))  # type: ignore[arg-type]
    t = task(symbol_targets=["add"])
    msg = agent.build_message(t, 3, m, edit_error="SEARCH text not found")
    assert "OPEN ISSUES" in msg and "unused import" in msg and "MUST STAY FIXED" in msg and "assert 1 == 2" in msg
    assert "LAST EDIT PROBLEMS" in msg and "PLAYBOOK bugfix" in msg and "FOCUS SYMBOLS: add" in msg and "1. add returns the sum" in msg
    narrow = agent.build_message(t, 3, m, shrink_level=2)
    assert "NARROW SCOPE" in narrow and "PLAYBOOK bugfix" in narrow and "NEARBY FILES" not in narrow
    be = FakeBackend(ctx.repo, lambda r: res(ok=False, files_changed=[], error="x"))
    EditorAgent(ctx, be).run(t, 4, m, shrink_level=1)  # type: ignore[arg-type]
    assert be.requests[0][0].focus_symbols == {"calc.py": ["add"]} and be.requests[0][0].read_files == []


# ---------- reviewer ----------
def fix_calc(ctx: AgentContext) -> None:
    (ctx.repo / "calc.py").write_text(PY_FILES["calc.py"].replace("a - b", "a + b"))


def test_reviewer_paths(tmp_path: Path):
    client = FakeClient(ReviewDraft=ReviewDraft(approved=True))
    ctx = make_ctx(tmp_path, client, PY_FILES)
    base = ctx.git.head()
    rv = ReviewerAgent(ctx)
    review, stats = rv.review(task(), 1, base)
    assert not review.approved and review.llm is not None and "No changes" in review.llm.feedback and not client.calls
    assert stats["new"] >= 1

    (ctx.repo / "calc.py").write_text(PY_FILES["calc.py"].replace("a - b", "a * b"))
    review, stats = rv.review(task(), 2, base)
    assert not review.approved and review.llm is None and not client.calls
    assert any(c.name == "test" and not c.ok for c in review.checks) and ctx.ledger.open_issues("T1")[0].kind in ("test", "criteria")

    fix_calc(ctx)
    review, stats = rv.review(task(), 3, base)
    assert review.approved and stats["resolved"] >= 1 and client.calls and not ctx.ledger.open_issues("T1")
    assert "AUTOMATED CHECKS" in client.calls[0][1][1]["content"] and "- test: passed" in client.calls[0][1][1]["content"]
    assert review.fingerprint

    ctx.client.responses["ReviewDraft"] = [ReviewDraft(approved=False, unmet=[2], feedback="negatives untested")]
    review, _ = rv.review(task(), 4, base)
    assert not review.approved and review.llm.unmet_criteria == ["negative numbers work"] and "negatives" in review.feedback_text()

    ctx.client.responses["ReviewDraft"] = [LLMError("down")]
    review, _ = rv.review(task(), 5, base)
    assert review.llm is None and review.approved


def test_reviewer_unverifiable_without_checks(tmp_path: Path):
    ctx = make_ctx(tmp_path, FakeClient(ReviewDraft=LLMError("down")), {"calc.py": "def add(a, b):\n    return a - b\n"})
    base = ctx.git.head()
    (ctx.repo / "calc.py").write_text("def add(a, b):\n    return a + b\n")
    review, _ = ReviewerAgent(ctx).review(task(verify_command=None), 1, base)
    assert not review.approved and "cannot be verified" in review.llm.feedback


def test_reviewer_defers_criteria_of_upcoming_tasks(tmp_path):
    from sdlc.agents.reviewer import ReviewDraft, ReviewerAgent
    from sdlc.core.schemas import Task

    from .helpers import FakeClient

    ctx = make_ctx(tmp_path, FakeClient(ReviewDraft=ReviewDraft(approved=False, unmet=[2], deferred=[2], feedback="no click handler")))
    t = Task(id="T1", title="Add button", description="markup", language="python", acceptance_criteria=["button exists", "click exports"])
    v = ReviewerAgent(ctx)._llm_verdict(t, [], "diff", ["T2 Add click handler (files: app.js)"])
    assert v.approved and not v.unmet_criteria
    v = ReviewerAgent(ctx)._llm_verdict(t, [], "diff", [])
    assert not v.approved and v.unmet_criteria == ["click exports"]
