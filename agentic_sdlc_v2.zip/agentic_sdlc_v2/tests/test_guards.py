from __future__ import annotations

from sdlc.core import guards

H_OLD = "class SquareWave : public Base\n{\npublic:\n    double value() const;\n};\n"
H_NEW = "class CosineWave : public Base\n{\npublic:\n    double value() const;\n};\n"


def test_removed_symbol_still_used_cpp(tmp_path):
    (tmp_path / "src").mkdir()
    (tmp_path / "src/Reg.cpp").write_text("void f() { auto p = std::make_unique<SquareWave>(); }\n")
    (tmp_path / "src/W.h").write_text(H_NEW)
    out = guards.destructive(tmp_path, "add CosineWave", [("src/W.h", H_OLD, H_NEW)])
    assert out and "SquareWave" in out[0] and "still used" in out[0]


def test_removed_python_function_unmentioned(tmp_path):
    (tmp_path / "a.py").write_text("def keep():\n    return 1\n")
    old = "def keep():\n    return 1\n\ndef gone():\n    return 2\n"
    out = guards.destructive(tmp_path, "tweak keep", [("a.py", old, "def keep():\n    return 1\n")])
    assert out and "gone" in out[0]
    assert guards.destructive(tmp_path, "remove gone", [("a.py", old, "def keep():\n    return 1\n")]) == []


def test_additions_are_fine(tmp_path):
    (tmp_path / "a.py").write_text("def a():\n    return 1\n\ndef b():\n    return 2\n")
    assert guards.destructive(tmp_path, "add b", [("a.py", "def a():\n    return 1\n", "def a():\n    return 1\n\ndef b():\n    return 2\n")]) == []


def test_unresolved_imports(tmp_path):
    (tmp_path / "test").mkdir()
    (tmp_path / "CMakeLists.txt").write_text("project(x)\n")
    bad = '#include "gtest/gtest.h"\n#include "CosineWave.h"\n#include <vector>\n'
    out = guards.unresolved_imports(tmp_path, "test/t.cpp", '#include "CosineWave.h"\n#include <gtest/gtest.h>\n')
    assert len(out) == 1 and "CosineWave.h" in out[0] and bad
    (tmp_path / "mod.py").write_text("x = 1\n")
    assert guards.unresolved_imports(tmp_path, "t.py", "import os\nimport mod\n") == []
    assert guards.unresolved_imports(tmp_path, "t.py", "import nopkg_zzz\n") == []
    assert guards.external_packages(tmp_path, "t.py", "import nopkg_zzz\nimport os\n") == ["nopkg_zzz"]
    assert guards.unresolved_imports(tmp_path, "t.js", "const a = require('./missing');\n")


def test_not_in_build(tmp_path):
    (tmp_path / "CMakeLists.txt").write_text("add_executable(x src/a.cpp)\n")
    assert guards.not_in_build(tmp_path, "test/t.cpp")
    assert not guards.not_in_build(tmp_path, "src/a.cpp")


def test_framework_include_is_a_dependency_not_an_error(tmp_path):
    (tmp_path / "CMakeLists.txt").write_text("project(x)\n")
    assert guards.unresolved_imports(tmp_path, "t/a.cpp", '#include "gtest/gtest.h"\n') == []
    assert guards.external_packages(tmp_path, "t/a.cpp", '#include "gtest/gtest.h"\n') == ["gtest"]


def test_note_dependencies_appends_requirements(tmp_path):
    (tmp_path / "requirements.txt").write_text("requests>=2\n")
    assert guards.note_dependencies(tmp_path, "a.py", ["requests", "fpdf"]) == "requirements.txt"
    assert (tmp_path / "requirements.txt").read_text() == "requests>=2\nfpdf\n"
    assert guards.note_dependencies(tmp_path, "a.js", ["jspdf"]) == ""


def test_duplicate_definitions():
    old = "function a() {}\nfunction b() {}\n"
    assert guards.duplicate_definitions("s.js", old, old + "function a() { return 1; }\n") == ["a"]
    assert guards.duplicate_definitions("s.js", old, old) == []


def test_web_contract(tmp_path):
    (tmp_path / "index.html").write_text("<div id='board'></div><div class='card'></div>")
    (tmp_path / "style.css").write_text(".card{} [data-theme=dark]{}")
    js = "document.getElementById('board'); document.getElementById('list'); document.body.classList.toggle('dark-mode'); el.classList.add('card');"
    out = guards.web_contract(tmp_path, "s.js", js)
    assert len(out) == 2 and "'list'" in out[0] and "dark-mode" in out[1]


def test_js_balance_fallback():
    from sdlc.runners.js_balance import js_balance_check

    assert js_balance_check("const a = `x${b.map(x => `<i>${x}</i>`).join('')}`; const r = /[/]/g; if (a?.b) { y = 1 / 2; }") == []
    assert js_balance_check("function f() {\n  if (x) {\n}\n")[0][0] == 1
    assert "unexpected" in js_balance_check("f(a));")[0][1]


def test_removed_out_of_class_definition_cpp(tmp_path):
    (tmp_path / "src").mkdir()
    (tmp_path / "src/Reg.cpp").write_text("auto p = std::make_unique<SquareWave>();\n")
    old = "double TriangleWave::value(double t) const\n{\n    return t;\n}\n\ndouble SquareWave::value(double t) const\n{\n    return -t;\n}\n"
    new = "double TriangleWave::value(double t) const\n{\n    return t;\n}\n\ndouble CosineWave::value(double t) const\n{\n    return t;\n}\n"
    out = guards.destructive(tmp_path, "Implement CosineWave methods", [("src/W.cpp", old, new)])
    assert out and "SquareWave::value" in out[0] and "still used" in out[0]


def test_dropped_uses_of_project_symbols(tmp_path):
    (tmp_path / "w.py").write_text("class SineWave:\n    pass\n\n\nclass SquareWave:\n    pass\n\n\nclass CosineWave:\n    pass\n")
    old = "from w import SineWave, SquareWave\n\nREG = [SineWave(), SquareWave()]\n"
    keep = "from w import SineWave, SquareWave, CosineWave\n\nREG = [SineWave(), SquareWave(), CosineWave()]\n"
    lose = "from w import CosineWave\n\nREG = [CosineWave()]\n"
    (tmp_path / "reg.py").write_text(lose)
    assert guards.dropped_uses(tmp_path, "Register CosineWave", [("reg.py", old, keep)]) == []
    out = guards.dropped_uses(tmp_path, "Register CosineWave", [("reg.py", old, lose)])
    assert out and "SineWave" in out[0] and "SquareWave" in out[0]
    assert guards.dropped_uses(tmp_path, "Replace SineWave and SquareWave by CosineWave", [("reg.py", old, lose)]) == []


def test_placeholder_path_maps_to_target():
    from sdlc.adapters import edit_engine as ee

    b = ee.parse_blocks("path/to/file.ext\n<<<<<<< SEARCH\na\n=======\nb\n>>>>>>> REPLACE\n", "app.js")
    assert b[0].path == "app.js"
