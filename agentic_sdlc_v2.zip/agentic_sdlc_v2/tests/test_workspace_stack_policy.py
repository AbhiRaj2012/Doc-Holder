from __future__ import annotations

import shutil
from pathlib import Path

import pytest

from sdlc.adapters.git_ops import GitRepo
from sdlc.core import hardware as hw
from sdlc.core.command_policy import CommandPolicy
from sdlc.core.config import LimitsCfg, load_settings
from sdlc.core.project_store import ProjectError, ProjectStore
from sdlc.core.schemas import Manifest, SuspendReason
from sdlc.core.task_stack import StackManager
from sdlc.runners.registry import detect_languages, get_runner
from sdlc.runners.web_runner import css_check, html_check


# ---------- project store ----------
def make_source(base: Path, name: str = "demo") -> Path:
    src = base / "srcs" / name
    (src / "node_modules" / "dep").mkdir(parents=True)
    (src / "node_modules" / "dep" / "index.js").write_text("module.exports = 1;\n")
    (src / "app.py").write_text("x = 1\n")
    return src


def test_project_store_isolation(tmp_path: Path):
    s = load_settings(overrides={"paths": {"projects_root": str(tmp_path / "projects")}})
    store = ProjectStore(s)
    src = make_source(tmp_path)
    p = store.open(src)
    assert p.id == "demo" and p.code == p.root / "demo" and p.workspace.is_dir()
    assert (p.code / "node_modules").is_symlink() and (p.code / "app.py").read_text() == "x = 1\n"
    assert not GitRepo(p.code).is_dirty()

    (p.code / "app.py").write_text("x = 2\n")
    again = store.open(src)
    assert again.id == "demo" and (again.code / "app.py").read_text() == "x = 2\n"

    other = store.open(make_source(tmp_path / "elsewhere"))
    assert other.id == "demo_2" and other.code != p.code
    assert store.load_manifest(other) is None

    m = Manifest(project_name="demo", root="")
    store.save_manifest(p, m)
    assert store.load_manifest(p) is not None
    store.save_manifest(other, m)
    p.manifest_path.write_text(other.manifest_path.read_text())
    assert store.load_manifest(p) is None

    patch = store.export(p)
    assert "+x = 2" in patch.read_text()

    (p.run_dir("r1") / "events.jsonl").write_text("{}")
    with pytest.raises(ProjectError):
        store.sync(p)
    (src / "app.py").write_text("x = 99\n")
    assert store.source_changed(p)
    store.sync(p, force=True)
    assert (p.code / "app.py").read_text() == "x = 99\n" and not p.manifest_path.exists()
    assert not store.source_changed(p)

    fresh = store.open(src, fresh=True)
    assert fresh.id == "demo" and (fresh.code / "app.py").read_text() == "x = 99\n"


# ---------- hardware ----------
SHOW = {"model_info": {
    "general.architecture": "llama", "llama.block_count": 32, "llama.attention.head_count": 32,
    "llama.attention.head_count_kv": 8, "llama.embedding_length": 4096, "llama.context_length": 131072,
}}


def test_hardware_context_and_budgets():
    arch = hw.parse_arch("m", SHOW, int(4.5 * hw.GIB))
    assert arch.head_dim == 128 and arch.kv_per_token("q8_0") == 2 * 32 * 8 * 128 * 1.0625
    ctx, warn = hw.derive_context(8, arch, "q8_0", 1.5)
    assert ctx % 1024 == 0 and 8192 <= ctx <= 131072 and not warn
    ctx_f16, _ = hw.derive_context(8, arch, "f16", 1.5)
    assert ctx_f16 < ctx
    assert hw.derive_context(4, arch, "q8_0", 1.5)[0] == 0
    big, warn = hw.derive_context(8, arch, "q8_0", 1.5, override=131072)
    assert big == 131072 and warn
    small = hw.derive_budgets(8192)
    large = hw.derive_budgets(32768)
    assert small["budget"]["step_max_lines"] == 60 and large["budget"]["step_max_lines"] == 200
    assert small["budget"]["max_output_tokens"]["editor"] < large["budget"]["max_output_tokens"]["editor"]
    s = load_settings(overrides={"hardware": {"gpu_vram_gb": 8, "kv_cache_type": "q8_0"}})
    new, warn = hw.apply_profile(s, arch)
    assert new.ollama.num_ctx == ctx and new.budget.max_output_tokens["planner"] > 0
    unchanged, warn = hw.apply_profile(load_settings(overrides={"hardware": {"gpu_vram_gb": 4}}), arch)
    assert warn and unchanged.ollama.num_ctx == 8192


def test_offload_detection_and_calibrate():
    assert hw.offload_reduction({"size": 100, "size_vram": 100}, 32768) is None
    assert hw.offload_reduction({"size": 100, "size_vram": 50}, 32768) == 24576

    class Fake:
        settings = None
        calls = 0

        def chat(self, *a, **k):
            return None

        def running(self):
            self.calls += 1
            return [{"name": "gpt-oss:20b", "size": 100, "size_vram": 50 if self.calls == 1 else 100}]

    s, notes = hw.calibrate(Fake(), load_settings())
    assert s.ollama.num_ctx == 24576 and len(notes) == 1

    class Stuck(Fake):
        def running(self):
            return [{"name": "gpt-oss:20b", "size": 100, "size_vram": 60}]

    s, notes = hw.calibrate(Stuck(), load_settings())
    assert s.ollama.num_ctx == 32768 and "CPU-resident" in notes[-1]


# ---------- task stack ----------
def mk(tid: str, deps: list[str] | None = None) -> dict:
    return {"id": tid, "status": "pending", "depends_on": deps or [], "shrink_level": 0}


def test_stack_order_suspend_resume_split():
    sm = StackManager([mk("A"), mk("B", ["A"]), mk("C")], [], LimitsCfg())
    src, task, _ = sm.pick_next()
    assert (src, task["id"]) == ("task", "A")
    frame = sm.suspend("A", SuspendReason.TOKEN_EXHAUSTED, iteration=2, base_tree="abc")
    assert frame.shrink_level == 1 and sm.get("A")["status"] == "suspended"
    src, task, fr = sm.pick_next()
    assert src == "frame" and task["id"] == "A" and StackManager.action_for(fr) == "trim"
    sm.suspend("A", SuspendReason.CONTEXT_OVERFLOW)
    _, _, fr = sm.pick_next()
    assert StackManager.action_for(fr) == "narrow"
    sm.suspend("A", SuspendReason.TOKEN_EXHAUSTED)
    _, _, fr = sm.pick_next()
    assert StackManager.action_for(fr) == "split"
    assert sm.suspend("A", SuspendReason.TOKEN_EXHAUSTED) is None
    ids = sm.split("A", [{"title": "one"}, {"title": "two"}])
    assert ids == ["A.1", "A.2"] and sm.get("A")["status"] == "split" and not sm.frames
    assert sm.pick_next()[1]["id"] == "A.1"
    sm.complete("A.1")
    assert sm.pick_next()[1]["id"] == "A.2"
    sm.complete("A.2")
    assert sm.get("A")["status"] == "completed"
    assert sm.pick_next()[1]["id"] == "B"
    sm.complete("B")
    assert sm.pick_next()[1]["id"] == "C"
    sm.complete("C")
    assert sm.finished() and sm.pick_next()[0] == "none"


def test_stack_frames_before_new_tasks_and_skip_blocking():
    sm = StackManager([mk("A"), mk("B", ["A"]), mk("C"), mk("D", ["B"])], [], LimitsCfg())
    sm.pick_next()
    sm.suspend("A", SuspendReason.STEP_TIMEOUT)
    sm.complete("A") if False else None
    assert sm.pick_next()[0] == "frame"
    sm.skip("A")
    assert sm.get("B")["status"] == "blocked" and sm.get("D")["status"] == "blocked" and not sm.frames
    assert sm.pick_next()[1]["id"] == "C"
    sm.complete("C")
    assert sm.finished()


def test_stack_caps_crash_and_persistence(tmp_path: Path):
    sm = StackManager([mk("A"), mk("B")], [], LimitsCfg(max_suspended_frames=1))
    sm.pick_next()
    assert sm.suspend("A", SuspendReason.TOKEN_EXHAUSTED)
    sm.pick_next()
    sm.pick_next()
    assert sm.suspend("A", SuspendReason.TOKEN_EXHAUSTED) is not None
    assert sm.suspend("B", SuspendReason.TOKEN_EXHAUSTED) is None

    crash = StackManager([mk("X"), mk("Y")], [], LimitsCfg())
    crash.pick_next()
    assert crash.recover_crash() == 1
    assert crash.frames[0]["reason"] == "crash_recovery" and crash.get("X")["shrink_level"] == 0
    path = tmp_path / "stack.json"
    crash.save(path)
    loaded = StackManager.load(path, LimitsCfg())
    assert loaded.pick_next()[0] == "frame" and loaded.counts()["frames"] == 0


# ---------- command policy ----------
@pytest.fixture
def repo(tmp_path: Path) -> Path:
    (tmp_path / "run.sh").write_text("echo hi\n")
    return tmp_path


def test_policy_normalise_and_allow(repo: Path):
    p = CommandPolicy(repo, "python")
    r = p.check("pytest -q")
    assert r.ok and r.command == "python3 -m pytest -q"
    assert p.check("python tests/x.py && echo done").ok
    r = p.check("CI=1 pytest 2>&1 | tail -n 20")
    assert r.ok and r.command.startswith("CI=1 python3 -m pytest 2>&1") and "| tail -n 20" in r.command
    assert p.check("bash ./run.sh").ok


def test_policy_denials(repo: Path):
    p = CommandPolicy(repo, "python")
    for cmd in ("curl http://x.y", "rm -rf build", "echo $(whoami)", "pytest > out.txt", "cat /etc/passwd",
                "bash /tmp/x.sh", "git push origin main", "pip install requests", "cat ../secret"):
        r = p.check(cmd)
        assert not r.ok and r.kind == "denied", cmd


def test_policy_not_allowed_proposals_and_resolve(repo: Path):
    p = CommandPolicy(repo, "python")
    r = p.check("make test")
    assert not r.ok and r.kind == "not_allowed" and r.executable == "make"
    assert "python3" in r.feedback(p.allowed_for_prompt())
    assert CommandPolicy(repo, "python", approved={"make"}).check("make test").ok
    res = p.resolve_verify("make test", "python3 -m pytest")
    assert res.source == "default" and res.command == "python3 -m pytest" and res.proposals == ["make"] and res.event["type"] == "policy_violation"
    res = p.resolve_verify("make test", None)
    assert res.needs_human and res.command is None
    assert p.resolve_verify(None, "python3 -m pytest").source == "default"
    assert p.resolve_verify("pytest", "x").source == "planner"


def test_policy_language_tools(repo: Path):
    assert CommandPolicy(repo, "js").check("npx jest").command == "npx --no-install jest"
    assert CommandPolicy(repo, "js").check("npm test").ok
    assert CommandPolicy(repo, "js").check("npm install").kind == "denied"
    assert CommandPolicy(repo, "js").check("npm audit").kind == "not_allowed"
    assert CommandPolicy(repo, "java").check("mvn test").command == "mvn -o test"
    (repo / "gradlew").write_text("#!/bin/sh\n")
    assert CommandPolicy(repo, "java").check("gradle test").command == "bash ./gradlew test --offline"
    assert CommandPolicy(repo, "cpp").check("cmake --build build && ctest --test-dir build").ok


# ---------- web runner ----------
def test_html_and_css_checks():
    assert html_check("<html><body><p>a<p>b<ul><li>x<li>y</ul><br><img src=x></body></html>") == []
    errs = html_check("<div><span>text</div>\n<b>open")
    assert any("closed by" in m for _, m in errs) and any("never closed" in m for _, m in errs)
    assert any("unexpected closing" in m for _, m in html_check("</p>"))
    assert css_check("a { color: red; }\n/* c } */ b { margin: 0 }") == []
    assert css_check("a { color: red;\n") == [(1, "{ opened here is never closed")]
    assert css_check("a { } }")[0][1] == "unexpected }"


def test_web_runner_and_detection(tmp_path: Path):
    (tmp_path / "index.html").write_text("<html><body><div></body></html>")
    (tmp_path / "style.css").write_text("a { color: red; }")
    (tmp_path / "app.js").write_text("let x = 1;\n")
    assert detect_languages(tmp_path) == {"web": 2, "js": 1}
    r = get_runner("web", tmp_path, timeout=30)
    res = r.run_all(["index.html", "style.css", "app.js"])
    assert res[0].name == "syntax" and not res[0].ok and len(res) == 1
    assert res[0].failures[0].file == "index.html"
    (tmp_path / "index.html").write_text("<html><body><div></div></body></html>")
    syn = r.syntax(["index.html", "style.css"])
    assert syn.ok and not syn.skipped
    if shutil.which("node"):
        (tmp_path / "app.js").write_text("let = ;\n")
        assert not r.syntax(["app.js"]).ok


def test_fetch_arch_weights_override():
    from sdlc.core import hardware as hw

    class C:
        def show(self, m):
            return {"model_info": {"general.architecture": "g", "g.block_count": 20, "g.attention.head_count": 8, "g.attention.head_count_kv": 2, "g.attention.key_length": 128, "g.context_length": 32768}}

        def model_sizes(self):
            return {"m": int(6.7 * 2**30)}

    assert hw.fetch_arch(C(), "m").weights_gb > 6
    arch = hw.fetch_arch(C(), "m", 2.0)
    assert arch.weights_gb == 2.0 and hw.derive_context(4, arch, "q4_0", 0.5)[0] > 0
