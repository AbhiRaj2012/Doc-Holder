from __future__ import annotations

import json
from pathlib import Path

from sdlc.core.config import LimitsCfg, LoopCfg
from sdlc.core.schemas import CheckResult, Failure, LLMVerdict, ReviewResult
from sdlc.graph.human_gate import decision
from sdlc.loop import escalation, progress, test_baseline
from sdlc.loop.budget import MECHANICAL, over_budget
from sdlc.loop.escalation import Diagnosis

from .test_graph import Env, calc, client, task_draft, write

TESTS = "from calc import add\n\n\ndef test_a():\n    assert add(1, 2) == 3\n\n\ndef test_b():\n    assert add(2, 2) == 4\n\n\ndef test_c():\n    assert add(0, 5) == 5\n"
FILES = {"calc.py": "def add(a, b):\n    return 0\n", "test_calc.py": TESTS}
VERIFY = "python3 -m pytest -q"


def body(expr: str):
    return write("calc.py", f"def add(a, b):\n    return {expr}\n")


def env(tmp_path: Path, actions, overrides=None, files=None, **extra) -> Env:
    ov = {"limits": {"max_iterations_per_task": 6}, **(overrides or {})}
    return Env(tmp_path, client([task_draft("T1", verify=VERIFY)], **extra), lambda r: actions, overrides=ov, files=files or FILES)


def fail(kind: str, n: int = 1) -> CheckResult:
    return CheckResult(name=kind, ok=False, failures=[Failure(kind=kind, file="t.py", name=f"t{i}", message=f"boom {i}") for i in range(n)])


def test_over_budget_splits_mechanical_failures():
    lim, loop = LimitsCfg(max_iterations_per_task=3), LoopCfg()
    assert not over_budget(lim, loop, 4, 2) and over_budget(lim, loop, 5, 2) and over_budget(lim, loop, 3, 0)
    assert over_budget(lim, LoopCfg(split_budgets=False), 3, 2) and "format" in MECHANICAL and "no_change" not in MECHANICAL


def test_score_orders_states_and_signature_changes():
    base = ReviewResult(checks=[fail("test", 3)], approved=False)
    fewer, build = ReviewResult(checks=[fail("test", 1)]), ReviewResult(checks=[fail("build")])
    unmet = ReviewResult(checks=[CheckResult(name="test", ok=True)], llm=LLMVerdict(approved=False, unmet_criteria=["a", "b"]))
    assert progress.score(ReviewResult(approved=True)) == 0
    assert progress.score(fewer) < progress.score(base) < progress.score(build)
    assert 0 < progress.score(unmet) < progress.score(fewer)
    assert progress.signature(fewer) != progress.signature(base) and progress.signature(base) == progress.signature(ReviewResult(checks=[fail("test", 3)]))


def test_baseline_apply_ignores_known_failures_only():
    from sdlc.core.schemas import Task

    old = fail("test", 2)
    known = sorted({test_baseline.key(f) for f in old.failures})
    task = Task(id="T1", title="fix add", description="add must return the sum", language="python", kind="bugfix", target_files=["calc.py"], acceptance_criteria=["sum"])
    assert test_baseline.apply([old], known, None, task)[0].ok
    mixed = CheckResult(name="test", ok=False, failures=[*old.failures, Failure(kind="test", file="t.py", name="new", message="fresh")])
    out = test_baseline.apply([mixed], known, None, task)[0]
    assert not out.ok and [f.name for f in out.failures] == ["new"]
    assert test_baseline.apply([mixed], [], None, task) == [mixed]
    target = Failure(kind="test", file="test_calc.py", name="test_a", message="assert 0 == 3: where 0 = add(1, 2)")
    c = CheckResult(name="test", ok=False, failures=[target])
    assert not test_baseline.apply([c], [test_baseline.key(target)], None, task)[0].ok


def test_rollback_to_best_when_attempt_is_worse(tmp_path: Path):
    e = env(tmp_path, [body("3 if (a, b) == (1, 2) else 0"), body("99"), body("a + b")])
    st = e.run()
    assert st.done and st.state["status"] == "completed"
    types = e.types()
    assert "rolled_back_to_best" in types
    msg = e.backend.requests[2].message
    assert "scored worse" in msg and "restored" in msg
    assert st.state["loop_stats"]["rollbacks"] == 1
    summary = json.loads((e.rt.run_dir / "run_summary.json").read_text())
    assert summary["loop"]["rollbacks"] == 1 and "first_pass_rate" in summary and summary["first_pass_rate"] == 0.0


def test_stall_gate_when_reviews_stop_improving(tmp_path: Path):
    e = env(tmp_path, [body("10"), body("11"), body("12"), body("13"), body("14")])
    st = e.run()
    assert not st.done and st.interrupt["type"] == "human_gate" and st.interrupt["reason"] == "no_progress"
    assert "no_improvement" in e.types()


def test_pre_existing_failing_test_does_not_block_task(tmp_path: Path):
    files = {"calc.py": "def add(a, b):\n    return 0\n", "test_calc.py": TESTS, "test_other.py": "def test_legacy():\n    assert False\n"}
    e = env(tmp_path, [body("a + b")], files=files)
    st = e.run()
    assert st.done and st.state["status"] == "completed"
    ev = [x for x in e.events() if x["type"] == "test_baseline"]
    assert ev and ev[0]["failing"] >= 1 and "baseline_ignored" in e.types()
    (tmp_path / "off").mkdir()
    off = env(tmp_path / "off", [body("a + b")], overrides={"loop": {"test_baseline": False}, "limits": {"max_iterations_per_task": 2}}, files=files)
    st2 = off.run()
    assert not st2.done and st2.interrupt["type"] == "human_gate"


def test_escalation_diagnoses_boosts_and_falls_back(tmp_path: Path):
    ov = {"loop": {"diagnose_after": 1, "boost_after": 2, "fallback_after": 3, "stall_window": 10}, "ollama": {"fallback_models": {"editor": "big-model"}}}
    diag = Diagnosis(root_cause="add ignores its arguments", fix_plan=["return the sum in calc.py add"], avoid="constants")
    e = env(tmp_path, [body("10"), body("11"), body("12"), body("a + b")], overrides=ov, Diagnosis=diag)
    st = e.run()
    assert st.done and st.state["status"] == "completed"
    reqs = e.backend.requests
    assert "DIAGNOSIS" not in reqs[0].message and "DIAGNOSIS" in reqs[1].message and "add ignores its arguments" in reqs[1].message
    assert reqs[1].temp_bump == 0 and reqs[2].temp_bump > 0 and reqs[2].model is None and reqs[3].model == "big-model"
    assert {"diagnosis", "escalation"} <= set(e.types())
    stats = st.state["loop_stats"]
    assert stats["diagnoses"] >= 3 and stats["fallback_model_uses"] == 1


def test_escalation_plan_levels():
    from sdlc.core.config import load_settings

    s = load_settings(overrides={"ollama": {"fallback_models": {"editor": "x"}}})
    assert escalation.plan(s, 1).level == 0 and escalation.plan(s, 2).diagnose and escalation.plan(s, 3).temp_bump > 0
    assert escalation.plan(s, 4).model == "x"
    off = load_settings(overrides={"loop": {"escalation": False}})
    assert escalation.plan(off, 9).level == 0


def test_human_work_resets_loop_counters(tmp_path: Path):
    e = env(tmp_path, [body("10"), body("11"), body("12"), body("13")])
    st = e.run()
    assert st.interrupt["reason"] == "no_progress"
    e.backend.actions = [body("a + b")]
    st = e.resume(decision("work", "return the sum"))
    assert st.done and st.state["status"] == "completed"
