from __future__ import annotations

import json
from pathlib import Path

import pytest

from sdlc.adapters.ollama_client import LLMError, LLMResponse
from sdlc.core.config import load_metrics, load_settings
from sdlc.evals.benchmark_writer import append_records, read_benchmark
from sdlc.evals.metrics import evaluate_run
from sdlc.evals.run_evals import evaluate_run_dir
from sdlc.evals.trace import RunData, build_trace, load_run

from .helpers import make_schema_judge
from .test_graph import Env, calc, client, write

NAMES = ("plan_quality", "plan_adherence", "tool_correctness", "argument_correctness", "step_efficiency", "task_completion")


def tool(tid: str, name: str, **kw):
    return {"type": "tool_call", "task_id": tid, "tool": name, "ok": True, **kw}


def synthetic() -> RunData:
    tasks = [
        {"id": "T1", "title": "fix add", "status": "completed", "language": "python", "kind": "bugfix", "target_files": ["calc.py"],
         "acceptance_criteria": ["a", "b"], "verify_source": "planner", "depends_on": [], "parent_id": None},
        {"id": "T2", "title": "add logging", "status": "skipped", "language": "python", "kind": "feature", "target_files": ["a.py", "b.py", "c.py"],
         "acceptance_criteria": ["x"], "verify_source": "default", "depends_on": ["T1"], "parent_id": None},
    ]
    summary = {"run_id": "r1", "project_id": "demo", "project_name": "demo", "objective": "fix and extend", "final_status": "partial", "num_tasks": 2,
               "tasks_completed": 1, "tasks_skipped": 1, "tasks_blocked": 0, "total_time_s": 12.5, "model_main": "gpt-oss:20b", "model_judge": "gpt-oss:20b",
               "context_size": 32768, "gpu_size_gb": 16, "tasks": tasks, "task_stats": {"T1": {"iterations": 1}, "T2": {"iterations": 3, "escalations": 1}}}
    events = [
        {"type": "plan_ready", "warnings": []},
        tool("T1", "apply_edit", args={"files": ["calc.py"], "format": "diff"}, blocks_applied=1, blocks_failed=0, blocks=[{"path": "calc.py"}]),
        tool("T1", "syntax_check", args={"files": ["calc.py"]}), tool("T1", "run_test", args={"command": "pytest"}),
        tool("T2", "apply_edit", args={"files": ["a.py", "z.py"], "format": "weird"}, blocks_applied=1, blocks_failed=3, blocks=[{"path": "z.py"}]),
        tool("T2", "run_test", args={"command": "make test"}, tool_missing=True),
        {"type": "policy_violation", "task_id": "T2", "command": "make test", "kind": "not_allowed", "reason": "x", "executable": "make"},
        {"type": "task_end", "task_id": "T1", "status": "completed", "files": ["calc.py"]},
    ]
    return RunData(summary, events)


def by_name(results):
    return {r.name: r for r in results}


def test_deterministic_metrics_and_fallback_sources():
    mcfg = load_metrics()
    res = by_name(evaluate_run(synthetic(), None, mcfg, load_settings().evals))
    assert list(res) == list(NAMES)
    assert res["tool_correctness"].source == "deterministic" and res["step_efficiency"].source == "deterministic"
    assert res["plan_quality"].source == "fallback" and res["plan_adherence"].source == "fallback" and res["task_completion"].source == "fallback"
    assert res["step_efficiency"].score == pytest.approx((1.0 + 1 / 4) / 2)
    assert res["task_completion"].score == 0.5 and res["plan_adherence"].score == pytest.approx(0.5 * 0.5 + 0.5 * 1.0)
    assert 0.5 < res["tool_correctness"].score < 1.0
    arg = res["argument_correctness"]
    assert arg.source == "deterministic" and arg.details["by_check"]["verify_command.allowed"] == 0.5
    assert arg.details["by_check"]["apply_edit.format"] == 0.5 and arg.details["by_check"]["apply_edit.blocks_applied"] < 1
    assert 0.3 < res["plan_quality"].score < 0.8
    for r in res.values():
        assert r.band in ("bad", "acceptable", "good") and r.passed == (r.score >= 0.7)
    assert res["task_completion"].band == "bad" and res["step_efficiency"].band == "bad"


def test_trace_budget_shrinks():
    run = synthetic()
    for i in range(40):
        run.events.append(tool("T1", "run_lint", args={"command": "ruff " + "x" * 200}))
    big = build_trace(run, 100_000)
    small = build_trace(run, 2500)
    assert len(json.dumps(small)) <= 2500 < len(json.dumps(big))
    assert small["children"][0]["name"] == "planner"


def test_end_to_end_with_schema_judge_and_global_benchmark(tmp_path: Path):
    env = Env(tmp_path, client(), lambda r: [write("calc.py", calc())])
    assert env.run().state["status"] == "completed"
    judge = make_schema_judge()
    bench = env.settings.benchmark_root() / "benchmark.jsonl"
    results, records = evaluate_run_dir(env.settings, env.rt.run_dir, judge=judge, log=lambda m: None)
    res = by_name(results)
    assert res["plan_quality"].source == "llm" and res["plan_adherence"].source == "llm" and res["task_completion"].source == "llm"
    assert res["tool_correctness"].score == 1.0 and res["step_efficiency"].score == 1.0
    assert res["argument_correctness"].source == "llm" and "llm_score" in res["argument_correctness"].details
    assert {"PlanQualityScore", "PlanAdherenceScore", "TaskCompletionVerdict", "Verdicts"} <= set(judge.calls)
    lines = read_benchmark(bench)
    head = next(r for r in lines if r["type"] == "run_summary")
    for key in ("project_name", "objective", "num_tasks", "total_time_s", "model_main", "model_judge", "context_size", "gpu_size_gb", "final_status", "metrics"):
        assert key in head, key
    assert head["project_name"] == "demo" and head["objective"] == "Fix the add function" and head["num_tasks"] == 1
    assert head["model_judge"] == "schema-judge" and head["self_judged"] is False and set(head["metrics"]) == set(NAMES)
    assert all({"score", "band", "passed", "threshold", "source"} <= set(m) for m in head["metrics"].values())
    assert [r["type"] for r in lines].count("task") == 1 and (env.rt.run_dir / "eval_results.json").exists()
    evaluate_run_dir(env.settings, env.rt.run_dir, judge=judge, log=lambda m: None)
    assert [r["type"] for r in read_benchmark(bench)].count("run_summary") == 1
    other = [{"run_id": "other", "project_id": "p", "project_name": "p", "type": "run_summary"}]
    append_records(bench, other)
    assert {r["run_id"] for r in read_benchmark(bench)} == {"run1", "other"}


def test_judge_failure_falls_back(tmp_path: Path):
    env = Env(tmp_path, client(), lambda r: [write("calc.py", calc())])
    env.run()
    results, _ = evaluate_run_dir(env.settings, env.rt.run_dir, judge=make_schema_judge(fail=True), log=lambda m: None)
    res = by_name(results)
    assert res["plan_quality"].source == "fallback" and "judge unavailable" in res["plan_quality"].reason
    assert res["argument_correctness"].source == "fallback" and res["tool_correctness"].source == "deterministic"
    assert all(0 <= r.score <= 1 for r in results)


def test_task_completion_capped_by_evidence():
    run = synthetic()
    judge = make_schema_judge({"score": 1.0})
    res = by_name(evaluate_run(run, judge, load_metrics(), load_settings().evals))
    tc = res["task_completion"]
    assert tc.source == "llm" and tc.score <= 0.5 and "capped" in tc.reason
    assert res["plan_adherence"].score <= res["plan_adherence"].details["deterministic_score"] + 0.15 + 1e-9


def test_load_run_requires_summary(tmp_path: Path):
    with pytest.raises(FileNotFoundError):
        load_run(tmp_path)


def test_ollama_judge_wrapper():
    from pydantic import BaseModel

    from sdlc.evals.judge import OllamaJudge

    class Out(BaseModel):
        task: str

    class Chat:
        def __init__(self, texts):
            self.texts, self.calls = list(texts), []

        def chat(self, node, messages, **kw):
            self.calls.append(kw)
            return LLMResponse(text=self.texts.pop(0))

    c = Chat(["nope", '{"task": "x"}'])
    j = OllamaJudge(c, "judge-model")
    assert j.generate("p", schema=Out).task == "x" and c.calls[0]["model"] == "judge-model" and c.calls[0]["temperature"] == 0.0
    assert "properties" in c.calls[0]["schema"]
    assert OllamaJudge(Chat(["plain"]), "m").generate("p") == "plain"
    with pytest.raises(LLMError):
        OllamaJudge(Chat(["bad", "bad"]), "m").generate("p", schema=Out)
