from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path

import pytest

from sdlc.core.config import load_metrics
from sdlc.dashboard.build_dashboard import MARKER, build_dashboard, build_data, render_html

NAMES = ("plan_quality", "plan_adherence", "tool_correctness", "argument_correctness", "step_efficiency", "task_completion")
XSS = '</script><img src=x onerror="window.__xss=1">'


def metrics(scores: dict[str, float], source: str = "llm") -> dict:
    mcfg = load_metrics()
    out = {}
    for n in NAMES:
        s = scores.get(n, 0.85)
        out[n] = {"score": s, "band": mcfg.band(n, s), "passed": mcfg.passed(n, s), "threshold": 0.7, "source": source, "reason": f"{n} reason", "details": {"k": 1}}
    return out


def run_rec(run_id: str, project: str, model: str, gpu: int, ctx: int, status: str, ts: str, scores: dict[str, float], objective: str = "do things", judge: str = "judge-a") -> dict:
    return {"type": "run_summary", "run_id": run_id, "project_id": project, "project_name": project, "ts": ts, "objective": objective, "final_status": status,
            "num_tasks": 2, "tasks_completed": 2 if status == "completed" else 1, "tasks_skipped": 0 if status == "completed" else 1, "tasks_blocked": 0,
            "total_time_s": 20.0, "wall_time_s": 30.0, "model_main": model, "model_judge": judge, "self_judged": judge == model, "context_size": ctx,
            "gpu_size_gb": gpu, "kv_cache_type": "q8_0", "iterations_total": 3, "tokens_total": 1234, "escalations": 1, "edit_failure_rate": 0.25,
            "policy_violations": 0, "branch": "b", "eval_time_s": 5.0, "metrics": metrics(scores)}


def records() -> list[dict]:
    recs = [
        run_rec("A", "alpha", "m1", 16, 32768, "completed", "2026-01-01T10:00:00", {}),
        run_rec("B", "alpha", "m1", 16, 32768, "partial", "2026-01-02T10:00:00", {"task_completion": 0.4, "plan_quality": 0.65}, judge="m1"),
        run_rec("C", "beta", "m2", 8, 8192, "partial", "2026-01-03T10:00:00", {"step_efficiency": 0.3}, objective=XSS),
    ]
    for rid in "ABC":
        for i in (1, 2):
            recs.append({"type": "task", "run_id": rid, "task_id": f"T{i}", "title": f"task {i}", "status": "completed", "language": "python", "kind": "bugfix",
                         "files": ["a.py"], "verify_source": "planner", "parent_id": None, "iterations": 1, "suspensions": 0, "escalations": 0, "splits": 0})
    recs.append({"type": "policy_violation", "run_id": "C", "task_id": "T2", "command": "make test", "kind": "not_allowed", "reason": "not in allowlist"})
    return recs


@pytest.fixture
def html_file(tmp_path: Path) -> Path:
    bench = tmp_path / "benchmark.jsonl"
    bench.write_text("\n".join(json.dumps(r) for r in records()) + "\n")
    return build_dashboard(bench, tmp_path / "out" / "dashboard.html")


def test_data_shape_and_ordering():
    data = build_data(records(), load_metrics())
    assert data["order"] == list(NAMES) and [r["run_id"] for r in data["runs"]] == ["A", "B", "C"]
    assert data["specs"]["step_efficiency"]["good_min"] == 0.85 and data["specs"]["plan_quality"]["bad_max"] == 0.59
    assert len(data["runs"][2]["tasks"]) == 2 and data["runs"][2]["violations"][0]["command"] == "make test"
    assert build_data([], load_metrics())["runs"] == []


def test_html_is_self_contained_and_escaped(html_file: Path):
    html = html_file.read_text(encoding="utf-8")
    assert MARKER not in html
    start = html.index('<script type="application/json" id="data">') + len('<script type="application/json" id="data">')
    blob = html[start:html.index("</script>", start)]
    data = json.loads(blob)
    assert data["runs"][2]["objective"] == XSS and "</" not in blob
    urls = set(re.findall(r"https?://[^\s\"')]+", html))
    assert urls <= {"http://www.w3.org/2000/svg"}
    code = html.replace(blob, "")
    for banned in ("fetch(", "XMLHttpRequest", "<link", " src=", "import(", "@import", "innerHTML", "eval("):
        assert banned not in code, banned


def test_empty_benchmark_builds(tmp_path: Path):
    out = build_dashboard(tmp_path / "missing.jsonl", tmp_path / "d.html")
    assert out.exists() and '"runs": []' in out.read_text()


def _jsdom_path() -> str | None:
    for cand in (os.environ.get("JSDOM_PATH"), "/tmp/jsd/node_modules"):
        if cand and (Path(cand) / "jsdom").exists():
            return cand
    return None


@pytest.mark.skipif(shutil.which("node") is None or _jsdom_path() is None, reason="node with jsdom not available")
def test_dom_behaviour(html_file: Path):
    env = {**os.environ, "NODE_PATH": _jsdom_path()}
    r = subprocess.run(["node", str(Path(__file__).with_name("dom_check.js")), str(html_file)], capture_output=True, text=True, env=env, timeout=120)
    assert r.returncode == 0, r.stderr
    out = json.loads(r.stdout.strip().splitlines()[-1])
    assert out["errors"] == []
    assert out["rows0"] == 3 and out["matrixRows"] == 6 and out["groupsRows"] == 2
    assert out["polylines0"] == 6 and out["polylinesAfterToggle"] == 5 and out["legendOff"] == 1
    assert "3 of 3 run(s)" in out["summary"] and "1 self-judged" in out["summary"]
    assert out["goodCell"].startswith("good") and out["okCell"].startswith("ok") and out["badCell"].startswith("bad")
    assert out["warnCell"].startswith("warn")
    assert out["filterOptions"] == ["", "alpha", "beta"]
    assert out["rowsBeta"] == 1 and out["groupsBeta"] == 1 and out["selRows"] == 1
    assert "Rejected verify commands" in out["detailText"] and "make test" in out["detailText"] and XSS in out["detailText"]
    assert out["imgCount"] == 0 and out["xss"] is True
    assert out["rowsCompleted"] == 1 and out["rowsNone"] == 0 and "No runs match" in out["emptyMsg"]


@pytest.mark.skipif(shutil.which("node") is None or _jsdom_path() is None, reason="node with jsdom not available")
def test_deep_link_selects_run(html_file: Path):
    env = {**os.environ, "NODE_PATH": _jsdom_path()}
    r = subprocess.run(["node", str(Path(__file__).with_name("dom_check.js")), str(html_file), "#run=B"], capture_output=True, text=True, env=env, timeout=120)
    assert r.returncode == 0, r.stderr
    out = json.loads(r.stdout.strip().splitlines()[-1])
    assert out["errors"] == [] and out["selRows"] == 1 and "alpha - B" in out["detailText"] and "plan_quality reason" in out["detailText"]
