from __future__ import annotations

import json
import stat
import sys
from pathlib import Path

import httpx
import pytest
from pydantic import BaseModel

from sdlc.adapters import edit_engine as ee
from sdlc.adapters.aider_cli import AiderCliBackend, parse_tokens, response_text
from sdlc.adapters.edit_types import EditRequest
from sdlc.adapters.editor_backend import HybridEditor
from sdlc.adapters.git_ops import GitRepo
from sdlc.adapters.ollama_client import LLMError, LLMResponse, OllamaClient, extract_json
from sdlc.core.config import load_settings


# ---------- ollama ----------
class Out(BaseModel):
    n: int


def make_client(handler) -> OllamaClient:
    return OllamaClient(load_settings(), transport=httpx.MockTransport(handler))


def test_extract_json_and_structured_retry():
    assert extract_json('noise {"a": 1} tail') == {"a": 1}
    calls = []

    def handler(req: httpx.Request) -> httpx.Response:
        body = json.loads(req.content)
        calls.append(body)
        text = "not json" if len(calls) == 1 else '{"n": 7}'
        return httpx.Response(200, json={"message": {"content": text}, "prompt_eval_count": 10, "eval_count": 5})

    obj, resp = make_client(handler).structured("planner", [{"role": "user", "content": "x"}], Out)
    assert obj.n == 7 and len(calls) == 2 and "format" in calls[0] and calls[0]["think"] == "high"
    assert calls[0]["options"]["num_ctx"] == 32768


def test_think_fallback_and_models():
    seen = []

    def handler(req: httpx.Request) -> httpx.Response:
        if req.url.path == "/api/tags":
            return httpx.Response(200, json={"models": [{"name": "b"}, {"name": "a"}]})
        body = json.loads(req.content)
        seen.append("think" in body)
        if "think" in body:
            return httpx.Response(400, text='{"error":"model does not support thinking"}')
        return httpx.Response(200, json={"message": {"content": "ok"}})

    c = make_client(handler)
    assert c.chat("editor", [{"role": "user", "content": "hi"}]).text == "ok"
    assert seen == [True, False]
    assert c.list_models() == ["a", "b"]
    with pytest.raises(LLMError):
        c.require_model("zzz")


def test_non_local_url_rejected():
    with pytest.raises(RuntimeError):
        OllamaClient(load_settings(overrides={"ollama": {"base_url": "http://example.com:11434"}}))


# ---------- git ----------
def test_git_flow(tmp_path: Path):
    (tmp_path / "a.py").write_text("x = 1\n")
    g = GitRepo(tmp_path)
    assert g.ensure_repo() is True
    branch, base = g.create_run_branch("sdlc/run-", "r1")
    assert branch == "sdlc/run-r1" and g.current_branch() == branch
    t0 = g.snapshot()
    (tmp_path / "a.py").write_text("x = 2\n")
    (tmp_path / "new.py").write_text("y = 1\n")
    t1 = g.snapshot()
    assert sorted(g.changed_between(t0, t1)) == ["a.py", "new.py"]
    assert "+x = 2" in g.diff_trees(t0, t1)
    assert "+x = 2" in g.diff_since(base)
    sha = g.commit_all("sdlc(T1): change")
    assert sha and g.commit_all("nothing") is None
    (tmp_path / "a.py").write_text("x = 3\n")
    (tmp_path / "later.py").write_text("z\n")
    g.restore_paths(t1, ["a.py", "later.py"])
    assert (tmp_path / "a.py").read_text() == "x = 2\n" and not (tmp_path / "later.py").exists()
    (tmp_path / "a.py").write_text("junk\n")
    g.reset_to(base)
    assert (tmp_path / "a.py").read_text() == "x = 1\n" and not (tmp_path / "new.py").exists()


# ---------- edit engine ----------
SRC = "def add(a, b):\n    total = a + b\n    return total\n\n\ndef sub(a, b):\n    return a - b\n"


def run_blocks(tmp_path: Path, src: str, text: str, allowed=("m.py",)):
    (tmp_path / "m.py").write_text(src)
    blocks = ee.parse_blocks(text)
    results, changed = ee.apply_blocks(tmp_path, blocks, list(allowed))
    return results, changed, (tmp_path / "m.py").read_text()


def block(path: str, s: str, r: str) -> str:
    return f"{path}\n<<<<<<< SEARCH\n{s}\n=======\n{r}\n>>>>>>> REPLACE\n"


def test_exact_and_whitespace_and_indent(tmp_path: Path):
    res, ch, out = run_blocks(tmp_path, SRC, block("m.py", "    return a - b", "    return a - b + 0"))
    assert res[0].ok and res[0].mode == "exact" and "a - b + 0" in out
    res, ch, out = run_blocks(tmp_path, SRC, block("m.py", "return   total", "return total * 2"))
    assert res[0].ok and res[0].mode == "whitespace" and "    return total * 2" in out
    res, ch, out = run_blocks(tmp_path, SRC, block("m.py", "total = a + b\nreturn total", "total = a + b\nif total < 0:\n    total = 0\nreturn total"))
    assert res[0].ok and "        total = 0" in out


def test_ambiguous_and_missing_hint(tmp_path: Path):
    src = "def f():\n    return 1\n\n\ndef g():\n    return 1\n"
    res, ch, out = run_blocks(tmp_path, src, block("m.py", "    return 1", "    return 2"))
    assert not res[0].ok and "matches 2 places" in res[0].error and out == src
    res, ch, out = run_blocks(tmp_path, SRC, block("m.py", "def add(a, b):\n    result = a * b\n    return result", "x"))
    assert not res[0].ok and "not found" in res[0].error and "Closest" in res[0].hint


def test_fuzzy_match(tmp_path: Path):
    big = "\n".join(f"line_{i} = {i}" for i in range(40)) + "\n"
    res, ch, out = run_blocks(tmp_path, big, block("m.py", "line_10 = 10\nline_11 = 11\nline_12 = 12x\nline_13 = 13", "line_10 = 0"))
    assert res[0].ok and res[0].mode == "fuzzy" and "line_10 = 0" in out and "line_14 = 14" in out


def test_elision_partial_create_scope_and_overlap(tmp_path: Path):
    res, ch, out = run_blocks(tmp_path, SRC, block("m.py", "def add(a, b):\n...\n    return total", "def add(x, y):\n...\n    return total"))
    assert res[0].mode == "elision" and "def add(x, y):\n    total = a + b" in out
    two = block("m.py", "    return a - b", "    return a * b") + block("m.py", "no such text here", "zzz")
    res, ch, out = run_blocks(tmp_path, SRC, two)
    assert [r.ok for r in res] == [True, False] and ch == ["m.py"] and "a * b" in out
    (tmp_path / "m.py").write_text(SRC)
    res, ch = ee.apply_blocks(tmp_path, ee.parse_blocks(block("pkg/new.py", "", "VALUE = 1")), ["m.py"])
    assert res[0].ok and (tmp_path / "pkg/new.py").read_text() == "VALUE = 1\n"
    res, ch = ee.apply_blocks(tmp_path, ee.parse_blocks(block("../evil.py", "", "x")), None)
    assert not res[0].ok and not (tmp_path.parent / "evil.py").exists()
    ov = block("m.py", "    total = a + b\n    return total", "    return a + b") + block("m.py", "    return total", "    return 0")
    res, ch, out = run_blocks(tmp_path, SRC, ov)
    assert [r.ok for r in res] == [True, False] and "overlaps" in res[1].error


def test_crlf_preserved_and_noop(tmp_path: Path):
    (tmp_path / "m.py").write_bytes(b"a = 1\r\nb = 2\r\n")
    res, ch = ee.apply_blocks(tmp_path, ee.parse_blocks(block("m.py", "b = 2", "b = 3")), ["m.py"])
    assert (tmp_path / "m.py").read_bytes() == b"a = 1\r\nb = 3\r\n"
    res, ch = ee.apply_blocks(tmp_path, ee.parse_blocks(block("m.py", "b = 3", "b  =  3")), ["m.py"])
    assert res[0].mode == "noop" and ch == []


def test_parse_whole_and_apply(tmp_path: Path):
    files = ee.parse_whole("Here:\nm.py\n```python\nx = 1\n```\n")
    assert files == {"m.py": "x = 1\n"}
    res, ch = ee.apply_whole(tmp_path, files, ["m.py"])
    assert res[0].ok and (tmp_path / "m.py").read_text() == "x = 1\n"


# ---------- aider backend ----------
HISTORY = (
    "TO LLM 2025-01-01 10:00:00\nexample\n<<<<<<< SEARCH\nfoo\n=======\nbar\n>>>>>>> REPLACE\n"
    "LLM RESPONSE 2025-01-01 10:00:05\ncalc.py\n<<<<<<< SEARCH\n    return a - b\n=======\n    return a + b\n>>>>>>> REPLACE\n"
)

FAKE = '''#!{py}
import sys, pathlib
a = sys.argv[1:]
val = lambda f: a[a.index(f) + 1]
msg = pathlib.Path(val("--message-file")).read_text()
target = pathlib.Path(a[-1])
if "NOOP" not in msg:
    target.write_text(target.read_text().replace("a - b", "a + b"))
    pathlib.Path(val("--llm-history-file")).write_text({hist!r})
    print("Applied edit to", a[-1])
print("Tokens: 1.2k sent, 300 received.")
'''


def fake_aider(tmp_path: Path) -> Path:
    p = tmp_path / "fake_aider"
    p.write_text(FAKE.format(py=sys.executable, hist=HISTORY))
    p.chmod(p.stat().st_mode | stat.S_IEXEC)
    return p


def test_aider_parsing_helpers():
    assert parse_tokens("Tokens: 1.2k sent, 300 received.\nTokens: 800 sent, 2.5k received.") == (2000, 2800)
    resp = response_text(HISTORY)
    assert "a + b" in resp and "foo" not in resp


def test_aider_backend_and_hybrid_fallback(tmp_path: Path):
    repo = tmp_path / "repo"
    repo.mkdir()
    (repo / "calc.py").write_text("def calc(a, b):\n    return a - b\n")
    g = GitRepo(repo)
    g.ensure_repo()
    s = load_settings(overrides={"aider": {"binary": str(fake_aider(tmp_path))}})
    run_dir = tmp_path / "run"
    be = AiderCliBackend(s, g)
    assert be.available()
    cmd = be.build_command(EditRequest(repo, ["calc.py"], "m", run_dir, "t1", read_files=["README.md"]), run_dir)
    assert "--no-auto-commits" in cmd and cmd[-1] == "calc.py" and "ollama_chat/gpt-oss:20b" in cmd and "--read" in cmd
    res = be.edit(EditRequest(repo, ["calc.py"], "fix it", run_dir, "t1"))
    assert res.ok and res.files_changed == ["calc.py"] and "+    return a + b" in res.diff
    assert res.tokens_in == 1200 and res.blocks[0]["path"] == "calc.py" and res.edit_format == "aider-diff"

    (repo / "calc.py").write_text("def calc(a, b):\n    return a - b\n")
    g.commit_all("reset")

    class FakeClient:
        def chat(self, node, messages, **kw):
            return LLMResponse(text=block("calc.py", "    return a - b", "    return a * b"), prompt_tokens=50, completion_tokens=20)

    hy = HybridEditor(s, FakeClient(), g)  # type: ignore[arg-type]
    noop = EditRequest(repo, ["calc.py"], "NOOP", run_dir, "t2")
    assert hy.plan(noop, 0) == ("aider", "diff") and hy.plan(noop, 2) == ("native", "whole") and hy.plan(noop, 3) == ("native", "whole")
    r = hy.edit(noop, failures=0)
    assert not r.ok and "no changes" in r.error
    r = hy.edit(EditRequest(repo, ["calc.py"], "fix it", run_dir, "t3"), failures=2)
    assert r.ok and r.edit_format == "native-whole" and r.invocation["parsed_as"] == "search-replace" and "a * b" in (repo / "calc.py").read_text() and r.blocks_applied == 1


def test_lenient_formats(tmp_path):
    from sdlc.adapters import edit_engine as ee

    assert len(ee.parse_blocks("a.py\n<<<< SEARCH\nx = 1\n====\nx = 2\n>>>> REPLACE\n", "")) == 1
    diff = "```diff\n--- a/a.py\n+++ b/a.py\n@@ -1,2 +1,2 @@\n def f():\n-    return 1\n+    return 2\n```\n"
    b = ee.parse_unified(diff, "")
    assert len(b) == 1 and b[0].path == "a.py" and b[0].search == "def f():\n    return 1" and b[0].replace == "def f():\n    return 2"
    assert ee.single_fenced("text\n```js\nlet a = 1;\n```\n") == "let a = 1;\n"


def test_two_whole_files_answer_to_diff_prompt(tmp_path):
    from sdlc.adapters.edit_types import EditRequest
    from sdlc.adapters.git_ops import GitRepo
    from sdlc.adapters.native_editor import NativeEditor
    from sdlc.adapters.ollama_client import LLMResponse
    from sdlc.core.config import load_settings

    repo = tmp_path / "r"
    repo.mkdir()
    (repo / "a.h").write_text("int a();\n")
    (repo / "a.cpp").write_text("int a() { return 1; }\n")
    g = GitRepo(repo)
    g.ensure_repo()
    g.commit_all("init")

    class C:
        def chat(self, node, messages, **kw):
            return LLMResponse(text="a.h\n```\nint a();\nint b();\n```\n\na.cpp\n```\nint a() { return 1; }\nint b() { return 2; }\n```\n")

    r = NativeEditor(load_settings(), C(), g).edit(EditRequest(repo, ["a.h", "a.cpp"], "add b", tmp_path, "t", edit_format="diff"))
    assert r.ok and r.invocation["parsed_as"] == "whole-file" and "int b();" in (repo / "a.h").read_text()


def test_missing_verify_tool_is_skipped(tmp_path):
    from sdlc.runners.python_runner import PythonRunner

    r = PythonRunner(tmp_path).run_kind("test", [], command="definitely_not_installed_tool --x")
    assert r.ok and r.skipped and "not used as a gate" in r.output_tail
