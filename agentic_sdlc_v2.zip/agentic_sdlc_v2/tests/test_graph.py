from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any, Callable

import pytest

from sdlc.agents.critic import Critique
from sdlc.agents.planner import PlanDraft, TaskDraft, VerifyFixes
from sdlc.agents.reviewer import ReviewDraft
from sdlc.agents.splitter import SplitPlan, SubTask
from sdlc.core.config import load_settings
from sdlc.core.project_store import ProjectStore
from sdlc.core.schemas import EditResult
from sdlc.graph import routing
from sdlc.graph.builder import build_graph, current_status, open_checkpointer, resume_pipeline, run_pipeline
from sdlc.graph.human_gate import approval, decision, read_issue
from sdlc.graph.runtime import build_runtime
from sdlc.telemetry.jsonl_logger import read_events

from .helpers import PY_FILES, FakeClient

CALC = "def add(a, b):\n    return {add}\n\n\nclass Calc:\n    def mul(self, a, b):\n        return {mul}\n"


def calc(add: str = "a + b", mul: str = "a * b") -> str:
    return CALC.format(add=add, mul=mul)


def write(path: str, text: str) -> Callable[[Path], EditResult]:
    def act(repo: Path) -> EditResult:
        (repo / path).write_text(text)
        return EditResult(ok=True, files_changed=[path], blocks_applied=1, edit_format="native-diff")

    return act


def truncated(repo: Path) -> EditResult:
    return EditResult(ok=False, truncated=True, error="output truncated (length limit reached)", edit_format="native-diff")


class Scripted:
    def __init__(self, repo: Path, actions: list[Callable[[Path], EditResult]]):
        self.repo, self.actions, self.requests = repo, list(actions), []

    def edit(self, req, failures=0):
        self.requests.append(req)
        action = self.actions.pop(0) if len(self.actions) > 1 else self.actions[0]
        return action(self.repo)


def task_draft(tid: str = "T1", verify: str = "python3 -m pytest -x -q", deps: list[str] | None = None, title: str = "fix add") -> TaskDraft:
    return TaskDraft(id=tid, title=title, description="add must return the sum", language="python", kind="bugfix",
                     target_files=["calc.py"], acceptance_criteria=["add returns the sum", "negative numbers work"],
                     verify_command=verify, depends_on=deps or [])


def client(tasks: list[TaskDraft] | None = None, **extra: Any) -> FakeClient:
    plan = PlanDraft(summary="fix the calculator", assumptions=["python only"], tasks=tasks or [task_draft()])
    return FakeClient(PlanDraft=plan, Critique=Critique(ok=True), ReviewDraft=ReviewDraft(approved=True), VerifyFixes=VerifyFixes(), **extra)


class Env:
    def __init__(self, tmp_path: Path, fake: FakeClient, actions: Callable[[Path], list], overrides: dict | None = None,
                 files: dict[str, str] | None = None, run_id: str = "run1"):
        self.tmp, self.fake, self.run_id = tmp_path, fake, run_id
        self.settings = load_settings(overrides={"features": {"plan_approval": False}, "paths": {"projects_root": str(tmp_path / "projects"), "benchmark_dir": str(tmp_path / "bench")}, **(overrides or {})})
        src = tmp_path / "src"
        src.mkdir(exist_ok=True)
        for name, text in (files or PY_FILES).items():
            (src / name).write_text(text)
        self.store = ProjectStore(self.settings)
        self.project = self.store.open(src, "demo")
        self.backend = Scripted(self.project.code, actions(self.project.code))
        self.open()

    def open(self) -> None:
        self.rt = build_runtime(self.settings, self.project, self.store, self.run_id, client=self.fake, editor_backend=self.backend)
        self.app = build_graph(self.rt, open_checkpointer(self.project.run_dir(self.run_id) / "checkpoint.sqlite"))

    def run(self, requirements: str = "Fix the add function"):
        return run_pipeline(self.app, self.rt, requirements)

    def resume(self, value: Any):
        return resume_pipeline(self.app, self.run_id, value)

    def events(self) -> list[dict]:
        return read_events(self.rt.run_dir / "events.jsonl")

    def types(self) -> list[str]:
        return [e["type"] for e in self.events()]

    @property
    def code(self) -> Path:
        return self.project.code


def test_happy_path(tmp_path: Path):
    env = Env(tmp_path, client(), lambda r: [write("calc.py", calc())])
    st = env.run()
    assert st.done and st.interrupt is None and st.state["status"] == "completed"
    assert env.code.joinpath("calc.py").read_text() == calc()
    assert "sdlc(T1): fix add" in env.rt.git.run("log", "--format=%s")
    assert env.rt.git.current_branch() == "sdlc/run-run1"
    run_dir = env.rt.run_dir
    summary = json.loads((run_dir / "run_summary.json").read_text())
    assert summary["final_status"] == "completed" and summary["num_tasks"] == 1 and summary["tasks_completed"] == 1
    assert summary["project_name"] == "demo" and summary["context_size"] == 32768 and summary["model_main"] == "gpt-oss:20b"
    assert summary["iterations_total"] == 1 and summary["edit_failure_rate"] == 0 and summary["total_time_s"] > 0
    assert (run_dir / "design_brief.md").exists() and (run_dir / "stack.json").exists() and (run_dir / "issue.md").exists() and (run_dir / "events.jsonl").exists()
    types = env.types()
    for t in ("run_start", "manifest", "plan_ready", "task_start", "tool_call", "review", "task_end", "run_end", "node"):
        assert t in types, t
    tools = {e.get("tool") for e in env.events() if e["type"] == "tool_call"}
    assert {"apply_edit", "syntax_check", "run_test"} <= tools
    assert env.rt.ledger.open_issues("T1") == []
    assert json.loads(env.project.manifest_path.read_text())["project_id"] == "demo"


def drive_to_gate(tmp_path: Path, then: Callable[[Path], list] | None = None):
    bad = write("calc.py", calc(add="a * b"))
    env = Env(tmp_path, client(), lambda r: [bad], overrides={"limits": {"max_iterations_per_task": 2}})
    st = env.run()
    assert not st.done and st.interrupt["type"] == "human_gate" and st.interrupt["reason"] == "max_iterations"
    return env, st


def test_gate_work_with_hint_and_cross_process_resume(tmp_path: Path):
    env, st = drive_to_gate(tmp_path)
    issue = read_issue(env.rt.run_dir)
    assert issue["task"]["id"] == "T1" and issue["iteration"] == 2 and "a * b" in issue["diff"] and issue["history"]
    assert st.interrupt["issue_path"].endswith("issue.json")
    env.backend.actions = [write("calc.py", calc())]
    env.open()
    assert current_status(env.app, "run1").interrupt["type"] == "human_gate"
    st = env.resume(decision("work", "use addition"))
    assert st.done and st.state["status"] == "completed" and st.state["escalations"] == 1
    assert "HUMAN HINT: use addition" in env.backend.requests[-1].message
    gate_log = (env.rt.run_dir / "human_gate.jsonl").read_text().splitlines()
    assert json.loads(gate_log[0])["decision"]["action"] == "work"
    assert env.rt.ledger.open_issues("T1") == []


def test_gate_proceed_skips_and_resets(tmp_path: Path):
    env, _ = drive_to_gate(tmp_path)
    st = env.resume(decision("proceed"))
    assert st.done and st.state["status"] == "partial"
    assert env.code.joinpath("calc.py").read_text() == PY_FILES["calc.py"]
    assert [t["status"] for t in st.state["tasks"]] == ["skipped"]
    ends = [e for e in env.events() if e["type"] == "task_end"]
    assert ends[-1]["status"] == "skipped"


def test_gate_abort(tmp_path: Path):
    env, _ = drive_to_gate(tmp_path)
    st = env.resume(decision("abort"))
    assert st.done and st.state["status"] == "aborted"
    assert env.code.joinpath("calc.py").read_text() == PY_FILES["calc.py"]
    assert json.loads((env.rt.run_dir / "run_summary.json").read_text())["final_status"] == "aborted"


def test_suspend_shrink_then_split(tmp_path: Path):
    split = SplitPlan(subtasks=[
        SubTask(title="fix add", target_files=["calc.py"], acceptance_criteria=["add returns the sum"]),
        SubTask(title="document add", target_files=["calc.py"], acceptance_criteria=["add is documented"]),
    ])
    fixed = write("calc.py", calc())
    documented = write("calc.py", "# add helpers\n" + calc())
    env = Env(tmp_path, client(SplitPlan=split), lambda r: [truncated, truncated, truncated, fixed, documented])
    st = env.run()
    assert st.done and st.state["status"] == "completed"
    statuses = {t["id"]: t["status"] for t in st.state["tasks"]}
    assert statuses == {"T1": "completed", "T1.1": "completed", "T1.2": "completed"}
    ev = env.events()
    suspended = [e for e in ev if e["type"] == "task_suspended"]
    assert [e["shrink_level"] for e in suspended] == [1, 2, 3] and all(e["reason"] == "token_exhausted" for e in suspended)
    starts = [e["action"] for e in ev if e["type"] == "task_start" and e["task_id"] == "T1"]
    assert starts == ["start", "trim", "narrow", "split"]
    assert any(e["type"] == "task_split" and e["children"] == ["T1.1", "T1.2"] for e in ev)
    assert env.code.joinpath("calc.py").read_text().startswith("# add helpers")
    assert "NARROW SCOPE" not in env.backend.requests[0].message
    log = env.rt.git.run("log", "--format=%s")
    assert "sdlc(T1.1)" in log and "sdlc(T1.2)" in log


def test_suspend_limit_goes_to_gate(tmp_path: Path):
    env = Env(tmp_path, client(SplitPlan=SplitPlan.model_construct(subtasks=[])), lambda r: [truncated],
              overrides={"limits": {"max_suspended_frames": 1, "max_shrink_level": 1}})
    st = env.run()
    assert not st.done and st.interrupt["reason"] == "suspend_limit"
    st = env.resume(decision("abort"))
    assert st.state["status"] == "aborted"


@pytest.mark.skipif(shutil.which("make") is None, reason="make not installed")
def test_command_approval_interrupt(tmp_path: Path):
    files = {**PY_FILES, "Makefile": "test:\n\tpython3 -m pytest -x -q\n"}
    fake = client([task_draft(verify="make test")])
    env = Env(tmp_path, fake, lambda r: [write("calc.py", calc())], files=files)
    st = env.run()
    assert not st.done and st.interrupt["type"] == "approve_commands" and st.interrupt["proposals"] == ["make"]
    assert st.interrupt["events"][0]["command"] == "make test"
    st = env.resume(approval(["make"]))
    assert st.done and st.state["status"] == "completed"
    assert st.state["tasks"][0]["verify_command"] == "make test" and st.state["tasks"][0]["verify_source"] == "planner"
    assert json.loads(env.project.approved_commands_path.read_text()) == ["make"]
    assert any(e["type"] == "commands_approved" and e["approved"] == ["make"] for e in env.events())


def test_regression_gate_catches_broken_earlier_task(tmp_path: Path):
    files = {**PY_FILES, "test_mul.py": "from calc import Calc\n\n\ndef test_mul():\n    assert Calc().mul(2, 3) == 6\n"}
    tasks = [task_draft("T1", "python3 -m pytest -q test_calc.py"),
             task_draft("T2", "python3 -m pytest -q test_mul.py", ["T1"], "tune mul")]
    breaks_add = write("calc.py", calc(add="a - b", mul="b * a"))
    all_good = write("calc.py", calc(mul="b * a"))
    env = Env(tmp_path, client(tasks), lambda r: [write("calc.py", calc()), breaks_add, all_good], files=files)
    st = env.run()
    assert st.done and st.state["status"] == "completed"
    ev = env.events()
    failed = [e for e in ev if e["type"] == "regression_failed"]
    assert len(failed) == 1 and failed[0]["task_id"] == "T2" and failed[0]["earlier"] == ["T1"]
    t2 = [i for i in env.rt.ledger.issues.values() if i.task_id == "T2" and i.kind == "regression"]
    assert t2 and t2[0].status.value == "resolved"
    assert env.code.joinpath("calc.py").read_text() == calc(mul="b * a")
    assert st.state["task_stats"]["T2"]["iterations"] == 2


def test_budget_exceeded_finishes_cleanly(tmp_path: Path):
    env = Env(tmp_path, client(), lambda r: [write("calc.py", calc())])
    env.rt.guard.tokens_used = 10**9
    st = env.run()
    assert st.done and st.state["status"] == "budget_exceeded"
    assert json.loads((env.rt.run_dir / "run_summary.json").read_text())["final_status"] == "budget_exceeded"
    assert "budget_exceeded" in env.types()


def test_plan_failure_finishes_as_failed(tmp_path: Path):
    from sdlc.adapters.ollama_client import LLMError

    fake = FakeClient(PlanDraft=LLMError("model down"), Critique=Critique(ok=True))
    env = Env(tmp_path, fake, lambda r: [write("calc.py", calc())])
    st = env.run()
    assert st.done and st.state["status"] == "failed" and "planning failed" in st.state["error"]


def test_routing_functions():
    from sdlc.core.config import LimitsCfg

    assert routing.after_plan({"allow_proposals": [{"executable": "make"}]}) == "approve_commands"
    assert routing.after_plan({"status": "failed"}) == "finish" and routing.after_plan({}) == "pick"
    assert routing.after_pick({"status": "all_done"}) == "integrate" and routing.after_integrate({}) == "finish" and routing.after_integrate({"integration_added": True}) == "pick" and routing.after_pick({"resume_action": "split"}) == "split"
    assert routing.after_edit({"suspend_reason": "x", "gate_reason": "y"}) == "suspend"
    assert routing.after_edit({"gate_reason": "max_iterations"}) == "gate" and routing.after_edit({"edit_ok": True}) == "review"
    assert routing.after_edit({}) == "edit"
    assert routing.after_review({"approved": True}) == "regression" and routing.after_review({"gate_reason": "no_progress"}) == "gate"
    assert routing.after_regression({"regression_ok": True}) == "commit" and routing.after_regression({}) == "edit"
    assert routing.after_gate({"decision": {"action": "work"}}) == "edit" and routing.after_gate({"decision": {"action": "proceed"}}) == "pick"
    assert routing.after_gate({"decision": {"action": "abort"}}) == "finish"
    assert routing.stalled(["a", "b", "b"], LimitsCfg()) and not routing.stalled(["a", "b"], LimitsCfg())
    assert routing.ladder_limit(2) == 4


def test_repeated_guard_problem_goes_to_gate_with_explanation(tmp_path):
    bad = write("calc.py", calc() + "\n\ndef add(a, b):\n    return 0\n")
    env = Env(tmp_path, client(), lambda code: [bad, bad, bad, bad, bad])
    status = env.run()
    assert status.interrupt and status.interrupt["type"] == "human_gate"
    assert status.interrupt["explanation"]["what_happened"]
    assert any(e["type"] == "repeat_problem" for e in env.rt.logger.read()) if hasattr(env.rt.logger, "read") else True


def test_two_noop_edits_review_existing_code(tmp_path):
    from .helpers import PY_FILES

    files = {**PY_FILES, "calc.py": PY_FILES["calc.py"].replace("return a - b", "return a + b")}
    same = write("calc.py", files["calc.py"])
    env = Env(tmp_path, client(), lambda code: [same, same, same], files=files)
    status = env.run()
    events = [json.loads(x) for x in (env.project.run_dir("run1") / "events.jsonl").read_text().splitlines()]
    assert any(e["type"] == "no_change_review" for e in events)
    assert status.state["status"] in ("completed", "partial") and status.state["tasks"][0]["status"] == "completed"


def test_gate_accept_keeps_change_and_completes(tmp_path: Path):
    env, _ = drive_to_gate(tmp_path)
    changed = env.code.joinpath("calc.py").read_text()
    st = env.resume(decision("accept"))
    assert st.done and [t["status"] for t in st.state["tasks"]] == ["completed"]
    assert env.code.joinpath("calc.py").read_text() == changed
    ends = [e for e in env.events() if e["type"] == "task_end"]
    assert ends[-1]["status"] == "completed" and ends[-1].get("accepted_by") == "human"
    assert any(e["type"] == "human_accept" for e in env.events())


def test_gate_restart_discards_changes_and_redoes_task(tmp_path: Path):
    env, _ = drive_to_gate(tmp_path)
    seen: list[str] = []
    good = write("calc.py", calc())

    def fresh(repo: Path):
        seen.append((repo / "calc.py").read_text())
        return good(repo)

    env.backend.actions = [fresh]
    st = env.resume(decision("restart", "use addition"))
    assert st.done and st.state["status"] == "completed"
    assert "return a * b\n\n\nclass" not in seen[0]
    assert "HUMAN HINT: use addition" in env.backend.requests[-1].message
    assert any(e["type"] == "task_restart" for e in env.events())


def _two_task_gate(tmp_path: Path):
    good, bad = write("calc.py", calc()), write("calc.py", calc(add="a * b"))
    tasks = [task_draft("T1"), task_draft("T2", deps=["T1"], title="second")]
    env = Env(tmp_path, client(tasks), lambda r: [good, bad], overrides={"limits": {"max_iterations_per_task": 2}})
    st = env.run()
    assert st.interrupt["type"] == "human_gate" and st.interrupt["task_id"] == "T2"
    return env


def test_gate_replan_keeps_completed_and_adds_new_tasks(tmp_path: Path):
    env = _two_task_gate(tmp_path)
    env.fake.responses["PlanDraft"] = [PlanDraft(summary="again", tasks=[task_draft("T1", title="missing step"), task_draft("T2", deps=["T1"], title="redo second")])]
    env.backend.actions = [write("calc.py", calc(mul="b * a")), write("calc.py", calc())]
    st = env.resume(decision("replan", "add the missing step first"))
    tasks = {t["id"]: t for t in st.state["tasks"]}
    assert st.done and set(tasks) == {"T1", "T3", "T4"}
    assert tasks["T1"]["status"] == "completed" and tasks["T4"]["depends_on"] == ["T3"]
    ev = [e for e in env.events() if e["type"] == "replan"]
    assert ev and ev[0]["keep_done"] and "T2 second" in ev[0]["before"]
    prompt = [m for name, m in env.fake.calls if name == "PlanDraft"][-1][-1]["content"]
    assert "T2 [STUCK]" in prompt and "add the missing step first" in prompt and "T1 [completed]" in prompt


def test_gate_replan_all_rolls_back_whole_run(tmp_path: Path):
    env = _two_task_gate(tmp_path)
    env.fake.responses["PlanDraft"] = [PlanDraft(summary="again", tasks=[task_draft("T1", title="fresh")])]
    seen: list[str] = []

    def fresh(repo: Path):
        seen.append((repo / "calc.py").read_text())
        return write("calc.py", calc())(repo)

    env.backend.actions = [fresh]
    st = env.resume(decision("replan_all"))
    assert st.done and [t["id"] for t in st.state["tasks"]] == ["T3"]
    assert seen[0] != calc()


def test_optional_task_is_skipped_without_human_gate(tmp_path: Path):
    bad = write("calc.py", calc(add="a * b"))
    t1 = task_draft("T1", title="Characterize existing calc behaviour")
    env = Env(tmp_path, client([t1]), lambda r: [bad], overrides={"limits": {"max_iterations_per_task": 2}})
    st = env.run()
    tasks = {t["id"]: t for t in st.state["tasks"]}
    assert tasks["T1"]["optional"] is True
    assert st.done and tasks["T1"]["status"] == "skipped" and st.state["status"] in ("completed", "partial")
    assert any(e["type"] == "optional_task_skipped" for e in env.events())
    assert not any(e["type"] == "human_gate" for e in env.events())
