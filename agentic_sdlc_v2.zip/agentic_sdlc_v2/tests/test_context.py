from __future__ import annotations

from sdlc.agents import context_select as cs
from sdlc.core import symbols as sym
from sdlc.core import ts_symbols


def test_tree_sitter_finds_what_regex_missed():
    src = "class A {\npublic:\n  A();\n  int f() const { return 1; }\n};\nA::A() {}\ndouble A::g(int x) const\n{\n  return x;\n}\nenum class Mode { X, Y };\n"
    names = {s.name for s in sym.extract("cpp", src)}
    if ts_symbols.available("cpp"):
        assert {"A", "A.f", "A::A", "A::g", "Mode"} <= names
    else:
        assert "A" in names


def test_js_nested_duplicates_and_methods():
    src = "document.addEventListener('x', () => {\n  function load() {}\n  function load() {}\n});\nclass B {\n  run() {}\n}\nconst h = () => 1;\n"
    names = [s.name for s in sym.extract("js", src)]
    assert names.count("load") == 2 and "B.run" in names and "h" in names


def test_identifiers_and_backend():
    ids = sym.identifiers("python", "import os\nx = os.path.join(a, b)\n")
    assert {"os", "join", "a", "b"} <= ids
    assert sym.backend("python") == "python-ast" and sym.backend("cpp") in ("tree-sitter", "regex")


def test_related_definitions_k1(tmp_path):
    (tmp_path / "geo.py").write_text("def area(w, h):\n    return w * h\n\n\nclass Shape:\n    pass\n")
    (tmp_path / "main.py").write_text("from geo import area\n\nprint(area(2, 3))\n")
    out = cs.related_definitions(tmp_path, ["main.py"], [], 200)
    assert "geo.py:1  def area(w, h):" in out and "Shape" not in out
    assert cs.related_definitions(tmp_path, ["main.py"], ["Shape"], 200).count("geo.py") == 2
    assert cs.related_definitions(tmp_path, ["main.py"], [], 10) == ""


def test_outline_signatures():
    out = cs.outline("w.h", "class S {\npublic:\n  int v() const { return 1; }\n};\n")
    assert out.splitlines()[0] == "1: class S {"


def test_regex_fallback_when_tree_sitter_missing(monkeypatch):
    monkeypatch.setattr(ts_symbols, "extract", lambda language, text: None)
    monkeypatch.setattr(ts_symbols, "identifiers", lambda language, text: None)
    src = "double S::v(double t) const\n{\n    return t;\n}\n"
    assert [s.name for s in sym.extract("cpp", src)] == ["S::v"]
    assert "S" in sym.identifiers("cpp", src)


def test_infer_targets(tmp_path):
    from sdlc.agents.targets import infer_targets
    from sdlc.core.schemas import Task

    (tmp_path / "src").mkdir()
    (tmp_path / "src/Waveforms.h").write_text("class SineWave {\npublic:\n  double value(double t) const;\n};\nclass CosineWave {\npublic:\n  double value(double t) const;\n};\n")
    (tmp_path / "src/Waveforms.cpp").write_text("#include \"Waveforms.h\"\ndouble SineWave::value(double t) const { return t; }\n")
    (tmp_path / "src/Registry.cpp").write_text("int x = 1;\n")
    t = Task(id="T2", title="Implement CosineWave value calculation", description="compute cosine", language="cpp", acceptance_criteria=["returns cos"])
    assert infer_targets(tmp_path, t) == ["src/Waveforms.cpp", "src/Waveforms.h"]
    t2 = Task(id="T3", title="Register it in Registry.cpp", description="", language="cpp", acceptance_criteria=["x"])
    assert infer_targets(tmp_path, t2) == ["src/Registry.cpp"]
