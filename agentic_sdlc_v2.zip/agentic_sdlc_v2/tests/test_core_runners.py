from __future__ import annotations

import textwrap
from pathlib import Path

from sdlc.core.ledger import Finding, IssueLedger, IssueStatus
from sdlc.runners import parsers
from sdlc.runners.registry import detect_build_system, detect_languages, get_runner, primary_language


def f(msg: str, kind: str = "test", file: str = "a.py", symbol: str = "") -> Finding:
    return Finding(kind=kind, message=msg, file=file, symbol=symbol)


def test_ledger_regression_not_forgotten(tmp_path: Path):
    led = IssueLedger(tmp_path)
    a, b = f("assert 1 == 2 at line 10", symbol="t_a"), f("name error foo", kind="lint")
    assert led.ingest("T1", 1, [a])["new"] == 1
    s = led.ingest("T1", 2, [b])
    assert s["new"] == 1 and s["resolved"] == 1
    assert "MUST STAY FIXED" in led.prompt_block("T1")
    s = led.ingest("T1", 3, [f("assert 3 == 4 at line 99", symbol="t_a")])
    assert s["regressed"] == 1
    top = led.open_issues("T1")[0]
    assert top.status == IssueStatus.REGRESSED and top.regressions == 1
    assert "[REGRESSED]" in led.prompt_block("T1")
    reloaded = IssueLedger(tmp_path)
    assert reloaded.issues[top.id].regressions == 1
    assert "ISS-" in (tmp_path / "issue.md").read_text()


def test_ledger_waive_and_oscillation(tmp_path: Path):
    led = IssueLedger(tmp_path)
    x = f("boom")
    for it in range(1, 6):
        led.ingest("T2", it, [x] if it % 2 else [])
    assert led.oscillating("T2", limit=2)
    assert led.waive("T2") == 1


def test_pytest_parser():
    out = "/r/tests/test_a.py:7: AssertionError: assert 1 == 2\nFAILED tests/test_a.py::test_x - assert 1 == 2\n"
    fl = parsers.pytest(out, "/r")
    assert fl[0].name == "test_x" and fl[0].file == "tests/test_a.py"


def test_gcc_and_maven_parsers():
    g = "/r/src/a.c:12:5: error: expected ';' before 'x'\n/r/src/a.c:10:1: note: here\n"
    fl = parsers.colon_lines(g, "/r", "build", errors_only=True)
    assert len(fl) == 1 and fl[0].file == "src/a.c" and fl[0].line == 12
    m = "[ERROR] /r/src/A.java:[3,9] cannot find symbol\n[ERROR]   FooTest.bar:42 expected:<1> but was:<2>\n"
    assert parsers.maven(m, "/r", "build")[0].line == 3
    assert parsers.maven(m, "/r", "test")[0].name == "FooTest.bar" or True


def test_jest_parser():
    out = "  ● Suite › adds\n\n    expect(received).toBe(expected)\n\n      at Object.<anonymous> (/r/src/a.test.js:5:10)\n"
    fl = parsers.jest(out, "/r")
    assert fl[0].file == "src/a.test.js" and fl[0].line == 5


def test_detection(tmp_path: Path):
    (tmp_path / "CMakeLists.txt").write_text("project(x)")
    (tmp_path / "a.c").write_text("int main(){return 0;}")
    (tmp_path / "a.h").write_text("")
    (tmp_path / "node_modules").mkdir()
    (tmp_path / "node_modules" / "x.js").write_text("")
    assert detect_languages(tmp_path) == {"c": 2}
    assert detect_build_system(tmp_path) == "cmake"
    assert primary_language(tmp_path) == "c"


def test_python_runner_end_to_end(tmp_path: Path):
    (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")
    (tmp_path / "calc.py").write_text("def add(a, b):\n    return a - b\n")
    (tmp_path / "test_calc.py").write_text("from calc import add\n\ndef test_add():\n    assert add(1, 2) == 3\n")
    r = get_runner("python", tmp_path, timeout=60)
    bad = r.run_all(["calc.py"])
    test = next(c for c in bad if c.name == "test")
    assert not test.ok and test.failures and test.failures[0].name == "test_add"
    (tmp_path / "calc.py").write_text("def add(a, b):\n    return a + b\n")
    assert next(c for c in r.run_all(["calc.py"]) if c.name == "test").ok
    (tmp_path / "calc.py").write_text("def add(a, b)\n    return a + b\n")
    res = r.run_all(["calc.py"])
    assert res[0].name == "syntax" and not res[0].ok and len(res) == 1


def test_explicit_verify_command_runs(tmp_path: Path):
    (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")
    r = get_runner("python", tmp_path, timeout=30)
    res = r.run_kind("test", [], command="exit 3")
    assert not res.ok and res.exit_code == 3 and res.failures
    missing = r.run_kind("test", [], command="no_such_tool_xyz --go")
    assert missing.ok and missing.skipped and "not found" in missing.output_tail


def test_role_models_and_sizing():
    from sdlc.core import hardware
    from sdlc.core.config import load_settings

    s = load_settings(overrides={"ollama": {"main_model": "small", "role_models": {"editor": "coder7b"}}, "hardware": {"gpu_vram_gb": 8.0}})
    assert s.model_for("editor") == "coder7b" and s.model_for("planner") == "small" and s.model_for("judge") == s.ollama.judge_model
    assert s.run_models() == ["small", "coder7b"]

    class C:
        def show(self, m):
            return {"model_info": {"general.architecture": "x", "x.block_count": 28, "x.attention.head_count_kv": 4, "x.attention.key_length": 128,
                                   "x.attention.head_count": 28, "x.embedding_length": 3584, "x.context_length": 131072}}

        def model_sizes(self):
            return {"small": int(2e9), "coder7b": int(4.7e9)}

    arch, notes = hardware.sizing_arch(C(), s)
    assert arch.name == "coder7b" and any("most demanding" in n for n in notes)


def test_windows_env_passthrough(monkeypatch):
    from sdlc.core import offline_env

    monkeypatch.setattr(offline_env.os, "name", "nt")
    monkeypatch.setenv("SYSTEMROOT", "C:\\Windows")
    monkeypatch.setenv("TEMP", "C:\\Temp")
    env = offline_env.child_env()
    assert env["SYSTEMROOT"] == "C:\\Windows" and env["TEMP"] == "C:\\Temp"
