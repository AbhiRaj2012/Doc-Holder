from __future__ import annotations

import os
from typing import Any

os.environ.setdefault("DEEPEVAL_TELEMETRY_OPT_OUT", "YES")

from deepeval.models import DeepEvalBaseLLM  # noqa: E402

from ..adapters.ollama_client import LLMError, extract_json  # noqa: E402


class OllamaJudge(DeepEvalBaseLLM):
    def __init__(self, client: Any, model_name: str):
        self.client = client
        self._model_name = model_name
        super().__init__(model_name)

    def load_model(self) -> "OllamaJudge":
        return self

    def get_model_name(self, *args: Any, **kwargs: Any) -> str:
        return self._model_name

    def supports_temperature(self) -> bool:
        return True

    def supports_structured_outputs(self) -> bool:
        return True

    def generate(self, prompt: str, schema: Any = None, **kwargs: Any) -> Any:
        messages = [{"role": "user", "content": prompt}]
        if schema is None:
            return self.client.chat("judge", messages, model=self._model_name, temperature=0.0).text
        last = ""
        for _ in range(2):
            resp = self.client.chat("judge", messages, schema=schema.model_json_schema(), model=self._model_name, temperature=0.0)
            try:
                return schema.model_validate(extract_json(resp.text))
            except ValueError as exc:
                last = str(exc)[:300]
                messages = [*messages, {"role": "assistant", "content": resp.text[:1500]},
                            {"role": "user", "content": f"Invalid JSON for the required schema ({last}). Return only the corrected JSON."}]
        raise LLMError(f"judge produced no valid {schema.__name__}: {last}")

    async def a_generate(self, prompt: str, schema: Any = None, **kwargs: Any) -> Any:
        return self.generate(prompt, schema=schema)
