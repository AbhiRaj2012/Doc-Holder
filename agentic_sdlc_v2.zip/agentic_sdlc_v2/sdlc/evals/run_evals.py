from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Callable

from ..core.config import Settings, load_metrics
from ..dashboard.build_dashboard import rebuild
from .benchmark_writer import append_records, benchmark_path, build_records
from .metrics import MetricResult, evaluate_run
from .trace import load_run


def evaluate_run_dir(
    settings: Settings, run_dir: Path, client: Any = None, judge: Any = None, log: Callable[[str], None] = print,
) -> tuple[list[MetricResult], list[dict[str, Any]]]:
    status_file = run_dir / "eval_status.json"

    def mark(**kw: Any) -> None:
        status_file.write_text(json.dumps(kw), encoding="utf-8")

    mark(state="running")
    try:
        results, records = _evaluate(settings, run_dir, client, judge, log)
    except Exception as exc:
        mark(state="failed", reason=f"{type(exc).__name__}: {exc}"[:500])
        raise
    mark(state="done", passed=sum(1 for r in results if r.passed), total=len(results))
    return results, records


def _evaluate(
    settings: Settings, run_dir: Path, client: Any, judge: Any, log: Callable[[str], None],
) -> tuple[list[MetricResult], list[dict[str, Any]]]:
    run = load_run(run_dir)
    if judge is None and settings.evals.llm_metrics:
        from ..adapters.ollama_client import OllamaClient
        from .judge import OllamaJudge

        judge = OllamaJudge(client or OllamaClient(settings), settings.ollama.judge_model)
    judge_name = judge.get_model_name() if judge is not None else "none"
    trace_chars = int(settings.prompt_tokens_for("judge") * 3.5 * 0.45)
    start = time.monotonic()
    results = evaluate_run(run, judge, load_metrics(), settings.evals, trace_chars, log)
    records = build_records(run, results, judge_name, time.monotonic() - start)
    (run_dir / "eval_results.json").write_text(json.dumps([r.model_dump() for r in results], indent=2), encoding="utf-8")
    append_records(benchmark_path(settings.benchmark_root()), records)
    try:
        log(f"dashboard: {rebuild(settings)}")
    except Exception as exc:
        log(f"dashboard rebuild failed: {exc}")
    return results, records
