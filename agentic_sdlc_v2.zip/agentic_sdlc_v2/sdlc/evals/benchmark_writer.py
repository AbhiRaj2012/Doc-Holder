from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path
from typing import Any

from .metrics import MetricResult
from .trace import RunData

SCHEMA_VERSION = 1
_LOCK = threading.Lock()


def benchmark_path(root: Path) -> Path:
    root.mkdir(parents=True, exist_ok=True)
    return root / "benchmark.jsonl"


def build_records(run: RunData, results: list[MetricResult], judge_model: str, eval_time_s: float) -> list[dict[str, Any]]:
    s = run.summary
    base = {"run_id": s["run_id"], "project_id": s["project_id"], "project_name": s["project_name"], "schema": SCHEMA_VERSION}
    ts = time.strftime("%Y-%m-%dT%H:%M:%S")
    metrics = {r.name: {"score": r.score, "band": r.band, "passed": r.passed, "threshold": r.threshold, "source": r.source, "reason": r.reason, "details": r.details} for r in results}
    head = {k: v for k, v in s.items() if k not in ("tasks", "task_stats")}
    records: list[dict[str, Any]] = [{
        **base, "type": "run_summary", "ts": ts, **head, "model_judge": judge_model, "self_judged": judge_model == s.get("model_main"),
        "metrics": metrics, "metrics_passed": sum(1 for r in results if r.passed), "metrics_total": len(results), "eval_time_s": round(eval_time_s, 2),
    }]
    for t in s.get("tasks", []):
        st = s.get("task_stats", {}).get(t["id"], {})
        records.append({**base, "type": "task", "ts": ts, "task_id": t["id"], "title": t["title"], "status": t["status"], "language": t.get("language"),
                        "kind": t.get("kind"), "files": t.get("target_files"), "verify_source": t.get("verify_source"), "parent_id": t.get("parent_id"),
                        "iterations": st.get("iterations", 0), "suspensions": st.get("suspensions", 0), "escalations": st.get("escalations", 0), "splits": st.get("splits", 0)})
    for e in run.of_type("policy_violation"):
        records.append({**base, "type": "policy_violation", "ts": ts, "task_id": e.get("task_id"), "command": e.get("command"), "kind": e.get("kind"), "reason": e.get("reason")})
    return records


def append_records(path: Path, records: list[dict[str, Any]]) -> None:
    if not records:
        return
    run_id = records[0]["run_id"]
    with _LOCK:
        kept: list[str] = []
        if path.exists():
            for line in path.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    if json.loads(line).get("run_id") == run_id:
                        continue
                except ValueError:
                    continue
                kept.append(line)
        kept += [json.dumps(r, ensure_ascii=False, default=str) for r in records]
        tmp = path.with_suffix(".jsonl.tmp")
        with tmp.open("w", encoding="utf-8") as fh:
            fh.write("\n".join(kept) + "\n")
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)


def read_benchmark(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    out: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            try:
                out.append(json.loads(line))
            except ValueError:
                continue
    return out
