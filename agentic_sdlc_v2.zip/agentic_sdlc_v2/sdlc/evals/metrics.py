from __future__ import annotations

import os
from statistics import mean
from typing import Any, Callable

os.environ.setdefault("DEEPEVAL_TELEMETRY_OPT_OUT", "YES")

from deepeval.metrics import (  # noqa: E402
    ArgumentCorrectnessMetric, PlanAdherenceMetric, PlanQualityMetric, StepEfficiencyMetric, TaskCompletionMetric, ToolCorrectnessMetric,
)
from deepeval.models import DeepEvalBaseLLM  # noqa: E402
from deepeval.test_case import LLMTestCase, ToolCall  # noqa: E402
from pydantic import BaseModel, Field  # noqa: E402

from ..core.config import EvalCfg, MetricsConfig  # noqa: E402
from .trace import CREATE_KINDS, RunData, build_trace, tool_cases, tool_sequence  # noqa: E402

EXPECTED_TOOLS = ("apply_edit", "syntax_check", "run_test")
NAMES = ("plan_quality", "plan_adherence", "tool_correctness", "argument_correctness", "step_efficiency", "task_completion")


class MetricResult(BaseModel):
    name: str
    score: float
    band: str
    passed: bool
    threshold: float
    source: str
    reason: str = ""
    details: dict[str, Any] = Field(default_factory=dict)


class NullModel(DeepEvalBaseLLM):
    def __init__(self) -> None:
        super().__init__("none")

    def load_model(self) -> "NullModel":
        return self

    def get_model_name(self, *a: Any, **k: Any) -> str:
        return "none"

    def generate(self, *a: Any, **k: Any) -> Any:
        raise RuntimeError("no judge model is available for this metric")

    async def a_generate(self, *a: Any, **k: Any) -> Any:
        raise RuntimeError("no judge model is available for this metric")


def _avg(values: list[float]) -> float:
    return float(mean(values)) if values else 0.0


def _planned(run: RunData) -> list[dict[str, Any]]:
    return [t for t in run.tasks if not t.get("parent_id")]


def plan_quality_det(run: RunData) -> tuple[float, str, dict[str, Any]]:
    planned = _planned(run)
    if not planned:
        return 0.0, "no plan was produced", {}
    crit = _avg([1.0 if len(t.get("acceptance_criteria") or []) >= 2 else 0.0 for t in planned])
    atomic = _avg([1.0 if 1 <= len(t.get("target_files") or []) <= 2 else 0.0 for t in planned])
    verifiable = _avg([1.0 if t.get("verify_source") in ("planner", "default") else 0.0 for t in planned])
    warnings = sum(len(e.get("warnings") or []) for e in run.of_type("plan_ready"))
    penalty = min(0.3, 0.1 * warnings)
    score = max(0.0, _avg([crit, atomic, verifiable]) - penalty)
    return score, f"criteria {crit:.2f}, atomic {atomic:.2f}, verifiable {verifiable:.2f}, plan warnings {warnings}", {"criteria": crit, "atomic": atomic, "verifiable": verifiable, "warnings": warnings}


def plan_adherence_det(run: RunData) -> tuple[float, str, dict[str, Any]]:
    planned = _planned(run)
    if not planned:
        return 0.0, "no plan was produced", {}
    completion = sum(1 for t in planned if t["status"] == "completed") / len(planned)
    scopes: list[float] = []
    for e in run.of_type("task_end"):
        if e.get("status") != "completed":
            continue
        t = run.task(e["task_id"])
        files = e.get("files") or []
        if not files or t.get("kind") in CREATE_KINDS:
            scopes.append(1.0)
            continue
        targets = set(t.get("target_files") or [])
        scopes.append(sum(1 for f in files if f in targets) / len(files))
    scope = _avg(scopes) if scopes else 1.0
    return 0.5 * completion + 0.5 * scope, f"planned tasks completed {completion:.2f}, changes inside planned files {scope:.2f}", {"completion": completion, "scope": scope}


def tool_correctness(run: RunData, threshold: float) -> tuple[float, str, dict[str, Any]]:
    scores: dict[str, float] = {}
    for t in run.executed_tasks():
        called = tool_sequence(run, t["id"])
        case = LLMTestCase(
            input=t["title"], actual_output=t["status"], tools_called=[ToolCall(name=n) for n in called],
            expected_tools=[ToolCall(name=n) for n in EXPECTED_TOOLS],
        )
        metric = ToolCorrectnessMetric(threshold=threshold, model=NullModel(), async_mode=False, include_reason=False, should_consider_ordering=True)
        scores[t["id"]] = float(metric.measure(case, _show_indicator=False))
    if not scores:
        return 0.0, "no tool calls were recorded", {}
    return _avg(list(scores.values())), f"expected sequence {' -> '.join(EXPECTED_TOOLS)} per task, ordering considered", {"per_task": scores}


def argument_det(run: RunData) -> tuple[float, str, dict[str, Any]]:
    checks: list[tuple[str, float]] = []
    violations = {e.get("task_id") for e in run.of_type("policy_violation")}
    for t in run.executed_tasks():
        tid, targets = t["id"], set(t.get("target_files") or [])
        create = t.get("kind") in CREATE_KINDS
        for e in run.tool_calls(tid):
            tool, args = e.get("tool", ""), e.get("args") or {}
            if tool == "apply_edit":
                files = args.get("files") or []
                checks.append(("apply_edit.files_present", 1.0 if files else 0.0))
                checks.append(("apply_edit.files_in_scope", 1.0 if files and (create or all(f in targets for f in files)) else 0.0))
                checks.append(("apply_edit.format", 1.0 if args.get("format") in ("diff", "whole", "udiff") else 0.0))
                applied, failed = e.get("blocks_applied") or 0, e.get("blocks_failed") or 0
                if applied + failed:
                    checks.append(("apply_edit.blocks_applied", applied / (applied + failed)))
                paths = [b.get("path") for b in e.get("blocks") or [] if b.get("path")]
                if paths:
                    checks.append(("apply_edit.block_paths_in_scope", _avg([1.0 if p in set(files) | targets or create else 0.0 for p in paths])))
            elif tool.startswith("run_") and e.get("tool_missing"):
                checks.append((f"{tool}.tool_available", 0.0))
        if tid in violations:
            checks.append(("verify_command.allowed", 0.0))
        elif t.get("verify_source") == "planner":
            checks.append(("verify_command.allowed", 1.0))
    if not checks:
        return 0.0, "no tool calls were recorded", {}
    by_check: dict[str, list[float]] = {}
    for name, v in checks:
        by_check.setdefault(name, []).append(v)
    return _avg([v for _, v in checks]), f"{len(checks)} argument checks", {"by_check": {k: round(_avg(v), 3) for k, v in by_check.items()}}


def step_efficiency_det(run: RunData) -> tuple[float, str, dict[str, Any]]:
    per: dict[str, float] = {}
    for t in run.tasks:
        st = run.stats(t["id"])
        if not st.get("iterations"):
            continue
        actual = st["iterations"] + st.get("splits", 0) + st.get("escalations", 0)
        per[t["id"]] = 1.0 / actual
    if not per:
        return 0.0, "no steps were recorded", {}
    return _avg(list(per.values())), "minimal path (1 edit step) divided by steps used, counting retries, splits and escalations", {"per_task": per}


def task_completion_det(run: RunData) -> tuple[float, str, dict[str, Any]]:
    leaves = run.leaf_tasks()
    if not leaves:
        return 0.0, "no tasks were planned", {}
    ratio = sum(1 for t in leaves if t["status"] == "completed") / len(leaves)
    return ratio, f"{int(ratio * len(leaves))}/{len(leaves)} tasks completed", {"ratio": ratio}


def verified_ratio(run: RunData) -> float:
    leaves = [x for x in run.leaf_tasks() if x["status"] == "completed"]
    if not leaves:
        return 0.0
    ok = 0
    for x in leaves:
        calls = [e for e in run.tool_calls(x["id"]) if e.get("tool") in ("run_build", "run_test")]
        ok += any(e.get("ok") and not e.get("skipped") for e in calls)
    return ok / len(leaves)


def _case(run: RunData, trace: dict[str, Any]) -> LLMTestCase:
    s = run.summary
    case = LLMTestCase(input=s.get("objective", ""), actual_output=f"{s.get('final_status')}: {s.get('tasks_completed')}/{s.get('num_tasks')} tasks completed")
    case._trace_dict = trace
    return case


def evaluate_run(
    run: RunData, judge: Any, mcfg: MetricsConfig, cfg: EvalCfg, trace_chars: int = 12000, log: Callable[[str], None] = lambda m: None,
) -> list[MetricResult]:
    th = {n: mcfg.metrics[n].threshold for n in NAMES}
    use_llm = bool(judge) and cfg.llm_metrics
    trace = build_trace(run, trace_chars)
    case = _case(run, trace)
    results: list[MetricResult] = []

    def done(name: str, score: float, source: str, reason: str, details: dict[str, Any]) -> None:
        score = round(max(0.0, min(1.0, score)), 4)
        results.append(MetricResult(name=name, score=score, band=mcfg.band(name, score), passed=mcfg.passed(name, score),
                                    threshold=th[name], source=source, reason=(reason or "")[:600], details=details))

    def llm(name: str, make: Callable[[], Any], det: tuple[float, str, dict[str, Any]], cap_margin: float | None) -> None:
        score_d, reason_d, details = det
        if use_llm:
            try:
                metric = make()
                value = float(metric.measure(case, _show_indicator=False))
                final = value if cap_margin is None else min(value, score_d + cap_margin)
                note = f" (capped by deterministic evidence {score_d:.2f})" if final < value else ""
                done(name, final, "llm", f"{getattr(metric, 'reason', '') or ''}{note}", {**details, "llm_score": round(value, 4), "deterministic_score": round(score_d, 4)})
                return
            except Exception as exc:
                log(f"{name}: judge failed ({exc})")
                reason_d = f"judge unavailable ({str(exc)[:120]}); heuristic used: {reason_d}"
        else:
            reason_d = f"LLM metrics disabled; heuristic used: {reason_d}"
        done(name, score_d, "fallback", reason_d, details)

    mk = lambda cls, name, **kw: (lambda: cls(threshold=th[name], model=judge, async_mode=False, include_reason=True, **kw))  # noqa: E731
    llm("plan_quality", mk(PlanQualityMetric, "plan_quality"), plan_quality_det(run), None)
    llm("plan_adherence", mk(PlanAdherenceMetric, "plan_adherence"), plan_adherence_det(run), 0.15)

    score, reason, details = tool_correctness(run, th["tool_correctness"])
    done("tool_correctness", score, "deterministic", reason, details)

    det_score, det_reason, det_details = argument_det(run)
    if use_llm and det_details:
        try:
            scores = []
            for t in run.executed_tasks()[: cfg.max_arg_cases]:
                cases = tool_cases(run, t["id"], cfg.max_tool_calls_per_case)
                if not cases:
                    continue
                tc = LLMTestCase(
                    input=f"{t['title']}. Criteria: " + " | ".join(t.get("acceptance_criteria") or []), actual_output=t["status"],
                    tools_called=[ToolCall(name=c.name, input_parameters=c.parameters, output=c.output) for c in cases],
                )
                metric = ArgumentCorrectnessMetric(threshold=th["argument_correctness"], model=judge, async_mode=False, include_reason=False)
                scores.append(float(metric.measure(tc, _show_indicator=False)))
            if scores:
                llm_score = _avg(scores)
                done("argument_correctness", (det_score + llm_score) / 2, "llm",
                     f"mean of deterministic checks ({det_score:.2f}) and DeepEval ArgumentCorrectness ({llm_score:.2f})",
                     {**det_details, "deterministic_score": round(det_score, 4), "llm_score": round(llm_score, 4)})
            else:
                done("argument_correctness", det_score, "deterministic", det_reason, det_details)
        except Exception as exc:
            log(f"argument_correctness: judge failed ({exc})")
            done("argument_correctness", det_score, "fallback", f"judge unavailable ({str(exc)[:120]}); deterministic checks only: {det_reason}", det_details)
    else:
        done("argument_correctness", det_score, "deterministic" if det_details else "fallback", det_reason, det_details)

    score, reason, details = step_efficiency_det(run)
    if use_llm and cfg.step_efficiency_cross_check:
        try:
            metric = StepEfficiencyMetric(threshold=th["step_efficiency"], model=judge, async_mode=False, include_reason=False)
            details["deepeval_step_efficiency"] = round(float(metric.measure(case, _show_indicator=False)), 4)
        except Exception as exc:
            log(f"step_efficiency cross-check failed ({exc})")
    done("step_efficiency", score, "deterministic", reason, details)

    objective = run.summary.get("objective", "")
    ratio_score = task_completion_det(run)
    llm("task_completion", mk(TaskCompletionMetric, "task_completion", task=objective), ratio_score, 0.0 if ratio_score[0] < 1.0 else None)
    ratio = verified_ratio(run)
    cap = 0.6 + 0.4 * ratio
    for r in results:
        if r.name in ("task_completion", "tool_correctness") and r.score > cap:
            note = f" Capped at {cap:.2f}: only {ratio:.0%} of completed tasks were verified by a build or test that actually ran."
            r.score, r.band, r.passed = round(cap, 4), mcfg.band(r.name, cap), mcfg.passed(r.name, cap)
            r.reason = (r.reason + note)[:700]
            r.details["verified_ratio"] = round(ratio, 4)
    return sorted(results, key=lambda r: NAMES.index(r.name))
