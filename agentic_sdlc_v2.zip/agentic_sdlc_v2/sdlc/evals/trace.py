from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..telemetry.jsonl_logger import read_events

CREATE_KINDS = ("scaffold", "feature", "test")


@dataclass
class RunData:
    summary: dict[str, Any]
    events: list[dict[str, Any]]
    brief: str = ""
    run_dir: Path | None = None

    @property
    def tasks(self) -> list[dict[str, Any]]:
        return self.summary.get("tasks", [])

    def leaf_tasks(self) -> list[dict[str, Any]]:
        parents = {t["parent_id"] for t in self.tasks if t.get("parent_id")}
        return [t for t in self.tasks if t["id"] not in parents]

    def task(self, tid: str) -> dict[str, Any]:
        return next((t for t in self.tasks if t["id"] == tid), {})

    def tool_calls(self, tid: str | None = None) -> list[dict[str, Any]]:
        return [e for e in self.events if e.get("type") == "tool_call" and (tid is None or e.get("task_id") == tid)]

    def of_type(self, kind: str) -> list[dict[str, Any]]:
        return [e for e in self.events if e.get("type") == kind]

    def stats(self, tid: str) -> dict[str, int]:
        return self.summary.get("task_stats", {}).get(tid, {})

    def executed_tasks(self) -> list[dict[str, Any]]:
        return [t for t in self.leaf_tasks() if self.tool_calls(t["id"]) or self.stats(t["id"]).get("iterations")]


def load_run(run_dir: Path) -> RunData:
    summary_path = run_dir / "run_summary.json"
    if not summary_path.exists():
        raise FileNotFoundError(f"no run_summary.json in {run_dir}; the run has not finished")
    brief = run_dir / "design_brief.md"
    return RunData(
        summary=json.loads(summary_path.read_text(encoding="utf-8")), events=read_events(run_dir / "events.jsonl"),
        brief=brief.read_text(encoding="utf-8") if brief.exists() else "", run_dir=run_dir,
    )


def _clip(value: Any, n: int) -> Any:
    if isinstance(value, str):
        return value if len(value) <= n else value[: n - 3] + "..."
    if isinstance(value, dict):
        return {k: _clip(v, n) for k, v in list(value.items())[:8]}
    if isinstance(value, list):
        return [_clip(v, n) for v in value[:8]]
    return value


def plan_text(run: RunData) -> str:
    lines = []
    for t in run.tasks:
        deps = f" after {', '.join(t['depends_on'])}" if t.get("depends_on") else ""
        lines.append(f"{t['id']}{deps}: {t['title']} [{t.get('language')}/{t.get('kind')}] files={', '.join(t.get('target_files') or []) or 'none'}; "
                     f"criteria: " + " | ".join(t.get("acceptance_criteria") or []))
    return "\n".join(lines)


def _tool_span(e: dict[str, Any], clip: int) -> dict[str, Any]:
    args = e.get("args") or {}
    out = f"ok={e.get('ok')}"
    if e.get("skipped"):
        out += " (skipped)"
    if e.get("files_changed"):
        out += f"; changed {e['files_changed']}"
    if e.get("blocks_applied") is not None:
        out += f"; blocks applied={e.get('blocks_applied')} failed={e.get('blocks_failed')}"
    if e.get("failures"):
        out += f"; failures={e['failures']}"
    return {"name": e.get("tool", "tool"), "type": "tool", "input": _clip(args, clip), "output": out}


def build_trace(run: RunData, max_chars: int = 12000) -> dict[str, Any]:
    s = run.summary
    plan_out = plan_text(run)
    for span_cap, clip in ((12, 120), (6, 100), (3, 80), (1, 60), (0, 40)):
        children: list[dict[str, Any]] = [{"name": "planner", "type": "llm", "input": _clip(s.get("objective", ""), 600), "output": plan_out}]
        for t in run.leaf_tasks():
            calls = run.tool_calls(t["id"])
            spans = [_tool_span(e, clip) for e in calls[:span_cap]]
            if len(calls) > span_cap:
                spans.append({"name": "more_tool_calls", "type": "tool", "input": {}, "output": f"{len(calls) - span_cap} further calls omitted"})
            st = run.stats(t["id"])
            children.append({
                "name": f"{t['id']}: {t['title']}", "type": "agent",
                "input": "criteria: " + " | ".join(t.get("acceptance_criteria") or []) + f"; files: {', '.join(t.get('target_files') or [])}",
                "output": f"status={t['status']}; iterations={st.get('iterations', 0)}; suspensions={st.get('suspensions', 0)}; escalations={st.get('escalations', 0)}",
                "children": spans,
            })
        trace = {
            "name": "sdlc_pipeline_run", "type": "agent", "input": _clip(s.get("objective", ""), 800),
            "output": f"status={s.get('final_status')}; completed {s.get('tasks_completed')}/{s.get('num_tasks')} tasks; "
                      f"skipped {s.get('tasks_skipped')}; blocked {s.get('tasks_blocked')}",
            "children": children,
        }
        if len(json.dumps(trace)) <= max_chars:
            return trace
    return trace


def tool_sequence(run: RunData, tid: str) -> list[str]:
    return [e["tool"] for e in run.tool_calls(tid) if e.get("tool") and not e.get("tool_missing")]


@dataclass
class ToolCase:
    task_id: str
    name: str
    parameters: dict[str, Any]
    output: str
    extras: dict[str, Any] = field(default_factory=dict)


def tool_cases(run: RunData, tid: str, limit: int) -> list[ToolCase]:
    priority = {"apply_edit": 0, "run_test": 1}
    calls = sorted(enumerate(run.tool_calls(tid)), key=lambda p: (priority.get(p[1].get("tool"), 2), p[0]))[:limit]
    return [ToolCase(tid, e.get("tool", ""), _clip(e.get("args") or {}, 160), f"ok={e.get('ok')}") for _, e in sorted(calls)]
