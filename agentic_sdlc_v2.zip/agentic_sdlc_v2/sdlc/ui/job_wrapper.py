from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def main(argv: list[str]) -> int:
    exit_file, cmd = Path(argv[0]), argv[1:]
    code = subprocess.call(cmd)
    exit_file.write_text(str(code))
    return code


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
