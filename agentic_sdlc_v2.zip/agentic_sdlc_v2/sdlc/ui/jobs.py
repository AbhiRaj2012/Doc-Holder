from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from ..core.config import PROJECT_ROOT, Settings
from ..core.project_store import Project, ProjectStore, new_run_id
from ..telemetry.jsonl_logger import read_events


def write_config(settings: Settings, run_dir: Path) -> Path:
    p = run_dir / "ui_settings.json"
    p.write_text(settings.model_dump_json(indent=2), encoding="utf-8")
    return p


def launch(args: list[str], run_dir: Path, config: Path) -> int:
    exit_file = run_dir / "exit.code"
    exit_file.unlink(missing_ok=True)
    cmd = [sys.executable, "-m", "sdlc.ui.job_wrapper", str(exit_file), sys.executable, "-m", "sdlc", "--config", str(config), *args]
    log = (run_dir / "cli.log").open("ab")
    detach: dict[str, Any] = {"creationflags": subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt" else {"start_new_session": True}
    proc = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, cwd=str(PROJECT_ROOT), **detach)
    (run_dir / "job.pid").write_text(str(proc.pid))
    return proc.pid


def start_run(settings: Settings, source: str, name: str, requirements: str, auto_context: bool, no_aider: bool, no_eval: bool) -> tuple[Project, str]:
    store = ProjectStore(settings)
    project = store.open(source, name or None)
    run_id = new_run_id()
    run_dir = project.run_dir(run_id)
    req = run_dir / "requirements.txt"
    req.write_text(requirements, encoding="utf-8")
    cfg = write_config(settings, run_dir)
    args = ["run", str(source), "--name", project.id, "--run-id", run_id, "--requirements-file", str(req), "--non-interactive"]
    args += (["--auto-context"] if auto_context else []) + (["--no-aider"] if no_aider else []) + (["--no-eval"] if no_eval else [])
    launch(args, run_dir, cfg)
    return project, run_id


def start_create(settings: Settings, name: str, request: str, language: str, auto_context: bool, no_eval: bool) -> tuple[Project, str]:
    from ..create.project import new_project

    run_id = new_run_id()
    project = new_project(settings, name or "new-app", run_id)
    run_dir = project.run_dir(run_id)
    req = run_dir / "request.txt"
    req.write_text(request, encoding="utf-8")
    args = ["create", "--project", project.id, "--run-id", run_id, "--request-file", str(req)]
    args += (["--language", language] if language else []) + (["--auto-context"] if auto_context else []) + (["--no-eval"] if no_eval else [])
    launch(args, run_dir, write_config(settings, run_dir))
    return project, run_id


def start_resume(settings: Settings, project: Project, run_id: str, action: str = "", hint: str = "", approve: list[str] | None = None, no_eval: bool = False, remove: list[str] | None = None) -> None:
    run_dir = project.run_dir(run_id)
    cfg = write_config(settings, run_dir)
    args = ["resume", run_id, "--project", project.id, "--non-interactive"]
    if approve is not None:
        args += ["--approve", ",".join(approve)] if approve else ["--approve", ""]
    if action:
        args += ["--action", action]
    if hint:
        args += ["--hint", hint]
    if remove:
        args += ["--remove", ",".join(remove)]
    if no_eval:
        args.append("--no-eval")
    launch(args, run_dir, cfg)


def start_eval(settings: Settings, project: Project, run_id: str) -> None:
    run_dir = project.run_dir(run_id)
    launch(["eval", run_id, "--project", project.id], run_dir, write_config(settings, run_dir))


def pid_alive(pid: int) -> bool:
    if os.name == "nt":
        import ctypes

        handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)
        if not handle:
            return False
        code = ctypes.c_ulong()
        ok = ctypes.windll.kernel32.GetExitCodeProcess(handle, ctypes.byref(code))
        ctypes.windll.kernel32.CloseHandle(handle)
        return bool(ok) and code.value == 259
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    try:
        return Path(f"/proc/{pid}/status").read_text().split("State:")[1].split()[0] != "Z"
    except (OSError, IndexError):
        return True


def job_state(run_dir: Path) -> str:
    exit_file = run_dir / "exit.code"
    if exit_file.exists():
        code = exit_file.read_text().strip()
        return {"0": "completed", "1": "finished with problems", "3": "waiting for human", "130": "stopped by user"}.get(code, f"error (exit {code})")
    pid_file = run_dir / "job.pid"
    if pid_file.exists():
        try:
            return "running" if pid_alive(int(pid_file.read_text())) else "stopped"
        except ValueError:
            return "unknown"
    return "idle"


def list_runs(settings: Settings, include_hidden: bool = False) -> list[dict[str, Any]]:
    store = ProjectStore(settings)
    out = []
    for pid in store.list_projects():
        project = store.get(pid)
        runs = project.workspace / "runs"
        if not runs.exists():
            continue
        for d in runs.iterdir():
            if d.is_dir() and (include_hidden or not (d / "hidden.flag").exists()):
                out.append({"project": pid, "run_id": d.name, "state": job_state(d), "dir": d, "hidden": (d / "hidden.flag").exists()})
    return sorted(out, key=lambda r: r["run_id"], reverse=True)


def stop_run(run_dir: Path) -> str:
    pid_file = run_dir / "job.pid"
    if not pid_file.exists():
        return "no process recorded for this run"
    try:
        pid = int(pid_file.read_text())
    except ValueError:
        return "invalid process id"
    if not pid_alive(pid):
        (run_dir / "exit.code").write_text("130")
        return "process was already gone"
    if os.name == "nt":
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)], capture_output=True)
    else:
        import signal
        import time

        try:
            os.killpg(os.getpgid(pid), signal.SIGTERM)
            time.sleep(1.0)
            if pid_alive(pid):
                os.killpg(os.getpgid(pid), signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            pass
    (run_dir / "exit.code").write_text("130")
    return "stopped"


def hide_run(run_dir: Path, hidden: bool = True) -> None:
    flag = run_dir / "hidden.flag"
    if hidden:
        flag.write_text("1")
    else:
        flag.unlink(missing_ok=True)


def running_runs(settings: Settings) -> list[dict[str, Any]]:
    return [r for r in list_runs(settings, include_hidden=True) if r["state"] == "running"]


def run_info(run_dir: Path) -> dict[str, Any]:
    stack = json.loads((run_dir / "stack.json").read_text()) if (run_dir / "stack.json").exists() else {"tasks": [], "suspended": []}
    summary = json.loads((run_dir / "run_summary.json").read_text()) if (run_dir / "run_summary.json").exists() else {}
    log = (run_dir / "cli.log").read_text(errors="replace")[-4000:] if (run_dir / "cli.log").exists() else ""
    return {"stack": stack, "summary": summary, "events": read_events(run_dir / "events.jsonl"), "log": log}


def pending_interrupt(settings: Settings, project: Project, run_id: str) -> dict[str, Any] | None:
    from ..cli.main import pending, run_settings

    st = pending(run_settings(project, run_id, settings), project, run_id)
    return None if st.done else st.interrupt


def tail_events(events: list[dict[str, Any]], n: int = 40) -> list[str]:
    skip = {"llm_call", "node"}
    lines = []
    for e in events:
        if e["type"] in skip:
            continue
        detail = {k: v for k, v in e.items() if k not in {"ts", "seq", "run_id", "project_id", "type"}}
        lines.append(f"{e['type']}  {json.dumps(detail, default=str)[:160]}")
    return lines[-n:]

