from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import streamlit as st

from sdlc.ui.views import p_dashboard, p_evals, p_live, p_run, p_setup

st.set_page_config(page_title="Agentic SDLC", layout="wide")
nav = st.navigation([
    st.Page(p_run.render, title="Run", url_path="run", default=True),
    st.Page(p_live.render, title="Live", url_path="live"),
    st.Page(p_evals.render, title="Evaluation", url_path="evals"),
    st.Page(p_dashboard.render, title="Dashboard", url_path="dashboard"),
    st.Page(p_setup.render, title="Models and hardware", url_path="setup"),
])
nav.run()
