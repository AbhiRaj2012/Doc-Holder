from __future__ import annotations

import json

import streamlit as st

from .. import common, jobs, live_model as lm
from . import p_gate


def _now_box(snap: dict, tasks: list | None = None, events: list | None = None) -> None:
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Process", snap["_state"])
    c2.metric("Active node", lm.NODE_LABEL.get(snap["node"], snap["node"] or "-"), f"{snap['node_since']} s" if snap["node"] else None)
    c3.metric("Task", lm.task_label(snap["task_id"], tasks or [], events or []))
    c4.metric("Iteration", snap["iteration"])
    c5.metric("Model calls / tokens", f"{snap['llm_calls']} / {snap['tokens']}")
    progress = lm.progress_caption(tasks or [], events or [])
    if snap["task_title"] or progress:
        st.caption(" · ".join(x for x in (f"Task: {snap['task_title']}" if snap["task_title"] else "", progress) if x))
    w = snap["waiting_model"]
    if w:
        st.info(f"Waiting for **{w['model']}** ({w['node']}) for {w['since']} s · prompt ≈ {w['prompt_tokens_est']} tokens · reasoning effort {w['effort']}")
    elif snap["_state"] == "running" and snap["idle_s"] > 60:
        st.warning(f"No events for {snap['idle_s']} s")


@st.fragment(run_every=2)
def panel(run: dict) -> None:
    info = jobs.run_info(run["dir"])
    events = info["events"]
    snap = lm.snapshot(events)
    snap["_state"] = jobs.job_state(run["dir"])
    key = f"state_{run['run_id']}"
    if st.session_state.get(key, run["state"]) != snap["_state"]:
        st.session_state[key] = snap["_state"]
        st.rerun()
    st.session_state[key] = snap["_state"]
    _now_box(snap, info["stack"]["tasks"], events)
    st.markdown(lm.strip_html(snap["node"], lm.done_nodes(events), lm.flow_for(events)), unsafe_allow_html=True)
    s = info["summary"]
    if s:
        st.success(f"Final: {s.get('final_status')} · tasks {s.get('tasks_completed')}/{s.get('num_tasks')} · {s.get('total_time_s')} s")
    t_timeline, t_out, t_fail, t_llm, t_tasks, t_log = st.tabs(["Timeline", "Node outputs", "Failures", "Model calls", "Tasks", "Process output"])
    with t_timeline:
        st.code("\n".join(reversed(lm.timeline(events))) or "no events yet", language="text")
    with t_out:
        outs = lm.node_outputs(events)
        if not outs:
            st.caption("No node has produced output yet.")
        for e in reversed(outs):
            title = f"{lm._fmt_time(e['ts'])} · {lm.NODE_LABEL.get(e['node'], e['node'])}" + (f" · {lm.short_id(e['task_id'])} it{e.get('iteration')}" if e.get("task_id") else "") + f" · {e.get('duration_s')} s"
            with st.expander(title, expanded=e is outs[-1]):
                for k, v in e["output"].items():
                    if k == "diff":
                        st.code(v, language="diff")
                    elif isinstance(v, list):
                        st.markdown(f"**{k}**\n" + "\n".join(f"- {x}" for x in v))
                    else:
                        st.markdown(f"**{k}:** {v}")
    with t_fail:
        fails = [e for e in events if e["type"] == "tool_call" and not e.get("ok") and e.get("error")][-8:]
        if not fails:
            st.caption("No failed tool calls.")
        for e in reversed(fails):
            with st.expander(f"{lm._fmt_time(e['ts'])} · {e.get('tool')} · {lm.short_id(e.get('task_id', ''))} it{e.get('iteration')} · {e.get('edit_format', '')}"):
                st.code(e.get("error", ""), language="text")
                if e.get("tail"):
                    st.markdown("**Backend output (tail)**")
                    st.code(e["tail"], language="text")
    with t_llm:
        calls = lm.llm_calls(events)
        if not calls:
            st.caption("No model calls yet.")
        for e in calls:
            flag = " ⚠ truncated" if e.get("done_reason") == "length" else ""
            retry = " (retry: low effort, bigger budget)" if e.get("retry") else ""
            head = f"{lm._fmt_time(e['ts'])} · {e['node']} · {e.get('prompt_tokens')}→{e.get('completion_tokens')} tok · {e.get('duration_s')} s{flag}{retry}"
            with st.expander(head):
                st.caption(f"model {e.get('model')} · effort {e.get('effort')} · max output {e.get('max_tokens')} · reasoning chars {e.get('thinking_chars', 0)}")
                st.markdown("**Output**")
                st.code(e.get("output") or "(empty: the output budget was spent on reasoning)", language="text")
                if e.get("thinking"):
                    st.markdown("**Reasoning (start)**")
                    st.code(e["thinking"], language="text")
    with t_tasks:
        stack = info["stack"]
        rows = lm.task_rows(stack["tasks"])
        if rows:
            st.markdown("| task | status | title | shrink | verify |\n|---|---|---|---|---|\n" + "\n".join(
                f"| {r['task']} | {r['status']} | {str(r['title'])[:90]} | {r['shrink']} | `{str(r['verify'])[:60]}` |" for r in rows), unsafe_allow_html=True)
        if stack["suspended"]:
            st.caption(f"Suspended frames: {len(stack['suspended'])}")
    with t_log:
        st.code(info["log"] or "empty", language="text")


def _debug_files(run: dict) -> None:
    files = [run["dir"] / n for n in ("timeline.txt", "plan.md", "failures.md") if (run["dir"] / n).exists()]
    if not files:
        return
    with st.expander("Debug files (timeline, plan, failures)"):
        st.caption(str(run["dir"]))
        cols = st.columns(len(files))
        for c, f in zip(cols, files):
            c.download_button(f.name, f.read_bytes(), file_name=f"{run['run_id']}_{f.name}", key=f"dl_{run['run_id']}_{f.name}")


def _explain(run: dict) -> None:
    f = run["dir"] / "run_explanation.json"
    if f.exists():
        e = json.loads(f.read_text())
        st.warning(f"**Why the run did not fully succeed:** {e.get('what_happened', '')}\n\n**Likely cause:** {e.get('why', '')}")


def _eval_status(s, run: dict) -> None:
    f = run["dir"] / "eval_status.json"
    st_ = json.loads(f.read_text()) if f.exists() else {}
    if st_.get("state") == "running":
        st.warning("Evaluation did not finish (process ended). Use Evaluate on the Evaluation page.")
    elif st_.get("state") == "failed":
        st.error(f"Evaluation failed: {st_.get('reason')}")
    elif st_.get("state") == "done":
        st.success(f"Evaluated: {st_.get('passed')}/{st_.get('total')} metrics passed. See the Evaluation page.")
    elif common.cfg()["run_eval"] and not (run["dir"] / "eval_results.json").exists():
        jobs.start_eval(s, common.project_of(s, run["project"]), run["run_id"])
        st.info("Evaluation was not started by the run; started it now.")


def render() -> None:
    st.header("Live")
    s = common.settings()
    others = jobs.running_runs(s)
    if others:
        with st.expander(f"{len(others)} run(s) still running in the background", expanded=True):
            for r in others:
                a, b = st.columns([4, 1])
                a.write(f"{r['project']} / {r['run_id']}")
                if b.button("Stop", key=f"stop_{r['run_id']}"):
                    st.toast(jobs.stop_run(r["dir"]))
                    st.rerun()
    run = common.run_picker(s, "live_run")
    if run is None:
        st.info("No runs yet.")
        return
    c1, c2, _ = st.columns([1, 1, 4])
    if c1.button("Stop this run", disabled=run["state"] != "running"):
        st.toast(jobs.stop_run(run["dir"]))
        st.rerun()
    if c2.button("Show again" if run["hidden"] else "Hide this run"):
        jobs.hide_run(run["dir"], not run["hidden"])
        st.rerun()
    if run["state"] == "waiting for human":
        with st.container(border=True):
            p_gate.panel(run)
    elif run["state"] in ("completed", "finished with problems"):
        _explain(run)
        _eval_status(s, run)
    if run["state"] != "running":
        _debug_files(run)
    panel(run)
