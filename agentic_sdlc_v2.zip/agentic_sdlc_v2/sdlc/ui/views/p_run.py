from __future__ import annotations

from pathlib import Path

import streamlit as st

from .. import common, jobs

MODES = {"edit": "Edit an existing project", "create": "Create a new project"}
LANGS = ["auto", "python", "c", "cpp", "java", "js", "web"]


def _edit(c: dict) -> None:
    source = st.text_input("Project directory")
    name = st.text_input("Project name (optional)")
    requirements = st.text_area("Requirements (feature or bug fix)", height=220)
    if st.button("Start run", type="primary"):
        if not source or not Path(source).is_dir():
            st.error("Project directory does not exist.")
        elif not requirements.strip():
            st.error("Enter the requirements.")
        else:
            project, run_id = jobs.start_run(common.settings(), source, name, requirements, c["auto_context"], not c["use_aider"], not c["run_eval"])
            st.session_state["last_run"] = (project.id, run_id)
            st.success(f"Started {project.id} / {run_id}. Follow it on the Live page.")


def _create(c: dict) -> None:
    name = st.text_input("Project name", value="new-app")
    lang = st.selectbox("Language", LANGS, help="auto lets the architect choose from the request")
    request = st.text_area("What application do you want to build?", height=220)
    if st.button("Start building", type="primary"):
        if not request.strip():
            st.error("Describe the application.")
        else:
            project, run_id = jobs.start_create(common.settings(), name, request, "" if lang == "auto" else lang, c["auto_context"], not c["run_eval"])
            st.session_state["last_run"] = (project.id, run_id)
            st.success(f"Started {project.id} / {run_id}. Files are written to {project.code}. Follow it on the Live page.")


def render() -> None:
    st.header("New run")
    c = common.cfg()
    mode = st.radio("Mode", list(MODES), format_func=MODES.get, horizontal=True, key="run_mode")
    _create(c) if mode == "create" else _edit(c)
