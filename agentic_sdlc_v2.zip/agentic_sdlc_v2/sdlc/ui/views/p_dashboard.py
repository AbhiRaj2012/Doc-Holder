from __future__ import annotations

import streamlit as st
import streamlit.components.v1 as components

from ...dashboard.build_dashboard import rebuild
from .. import common


def render() -> None:
    st.header("Dashboard")
    s = common.settings()
    if st.button("Rebuild"):
        rebuild(s)
    path = s.benchmark_root() / "dashboard.html"
    if not path.exists():
        rebuild(s)
    components.html(path.read_text(encoding="utf-8"), height=1100, scrolling=True)
    st.download_button("Download dashboard.html", path.read_bytes(), "dashboard.html", "text/html")
