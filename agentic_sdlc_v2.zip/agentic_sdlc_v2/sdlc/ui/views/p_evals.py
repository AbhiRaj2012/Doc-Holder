from __future__ import annotations

import json

import streamlit as st

from .. import common, jobs


def render() -> None:
    st.header("Evaluation")
    s = common.settings()
    run = common.run_picker(s, "eval_run")
    if run is None:
        st.info("No runs yet.")
        return
    st.caption(f"Judge model: {s.ollama.judge_model}")
    if st.button("Evaluate this run"):
        jobs.start_eval(s, common.project_of(s, run["project"]), run["run_id"])
        st.success("Evaluation started; the dashboard rebuilds when it finishes.")
    f = run["dir"] / "eval_results.json"
    if f.exists():
        rows = json.loads(f.read_text())
        common.table([{k: r.get(k) for k in ("name", "score", "band", "passed", "threshold", "source", "reason")} for r in rows])
    else:
        st.info("This run has not been evaluated yet.")
    log = run["dir"] / "cli.log"
    if log.exists():
        with st.expander("Process output"):
            st.code(log.read_text(errors="replace")[-3000:], language="text")
