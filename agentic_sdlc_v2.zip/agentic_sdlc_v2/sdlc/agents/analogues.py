from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field
from difflib import SequenceMatcher
from pathlib import Path

from ..core.schemas import Manifest
from ..runners.registry import config_files, source_files

CAMEL = re.compile(r"\b[A-Z][a-z0-9]+(?:[A-Z][a-z0-9]*)+\b")
SNAKE = re.compile(r"\b[a-z][a-z0-9]*(?:_[a-z0-9]+)+\b")
WORDS = re.compile(r"[A-Z][a-z0-9]*|[a-z0-9]+")
TYPE_PREFIXES = ("class ", "struct ", "interface ", "enum ", "record ", "union ")
MAX_FILE = 300_000


@dataclass
class Touchpoint:
    file: str
    line: int
    text: str


@dataclass
class Analogue:
    new_name: str
    existing: str
    defined_in: list[str]
    touchpoints: list[Touchpoint] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


def words(name: str) -> list[str]:
    parts = [w.lower() for w in WORDS.findall(name.replace("_", " ").replace("-", " "))]
    return parts


def defined_names(manifest: Manifest) -> dict[str, list[str]]:
    out: dict[str, list[str]] = {}
    for f in manifest.files:
        for s in f.symbols:
            kind_type = s.startswith(TYPE_PREFIXES)
            name = s.split(" ", 1)[1] if kind_type else s
            base = name.split(".")[-1].split("::")[-1]
            if kind_type or "." not in name:
                out.setdefault(base, []).append(f.path)
    return out


def new_candidates(text: str, known: set[str]) -> list[str]:
    found: list[str] = []
    for rx in (CAMEL, SNAKE):
        for m in rx.findall(text):
            if m not in known and m not in found and len(m) > 4:
                found.append(m)
    return found[:6]


def similarity(new: str, old: str) -> float:
    a, b = words(new), words(old)
    if not a or not b:
        return 0.0
    shared = len(set(a) & set(b))
    score = shared + (1.0 if a[-1] == b[-1] else 0.0)
    score += SequenceMatcher(None, new.lower(), old.lower()).ratio()
    if any(x in y or y in x for x in a for y in b if len(x) > 3 and len(y) > 3 and x != y):
        score += 0.5
    return score


def best_analogues(new: str, defined: dict[str, list[str]], limit: int = 1, min_score: float = 1.6) -> list[str]:
    scored = sorted(((similarity(new, d), d) for d in defined if d != new), reverse=True)
    return [d for s, d in scored if s >= min_score][:limit]


def scan_touchpoints(repo: Path, name: str, skip: set[str], max_files: int = 12, max_lines: int = 2) -> list[Touchpoint]:
    rx = re.compile(rf"\b{re.escape(name)}\b")
    out: list[Touchpoint] = []
    for rel in [*source_files(repo), *config_files(repo)]:
        if rel in skip:
            continue
        p = repo / rel
        try:
            if p.stat().st_size > MAX_FILE:
                continue
            lines = p.read_text(encoding="utf-8", errors="ignore").splitlines()
        except OSError:
            continue
        hits = [(i + 1, ln.strip()[:160]) for i, ln in enumerate(lines) if rx.search(ln)]
        for n, text in hits[:max_lines]:
            out.append(Touchpoint(rel, n, text))
        if len({t.file for t in out}) >= max_files:
            break
    return out


def find_analogues(manifest: Manifest, repo: Path, requirements: str, user_input: str = "") -> list[Analogue]:
    if manifest.is_empty:
        return []
    defined = defined_names(manifest)
    result: list[Analogue] = []
    for new in new_candidates(f"{requirements}\n{user_input}", set(defined)):
        for old in best_analogues(new, defined):
            files = defined[old]
            result.append(Analogue(new, old, files, scan_touchpoints(repo, old, set())))
    return result[:3]


def prompt_block(analogues: list[Analogue]) -> str:
    if not analogues:
        return ""
    parts = ["EXISTING PATTERN TO FOLLOW (new code must be connected to the program the same way, never left isolated):"]
    for a in analogues:
        parts.append(f"- New '{a.new_name}' is similar to existing '{a.existing}' (defined in {', '.join(a.defined_in)}). '{a.existing}' is used in:")
        for t in a.touchpoints[:14]:
            parts.append(f"    {t.file}:{t.line}: {t.text}")
        parts.append(f"  Plan a task for every file above (except the definition) that must also learn about '{a.new_name}': build files, registries or factories, UI, entry points, tests.")
    return "\n".join(parts)


def reference_files(analogues: list[Analogue], limit: int = 2) -> list[str]:
    out: list[str] = []
    for a in analogues:
        for f in a.defined_in:
            if f not in out:
                out.append(f)
    return out[:limit]


FIELD_C = re.compile(r"^\s*(?!return\b|delete\b|throw\b|case\b|goto\b|using\b|else\b)(?:[\w:<>\[\],*&]+\s+)+[*&]?(?P<n>[A-Za-z_]\w*)\s*(?:=\s*[^=;][^;]*|\{[^}]*\})?;\s*(?://.*)?$")
FIELD_PY = re.compile(r"^(?:\s*self\.(?P<s>[A-Za-z_]\w*)\s*(?::\s*[\w\[\], .|]+)?\s*=\s*[^=].*|(?:    |\t)?(?P<n>[A-Za-z_]\w*)\s*:\s*[\w\[\], .|]+(?:=\s*[^=].*)?)$")


def _field(line: str, path: str) -> str:
    m = (FIELD_PY if path.endswith(".py") else FIELD_C).match(line)
    if not m:
        return ""
    return (m.groupdict().get("s") or m.group("n") or "") if path.endswith(".py") else m.group("n")


def added_fields(diff: str) -> list[tuple[str, str, str]]:
    out: list[tuple[str, str, str]] = []
    path, prev = "", ""
    for ln in diff.splitlines():
        if ln.startswith("+++ "):
            path, prev = ln[6:] if ln.startswith("+++ b/") else "", ""
            continue
        if ln.startswith(("---", "diff ", "index ")):
            continue
        if ln.startswith("@@"):
            prev = ""
            continue
        if ln.startswith("-") or not path:
            continue
        body = ln[1:]
        name = _field(body, path)
        if ln.startswith("+") and name and prev and prev != name:
            out.append((path, name, prev))
        prev = name or ("" if body.strip() else prev)
    return out


def field_wiring(repo: Path, diff: str, is_test) -> list[tuple[str, str, str, list[Touchpoint]]]:
    found = []
    for path, new, old in added_fields(diff):
        if is_test(path) or len(new) < 4 or len(old) < 4:
            continue
        strict = path.endswith((".py", ".h", ".hpp", ".hh", ".hxx", ".java", ".ts"))
        others = [t for t in scan_touchpoints(repo, new, {path}) if not is_test(t.file)]
        if not others and not strict:
            continue
        tps = [t for t in scan_touchpoints(repo, old, {path}) if not is_test(t.file)]
        if tps:
            found.append((path, new, old, tps))
    return found



def field_readers(repo: Path, name: str, is_test) -> list[str]:
    rx = re.compile(rf"\b{re.escape(name)}\b")
    write = re.compile(rf"\b{re.escape(name)}\b\s*(?:\[[^\]]*\])?\s*(?::\s*[\w\[\], .|]+)?\s*=(?!=)")
    out = []
    for rel in source_files(repo):
        if is_test(rel):
            continue
        try:
            text = (repo / rel).read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        if any(rx.search(ln) and not write.search(ln) and not _field(ln, rel) for ln in text.splitlines()):
            out.append(rel)
    return out
