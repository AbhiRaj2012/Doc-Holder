from __future__ import annotations

import re
from typing import Any
from dataclasses import dataclass, field
from pathlib import Path

from ..adapters.edit_engine import classify
from ..adapters.edit_types import EditRequest
from ..adapters.editor_backend import HybridEditor
from ..core.budget import Section, fit_sections
from ..core import guards
from ..core import symbols as sym
from ..core.ledger import Finding
from ..core.paths import posix_list
from ..core.schemas import EditResult, Manifest, SuspendReason, Task
from ..runners.registry import config_files, get_runner
from . import context_select, prompts
from .analyser import looks_like_test
from .context import AgentContext

CREATE_KINDS = ("scaffold", "feature", "test")


@dataclass
class EditOutcome:
    result: EditResult
    ok: bool
    failure_class: str = ""
    suspend: SuspendReason | None = None
    feedback: str = ""
    restored: list[str] = field(default_factory=list)
    counts_as_failure: bool = False
    moved: dict[str, str] = field(default_factory=dict)


def related_tests(manifest: Manifest | None, targets: list[str], limit: int = 2) -> list[str]:
    if not manifest:
        return []
    stems = {Path(t).stem.lower() for t in targets}
    found = [f.path for f in manifest.files if looks_like_test(f.path) and any(s and s in Path(f.path).stem.lower() for s in stems)]
    return found[:limit]


def repo_slice(manifest: Manifest | None, targets: list[str], max_lines: int = 25) -> str:
    if not manifest or not manifest.repo_map:
        return ""
    dirs = {str(Path(t).parent) for t in targets}
    lines = [ln for ln in manifest.repo_map.splitlines() if str(Path(ln.split(":")[0]).parent) in dirs and ln.split(":")[0] not in targets]
    return "NEARBY FILES:\n" + "\n".join(lines[:max_lines]) if lines else ""


def edit_findings(outcome: EditOutcome) -> list[Finding]:
    if not outcome.failure_class and not outcome.result.blocks_failed:
        return []
    first = (outcome.result.error or outcome.feedback or "edit failed").strip().splitlines()[0][:200]
    return [Finding(kind="edit", message=f"{outcome.failure_class or 'partial'}: {first}", detail=outcome.feedback[:600])]


class EditorAgent:
    def __init__(self, ctx: AgentContext, backend: HybridEditor):
        self.ctx, self.backend = ctx, backend

    def _ref_limit_bytes(self) -> int:
        return int(self.ctx.settings.prompt_tokens_for("editor") / 6 * 3.5)

    def _reference_files(self, task: Task, shrink_level: int) -> list[str]:
        if shrink_level > 1:
            return []
        out: list[str] = []
        for f in task.reference_files:
            p = self.ctx.repo / f
            if f not in task.target_files and p.exists() and p.stat().st_size <= min(14_000, self._ref_limit_bytes()):
                out.append(f)
        return out[:2]

    def _reference_outlines(self, task: Task, shrink_level: int, full: list[str]) -> str:
        parts = []
        for f in task.reference_files:
            p = self.ctx.repo / f
            if f in full or f in task.target_files or not p.is_file():
                continue
            parts.append(f"--- {f} (outline) ---\n{context_select.outline(f, p.read_text(encoding='utf-8', errors='replace'))}")
        return "\n".join(parts[:2])

    def build_message(
        self, task: Task, iteration: int, manifest: Manifest | None, edit_error: str = "",
        shrink_level: int = 0, scope_symbols: list[str] | None = None,
    ) -> str:
        s = self.ctx.settings
        symbols = scope_symbols or task.symbol_targets
        issues = self.ctx.ledger.prompt_block(task.id, max_open=5 if shrink_level == 0 else 3, max_guard=8 if shrink_level == 0 else 4)
        scope = f"FILES TO EDIT: {', '.join(task.target_files) or 'decide from the task'}"
        if symbols and shrink_level >= 2:
            scope += f"\nNARROW SCOPE: change only these symbols and leave everything else untouched: {', '.join(symbols)}"
        elif symbols:
            scope += f"\nFOCUS SYMBOLS: {', '.join(symbols)}"
        refs = self._reference_files(task, shrink_level)
        if refs:
            scope += f"\nREFERENCE (read-only, mirror its structure, naming and wiring): {', '.join(refs)}"
        playbook = prompts.skill_text(task.kind, task.language) if shrink_level == 0 else prompts.skill_text(task.kind, task.language, 120)
        slice_ = repo_slice(manifest, task.target_files) if shrink_level == 0 else ""
        budget = s.prompt_tokens_for("editor") // 2
        named = [w for w in re.findall(r"[A-Za-z_]\w{2,}", " ".join([task.title, task.description, *task.acceptance_criteria])) if not (self.ctx.repo / w).exists()] if any(not (self.ctx.repo / f).exists() for f in task.target_files) else []
        related = context_select.related_definitions(self.ctx.repo, task.target_files, [*(symbols or []), *named], budget // 4) if shrink_level < 2 else ""
        ref_outline = self._reference_outlines(task, shrink_level, refs) if shrink_level < 2 else ""
        parts = fit_sections([
            Section("issues", issues, 9, 150, "head"), Section("error", edit_error, 8, 100, "head"),
            Section("related", related, 5, 0, "head"), Section("outline", ref_outline, 4, 0, "head"),
            Section("playbook", playbook, 3, 0, "head"), Section("slice", slice_, 2, 0, "head"),
        ], budget)
        extra = ""
        if parts["related"].strip():
            extra += f"RELATED DEFINITIONS in other files (use these exact names and signatures; do not redefine them):\n{parts['related']}\n"
        if parts["outline"].strip():
            extra += f"REFERENCE OUTLINES (structure to mirror):\n{parts['outline']}\n"
        return prompts.render(
            "editor_task", id=task.id, title=task.title, language=task.language, kind=task.kind, description=task.description,
            criteria="\n".join(f"{n}. {c}" for n, c in enumerate(task.acceptance_criteria, 1)), scope=scope,
            issues=parts["issues"], edit_error=f"LAST EDIT PROBLEMS (fix these):\n{parts['error']}" if parts["error"].strip() else "",
            playbook=parts["playbook"], repo_slice=parts["slice"], related=extra,
        )

    def run(
        self, task: Task, iteration: int, manifest: Manifest | None, failures: int = 0, edit_error: str = "",
        shrink_level: int = 0, scope_symbols: list[str] | None = None, escalation: Any = None,
    ) -> EditOutcome:
        ctx = self.ctx
        message = self.build_message(task, iteration, manifest, edit_error, shrink_level, scope_symbols)
        symbols = scope_symbols or task.symbol_targets
        req = EditRequest(
            repo=ctx.repo, files=list(task.target_files), message=message, run_dir=ctx.run_dir,
            tag=f"{task.id}-i{iteration}", read_files=(related_tests(manifest, task.target_files) if shrink_level == 0 else []) + self._reference_files(task, shrink_level),
            focus_symbols={f: symbols for f in task.target_files} if symbols else {},
        )
        if escalation is not None:
            req.temp_bump, req.effort, req.model = escalation.temp_bump, escalation.effort, escalation.model
        before = ctx.git.snapshot()
        result = self.backend.edit(req, failures)
        ctx.log({"type": "tool_call", "node": "editor", "tool": "apply_edit", "task_id": task.id, "iteration": iteration,
                 "args": result.invocation, "ok": result.ok, "blocks": result.blocks, "files_changed": result.files_changed,
                 "blocks_applied": result.blocks_applied, "blocks_failed": result.blocks_failed,
                 "edit_format": result.edit_format, "tokens_in": result.tokens_in, "tokens_out": result.tokens_out,
                 "duration_s": result.duration_s, **({"error": result.error[:500], "tail": result.stdout_tail[-600:]} if not result.ok else {})})
        if getattr(self.backend, "just_disabled", False):
            ctx.log({"type": "editor_backend_disabled", "backend": "aider", "reason": getattr(self.backend, "disabled_reason", "")})
            ctx.git.restore_paths(before, result.files_changed)
            return EditOutcome(result, False, "backend", None, getattr(self.backend, "disabled_reason", ""), list(result.files_changed), counts_as_failure=False)
        if not result.ok:
            cls = classify(result.error, result.truncated)
            suspend = SuspendReason.TOKEN_EXHAUSTED if cls == "length" else SuspendReason.STEP_TIMEOUT if cls == "timeout" else None
            ctx.git.restore_paths(before, result.files_changed)
            return EditOutcome(result, False, cls or "other", suspend, result.error, list(result.files_changed), counts_as_failure=suspend is None)
        restored = self._enforce_scope(task, before, result)
        runner = get_runner(task.language, ctx.repo, ctx.settings.limits.subprocess_timeout_s)
        changed = [f for f in result.files_changed if f not in restored]
        if task.mirror and "old" in task.mirror:
            for f in task.target_files:
                p = ctx.repo / f
                if not p.is_file():
                    continue
                text, fixed = guards.mirror_autofix(p.read_text(encoding="utf-8", errors="replace"), task.mirror["old"], task.mirror["new"])
                if fixed:
                    p.write_text(text, encoding="utf-8")
                    changed = sorted({*changed, f})
                    result.files_changed = sorted({*result.files_changed, f})
                    ctx.log({"type": "mirror_autofix", "task_id": task.id, "file": f, "lines": fixed, "why": f"added the {task.mirror['new']} lines that mirror existing {task.mirror['old']} handling"})
        for f in changed:
            p = ctx.repo / f
            if not p.is_file() or not ctx.git.exists_in(before, f):
                continue
            old_text = ctx.git.show_file(before, f)
            fixed_text, names = guards.restore_removed_fields(ctx.repo, f, old_text, p.read_text(encoding="utf-8", errors="replace"))
            if names:
                p.write_text(fixed_text, encoding="utf-8")
                ctx.log({"type": "guard_repair", "task_id": task.id, "file": f, "restored": names, "why": "the edit deleted existing members that are still used; they were put back and the rest of the edit kept"})
        moved = self._relocate(task, before, changed)
        if moved:
            changed = [moved.get(f, f) for f in changed]
            result.files_changed = [moved.get(f, f) for f in result.files_changed]
        syntax = runner.syntax(runner.scoped(changed))
        ctx.log({"type": "tool_call", "node": "editor", "tool": "syntax_check", "task_id": task.id, "iteration": iteration,
                 "args": {"files": changed}, "ok": syntax.ok, "skipped": syntax.skipped})
        if not syntax.ok and not syntax.skipped:
            ctx.git.restore_paths(before, result.files_changed)
            after = ctx.git.snapshot()
            result.files_changed, result.diff = [], ctx.git.diff_trees(before, after)
            text = "\n".join(f.short() for f in syntax.failures[:5])
            return EditOutcome(result, False, "syntax_after_edit", None, f"The edit was reverted because it broke syntax:\n{text}",
                               list(changed) + restored, counts_as_failure=True)
        problems, warnings = self._guard(task, before, changed)
        for w in warnings:
            ctx.log({"type": "guard_warning", "task_id": task.id, "iteration": iteration, "message": w})
        if problems:
            ctx.log({"type": "guard_rejected", "task_id": task.id, "iteration": iteration, "problems": problems})
            ctx.git.restore_paths(before, result.files_changed)
            result.files_changed = []
            return EditOutcome(result, False, "guard", None, "The edit was reverted:\n- " + "\n- ".join(problems), list(changed) + restored, counts_as_failure=True)
        after = ctx.git.snapshot()
        result.files_changed, result.diff = ctx.git.changed_between(before, after), ctx.git.diff_trees(before, after)
        feedback = result.error if result.blocks_failed else ""
        if restored:
            feedback = (feedback + "\n" if feedback else "") + f"Changes outside the task scope were reverted: {', '.join(restored)}"
        return EditOutcome(result, bool(result.files_changed), "" if result.files_changed else "no_change", None, feedback, restored,
                           counts_as_failure=not result.files_changed, moved=moved)

    def _relocate(self, task: Task, before: str, changed: list[str]) -> dict[str, str]:
        moved: dict[str, str] = {}
        for f in changed:
            p = self.ctx.repo / f
            if not p.is_file() or self.ctx.git.exists_in(before, f):
                continue
            text = p.read_text(encoding="utf-8", errors="replace")
            dest = guards.relocation(self.ctx.repo, f, text)
            if not dest:
                continue
            (self.ctx.repo / dest).parent.mkdir(parents=True, exist_ok=True)
            (self.ctx.repo / dest).write_text(text, encoding="utf-8")
            p.unlink()
            moved[f] = dest
            task.target_files = [dest if t == f else t for t in task.target_files]
            self.ctx.log({"type": "file_relocated", "task_id": task.id, "from": f, "to": dest, "why": "its imports only work from the package's import root"})
        return moved

    def _guard(self, task: Task, before: str, changed: list[str]) -> tuple[list[str], list[str]]:
        repo = self.ctx.repo
        text = " ".join([task.title, task.description, *task.acceptance_criteria, *task.symbol_targets])
        changes, problems, warnings = [], [], []
        for f in changed:
            p = repo / f
            if not p.is_file():
                continue
            new = p.read_text(encoding="utf-8", errors="replace")
            existed = self.ctx.git.exists_in(before, f)
            old = self.ctx.git.show_file(before, f) if existed else ""
            changes.append((f, old, new))
            wrong = guards.wrong_language(f, new)
            if wrong:
                problems.append(wrong)
            problems += guards.removed_fields(repo, f, old, new) if old else []
            had_imports = set(guards.unresolved_imports(repo, f, old)) if old else set()
            problems += [f"{f}: {m}" for m in guards.unresolved_imports(repo, f, new) if m not in had_imports]
            problems += [f"{f}: `{n}` is now defined more than once; keep one definition and change it in place" for n in guards.duplicate_definitions(f, old, new)]
            problems += [f"{f}: placeholder code is not allowed (`{h}`). Implement it fully; a value that should be adjustable belongs in the existing parameters/settings next to similar values, not hard-coded" for h in guards.placeholders(old, new)]
            if f.endswith((".js", ".mjs")):
                had = set(guards.web_contract(repo, f, old)) if old else set()
                problems += [m for m in guards.web_contract(repo, f, new) if m not in had]
            packages = guards.external_packages(repo, f, new)
            if packages and looks_like_test(f) and sym.lang_for(f) in ("c", "cpp", "java"):
                problems.append(f"{f}: the test framework {', '.join(packages)} is not available in this project; write a self-contained test with the standard library (assert and main) instead")
            elif packages:
                noted = guards.note_dependencies(repo, f, packages)
                self.ctx.log({"type": "dependency_needed", "task_id": task.id, "file": f, "packages": packages, "noted_in": noted})
            if not existed and guards.not_in_build(repo, f):
                builds = [t for t in task.target_files if t in config_files(repo)]
                if builds:
                    problems.append(f"{f} is not listed in {', '.join(builds)}; add it there so it is compiled and run")
                else:
                    warnings.append(f"{f} is not listed in any build file, so it will not be compiled or run")
        return problems + guards.destructive(repo, text, changes) + guards.dropped_uses(repo, text, changes), warnings

    def _enforce_scope(self, task: Task, before: str, result: EditResult) -> list[str]:
        allowed = set(posix_list(task.target_files))
        out: list[str] = []
        for f in result.files_changed:
            f = f.replace("\\", "/")
            if f in allowed:
                continue
            is_new = not self.ctx.git.exists_in(before, f)
            if not (is_new and task.kind in CREATE_KINDS):
                out.append(f)
        if out:
            self.ctx.git.restore_paths(before, out)
        return out


def failures_after(prev: int, outcome: EditOutcome) -> int:
    return prev + 1 if outcome.counts_as_failure else 0 if outcome.ok and not outcome.feedback else prev
