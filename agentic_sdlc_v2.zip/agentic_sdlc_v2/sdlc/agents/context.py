from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from ..adapters.git_ops import GitRepo
from ..core.config import Settings
from ..core.ledger import IssueLedger


def _noop(event: dict[str, Any]) -> None:
    return None


@dataclass
class AgentContext:
    settings: Settings
    client: Any
    repo: Path
    run_dir: Path
    git: GitRepo
    ledger: IssueLedger
    project_id: str = ""
    project_name: str = ""
    log: Callable[[dict[str, Any]], None] = field(default=_noop)

    @property
    def baseline(self) -> dict[str, Any]:
        p = self.run_dir / "baseline.json"
        try:
            return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
        except (OSError, ValueError):
            return {}
