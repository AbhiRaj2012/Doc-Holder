from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from ..core.budget import estimate_tokens
from ..core.schemas import Manifest, Task
from . import prompts
from .context import AgentContext


class SubTask(BaseModel):
    title: str
    description: str = ""
    target_files: list[str] = Field(default_factory=list)
    symbol_targets: list[str] = Field(default_factory=list)
    acceptance_criteria: list[str] = Field(min_length=1)


class SplitPlan(BaseModel):
    subtasks: list[SubTask] = Field(min_length=2, max_length=4)


def _child(parent: dict[str, Any], title: str, description: str, files: list[str], symbols: list[str], criteria: list[str]) -> dict[str, Any]:
    t = Task(
        id="x", title=title, description=description or parent["description"], language=parent["language"], kind=parent["kind"],
        target_files=files, symbol_targets=symbols, acceptance_criteria=criteria, verify_command=parent.get("verify_command"),
        priority=parent.get("priority", 3), verify_source=parent.get("verify_source", "planner"),
    )
    return t.model_dump(mode="json")


def deterministic_split(task: dict[str, Any]) -> list[dict[str, Any]]:
    files, symbols, criteria = task.get("target_files", []), task.get("symbol_targets", []), task["acceptance_criteria"]
    if len(files) > 1:
        return [_child(task, f"{task['title']} ({f})", task["description"], [f], [], criteria) for f in files]
    if len(symbols) > 1:
        return [_child(task, f"{task['title']} ({s})", task["description"], files, [s], criteria) for s in symbols]
    if len(criteria) > 1:
        mid = (len(criteria) + 1) // 2
        groups = [criteria[:mid], criteria[mid:]]
        return [_child(task, f"{task['title']} (part {n})", task["description"], files, symbols, g) for n, g in enumerate(groups, 1)]
    return []


class Splitter:
    def __init__(self, ctx: AgentContext):
        self.ctx = ctx

    def _outline(self, task: dict[str, Any], manifest: Manifest | None) -> str:
        if not manifest:
            return ""
        wanted = set(task.get("target_files", []))
        lines = [f"{f.path}: {', '.join(f.symbols[:30])} ({f.size} bytes)" for f in manifest.files if f.path in wanted]
        return "\n".join(lines)

    def split(self, task: dict[str, Any], manifest: Manifest | None, reason: str) -> list[dict[str, Any]]:
        system = prompts.load("splitter")
        body = (
            f"TASK {task['id']}: {task['title']}\n{task['description']}\nLanguage: {task['language']}  Kind: {task['kind']}\n"
            f"Files: {', '.join(task.get('target_files', [])) or 'none'}\nSymbols: {', '.join(task.get('symbol_targets', [])) or 'none'}\n"
            "Criteria:\n" + "\n".join(f"- {c}" for c in task["acceptance_criteria"]) + f"\n\nWhy it must be split: {reason}\n\nFILE OUTLINES:\n{self._outline(task, manifest)}"
        )
        if estimate_tokens(system + body) > self.ctx.settings.prompt_tokens_for("planner"):
            return deterministic_split(task)
        try:
            plan, _ = self.ctx.client.structured("planner", [{"role": "system", "content": system}, {"role": "user", "content": body}], SplitPlan, max_tokens=1500, retries=1)
        except Exception:
            return deterministic_split(task)
        parent_files = set(task.get("target_files", []))
        out: list[dict[str, Any]] = []
        for s in plan.subtasks:
            files = [f for f in s.target_files if not parent_files or f in parent_files] or task.get("target_files", [])[:1]
            out.append(_child(task, s.title, s.description, files, s.symbol_targets, s.acceptance_criteria))
        if len({o["title"] for o in out}) < 2:
            return deterministic_split(task)
        self.ctx.log({"type": "split", "task_id": task["id"], "children": len(out), "reason": reason})
        return out
