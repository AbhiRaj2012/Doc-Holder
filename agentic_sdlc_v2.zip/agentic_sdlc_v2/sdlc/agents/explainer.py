from __future__ import annotations

import hashlib
import json
from typing import Literal

from pydantic import BaseModel

from ..core.budget import Section, estimate_tokens, fit_sections
from . import prompts
from .context import AgentContext


class Explanation(BaseModel):
    what_happened: str
    why: str = ""
    recommendation: Literal["work", "restart", "replan", "replan_all", "accept", "proceed", "abort"] = "work"
    suggested_hint: str = ""


def fallback(facts: str) -> Explanation:
    lines = [x.strip() for x in facts.splitlines() if x.strip()]
    problem = next((x for x in reversed(lines) if x.lower().startswith(("last edit problem", "problem:", "- "))), lines[-1] if lines else "unknown problem")
    return Explanation(what_happened=problem[:300], why="The assistant could not summarise this automatically; see the details below.", recommendation="work",
                       suggested_hint="Change the approach: re-read the problem above and fix exactly that before anything else.")


class Explainer:
    def __init__(self, ctx: AgentContext):
        self.ctx = ctx

    def explain(self, facts: str, task_id: str = "") -> Explanation:
        cache = self.ctx.run_dir / "explanations.json"
        key = hashlib.sha1(facts.encode("utf-8")).hexdigest()
        try:
            known = json.loads(cache.read_text(encoding="utf-8")) if cache.exists() else {}
        except (OSError, ValueError):
            known = {}
        if key in known:
            return Explanation.model_validate(known[key])
        out = self._explain(facts, task_id)
        known[key] = out.model_dump()
        try:
            cache.write_text(json.dumps(known, indent=1), encoding="utf-8")
        except OSError:
            pass
        return out

    def _explain(self, facts: str, task_id: str = "") -> Explanation:
        system = prompts.load("explainer")
        budget = self.ctx.settings.prompt_tokens_for("reviewer") - estimate_tokens(system) - 100
        parts = fit_sections([Section("facts", facts, 9, 300, "middle")], budget)
        msgs = [{"role": "system", "content": system}, {"role": "user", "content": parts["facts"]}]
        try:
            out, _ = self.ctx.client.structured("reviewer", msgs, Explanation, max_tokens=1000, think=False)
            if not out.what_happened.strip():
                raise ValueError("empty explanation")
        except Exception as exc:
            self.ctx.log({"type": "explanation_failed", "task_id": task_id, "error": str(exc)[:200]})
            out = fallback(facts)
        self.ctx.log({"type": "explanation", "task_id": task_id, **out.model_dump()})
        return out
