from __future__ import annotations

import hashlib
import json
import re
import time
import tomllib
from pathlib import Path

from ..core import symbols as sym
from ..core.budget import estimate_tokens, truncate_to_tokens
from ..core.config import Settings
from ..core.project_store import code_tree_hash
from ..core.schemas import FileInfo, Manifest
from ..runners.registry import config_files, detect_build_system, detect_languages, get_runner, load_languages, primary_language, source_files

MAX_BYTES = 1_000_000
ENTRY_NAMES = {"main.py", "__main__.py", "app.py", "manage.py", "index.js", "main.js", "server.js", "index.html", "main.c", "main.cpp", "Main.java", "App.java", "Application.java"}
TEST_RX = re.compile(r"(^|/)(tests?|__tests__|spec)/|(^|/)test_[^/]+\.py$|_test\.(py|c|cc|cpp|go)$|\.(test|spec)\.(js|jsx|ts|tsx)$|Test\.java$|Tests?\.java$")


def _task_language(sym_lang: str) -> str:
    return {"css": "web", "html": "web"}.get(sym_lang, sym_lang)


def looks_like_test(rel: str) -> bool:
    return bool(TEST_RX.search(rel))


def detect_dependencies(repo: Path) -> dict[str, list[str]]:
    deps: dict[str, list[str]] = {}

    def text(name: str) -> str:
        p = repo / name
        return p.read_text(encoding="utf-8", errors="ignore") if p.exists() else ""

    py: list[str] = []
    for line in text("requirements.txt").splitlines():
        m = re.match(r"^\s*([A-Za-z0-9_.\-]+)", line)
        if m and not line.strip().startswith(("#", "-")):
            py.append(m.group(1))
    if (repo / "pyproject.toml").exists():
        try:
            data = tomllib.loads(text("pyproject.toml"))
            for d in data.get("project", {}).get("dependencies", []):
                m = re.match(r"^([A-Za-z0-9_.\-]+)", d)
                if m:
                    py.append(m.group(1))
        except tomllib.TOMLDecodeError:
            pass
    if py:
        deps["python"] = sorted(set(py))[:40]
    if (repo / "package.json").exists():
        try:
            pkg = json.loads(text("package.json"))
            deps["npm"] = sorted({*pkg.get("dependencies", {}), *pkg.get("devDependencies", {})})[:40]
        except ValueError:
            pass
    if (repo / "pom.xml").exists():
        deps["maven"] = sorted(set(re.findall(r"<artifactId>([^<]+)</artifactId>", text("pom.xml"))))[:40]
    gradle = text("build.gradle") + text("build.gradle.kts")
    if gradle:
        deps["gradle"] = sorted(set(re.findall(r"""(?:implementation|api|compileOnly|testImplementation)\s*\(?\s*["']([^"']+)["']""", gradle)))[:40]
    if (repo / "CMakeLists.txt").exists():
        deps["cmake"] = sorted(set(re.findall(r"find_package\(\s*(\w+)", text("CMakeLists.txt"))))
    return deps


def parser_engines() -> str:
    return ",".join(f"{lang}={sym.backend(lang)}" for lang in ("c", "cpp", "java", "js", "css", "html"))


class Analyser:
    def __init__(self, settings: Settings, repo: Path, project_id: str = "", project_name: str = ""):
        self.settings = settings
        self.repo = Path(repo).resolve()
        self.project_id = project_id
        self.project_name = project_name or self.repo.name

    def _info(self, rel: str, header_lang: str) -> FileInfo:
        data = (self.repo / rel).read_bytes()
        lang = sym.lang_for(rel, header_lang)
        symbols: list[str] = []
        if lang and len(data) <= MAX_BYTES:
            symbols = sym.names(sym.extract(lang, data.decode("utf-8", errors="replace")))
        return FileInfo(path=rel, language=_task_language(lang) or "other", sha256=hashlib.sha256(data).hexdigest(), size=len(data), symbols=symbols)

    def _header_lang(self, files: list[str]) -> str:
        cpp = sum(1 for f in files if Path(f).suffix.lower() in (".cc", ".cpp", ".cxx", ".hpp", ".hh", ".hxx"))
        c = sum(1 for f in files if Path(f).suffix.lower() == ".c")
        return "cpp" if cpp >= c and cpp else "c"

    def _repo_map(self, infos: list[FileInfo], entries: list[str]) -> str:
        def rank(fi: FileInfo) -> tuple[int, int]:
            return (0 if fi.path in entries else 1 if fi.language == "other" else 2, -len(fi.symbols))

        lines: list[str] = []
        budget = max(400, self.settings.prompt_tokens_for("planner") // 4)
        used = 0
        for fi in sorted(infos, key=rank):
            shown = ", ".join(fi.symbols[:12]) + (f", +{len(fi.symbols) - 12} more" if len(fi.symbols) > 12 else "")
            line = f"{fi.path}: {shown}" if shown else fi.path
            cost = estimate_tokens(line) + 1
            if used + cost > budget:
                lines.append(f"... {len(infos) - len(lines)} more files not shown")
                break
            lines.append(line)
            used += cost
        return "\n".join(lines)

    def _assemble(self, infos: list[FileInfo]) -> Manifest:
        langs = detect_languages(self.repo)
        primary = primary_language(self.repo)
        rels = [f.path for f in infos]
        entries = sorted({f.path for f in infos if Path(f.path).name in ENTRY_NAMES or "main" in f.symbols})
        commands: dict[str, str] = {}
        if infos:
            runner = get_runner(primary, self.repo, self.settings.limits.subprocess_timeout_s)
            commands = {k: v for k, v in runner.commands().items() if v and runner.enabled(k)}  # type: ignore[arg-type]
        return Manifest(
            project_id=self.project_id, code_tree_hash=code_tree_hash(self.repo, rels), project_name=self.project_name,
            root=str(self.repo), is_empty=not infos, has_tests=any(looks_like_test(r) for r in rels),
            languages=list(langs), primary_language=primary, build_system=detect_build_system(self.repo),
            commands=commands, dependencies=detect_dependencies(self.repo), entry_points=entries, files=infos,
            repo_map=self._repo_map(infos, entries), generated_at=time.strftime("%Y-%m-%dT%H:%M:%S"),
        )

    def run(self, prev: Manifest | None = None) -> Manifest:
        sources = source_files(self.repo)
        files = sources + [f for f in config_files(self.repo) if f not in sources]
        header_lang = self._header_lang(sources)
        engine = parser_engines()
        old = {f.path: f for f in prev.files} if prev and prev.project_id == self.project_id and prev.parser == engine else {}
        infos: list[FileInfo] = []
        for rel in sorted(files):
            digest = hashlib.sha256((self.repo / rel).read_bytes()).hexdigest()
            cached = old.get(rel)
            infos.append(cached if cached and cached.sha256 == digest else self._info(rel, header_lang))
        out = self._assemble(infos)
        out.parser = engine
        return out

    def refresh(self, manifest: Manifest, changed: list[str]) -> Manifest:
        known = {f.path: f for f in manifest.files}
        changed = [c.replace("\\", "/") for c in changed]
        header_lang = self._header_lang(list(known) + changed)
        for rel in changed:
            p = self.repo / rel
            cfg = load_languages()
            is_config = Path(rel).name in cfg.get("config_names", []) or Path(rel).suffix.lower() in cfg.get("config_extensions", [])
            if p.exists() and (Path(rel).suffix.lower() in cfg["extensions"] or is_config):
                known[rel] = self._info(rel, header_lang)
            else:
                known.pop(rel, None)
        out = self._assemble([known[k] for k in sorted(known)])
        out.parser = manifest.parser
        return out


def manifest_text(m: Manifest, max_tokens: int) -> str:
    parts = [
        f"Project: {m.project_name}  (primary language: {m.primary_language}; languages: {', '.join(m.languages) or 'none'})",
        f"Build system: {m.build_system or 'unknown'}",
        f"Existing tests: {'yes' if m.has_tests else 'NO'}",
        "Commands: " + ("; ".join(f"{k}={v}" for k, v in m.commands.items()) or "none detected"),
    ]
    if m.dependencies:
        parts.append("Dependencies: " + "; ".join(f"{k}: {', '.join(v[:15])}" for k, v in m.dependencies.items()))
    if m.entry_points:
        parts.append("Entry points: " + ", ".join(m.entry_points[:8]))
    head = "\n".join(parts)
    if m.is_empty:
        return head + "\nThe project is empty: plan scaffolding first."
    rest = max(200, max_tokens - estimate_tokens(head))
    return head + "\nProject map (file: symbols):\n" + truncate_to_tokens(m.repo_map, rest, "head")
