from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Any

from pydantic import BaseModel, Field, model_validator

from ..core.budget import Section, estimate_tokens, fit_sections
from ..core.command_policy import CommandPolicy, load_approved
from ..core.paths import posix
from ..core.schemas import Language, Manifest, Plan, Task, TaskKind
from ..runners.registry import config_files, load_languages
from . import prompts
from . import analogues as ana
from .analyser import manifest_text
from .context import AgentContext
from .analyser import looks_like_test
from .targets import characterization_target, infer_targets

TEST_FIRST = "The project has no tests: make T1 a characterization-test task (kind test) in a NEW test file that imports the logic modules the later tasks will touch and pins down their current behaviour. Never put tests inside existing source files, and never start windows, GUI apps, event loops, servers or network in a test."
TEST_NO_TOOLING = "The project has no test framework: a test task must create a self-contained test program that uses only the standard library (assert and main), list the build file (CMakeLists.txt, .pro or Makefile) in its target_files so the test is compiled, and register it so the project's test command runs it (CMake: add_executable for the test, enable_testing() and add_test(NAME <name> COMMAND <target>); Make: a test target). The test must check the behaviour the request asks for (for example that a value changes the output as described), not only that the code runs. Do not use M_PI (not standard C++); define a local pi constant."
ANALYSIS_ONLY = re.compile(r"(analy[sz]e|understand|investigate|explore|study|examine|inspect|research|identify|review)\b(?!.*\b(add|implement|create|fix|update|register|wire|write)\b)", re.I)
TEST_OK = "Add or update tests only where a task changes behaviour."


class TaskDraft(BaseModel):
    id: str
    title: str
    description: str
    language: Language
    kind: TaskKind = "feature"
    target_files: list[str] = Field(default_factory=list)
    symbol_targets: list[str] = Field(default_factory=list)
    acceptance_criteria: list[str] = Field(min_length=1)
    verify_command: str = ""
    depends_on: list[str] = Field(default_factory=list)
    priority: int = Field(default=3, ge=1, le=5)


class PlanDraft(BaseModel):
    summary: str
    assumptions: list[str] = Field(default_factory=list)
    tasks: list[TaskDraft] = Field(min_length=1)

    @model_validator(mode="after")
    def _graph_ok(self) -> "PlanDraft":
        Plan(summary=self.summary, tasks=[to_task(t) for t in self.tasks])
        return self


class VerifyFix(BaseModel):
    task_id: str
    verify_command: str = ""


class VerifyFixes(BaseModel):
    fixes: list[VerifyFix] = Field(default_factory=list)


@dataclass
class PlanResult:
    plan: Plan
    assumptions: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    policy_events: list[dict[str, Any]] = field(default_factory=list)
    proposals: list[str] = field(default_factory=list)
    analogues: list[dict[str, Any]] = field(default_factory=list)


def to_task(d: TaskDraft) -> Task:
    return Task(
        id=d.id, title=d.title, description=d.description, language=d.language, kind=d.kind,
        target_files=d.target_files, symbol_targets=d.symbol_targets, acceptance_criteria=d.acceptance_criteria,
        verify_command=d.verify_command.strip() or None, depends_on=d.depends_on, priority=d.priority,
    )


def _clean_path(p: str) -> str:
    p = posix(p)
    return "" if (not p or p.startswith(("/", "~")) or ".." in Path(p).parts) else p


def infer_language(path: str, header_lang: str = "cpp") -> str:
    ext = Path(path).suffix.lower()
    lang = load_languages()["extensions"].get(ext, "")
    return header_lang if lang == "header" else lang


def wants_test_first(manifest: Manifest) -> bool:
    return not manifest.has_tests and not manifest.is_empty and manifest.primary_language in ("python", "js", "java")


class Planner:
    def __init__(self, ctx: AgentContext, approved_path: Path | None = None):
        self.ctx = ctx
        self.approved = load_approved(approved_path) if approved_path else set()
        self._analogues: list[ana.Analogue] = []

    def _policy(self, lang: str, cache: dict[str, CommandPolicy]) -> CommandPolicy:
        if lang not in cache:
            cache[lang] = CommandPolicy(self.ctx.repo, lang, approved=self.approved)
        return cache[lang]

    def _messages(self, manifest: Manifest, requirements: str, user_input: str, extra: str = "") -> list[dict[str, str]]:
        s = self.ctx.settings
        policy = CommandPolicy(self.ctx.repo, manifest.primary_language, approved=self.approved)
        system = prompts.render(
            "planner", max_tasks=str(s.limits.max_tasks), allowed_tools=", ".join(policy.allowed_for_prompt()),
            test_rule=TEST_FIRST if wants_test_first(manifest) else TEST_NO_TOOLING if (not manifest.has_tests and manifest.primary_language in ("c", "cpp")) else TEST_OK,
        )
        budget = s.prompt_tokens_for("planner") - estimate_tokens(system) - 150
        parts = fit_sections([
            Section("req", requirements, 9, 600, "head"),
            Section("user", user_input, 8, 0, "head"),
            Section("extra", extra, 7, 0, "head"),
            Section("manifest", manifest_text(manifest, budget), 4, 400, "head"),
        ], budget)
        body = f"REQUIREMENTS:\n{parts['req']}\n"
        if parts["user"].strip():
            body += f"\nUSER INPUT (changes, new features, feedback):\n{parts['user']}\n"
        if parts["extra"].strip():
            body += f"\n{parts['extra']}\n"
        body += f"\nPROJECT:\n{parts['manifest']}"
        return [{"role": "system", "content": system}, {"role": "user", "content": body}]

    def _normalise(self, draft: PlanDraft, manifest: Manifest) -> PlanResult:
        result = PlanResult(plan=Plan(summary=draft.summary, tasks=[to_task(t) for t in draft.tasks]), assumptions=draft.assumptions)
        existing = {f.path for f in manifest.files}
        header_lang = "cpp" if "cpp" in manifest.languages or "c" not in manifest.languages else "c"
        tasks = result.plan.ordered()
        if len(tasks) > self.ctx.settings.limits.max_tasks:
            keep = {t.id for t in tasks[: self.ctx.settings.limits.max_tasks]}
            result.warnings.append(f"plan truncated to {len(keep)} tasks")
            tasks = [t for t in tasks if t.id in keep]
            for t in tasks:
                t.depends_on = [d for d in t.depends_on if d in keep]
        study = [t for t in tasks if ANALYSIS_ONLY.match(t.title.strip()) and t.kind != "test"]
        if study and len(study) < len(tasks):
            gone = {t.id for t in study}
            tasks = [t for t in tasks if t.id not in gone]
            for t in tasks:
                t.depends_on = [d for d in t.depends_on if d not in gone]
            result.warnings.append(f"dropped analysis-only tasks {', '.join(sorted(gone))}: the project is analysed before planning and every task must change code")
        cache: dict[str, CommandPolicy] = {}
        for t in tasks:
            t.target_files = [p for p in (_clean_path(x) for x in t.target_files) if p]
            if not t.target_files:
                t.target_files = infer_targets(self.ctx.repo, t)
                if t.target_files:
                    result.warnings.append(f"{t.id}: no target files given; inferred {', '.join(t.target_files)}")
            langs = {infer_language(p, header_lang) for p in t.target_files} - {""}
            if langs and t.language not in langs:
                fixed = sorted(langs)[0]
                result.warnings.append(f"{t.id}: language {t.language} -> {fixed} (from target files)")
                t.language = fixed  # type: ignore[assignment]
            if t.kind != "test" and t.target_files and all(looks_like_test(p) for p in t.target_files):
                t.kind = "test"  # type: ignore[assignment]
            if t.kind == "test" and t.language in ("c", "cpp") and any(p not in existing for p in t.target_files):
                build = next((c for c in config_files(self.ctx.repo) if PurePosixPath(c).name in ("CMakeLists.txt", "Makefile", "makefile") or c.endswith(".pro")), None)
                if build and build not in t.target_files:
                    t.target_files.append(build)
                    result.warnings.append(f"{t.id}: added {build} so the new test is compiled")
            if len(t.target_files) > 3:
                result.warnings.append(f"{t.id}: targets {len(t.target_files)} files; it may be split at runtime")
            if t.kind in ("bugfix", "refactor"):
                missing = [p for p in t.target_files if p not in existing]
                if missing:
                    result.warnings.append(f"{t.id}: {t.kind} targets missing files {missing}")
            policy = self._policy(t.language, cache)
            res = policy.resolve_verify(t.verify_command, manifest.commands.get("test"))
            t.verify_command, t.verify_source = res.command, res.source  # type: ignore[assignment]
            if res.event:
                result.policy_events.append({**res.event, "task_id": t.id})
                result.proposals += [p for p in res.proposals if p not in result.proposals]
        tested: dict[str, str] = {}
        for i, t in enumerate(tasks):
            later = [f for x in [*tasks[i + 1:], *tasks[:i]] for f in x.target_files]
            moved = characterization_target(self.ctx.repo, t, later, looks_like_test)
            if moved:
                src, test = moved
                if [test] != t.target_files:
                    result.warnings.append(f"{t.id}: test goes into new file {test} (testing {src}) instead of {', '.join(t.target_files) or 'no file'}")
                t.target_files, tested[t.id], t.kind = [test], src, "test"
                if re.search(r"characteri[sz]", t.title, re.I):
                    t.optional = True
                t.verify_command = manifest.commands.get("test")
                t.verify_source = "default" if t.verify_command else "none"  # type: ignore[assignment]
        optional = {t.id for t in tasks if t.optional}
        for t in tasks:
            t.depends_on = [d for d in t.depends_on if d not in optional]
        refs = ana.reference_files(self._analogues)
        for t in tasks:
            t.reference_files = [r for r in refs if r not in t.target_files and infer_language(r, header_lang) in ("", t.language)][:2]
            if t.id in tested:
                t.reference_files = [tested[t.id], *[r for r in t.reference_files if r != tested[t.id]]][:2]
        result.analogues = [a.to_dict() for a in self._analogues]
        result.plan = Plan(summary=draft.summary, tasks=tasks)
        return result

    def _repair_verify(self, result: PlanResult, manifest: Manifest) -> PlanResult:
        bad = [e for e in result.policy_events if e["kind"] in ("not_allowed", "denied")]
        if not bad:
            return result
        cache: dict[str, CommandPolicy] = {}
        by_id = {t.id: t for t in result.plan.tasks}
        lines = []
        for e in bad:
            t = by_id[e["task_id"]]
            allowed = self._policy(t.language, cache).allowed_for_prompt()
            lines.append(f"{t.id} ({t.language}): '{e['command']}' rejected: {e['reason']}. Allowed tools: {', '.join(allowed)}")
        msgs = [
            {"role": "system", "content": "Fix verify commands. Return JSON only: fixes is a list of {task_id, verify_command}. Use only the allowed tools, or an empty string if none fits."},
            {"role": "user", "content": "\n".join(lines)},
        ]
        try:
            fixes, _ = self.ctx.client.structured("planner", msgs, VerifyFixes, max_tokens=800, retries=1)
        except Exception:
            return result
        for fx in fixes.fixes:
            t = by_id.get(fx.task_id)
            if not t:
                continue
            res = self._policy(t.language, cache).resolve_verify(fx.verify_command, manifest.commands.get("test"))
            if res.source == "planner":
                t.verify_command, t.verify_source = res.command, "planner"
                result.policy_events = [e for e in result.policy_events if e["task_id"] != t.id]
        result.proposals = [p for p in result.proposals if any(e["executable"] == p for e in result.policy_events)]
        return result

    def plan(self, manifest: Manifest, requirements: str, user_input: str = "") -> PlanResult:
        self._analogues = ana.find_analogues(manifest, self.ctx.repo, requirements, user_input)
        for a in self._analogues:
            self.ctx.log({"type": "analogue", "new": a.new_name, "existing": a.existing, "files": sorted({t.file for t in a.touchpoints})})
        msgs = self._messages(manifest, requirements, user_input, ana.prompt_block(self._analogues))
        draft, _ = self.ctx.client.structured("planner", msgs, PlanDraft)
        result = self._repair_verify(self._normalise(draft, manifest), manifest)
        self.ctx.log({"type": "plan", "tasks": len(result.plan.tasks), "warnings": result.warnings, "policy_events": len(result.policy_events)})
        return result

    def revise(self, manifest: Manifest, requirements: str, user_input: str, previous: PlanResult, critique: str) -> PlanResult:
        extra = ana.prompt_block(self._analogues) + f"\nPREVIOUS PLAN (summary): {previous.plan.summary}\nTASKS: " + "; ".join(f"{t.id} {t.title}" for t in previous.plan.tasks)
        msgs = self._messages(manifest, requirements, user_input, extra + f"\n\nREVIEW FINDINGS TO FIX:\n{critique}")
        draft, _ = self.ctx.client.structured("planner", msgs, PlanDraft)
        result = self._repair_verify(self._normalise(draft, manifest), manifest)
        self.ctx.log({"type": "plan_revised", "tasks": len(result.plan.tasks)})
        return result


    def replan(self, manifest: Manifest, requirements: str, user_input: str, previous: list[dict[str, Any]], stuck_id: str,
               problem: str, note: str, keep_done: bool) -> PlanResult:
        self._analogues = ana.find_analogues(manifest, self.ctx.repo, requirements, user_input)
        rows = []
        for t in previous:
            state = t.get("status", "pending")
            if t["id"] == stuck_id:
                state = "STUCK"
            elif not keep_done:
                state = f"{state}, now rolled back"
            rows.append(f"- {t['id']} [{state}] {t['title']} (files: {', '.join(t.get('target_files') or []) or 'none'})")
        done = [t for t in previous if keep_done and t.get("status") == "completed"]
        scope = ("Tasks marked completed are already in the code: do not repeat them. Plan ONLY the remaining work, "
                 "including any intermediate step the previous plan missed before the stuck task.") if keep_done else \
                ("All previous changes were rolled back. Plan the whole request again, fixing the gaps that made the previous plan fail.")
        extra = (ana.prompt_block(self._analogues) + "\nPREVIOUS PLAN (it did not work):\n" + "\n".join(rows)
                 + f"\n\nWHY {stuck_id} GOT STUCK:\n{problem.strip()[:1500]}\n"
                 + (f"\nHUMAN NOTE (follow it):\n{note.strip()}\n" if note.strip() else "")
                 + f"\nREPLANNING: {scope} Number new tasks T1, T2, ... in order; depends_on may only name new tasks.")
        msgs = self._messages(manifest, requirements, user_input, extra)
        draft, _ = self.ctx.client.structured("planner", msgs, PlanDraft)
        result = self._repair_verify(self._normalise(draft, manifest), manifest)
        taken = [int(m.group(1)) for t in previous if (m := re.match(r"T(\d+)$", t["id"]))]
        start = max(taken, default=0) + 1
        mapping = {t.id: f"T{start + i}" for i, t in enumerate(result.plan.tasks)}
        for t in result.plan.tasks:
            t.id = mapping[t.id]
            t.depends_on = [mapping[d] for d in t.depends_on if d in mapping]
        result.plan = Plan(summary=result.plan.summary, tasks=result.plan.tasks)
        if done:
            result.warnings.append("kept completed tasks: " + ", ".join(t["id"] for t in done))
        self.ctx.log({"type": "replan", "keep_done": keep_done, "stuck": stuck_id, "before": [f"{t['id']} {t['title']}" for t in previous],
                      "after": [f"{t.id} {t.title}" for t in result.plan.tasks], "warnings": result.warnings})
        return result


def render_brief(requirements: str, result: PlanResult) -> str:
    out = ["# Design brief", "", "## Objective", requirements.strip(), "", "## Summary", result.plan.summary, ""]
    if result.assumptions:
        out += ["## Assumptions"] + [f"- {a}" for a in result.assumptions] + [""]
    out += ["## Tasks", ""]
    for t in result.plan.tasks:
        deps = f" (after {', '.join(t.depends_on)})" if t.depends_on else ""
        out.append(f"### {t.id}: {t.title}{deps}")
        out.append(f"{t.language} / {t.kind} / files: {', '.join(t.target_files) or 'none'}")
        out += [f"- {c}" for c in t.acceptance_criteria]
        out.append(f"- verify ({t.verify_source}): `{t.verify_command or 'none'}`")
        out.append("")
    if result.warnings:
        out += ["## Plan warnings"] + [f"- {w}" for w in result.warnings]
    return "\n".join(out)


def write_brief(run_dir: Path, requirements: str, result: PlanResult) -> Path:
    p = run_dir / "design_brief.md"
    p.write_text(render_brief(requirements, result), encoding="utf-8")
    return p
