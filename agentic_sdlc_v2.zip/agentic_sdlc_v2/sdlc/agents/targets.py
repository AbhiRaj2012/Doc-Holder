from __future__ import annotations

import re
from pathlib import Path, PurePosixPath

from ..core import symbols as sym
from ..core.schemas import Task
from ..runners.registry import source_files

SOURCE_FOR_HEADER = (".cpp", ".cc", ".cxx", ".c")
IMPL_WORDS = re.compile(r"\b(implement|implementation|define|definition|body|logic|calculate|calculation|compute)\b", re.I)


def _text(task: Task) -> str:
    return " ".join([task.title, task.description, *task.acceptance_criteria, *task.symbol_targets])


def infer_targets(repo: Path, task: Task, limit: int = 2) -> list[str]:
    text = _text(task)
    low = text.lower()
    files = source_files(repo)
    named = [f for f in files if re.search(rf"(?<![\w/]){re.escape(PurePosixPath(f).name.lower())}(?!\w)", low) or f.lower() in low]
    picked: list[str] = list(dict.fromkeys(named))
    if not picked:
        words = set(re.findall(r"\b[A-Za-z_]\w{2,}\b", text)) | {re.split(r"[.:]+", s)[-1] for s in task.symbol_targets}
        for f in files:
            lang = sym.lang_for(f)
            if not lang or lang in ("css", "html"):
                continue
            try:
                found = {re.split(r"[.:]+", s.name)[-1] for s in sym.extract(lang, (repo / f).read_text(encoding="utf-8", errors="ignore"))}
            except OSError:
                continue
            if found & words:
                picked.append(f)
    out: list[str] = []
    for f in picked:
        p = PurePosixPath(f)
        if p.suffix in (".h", ".hpp", ".hh") and IMPL_WORDS.search(text):
            sibling = next((str(p.with_suffix(ext)) for ext in SOURCE_FOR_HEADER if str(p.with_suffix(ext)) in files), "")
            if sibling and sibling not in out:
                out.insert(0, sibling)
        if f not in out:
            out.append(f)
    return out[:limit]


ENTRY_NAMES = {"main", "app", "__main__", "index", "server", "run", "gui", "window", "mainwindow"}


def import_root(repo: Path, rel: str) -> PurePosixPath:
    parent = PurePosixPath(rel).parent
    while str(parent) not in ("", ".") and (repo / str(parent) / "__init__.py").exists():
        parent = parent.parent
    return parent


def test_file_for(repo: Path, src: str, language: str) -> str | None:
    p = PurePosixPath(src)
    if language == "python":
        out = import_root(repo, src) / f"test_{p.stem}.py"
    elif language == "js":
        out = p.parent / f"{p.stem}.test.js"
    else:
        return None
    return str(out)


def characterization_target(repo: Path, task: Task, later_targets: list[str], is_test) -> tuple[str, str] | None:
    if (task.kind != "test" and not re.search(r"characteri[sz]", task.title, re.I)) or task.language not in ("python", "js"):
        return None
    tests = [f for f in task.target_files if is_test(f)]
    if tests:
        if task.language != "python" or len(tests) != 1 or (repo / tests[0]).exists():
            return None
        srcs = [f for f in later_targets if f.endswith(".py") and not is_test(f) and (repo / f).is_file()]
        srcs += [f for f in source_files(repo) if f.endswith(".py") and not is_test(f) and f not in srcs and PurePosixPath(f).stem.lower() not in ENTRY_NAMES]
        if not srcs:
            return None
        root = import_root(repo, srcs[0])
        if import_root(repo, tests[0]) == root:
            return srcs[0], tests[0]
        return srcs[0], str(root / PurePosixPath(tests[0]).name)
    ext = ".py" if task.language == "python" else ".js"
    pool = [f for f in [*later_targets, *task.target_files] if f.endswith(ext) and not is_test(f) and (repo / f).is_file()]
    pool += [f for f in source_files(repo) if f.endswith(ext) and f not in pool and not is_test(f)]
    logic = [f for f in pool if PurePosixPath(f).stem.lower() not in ENTRY_NAMES]
    src = (logic or pool or [None])[0]
    if not src:
        return None
    test = test_file_for(repo, src, task.language)
    return (src, test) if test else None
