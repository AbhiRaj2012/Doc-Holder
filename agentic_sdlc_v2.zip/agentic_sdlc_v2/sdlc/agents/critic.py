from __future__ import annotations

from pydantic import BaseModel, Field

from ..core.budget import Section, estimate_tokens, fit_sections
from ..core.schemas import Plan
from . import prompts
from .context import AgentContext


class CritiqueIssue(BaseModel):
    task_id: str = ""
    problem: str
    fix: str = ""


class Critique(BaseModel):
    ok: bool
    issues: list[CritiqueIssue] = Field(default_factory=list)
    missing_requirements: list[str] = Field(default_factory=list)

    def as_text(self) -> str:
        lines = [f"{i.task_id or 'PLAN'}: {i.problem}" + (f" Fix: {i.fix}" if i.fix else "") for i in self.issues]
        lines += [f"MISSING REQUIREMENT: {m}" for m in self.missing_requirements]
        return "\n".join(lines)


def plan_text(plan: Plan) -> str:
    out = [f"Summary: {plan.summary}"]
    for t in plan.tasks:
        out.append(
            f"{t.id} [{t.language}/{t.kind}] {t.title}; files: {', '.join(t.target_files) or 'none'}; "
            f"after: {', '.join(t.depends_on) or '-'}; criteria: " + " | ".join(t.acceptance_criteria)
            + f"; verify: {t.verify_command or 'none'}"
        )
    return "\n".join(out)


class PlanCritic:
    def __init__(self, ctx: AgentContext):
        self.ctx = ctx

    def review(self, requirements: str, plan: Plan) -> Critique:
        system = prompts.load("critic")
        budget = self.ctx.settings.prompt_tokens_for("reviewer") - estimate_tokens(system) - 100
        parts = fit_sections([Section("req", requirements, 9, 400, "head"), Section("plan", plan_text(plan), 8, 400, "middle")], budget)
        msgs = [
            {"role": "system", "content": system},
            {"role": "user", "content": f"REQUIREMENTS:\n{parts['req']}\n\nPLAN:\n{parts['plan']}"},
        ]
        verdict, _ = self.ctx.client.structured("reviewer", msgs, Critique, max_tokens=1200)
        self.ctx.log({"type": "plan_critic", "ok": verdict.ok, "issues": len(verdict.issues), "missing": len(verdict.missing_requirements)})
        return verdict
