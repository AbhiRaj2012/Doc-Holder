from __future__ import annotations

from ..core.budget import truncate_to_tokens
from ..core.config import CONFIG_DIR


def load(name: str) -> str:
    return (CONFIG_DIR / "prompts" / f"{name}.md").read_text(encoding="utf-8").strip()


def render(name: str, **values: str) -> str:
    text = load(name)
    for key, value in values.items():
        text = text.replace("{{" + key + "}}", value)
    return text


def skill_text(kind: str, language: str, max_tokens: int = 350) -> str:
    parts: list[str] = []
    for fname in (f"{kind}.md", f"lang_{language}.md"):
        p = CONFIG_DIR / "skills" / fname
        if p.exists():
            parts.append(p.read_text(encoding="utf-8").strip())
    return truncate_to_tokens("\n\n".join(parts), max_tokens, "head") if parts else ""
