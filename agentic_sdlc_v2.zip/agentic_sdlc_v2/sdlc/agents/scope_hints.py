from __future__ import annotations

import re
from pathlib import Path, PurePosixPath

from . import context_select
from ..runners.registry import config_files
from .analyser import looks_like_test

MISSING_MEMBER = [
    re.compile(r"['‘`](?:const\s+)?(?:struct|class)\s+([A-Za-z_]\w*)['’`]\s+has no member named"),
    re.compile(r"\b([A-Z]\w*) has no (?:attribute|member) `"),
    re.compile(r"`([A-Za-z_]\w*)\(\.\.\.\)` has no parameter `"),
    re.compile(r"'([A-Za-z_]\w*)' object has no attribute"),
    re.compile(r"Property '\w+' does not exist on type '([A-Za-z_]\w*)'"),
    re.compile(r"location: (?:class|variable \w+ of type) ([A-Za-z_]\w*)"),
]
UNDECLARED_IN = re.compile(r"([\w./\\-]+\.(?:c|cc|cpp|cxx)):\d+.*?['‘]([A-Za-z_]\w*)['’] was not declared in this scope")
HEADER_EXT = (".h", ".hpp", ".hh", ".hxx")


def _rel(repo: Path, raw: str) -> str | None:
    p = PurePosixPath(raw.replace("\\", "/"))
    parts = [x for x in p.parts if x not in ("..", ".")]
    for i in range(len(parts)):
        cand = "/".join(parts[i:])
        if (repo / cand).is_file():
            return cand
    return None


def extra_targets(repo: Path, text: str, targets: list[str], limit: int = 2) -> list[tuple[str, str]]:
    if not text:
        return []
    found: list[tuple[str, str]] = []
    names = {m.group(1) for rx in MISSING_MEMBER for m in rx.finditer(text)}
    index = context_select.project_index(repo) if names else {}
    for name in sorted(names):
        defs = [rel for rel, full, _line, _sig in index.get(name, []) if full.split("::")[-1].split(".")[-1] == name and not looks_like_test(rel)]
        defs.sort(key=lambda r: (not r.endswith(HEADER_EXT), r))
        for rel in defs[:1]:
            if rel not in targets and rel not in [f for f, _ in found]:
                found.append((rel, f"{name} is defined there and needs the missing member"))
    for m in UNDECLARED_IN.finditer(text):
        src = _rel(repo, m.group(1))
        if not src or src not in targets:
            continue
        for ext in HEADER_EXT:
            header = str(PurePosixPath(src).with_suffix(ext))
            if (repo / header).is_file() and header not in targets and header not in [f for f, _ in found]:
                found.append((header, f"`{m.group(2)}` is used in {src} but must be declared in its header"))
    if "the new test was never run" in text:
        build = next((c for c in config_files(repo) if PurePosixPath(c).name in ("CMakeLists.txt", "Makefile", "makefile", "meson.build") or c.endswith(".pro")), None)
        if build and build not in targets and build not in [f for f, _ in found]:
            found.append((build, "the test has to be registered in the build so the test command runs it"))
    return found[:limit]
