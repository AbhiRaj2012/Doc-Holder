from __future__ import annotations

import re
from pathlib import Path

from ..core import symbols as sym
from ..core.budget import estimate_tokens
from ..runners.registry import source_files

_INDEX: dict[str, tuple[float, list[tuple[str, str, int, str]]]] = {}
STOP = {"self", "this", "main", "init", "get", "set", "value", "name", "data", "item", "list", "map", "size", "len", "str", "int", "string",
        "print", "return", "true", "false", "none", "null", "document", "window", "console", "std", "args", "result", "error"}


def signature(lines: list[str], start: int, max_lines: int = 2) -> str:
    out = []
    for ln in lines[start - 1:start - 1 + max_lines + 2]:
        s = ln.rstrip()
        if s.strip().startswith(("@", "#", "//", "/*", "*")) and not out:
            continue
        out.append(s)
        if "{" in s or re.search(r"[:;}]\s*$|=>", s) or len(out) >= max_lines:
            break
    return " ".join(x.strip() for x in out)[:220]


def _file_symbols(repo: Path, rel: str) -> list[tuple[str, str, int, str]]:
    p = repo / rel
    try:
        mtime = p.stat().st_mtime
    except OSError:
        return []
    key = str(p)
    hit = _INDEX.get(key)
    if hit and hit[0] == mtime:
        return hit[1]
    lang = sym.lang_for(rel)
    entries: list[tuple[str, str, int, str]] = []
    if lang and lang not in ("css", "html"):
        text = p.read_text(encoding="utf-8", errors="replace")
        lines = text.splitlines()
        for s in sym.extract(lang, text):
            leaf = re.split(r"[.:]+", s.name)[-1]
            entries.append((leaf, s.name, s.start, signature(lines, s.start)))
    _INDEX[key] = (mtime, entries)
    return entries


def project_index(repo: Path, limit: int = 1500) -> dict[str, list[tuple[str, str, int, str]]]:
    index: dict[str, list[tuple[str, str, int, str]]] = {}
    for rel in source_files(repo)[:limit]:
        for leaf, full, line, sig in _file_symbols(repo, rel):
            index.setdefault(leaf, []).append((rel, full, line, sig))
    return index


def related_definitions(repo: Path, targets: list[str], extra_names: list[str], budget_tokens: int, exclude: set[str] | None = None) -> str:
    if budget_tokens <= 50:
        return ""
    exclude = set(targets) | (exclude or set())
    used: dict[str, int] = {}
    for t in targets:
        p = repo / t
        if not p.is_file():
            continue
        lang = sym.lang_for(t)
        if not lang:
            continue
        for name in sym.identifiers(lang, p.read_text(encoding="utf-8", errors="replace")):
            used[name] = used.get(name, 0) + 1
    for n in extra_names:
        used[re.split(r"[.:]+", n)[-1]] = 99
    index = project_index(repo)
    lines: list[str] = []
    seen: set[tuple[str, str]] = set()
    for name in sorted(used, key=lambda n: -used[n]):
        if len(name) < 3 or name.lower() in STOP:
            continue
        for rel, full, line, sig in index.get(name, [])[:3]:
            if rel in exclude or (rel, full) in seen:
                continue
            seen.add((rel, full))
            entry = f"{rel}:{line}  {sig}"
            if estimate_tokens("\n".join([*lines, entry])) > budget_tokens:
                return "\n".join(lines)
            lines.append(entry)
    return "\n".join(lines)


def outline(path: str, text: str) -> str:
    lang = sym.lang_for(path)
    if not lang:
        return text[:1500]
    lines = text.splitlines()
    syms = sym.extract(lang, text)
    if not syms:
        return text[:1500]
    return "\n".join(f"{s.start}: {signature(lines, s.start)}" for s in syms)
