from __future__ import annotations

import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command

from ..core.budget import BudgetExceeded
from ..core.state import PipelineState
from . import routing
from .nodes.finish import make_finish
from .nodes.gate import make_gate
from .nodes.integrate import make_integrate
from .nodes.plan_gate import make_approve_plan
from .nodes.setup import make_analyse, make_approve_commands, make_plan, make_prepare
from .nodes.tasks import make_commit, make_pick, make_split, make_suspend
from .nodes.work import make_edit, make_regression, make_review
from .runtime import Runtime

NO_ACTIVE_TIME = ("gate", "approve_commands", "approve_plan")


@dataclass
class RunStatus:
    done: bool
    interrupt: dict[str, Any] | None
    state: dict[str, Any]


def open_checkpointer(path: Path) -> SqliteSaver:
    path.parent.mkdir(parents=True, exist_ok=True)
    return SqliteSaver(sqlite3.connect(str(path), check_same_thread=False))


def thread_config(run_id: str) -> dict[str, Any]:
    return {"configurable": {"thread_id": run_id}, "recursion_limit": 100_000}


def _short(v: Any, n: int = 400) -> Any:
    if isinstance(v, str):
        return v if len(v) <= n else v[:n] + "..."
    return v


def summarize(name: str, update: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    last = update.get("last_edit") or {}
    if name == "edit" and last:
        out.update({"ok": update.get("edit_ok"), "format": last.get("edit_format"), "files": last.get("files_changed"),
                    "blocks": f"{last.get('blocks_applied', 0)} applied / {last.get('blocks_failed', 0)} failed",
                    "error": _short(update.get("edit_error", "")), "diff": _short(last.get("diff_head", ""), 1500)})
    elif name == "review" and update.get("last_review"):
        rv = update["last_review"]
        checks = [f"{c.get('name')}:{'skip' if c.get('skipped') else 'ok' if c.get('ok') else 'FAIL'}" for c in rv.get("checks", [])]
        out.update({"approved": update.get("approved"), "checks": ", ".join(checks), "llm_verdict": _short((rv.get("llm") or {}).get("feedback", ""), 300),
                    "feedback": _short(update.get("feedback", ""), 700)})
    elif name in ("plan", "approve_plan"):
        out.update({"tasks": [f"{t['id']}: {t['title']}" for t in update.get("tasks", [])][:12], "status": update.get("status", "")})
    elif name in ("pick", "split", "suspend", "commit", "regression", "gate", "finish", "prepare", "analyse"):
        for k in ("current_task_id", "resume_action", "shrink_level", "suspend_reason", "gate_reason", "regression_ok", "status", "last_good_commit", "error"):
            if update.get(k) not in (None, "", []):
                out[k] = _short(update[k])
    return {k: v for k, v in out.items() if v not in (None, "")}


def _traced(rt: Runtime, name: str, fn: Callable[[PipelineState], dict[str, Any]]) -> Callable[[PipelineState], dict[str, Any]]:
    def wrapper(state: PipelineState) -> dict[str, Any]:
        t0 = time.monotonic()
        rt.logger({"type": "node_start", "node": name, "task_id": state.get("current_task_id", ""), "iteration": state.get("iteration", 0)})
        try:
            update = dict(fn(state) or {})
        except BudgetExceeded as exc:
            rt.logger({"type": "budget_exceeded", "node": name, "reason": exc.reason})
            update = {"status": "budget_exceeded", "exit_reason": "budget_exceeded", "error": exc.reason}
        dur = time.monotonic() - t0
        rt.logger({"type": "node", "node": name, "task_id": state.get("current_task_id", ""), "iteration": state.get("iteration", 0), "duration_s": round(dur, 3),
                   "output": summarize(name, update)})
        if name not in NO_ACTIVE_TIME:
            update["active_s"] = round(state.get("active_s", 0.0) + dur, 3)
        return update

    return wrapper


def build_graph(rt: Runtime, checkpointer: SqliteSaver):
    nodes = {
        "prepare": make_prepare(rt), "analyse": make_analyse(rt), "plan": make_plan(rt), "approve_plan": make_approve_plan(rt), "approve_commands": make_approve_commands(rt),
        "pick": make_pick(rt), "split": make_split(rt), "edit": make_edit(rt), "suspend": make_suspend(rt), "review": make_review(rt),
        "regression": make_regression(rt), "commit": make_commit(rt), "integrate": make_integrate(rt), "gate": make_gate(rt), "finish": make_finish(rt),
    }
    g = StateGraph(PipelineState)
    for name, fn in nodes.items():
        g.add_node(name, _traced(rt, name, fn))
    g.add_edge(START, "prepare")
    g.add_edge("prepare", "analyse")
    g.add_edge("analyse", "plan")
    g.add_conditional_edges("plan", routing.after_plan, {"approve_plan": "approve_plan", "approve_commands": "approve_commands", "pick": "pick", "finish": "finish"})
    g.add_conditional_edges("approve_plan", routing.after_approve_plan, {"approve_plan": "approve_plan", "approve_commands": "approve_commands", "pick": "pick", "finish": "finish"})
    g.add_edge("approve_commands", "pick")
    g.add_conditional_edges("pick", routing.after_pick, {"edit": "edit", "split": "split", "integrate": "integrate"})
    g.add_conditional_edges("integrate", routing.after_integrate, {"pick": "pick", "finish": "finish"})
    g.add_conditional_edges("split", routing.after_split, {"pick": "pick", "gate": "gate"})
    g.add_conditional_edges("edit", routing.after_edit, {"edit": "edit", "review": "review", "suspend": "suspend", "gate": "gate", "finish": "finish"})
    g.add_conditional_edges("suspend", routing.after_suspend, {"pick": "pick", "gate": "gate"})
    g.add_conditional_edges("review", routing.after_review, {"edit": "edit", "regression": "regression", "gate": "gate", "finish": "finish"})
    g.add_conditional_edges("regression", routing.after_regression, {"commit": "commit", "edit": "edit", "gate": "gate", "finish": "finish"})
    g.add_edge("commit", "pick")
    g.add_conditional_edges("gate", routing.after_gate, {"edit": "edit", "pick": "pick", "finish": "finish", "commit": "commit"})
    g.add_edge("finish", END)
    return g.compile(checkpointer=checkpointer)


def initial_state(rt: Runtime, project_id: str, requirements: str, user_input: str = "") -> dict[str, Any]:
    return {
        "run_id": rt.run_id, "project_id": project_id, "repo_path": str(rt.project.code), "workspace": str(rt.project.workspace),
        "requirements": requirements, "user_input": user_input, "started_at": time.time(),
    }


def _status(app: Any, cfg: dict[str, Any]) -> RunStatus:
    snap = app.get_state(cfg)
    pending = [i.value for t in snap.tasks for i in t.interrupts]
    return RunStatus(done=not snap.next, interrupt=pending[0] if pending else None, state=dict(snap.values))


def run_pipeline(app: Any, rt: Runtime, requirements: str, user_input: str = "") -> RunStatus:
    cfg = thread_config(rt.run_id)
    app.invoke(initial_state(rt, rt.project.id, requirements, user_input), cfg)
    return _status(app, cfg)


def resume_pipeline(app: Any, run_id: str, value: Any = None) -> RunStatus:
    cfg = thread_config(run_id)
    app.invoke(Command(resume=value) if value is not None else None, cfg)
    return _status(app, cfg)


def current_status(app: Any, run_id: str) -> RunStatus:
    return _status(app, thread_config(run_id))
