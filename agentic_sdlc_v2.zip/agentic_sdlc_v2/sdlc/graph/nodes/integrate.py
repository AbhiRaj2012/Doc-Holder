from __future__ import annotations

import re
from pathlib import Path
from dataclasses import asdict
from typing import Any, Callable

from ...agents.analogues import Analogue, best_analogues, defined_names, field_readers, field_wiring, scan_touchpoints
from ...agents.analyser import looks_like_test
from ...agents.planner import infer_language
from ...core import guards
from ...core.schemas import Manifest, Task
from ...core.state import PipelineState
from ..runtime import Runtime

Node = Callable[[PipelineState], dict[str, Any]]
MAX_WIRING_TASKS = 4


def make_integrate(rt: Runtime) -> Node:
    def integrate(state: PipelineState) -> dict[str, Any]:
        if state.get("integration_round", 0) >= 1 or not state.get("manifest"):
            return {"integration_added": False, "integration_round": 1}
        before = Manifest.model_validate(state["manifest"])
        manifest = rt.analyser.run(before)
        defined = defined_names(manifest)
        analogues = list(state.get("analogues") or [])
        known = {a["new_name"] for a in analogues}
        old_defined = defined_names(before)
        new_types = sorted(n for n in set(defined) - set(old_defined) if not all(looks_like_test(f) for f in defined[n]))
        for new in sorted(set(defined) - set(old_defined)):
            if new in known or all(looks_like_test(f) for f in defined[new]):
                continue
            for old in best_analogues(new, old_defined, min_score=2.5):
                analogues.append(Analogue(new, old, defined[new], scan_touchpoints(rt.ctx.repo, old, set())).to_dict())
                rt.logger({"type": "analogue", "new": new, "existing": old, "found": "after the tasks ran"})
        since = state.get("base_commit") or state.get("last_good_commit")
        fields = field_wiring(rt.ctx.repo, rt.git.diff_since(since, max_chars=400_000), looks_like_test) if since else []
        for path, new, old, tps in fields:
            analogues.append({"new_name": new, "existing": old, "defined_in": [path], "touchpoints": [asdict(t) for t in tps], "member": True})
            rt.logger({"type": "analogue", "new": new, "existing": old, "found": "new field next to an existing one"})
        if not analogues:
            return {"integration_added": False, "integration_round": 1}
        header_lang = "cpp" if "cpp" in manifest.languages or "c" not in manifest.languages else "c"
        tasks = [dict(t) for t in state.get("tasks", [])]
        taken = {t["id"] for t in tasks}
        added: list[dict[str, Any]] = []
        missing_report: list[str] = []
        for a in analogues:
            new, old = a["new_name"], a["existing"]
            if new not in defined and not a.get("member"):
                continue
            own = set(defined.get(new, [])) | set(a.get("defined_in", []))
            rx = re.compile(rf"\b{re.escape(new)}\b")
            by_file: dict[str, list[dict[str, Any]]] = {}
            for tp in a.get("touchpoints", []):
                by_file.setdefault(tp["file"], []).append(tp)
            for file, tps in by_file.items():
                if file in own or looks_like_test(file) or len(added) >= MAX_WIRING_TASKS:
                    continue
                path = rt.ctx.repo / file
                if not path.exists():
                    continue
                body = path.read_text(encoding="utf-8", errors="ignore")
                if a.get("member"):
                    if not guards.mirror_gaps(body, old, new):
                        continue
                elif rx.search(body):
                    continue
                missing_report.append(f"{new} is not referenced in {file} (where {old} is)")
                n = 1
                while f"W{n}" in taken:
                    n += 1
                tid = f"W{n}"
                taken.add(tid)
                lines = "; ".join(f"line {t['line']}: {t['text']}" for t in tps[:3])
                command = manifest.commands.get("test")
                header = next((str(Path(file).with_suffix(x)).replace("\\", "/") for x in (".h", ".hpp") if file.endswith((".cpp", ".cc", ".c")) and (rt.ctx.repo / Path(file).with_suffix(x)).exists()), None)
                owners = ", ".join(new_types[:3])
                what = (f"{new} is a new field next to {old}, but nothing in {file} sets or uses it, so it keeps its default value. {old} is handled there ({lines}). Handle {new} the same way (for example a matching input control and the line that copies its value), so users can change it. "
                        f"If {old}'s control is only shown or enabled under a condition (a flag or a method such as uses..., a mode check), add the matching condition so {new} is shown when it applies" + (f" (it is used by {owners})" if owners else "") + ". "
                        f"Give it a default and a range that make its effect visible at the program's normal scale, like {old}'s range."
                        if a.get("member") else
                        f"{new} is defined but not used in {file}. {old} is wired there ({lines}). Add {new} in the same way, matching the existing style, so the feature is reachable from the program.")
                task = Task(
                    id=tid, title=f"Wire {new} into {file}",
                    description=what,
                    language=infer_language(file, header_lang) or manifest.primary_language, kind="feature", target_files=[file, *([header] if header else [])],
                    acceptance_criteria=[f"{file} references {new}", f"{new} is wired in {file} the same way as {old}", "the project still builds"],
                    verify_command=command, verify_source="default" if command else "none",
                    reference_files=[f for f in (defined.get(new) or a.get("defined_in", [])) if f != file][:1],
                    mirror={"old": old, "new": new},
                )
                added.append(task.model_dump(mode="json"))
        for path, new, old, tps in fields:
            if len(added) >= MAX_WIRING_TASKS or field_readers(rt.ctx.repo, new, looks_like_test):
                continue
            readers = [f for f in field_readers(rt.ctx.repo, old, looks_like_test) if f != path]
            owners = [f for n in new_types for f in defined.get(n, []) if not looks_like_test(f)]
            target = (owners or readers or [None])[0]
            if not target:
                continue
            n = 1
            while f"W{n}" in taken:
                n += 1
            tid = f"W{n}"
            taken.add(tid)
            missing_report.append(f"{new} is set but never read, so it has no effect")
            users = ", ".join(t for t in new_types if target in defined.get(t, [])) or "the code that produces the result"
            command = manifest.commands.get("test")
            added.append(Task(
                id=tid, title=f"Make {new} take effect in {target}",
                description=f"{new} (next to {old} in {path}) is stored but nothing reads it, so changing it does nothing. In {target}, make {users} read {new} from the same parameters object it already receives, the way other code reads {old}, so the value changes the result as the request describes.",
                language=infer_language(target, header_lang) or manifest.primary_language, kind="feature", target_files=[target],
                acceptance_criteria=[f"{target} reads {new}", f"changing {new} changes the result", "the project still builds and existing tests pass"],
                verify_command=command, verify_source="default" if command else "none", reference_files=[path], mirror={"read": new},
            ).model_dump(mode="json"))
        if not added:
            rt.logger({"type": "integration_ok", "checked": [a["new_name"] for a in analogues]})
            return {"integration_added": False, "integration_round": 1}
        rt.logger({"type": "integration_tasks", "tasks": [t["id"] for t in added], "missing": missing_report})
        return {"tasks": tasks + added, "status": "running", "integration_added": True, "integration_round": 1}

    return integrate
