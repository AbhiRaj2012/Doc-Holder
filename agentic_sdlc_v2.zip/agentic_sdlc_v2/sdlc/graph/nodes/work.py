from __future__ import annotations

from typing import Any, Callable

from ...agents.editor import edit_findings, failures_after
from ...agents.scope_hints import extra_targets
from ...agents.targets import infer_targets
from ...core.ledger import Finding
from ...core.paths import posix_list
from ...core.schemas import ExitReason, Manifest, SuspendReason, Task
from ...core.state import PipelineState, current_task
from ...runners.registry import get_runner
from ...loop import escalation, stats, test_baseline
from ...loop.budget import MECHANICAL, over_budget
from ...loop.progress import track
from ..routing import ladder_limit, stalled
from ..runtime import Runtime
from .tasks import bump

Node = Callable[[PipelineState], dict[str, Any]]


def make_edit(rt: Runtime) -> Node:
    def edit(state: PipelineState) -> dict[str, Any]:
        s = rt.settings
        rt.guard.check()
        task = Task.model_validate(current_task(state))
        inferred: list[str] = []
        if not task.target_files:
            inferred = infer_targets(rt.ctx.repo, task)
            if inferred:
                task.target_files = inferred
                rt.logger({"type": "targets_inferred", "task_id": task.id, "files": inferred, "why": "the task named no files to edit; chosen from the task text and the project's symbols"})
        iteration = state.get("iteration", 0) + 1
        manifest = Manifest.model_validate(state["manifest"]) if state.get("manifest") else None
        hint, error = state.get("human_hint", ""), state.get("edit_error", "")
        widened = extra_targets(rt.ctx.repo, "\n".join([error, state.get("feedback", "") or ""]), task.target_files)
        for f, why in widened:
            task.target_files.append(f)
            rt.logger({"type": "scope_extended", "task_id": task.id, "file": f, "why": why})
        if widened:
            error += "\nYou may now also edit: " + ", ".join(f"{f} ({why})" for f, why in widened)
        extra: dict[str, Any] = {}
        lstats = dict(state.get("loop_stats", {}))
        if s.loop.test_baseline and not state.get("baseline_ready"):
            known = test_baseline.capture(rt, task)
            extra.update({"test_baseline": known, "baseline_ready": True})
            if known:
                rt.logger({"type": "test_baseline", "task_id": task.id, "failing": len(known), "why": "these tests already fail before the task starts and are not used as its gate"})
                lstats = stats.bump(state, "baseline_failing_tests", len(known), lstats)
        rejections = state.get("review_rejections", 0)
        esc = escalation.plan(s, rejections)
        diagnosis = state.get("diagnosis", "")
        if esc.diagnose and state.get("feedback") and state.get("diagnosed_at") != rejections:
            diagnosis = escalation.diagnose(rt, task, state["feedback"], rt.git.diff_since(state["task_base"], max_chars=20000))
            extra.update({"diagnosis": diagnosis, "diagnosed_at": rejections})
            lstats = stats.bump(state, "diagnoses", 1, lstats)
        if esc.level >= 2:
            rt.logger({"type": "escalation", "task_id": task.id, "level": esc.level, "temperature_bump": esc.temp_bump, "effort": esc.effort, "model": esc.model, "rejections": rejections})
            lstats = stats.bump(state, "fallback_model_uses" if esc.model else "boosted_attempts", 1, lstats)
        text = (f"HUMAN HINT: {hint}\n" if hint else "") + error + (f"\nDIAGNOSIS OF THE PREVIOUS ATTEMPTS:\n{diagnosis}" if esc.diagnose and diagnosis else "")
        outcome = rt.editor.run(
            task, iteration, manifest, failures=state.get("edit_failures", 0), edit_error=text,
            shrink_level=state.get("shrink_level", 0), scope_symbols=state.get("scope_symbols"), escalation=esc if esc.level else None,
        )
        mech = state.get("mech_total", 0) + (1 if outcome.counts_as_failure and outcome.failure_class in MECHANICAL else 0)
        findings = edit_findings(outcome)
        if findings:
            rt.ledger.ingest(task.id, iteration, findings, resolve=False)
        if outcome.result.edit_format.startswith("aider"):
            rt.guard.add_tokens(outcome.result.tokens_in + outcome.result.tokens_out)
        failures = failures_after(state.get("edit_failures", 0), outcome)
        suspend = outcome.suspend.value if outcome.suspend else ""
        gate = ""
        if not outcome.ok and not suspend:
            if failures >= ladder_limit(s.aider.fallback_after_failures):
                suspend = SuspendReason.EDIT_LADDER.value
            elif over_budget(s.limits, s.loop, iteration, mech):
                gate = ExitReason.MAX_ITER.value
        streak = state.get("no_change_streak", 0) + 1 if (outcome.failure_class == "no_change" and state.get("feedback")) else 0
        if streak >= 2 and not suspend and not gate:
            gate = ExitReason.NO_PROGRESS.value
            rt.logger({"type": "no_change_loop", "task_id": task.id, "why": "the model keeps returning edits that change nothing after a rejected review; the review feedback probably cannot be fixed by editing"})
        repeats = state.get("repeat_count", 0) + 1 if outcome.failure_class in ("guard", "syntax_after_edit") and outcome.feedback == state.get("last_problem") else 0
        feedback = outcome.feedback
        if repeats and not suspend and not gate:
            feedback += "\nTHE SAME PROBLEM CAME BACK. Do not repeat your last answer. Change that part first, and follow the problem text literally."
        if repeats >= 2 and not suspend and not gate:
            gate = ExitReason.NO_PROGRESS.value
            rt.logger({"type": "repeat_problem", "task_id": task.id, "why": "the same problem was rejected three times in a row"})
        edit_ok = outcome.ok
        if outcome.failure_class == "no_change" and not state.get("feedback") and iteration >= 2 and not gate:
            edit_ok, suspend, failures = True, "", 0
            rt.logger({"type": "no_change_review", "task_id": task.id, "why": "the editor made no change twice; checking whether the existing code already satisfies the task"})
        tasks = state.get("tasks", [])
        if widened:
            tasks = [dict(x, target_files=list(task.target_files)) if x["id"] == task.id else x for x in tasks]
        if inferred:
            tasks = [dict(x, target_files=inferred) if x["id"] == task.id else x for x in tasks]
        if outcome.moved:
            tasks = [dict(x, target_files=[outcome.moved.get(f, f) for f in x.get("target_files", [])]) for x in tasks]
        if outcome.result.files_changed and task.kind in ("scaffold", "feature", "test"):
            tasks = [dict(x, target_files=sorted({*x.get("target_files", []), *posix_list(outcome.result.files_changed)})) if x["id"] == task.id else x for x in tasks]
        light = outcome.result.model_dump(mode="json", exclude={"diff"})
        light["diff_head"] = outcome.result.diff[:2000]
        return {
            "tasks": tasks, "no_change_streak": streak, "iteration": iteration, "edit_failures": failures, "edit_error": feedback, "repeat_count": repeats, "last_problem": outcome.feedback, "edit_ok": edit_ok, "last_edit": light,
            "suspend_reason": suspend, "gate_reason": gate, "human_hint": "", "tokens_used": rt.guard.tokens_used,
            "iterations_total": state.get("iterations_total", 0) + 1, "edit_attempts": state.get("edit_attempts", 0) + 1,
            "edit_failed_attempts": state.get("edit_failed_attempts", 0) + (1 if outcome.counts_as_failure else 0),
            "task_stats": bump(state, task.id, "iterations"), "mech_total": mech, "loop_stats": lstats, **extra,
        }

    return edit


def make_review(rt: Runtime) -> Node:
    def review(state: PipelineState) -> dict[str, Any]:
        s = rt.settings
        rt.guard.check()
        task = Task.model_validate(current_task(state))
        iteration = state.get("iteration", 0)
        upcoming = [f"{t['id']} {t['title']} (files: {', '.join(t.get('target_files') or [])})" for t in state.get("tasks", []) if t["status"] == "pending" and t["id"] != task.id][:6]
        result, _ = rt.reviewer.review(task, iteration, state["task_base"], upcoming, known_failures=state.get("test_baseline"))
        prints = [*state.get("fingerprints", []), result.fingerprint]
        gate = ""
        if not result.approved:
            if over_budget(s.limits, s.loop, iteration, state.get("mech_total", 0)):
                gate = ExitReason.MAX_ITER.value
            elif stalled(prints, s.limits):
                gate = ExitReason.NO_PROGRESS.value
            elif rt.ledger.oscillating(task.id):
                gate = ExitReason.OSCILLATION.value
        feedback = result.feedback_text(s.limits.max_failures_fed_back)
        update: dict[str, Any] = {
            "last_review": result.model_dump(mode="json"), "fingerprints": prints, "approved": result.approved, "gate_reason": gate,
            "feedback": feedback, "tokens_used": rt.guard.tokens_used, "review_rejections": state.get("review_rejections", 0) + (0 if result.approved else 1),
        }
        if s.loop.best_snapshot:
            prog = track(rt, state, result, feedback)
            if not result.approved and not gate and prog.get("gate_reason"):
                gate = prog["gate_reason"]
            update.update({k: v for k, v in prog.items() if k != "gate_reason"})
            update["gate_reason"] = gate
            if prog.get("rolled_back"):
                update["loop_stats"] = stats.bump(state, "rollbacks")
            if prog.get("gate_reason") and gate == prog["gate_reason"]:
                update["loop_stats"] = stats.bump(state, "no_improvement_gates", 1, update.get("loop_stats"))
        return update

    return review


def make_regression(rt: Runtime) -> Node:
    def regression(state: PipelineState) -> dict[str, Any]:
        s = rt.settings
        if not s.features.regression_gate:
            return {"regression_ok": True}
        task = Task.model_validate(current_task(state))
        iteration = state.get("iteration", 0)
        changed = set(rt.git.changed_since(state["task_base"]))
        done = [Task.model_validate(t) for t in state.get("tasks", []) if t["status"] == "completed" and t.get("verify_command") and t.get("verify_passed")]
        seen = {task.verify_command}
        chosen: list[Task] = []
        for t in done:
            if t.verify_command in seen or not (set(t.target_files) & changed or t.id in task.depends_on):
                continue
            seen.add(t.verify_command)
            chosen.append(t)
        findings: list[Finding] = []
        for t in chosen:
            runner = get_runner(t.language, rt.ctx.repo, s.limits.subprocess_timeout_s)
            check = runner.finish_test(runner.run_kind("test", [], command=t.verify_command))
            if check.skipped:
                continue
            rt.logger({"type": "tool_call", "node": "regression", "tool": "run_test", "task_id": task.id, "iteration": iteration,
                       "args": {"command": check.command, "earlier_task": t.id}, "ok": check.ok, "duration_s": check.duration_s})
            if not check.ok:
                first = check.failures[0].short(200) if check.failures else "command failed"
                findings.append(Finding(kind="regression", message=f"earlier task {t.id} no longer passes: {first}", symbol=t.id,
                                        detail="\n".join(f.short(200) for f in check.failures[:5])))
        rt.ledger.ingest(task.id, iteration, findings)
        if not findings:
            return {"regression_ok": True}
        rt.logger({"type": "regression_failed", "task_id": task.id, "earlier": [f.symbol for f in findings]})
        gate = ExitReason.MAX_ITER.value if over_budget(s.limits, s.loop, iteration, state.get("mech_total", 0)) else ""
        return {"regression_ok": False, "approved": False, "gate_reason": gate, "edit_error": "\n".join(f.message for f in findings),
                "review_rejections": state.get("review_rejections", 0) + 1}

    return regression
