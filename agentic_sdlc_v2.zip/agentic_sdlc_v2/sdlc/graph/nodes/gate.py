from __future__ import annotations

import json
import time
from typing import Any, Callable

from langgraph.types import interrupt

from ...agents.planner import write_brief
from ...core.schemas import ExitReason, HumanDecision, IssueRecord, Manifest, ReviewResult, Task
from ...adapters.ollama_client import LLMError
from ...core.state import PipelineState, current_task
from ...core.task_stack import StackManager
from ..runtime import Runtime
from .tasks import bump

Node = Callable[[PipelineState], dict[str, Any]]


def build_issue_record(rt: Runtime, state: PipelineState, reason: ExitReason) -> IssueRecord:
    task = Task.model_validate(current_task(state))
    review = ReviewResult.model_validate(state["last_review"]) if state.get("last_review") else None
    history = [f"[{i.status.value}] {i.kind}: {i.message[:200]}" for i in rt.ledger.issues.values() if i.task_id == task.id][-20:]
    if state.get("edit_error"):
        history.append(f"last edit problem: {state['edit_error'][:300]}")
    return IssueRecord(
        run_id=rt.run_id, task=task, iteration=state.get("iteration", 0), reason=reason,
        diff=rt.git.diff_since(state["task_base"], max_chars=20000), review=review, history=history,
        created_at=time.strftime("%Y-%m-%dT%H:%M:%S"),
    )


FRESH_TASK = {"iteration": 0, "edit_failures": 0, "fingerprints": [], "repeat_count": 0, "no_change_streak": 0, "last_problem": "", "edit_error": "",
              "feedback": "", "shrink_level": 0, "scope_symbols": None, "gate_reason": "", "suspend_reason": "", "approved": False, "gate_sig": "", "gate_repeats": 0,
              "best_score": None, "best_snapshot": "", "best_feedback": "", "no_improve": 0, "fail_sigs": [], "review_rejections": 0, "mech_total": 0, "diagnosis": "", "diagnosed_at": -1, "test_baseline": [], "baseline_ready": False, "rolled_back": False}


def replan(rt: Runtime, state: PipelineState, record: IssueRecord, keep_done: bool, note: str) -> dict[str, Any]:
    target = state["last_good_commit"] if keep_done else state["base_commit"]
    rt.git.reset_to(target)
    previous = [dict(t) for t in state.get("tasks", [])]
    problem = "\n".join([f"gate reason: {record.reason.value}", *(record.history[-6:])])
    if record.review is not None:
        problem += "\nreview: " + record.review.feedback_text(4)[:600]
    exp = record.explanation or {}
    if exp:
        problem += f"\nplain explanation: {exp.get('what_happened', '')} {exp.get('why', '')}"
    for t in previous:
        if t.get("status") not in ("completed", "skipped"):
            rt.ledger.waive(t["id"])
    try:
        manifest = rt.analyser.run(Manifest.model_validate(state["manifest"]))
        result = rt.planner.replan(manifest, state.get("requirements", ""), state.get("user_input", ""), previous, record.task.id, problem, note, keep_done)
    except (LLMError, ValueError) as exc:
        rt.logger({"type": "replan_failed", "error": str(exc)[:300], "why": "the planner could not produce a new plan; the stuck task is restarted instead"})
        tasks = [dict(t, status="pending") if t["id"] == record.task.id else t for t in previous]
        return {**FRESH_TASK, "tasks": tasks, "suspended": [], "current_task_id": "", "last_good_commit": target, "task_base": target}
    write_brief(rt.run_dir, state.get("requirements", ""), result)
    kept = [t for t in previous if keep_done and t.get("status") == "completed"]
    gone = [t["id"] for t in previous if t not in kept]
    for tid in gone:
        rt.logger({"type": "task_end", "task_id": tid, "status": "replaced", "why": "replaced by a new plan" + ("" if keep_done else " after rolling back the whole run")})
    tasks = kept + [t.model_dump(mode="json") for t in result.plan.tasks]
    StackManager(tasks, [], rt.settings.limits).save(rt.run_dir / "stack.json")
    rt.logger({"type": "plan_ready", "tasks": len(tasks), "warnings": result.warnings, "proposals": [], "replanned": True})
    return {**FRESH_TASK, "tasks": tasks, "suspended": [], "current_task_id": "", "status": "running", "last_good_commit": target, "task_base": target,
            "manifest": manifest.model_dump(mode="json"), "analogues": result.analogues, "integration_round": 0, "replans": state.get("replans", 0) + 1}


def make_gate(rt: Runtime) -> Node:
    def gate(state: PipelineState) -> dict[str, Any]:
        reason = ExitReason(state.get("gate_reason") or ExitReason.MAX_ITER.value)
        record = build_issue_record(rt, state, reason)
        if record.task.optional:
            rt.git.reset_to(state["last_good_commit"])
            sm = StackManager.from_state(dict(state), rt.settings.limits)
            rt.ledger.waive(record.task.id)
            sm.skip(record.task.id)
            sm.save(rt.run_dir / "stack.json")
            rt.logger({"type": "optional_task_skipped", "task_id": record.task.id, "reason": reason.value,
                       "why": "this safety-net test was added by the workflow, not by the request; it could not be made to pass, so it is dropped instead of blocking the run"})
            rt.logger({"type": "task_end", "task_id": record.task.id, "status": "skipped", "iterations": record.iteration})
            return {**sm.to_state(), "decision": {"action": "proceed", "hint": ""}, "current_task_id": "", "gate_reason": "", "suspend_reason": "", "iteration": 0, "edit_failures": 0,
                    "repeat_count": 0, "no_change_streak": 0, "last_problem": "", "edit_error": ""}
        sig = f"{record.task.id}|{(state.get('last_problem') or state.get('edit_error') or '')[:160]}"
        repeats = state.get("gate_repeats", 0) + 1 if sig == state.get("gate_sig") else 0
        facts = "\n".join([f"Gate reason: {reason.value}", f"Task {record.task.id}: {record.task.title}", f"Files this task may change: {', '.join(record.task.target_files) or 'new files only'}", f"Iteration {record.iteration}", f"Times this same problem reached the human: {repeats + 1}", *record.history[-8:]])
        if record.review is not None:
            facts += "\nReview feedback: " + record.review.feedback_text(5)[:600]
            ran = [f"{c.name}: {'passed' if c.ok else 'FAILED'}" for c in record.review.checks if not c.skipped]
            facts += "\nAutomated checks that ran: " + (", ".join(ran) if ran else "none")
        if reason.value == "no_progress" and state.get("no_change_streak", 0) >= 2:
            facts += "\nThe editor made no further change after the last rejection (it considers the code already correct)."
        facts += "\nThe editor can only change the content of the files listed above; it cannot move, rename or delete files."
        if (state.get("edit_error") or state.get("last_problem") or "").startswith("The edit was reverted"):
            facts += ("\nThe rejected edit was undone automatically: the project code is unchanged and still builds. Existing code named in the problem "
                      "(for example a member that was 'removed') is correct and must be KEPT; never suggest deleting or rewriting it.")
        if repeats >= 1:
            facts += f"\n'work' was already chosen {repeats} time(s) for this same problem and nothing changed. Recommend accept, proceed or abort, unless a clearly different concrete instruction would help."
        facts += "\nWhole plan: " + "; ".join(f"{t['id']} [{t.get('status', 'pending')}] {t['title']}" for t in state.get("tasks", []))[:800]
        facts += "\nCurrent change for this task:\n" + record.diff[:1500]
        explanation = rt.explainer.explain(facts, record.task.id)
        record.explanation = explanation.model_dump()
        issue_path = rt.run_dir / "issue.json"
        issue_path.write_text(record.model_dump_json(indent=2), encoding="utf-8")
        raw = interrupt({
            "type": "human_gate", "run_id": rt.run_id, "task_id": record.task.id, "title": record.task.title,
            "reason": reason.value, "iteration": record.iteration, "issue_path": str(issue_path), "explanation": record.explanation, "repeats": repeats,
        })
        decision = HumanDecision.model_validate(raw)
        if decision.action == "work" and not decision.hint.strip() and repeats >= 1 and explanation.suggested_hint:
            decision = HumanDecision(action="work", hint=explanation.suggested_hint)
            rt.logger({"type": "auto_hint", "task_id": record.task.id, "hint": decision.hint[:300]})
        with (rt.run_dir / "human_gate.jsonl").open("a", encoding="utf-8") as fh:
            fh.write(json.dumps({"ts": time.time(), "decision": decision.model_dump(), "record": json.loads(record.model_dump_json())}) + "\n")
        rt.logger({"type": "human_gate", "task_id": record.task.id, "reason": reason.value, "action": decision.action, "hint": decision.hint[:300]})
        base = {"gate_sig": sig, "gate_repeats": repeats, "decision": decision.model_dump(), "escalations": state.get("escalations", 0) + 1, "task_stats": bump(state, record.task.id, "escalations")}
        if decision.action == "accept":
            rt.logger({"type": "human_accept", "task_id": record.task.id, "why": "the human accepted the current change as done"})
            return {**base, "approved": True, "regression_ok": True, "gate_reason": "", "suspend_reason": "", "accepted_by_human": True}
        if decision.action == "work":
            return {**base, "iteration": 0, "edit_failures": 0, "fingerprints": [], "repeat_count": 0, "no_change_streak": 0, "human_hint": decision.hint, "gate_reason": "",
                    "suspend_reason": "", "approved": False, "no_improve": 0, "mech_total": 0, "review_rejections": 0, "diagnosed_at": -1}
        if decision.action in ("replan", "replan_all"):
            return {**base, **replan(rt, state, record, decision.action == "replan", decision.hint)}
        rt.git.reset_to(state["last_good_commit"])
        if decision.action == "restart":
            rt.ledger.waive(record.task.id)
            rt.logger({"type": "task_restart", "task_id": record.task.id, "to_commit": state["last_good_commit"], "why": "the human discarded this task's changes and restarted it from a clean state"})
            return {**base, **FRESH_TASK, "human_hint": decision.hint, "task_base": state["last_good_commit"]}
        if decision.action == "abort":
            return {**base, "status": "aborted", "exit_reason": ExitReason.ABORTED.value, "gate_reason": ""}
        sm = StackManager.from_state(dict(state), rt.settings.limits)
        rt.ledger.waive(record.task.id)
        sm.skip(record.task.id)
        sm.save(rt.run_dir / "stack.json")
        rt.logger({"type": "task_end", "task_id": record.task.id, "status": "skipped", "iterations": record.iteration, "stats": base["task_stats"].get(record.task.id, {})})
        return {**base, **sm.to_state(), "current_task_id": "", "gate_reason": ""}

    return gate
