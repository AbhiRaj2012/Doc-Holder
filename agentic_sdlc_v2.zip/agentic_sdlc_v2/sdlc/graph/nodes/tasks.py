from __future__ import annotations

from typing import Any, Callable

from ...core.schemas import ExitReason, Manifest, SuspendReason
from ...agents.splitter import deterministic_split
from ...core.state import PipelineState
from ...core.task_stack import StackManager
from ..runtime import Runtime

Node = Callable[[PipelineState], dict[str, Any]]


def bump(state: PipelineState, task_id: str, key: str, n: int = 1) -> dict[str, dict[str, int]]:
    stats = {k: dict(v) for k, v in state.get("task_stats", {}).items()}
    row = stats.setdefault(task_id, {})
    row[key] = row.get(key, 0) + n
    return stats


def _manager(rt: Runtime, state: PipelineState) -> StackManager:
    return StackManager.from_state(dict(state), rt.settings.limits)


def _save(rt: Runtime, sm: StackManager) -> None:
    sm.save(rt.run_dir / "stack.json")


def make_pick(rt: Runtime) -> Node:
    def pick(state: PipelineState) -> dict[str, Any]:
        sm = _manager(rt, state)
        sm.recover_crash()
        source, task, frame = sm.pick_next()
        _save(rt, sm)
        if task is None:
            return {**sm.to_state(), "status": "all_done", "current_task_id": ""}
        action = StackManager.action_for(frame) if frame else "start"
        rt.logger({"type": "task_start", "task_id": task["id"], "title": task["title"], "source": source, "action": action,
                   "shrink_level": task.get("shrink_level", 0), "language": task["language"], "kind": task["kind"]})
        return {
            **sm.to_state(), "current_task_id": task["id"], "iteration": 0, "no_change_streak": 0, "edit_failures": 0, "fingerprints": [], "feedback": "",
            "edit_error": "", "human_hint": "", "exit_reason": "", "approved": False, "edit_ok": False, "regression_ok": False,
            "suspend_reason": "", "gate_reason": "", "task_base": rt.git.head(), "resume_action": action,
            "shrink_level": task.get("shrink_level", 0),
            "best_score": None, "best_snapshot": "", "best_feedback": "", "no_improve": 0, "fail_sigs": [], "review_rejections": 0, "mech_total": 0,
            "diagnosis": "", "diagnosed_at": -1, "test_baseline": [], "baseline_ready": False, "rolled_back": False,
            "scope_symbols": (frame or {}).get("scope_symbols") or task.get("symbol_targets", []), "decision": {},
        }

    return pick


def make_split(rt: Runtime) -> Node:
    def split(state: PipelineState) -> dict[str, Any]:
        sm = _manager(rt, state)
        task = sm.get(state["current_task_id"])
        manifest = Manifest.model_validate(state["manifest"]) if state.get("manifest") else None
        depth = state["current_task_id"].count(".")
        if task and depth >= rt.settings.limits.max_split_depth:
            rt.git.reset_to(state["task_base"])
            rt.logger({"type": "split_refused", "task_id": task["id"], "why": f"already split {depth} levels; a smaller task will not fix a model-output problem"})
            return {"gate_reason": ExitReason.CANNOT_SPLIT.value}
        children = rt.splitter.split(task, manifest, "the task exceeded the model's context budget") if task else []
        if task and any(c["title"].strip().lower() == task["title"].strip().lower() for c in children):
            children = deterministic_split(task)
        rt.git.reset_to(state["task_base"])
        if not children or not task:
            rt.logger({"type": "split_refused", "task_id": (task or {}).get("id", ""), "why": "no useful split found"})
            return {"gate_reason": ExitReason.CANNOT_SPLIT.value}
        ids = sm.split(task["id"], children)
        _save(rt, sm)
        rt.logger({"type": "task_split", "task_id": task["id"], "children": ids})
        return {**sm.to_state(), "current_task_id": "", "gate_reason": "", "task_stats": bump(state, task["id"], "splits")}

    return split


def make_suspend(rt: Runtime) -> Node:
    def suspend(state: PipelineState) -> dict[str, Any]:
        sm = _manager(rt, state)
        task = sm.get(state["current_task_id"])
        reason = SuspendReason(state.get("suspend_reason") or SuspendReason.EDIT_LADDER.value)
        if reason == SuspendReason.EDIT_LADDER and task and task.get("shrink_level", 0) >= rt.settings.limits.max_ladder_suspends:
            rt.logger({"type": "suspend_refused", "task_id": state["current_task_id"], "reason": reason.value,
                       "why": "the edit failures repeated after shrinking; shrinking or splitting does not fix an editor that cannot produce a valid edit"})
            return {"gate_reason": ExitReason.SUSPEND_LIMIT.value, "suspend_reason": ""}
        frame = sm.suspend(
            state["current_task_id"], reason, step="edit", iteration=state.get("iteration", 0), base_tree=rt.git.snapshot(),
            open_issue_ids=[i.id for i in rt.ledger.open_issues(state["current_task_id"])],
            scope_files=(task or {}).get("target_files", []), scope_symbols=state.get("scope_symbols", []),
            note=(state.get("edit_error") or "")[:300],
        )
        if frame is None:
            rt.logger({"type": "suspend_refused", "task_id": state["current_task_id"], "reason": reason.value})
            return {"gate_reason": ExitReason.SUSPEND_LIMIT.value, "suspend_reason": ""}
        _save(rt, sm)
        rt.logger({"type": "task_suspended", "task_id": frame.task_id, "reason": reason.value, "shrink_level": frame.shrink_level, "frames": len(sm.frames)})
        return {**sm.to_state(), "suspend_reason": "", "gate_reason": "", "task_stats": bump(state, frame.task_id, "suspensions")}

    return suspend


def make_commit(rt: Runtime) -> Node:
    def commit(state: PipelineState) -> dict[str, Any]:
        sm = _manager(rt, state)
        task = sm.get(state["current_task_id"]) or {}
        changed = rt.git.changed_since(state["task_base"])
        sha = rt.git.commit_all(f"sdlc({task.get('id', '?')}): {task.get('title', '')}"[:200]) or rt.git.head()
        sm.complete(state["current_task_id"])
        checks = (state.get("last_review") or {}).get("checks", [])
        passed = any(c.get("name") == "test" and c.get("ok") and not c.get("skipped") for c in checks)
        for t in sm.tasks:
            if t["id"] == state["current_task_id"]:
                t["verify_passed"] = passed
        _save(rt, sm)
        manifest = rt.analyser.refresh(Manifest.model_validate(state["manifest"]), changed)
        rt.store.save_manifest(rt.project, manifest)
        stats = state.get("task_stats", {}).get(state["current_task_id"], {})
        rt.logger({"type": "task_end", "task_id": state["current_task_id"], "status": "completed", "files": changed, "commit": sha,
                   "iterations": state.get("iteration", 0), "stats": stats, **({"accepted_by": "human"} if state.get("accepted_by_human") else {})})
        return {**sm.to_state(), "last_good_commit": sha, "manifest": manifest.model_dump(mode="json"), "current_task_id": "", "accepted_by_human": False}

    return commit
