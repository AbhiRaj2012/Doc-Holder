from __future__ import annotations

from typing import Any, Callable

from langgraph.types import interrupt

from ...adapters.ollama_client import LLMError
from ...agents.planner import PlanResult, write_brief
from ...core.plan_review import feedback_block, plan_view, remove_tasks
from ...core.schemas import ExitReason, Manifest, PlanDecision
from ...core.state import PipelineState
from ..runtime import Runtime

Node = Callable[[PipelineState], dict[str, Any]]


def plan_fields(rt: Runtime, result: PlanResult, rnd: int = 0) -> dict[str, Any]:
    return {
        "tasks": [t.model_dump(mode="json") for t in result.plan.tasks],
        "allow_proposals": [{"executable": p} for p in result.proposals],
        "policy_events": result.policy_events, "analogues": result.analogues,
        "plan_review": rt.settings.features.plan_approval and bool(result.plan.tasks),
        "plan_round": rnd, "plan_summary": result.plan.summary, "plan_warnings": result.warnings,
    }


def make_approve_plan(rt: Runtime) -> Node:
    def approve_plan(state: PipelineState) -> dict[str, Any]:
        tasks = [dict(t) for t in state.get("tasks", [])]
        rnd = state.get("plan_round", 0)
        raw = interrupt({
            "type": "approve_plan", "mode": "edit", "run_id": rt.run_id, "round": rnd,
            "summary": state.get("plan_summary", ""), "warnings": state.get("plan_warnings", []),
            "tasks": [plan_view(t) for t in tasks], "requirements": state.get("requirements", ""),
        })
        d = PlanDecision.model_validate(raw)
        rt.logger({"type": "plan_decision", "action": d.action, "hint": d.hint[:500], "remove": d.remove, "round": rnd})
        if d.action == "abort":
            return {"status": "aborted", "exit_reason": ExitReason.ABORTED.value, "plan_review": False}
        if d.action == "revise":
            try:
                manifest = Manifest.model_validate(state["manifest"])
                result = rt.planner.plan(manifest, state.get("requirements", ""), state.get("user_input", "") + feedback_block(d.hint, tasks))
            except (LLMError, ValueError) as exc:
                rt.logger({"type": "plan_revise_failed", "error": str(exc)[:300], "why": "the planner could not apply the feedback; the previous plan is shown again"})
                return {"plan_review": True, "plan_round": rnd + 1, "plan_warnings": [*state.get("plan_warnings", []), f"revision failed: {str(exc)[:200]}"]}
            write_brief(rt.run_dir, state.get("requirements", ""), result)
            for event in result.policy_events:
                rt.logger(event)
            rt.logger({"type": "plan_ready", "tasks": len(result.plan.tasks), "warnings": result.warnings, "proposals": result.proposals, "revised_by_human": True})
            return plan_fields(rt, result, rnd + 1) | {"plan_review": True}
        kept, gone = remove_tasks(tasks, d.remove)
        rt.logger({"type": "plan_approved", "tasks": len(kept), "removed": gone, "round": rnd})
        return {"tasks": kept, "plan_review": False}

    return approve_plan
