from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ..core.schemas import HumanDecision, PlanDecision


def read_issue(run_dir: Path) -> dict[str, Any]:
    p = run_dir / "issue.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}


def decision(action: str, hint: str = "") -> dict[str, Any]:
    return HumanDecision(action=action, hint=hint).model_dump()  # type: ignore[arg-type]


def plan_decision(action: str, hint: str = "", remove: list[str] | None = None) -> dict[str, Any]:
    return PlanDecision(action=action, hint=hint, remove=remove or []).model_dump()  # type: ignore[arg-type]


def approval(approved: list[str]) -> dict[str, Any]:
    return {"approved": approved}
