from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Any

from ..adapters.editor_backend import HybridEditor
from ..adapters.git_ops import GitRepo
from ..adapters.ollama_client import OllamaClient
from ..agents.analyser import Analyser
from ..agents.context import AgentContext
from ..agents.critic import PlanCritic
from ..agents.editor import EditorAgent
from ..agents.planner import Planner
from ..agents.reviewer import ReviewerAgent
from ..agents.explainer import Explainer
from ..agents.splitter import Splitter
from ..core.budget import RunGuard
from ..core.command_policy import load_approved
from ..core.config import Settings
from ..core.ledger import IssueLedger
from ..core.project_store import Project, ProjectStore
from ..telemetry.jsonl_logger import EventLogger, log_llm


@dataclass
class Runtime:
    settings: Settings
    project: Project
    store: ProjectStore
    run_id: str
    git: GitRepo
    ledger: IssueLedger
    logger: EventLogger
    guard: RunGuard
    ctx: AgentContext
    analyser: Analyser
    planner: Planner
    critic: PlanCritic
    splitter: Splitter
    explainer: Explainer
    editor: EditorAgent
    reviewer: ReviewerAgent
    approved: set[str] = field(default_factory=set)

    @property
    def run_dir(self):
        return self.ctx.run_dir


def build_runtime(
    settings: Settings, project: Project, store: ProjectStore, run_id: str,
    client: Any = None, editor_backend: Any = None, use_aider: bool = True,
) -> Runtime:
    run_dir = project.run_dir(run_id)
    try:
        if json.loads((run_dir / "baseline.json").read_text(encoding="utf-8")).get("jobs") == 1:
            os.environ["SDLC_BUILD_JOBS"] = "1"
    except (OSError, ValueError):
        pass
    logger = EventLogger(run_dir / "events.jsonl", run_id, project.id)
    guard = RunGuard(settings.limits.max_wall_seconds, settings.limits.max_total_tokens)
    git = GitRepo(project.code, settings.git.author_name, settings.git.author_email)
    if client is None:
        client = OllamaClient(settings, guard, on_call=lambda e: log_llm(logger, e),
                              on_start=lambda e: logger({"type": "llm_start", **e}))
    ledger = IssueLedger(run_dir)
    ctx = AgentContext(settings, client, project.code, run_dir, git, ledger, project.id, project.meta.get("name", project.id), logger)
    backend = editor_backend or HybridEditor(settings, client, git, use_aider=use_aider)
    return Runtime(
        settings=settings, project=project, store=store, run_id=run_id, git=git, ledger=ledger, logger=logger, guard=guard, ctx=ctx,
        analyser=Analyser(settings, project.code, project.id, ctx.project_name), planner=Planner(ctx, project.approved_commands_path),
        critic=PlanCritic(ctx), splitter=Splitter(ctx), explainer=Explainer(ctx), editor=EditorAgent(ctx, backend), reviewer=ReviewerAgent(ctx),
        approved=load_approved(project.approved_commands_path),
    )
