from __future__ import annotations

from typing import Any

from ..core.config import LimitsCfg

State = dict[str, Any]


def _stop(state: State) -> bool:
    return state.get("status") in ("budget_exceeded", "failed")


def after_plan(state: State) -> str:
    if _stop(state):
        return "finish"
    if state.get("plan_review"):
        return "approve_plan"
    return "approve_commands" if state.get("allow_proposals") else "pick"


def after_approve_plan(state: State) -> str:
    if state.get("status") == "aborted":
        return "finish"
    if state.get("plan_review"):
        return "approve_plan"
    return "approve_commands" if state.get("allow_proposals") else "pick"


def after_pick(state: State) -> str:
    if state.get("status") == "all_done":
        return "integrate"
    return "split" if state.get("resume_action") == "split" else "edit"


def after_integrate(state: State) -> str:
    return "pick" if state.get("integration_added") else "finish"


def after_split(state: State) -> str:
    return "gate" if state.get("gate_reason") else "pick"


def after_edit(state: State) -> str:
    if _stop(state):
        return "finish"
    if state.get("suspend_reason"):
        return "suspend"
    if state.get("gate_reason"):
        return "gate"
    return "review" if state.get("edit_ok") else "edit"


def after_review(state: State) -> str:
    if _stop(state):
        return "finish"
    if state.get("approved"):
        return "regression"
    return "gate" if state.get("gate_reason") else "edit"


def after_regression(state: State) -> str:
    if _stop(state):
        return "finish"
    if state.get("regression_ok"):
        return "commit"
    return "gate" if state.get("gate_reason") else "edit"


def after_suspend(state: State) -> str:
    return "gate" if state.get("gate_reason") else "pick"


def after_gate(state: State) -> str:
    action = (state.get("decision") or {}).get("action", "")
    return {"work": "edit", "restart": "edit", "replan": "pick", "replan_all": "pick", "proceed": "pick", "abort": "finish", "accept": "commit"}.get(action, "finish")


def ladder_limit(fallback_after_failures: int) -> int:
    return fallback_after_failures + 2


def stalled(fingerprints: list[str], limits: LimitsCfg) -> bool:
    n = limits.no_progress_repeats
    return len(fingerprints) >= n and len(set(fingerprints[-n:])) == 1
