import sys

try:
    from .cli.main import main
except ImportError as exc:
    text = str(exc)
    if "Application Control" in text or "DLL load failed" in text:
        print(f"A native Python extension was blocked by this machine ({text}).\nSee 'Windows blocks native DLLs' in CLAUDE.md: run inside WSL2, turn off Smart App Control, or ask IT to allow the file.")
        sys.exit(4)
    raise

if __name__ == "__main__":
    sys.exit(main())
