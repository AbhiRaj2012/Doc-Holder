from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable

from ..graph.builder import open_checkpointer
from ..graph.human_gate import plan_decision
from .plan_prompts import ask_plan_decision, describe_plan

Out = Callable[[str], None]
MODE_FILE = "mode.txt"


def mark_create(run_dir: Path) -> None:
    (run_dir / MODE_FILE).write_text("create", encoding="utf-8")


def is_create_run(run_dir: Path) -> bool:
    p = run_dir / MODE_FILE
    return p.exists() and p.read_text(encoding="utf-8").strip() == "create"


def checkpointer_for(run_dir: Path) -> Any:
    return open_checkpointer(run_dir / "checkpoint.sqlite")


def drive(rt: Any, cp: Any, run_id: str, project_id: str, result: dict[str, Any], interactive: bool, ask: Callable[[str], str], out: Out) -> dict[str, Any]:
    from ..create.graph import resume_create

    while result.get("paused"):
        describe_plan(result["interrupt"], out)
        if not interactive:
            out(f"\nPaused. Resume with: python -m sdlc resume {run_id} --project {project_id} --action approve|revise|abort [--hint TEXT] [--remove path1,path2]")
            return result
        result = resume_create(rt, cp, ask_plan_decision(ask))
    return result


def resume_with(rt: Any, cp: Any, action: str, hint: str, remove: list[str]) -> dict[str, Any]:
    from ..create.graph import resume_create

    return resume_create(rt, cp, plan_decision(action or "approve", hint, remove))


def report(project: Any, run_id: str, summary: dict[str, Any], out: Out) -> None:
    out(f"\nRun {run_id}: {summary.get('final_status')}  ({summary.get('tasks_completed')}/{summary.get('num_tasks')} files approved, project check {'passed' if summary.get('verify_ok') else 'failed'})")
    exp = project.run_dir(run_id) / "run_explanation.json"
    if exp.exists():
        e = json.loads(exp.read_text(encoding="utf-8"))
        out(f"What happened: {e.get('what_happened')}\nLikely cause: {e.get('why')}")
    out(f"Project files: {project.code}")
