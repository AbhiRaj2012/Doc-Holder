from __future__ import annotations

from typing import Any, Callable

from ..graph.human_gate import plan_decision

Out = Callable[[str], None]


def describe_plan(info: dict[str, Any], out: Out) -> None:
    kind = "Blueprint" if info.get("mode") == "create" else "Plan"
    out(f"\n{kind} awaiting approval (round {info.get('round', 0)}):  {info.get('summary', '')}")
    if info.get("mode") == "create":
        out(f"  language: {info.get('language')}  entry: {info.get('entry')}  run: {info.get('run_command') or '-'}  test: {info.get('test_command') or '-'}")
    for t in info.get("tasks", []):
        out(f"  {t.get('id')}  {t.get('title')}")
        if t.get("description") and info.get("mode") == "create":
            out(f"      purpose: {t['description']}")
        if t.get("target_files") and info.get("mode") != "create":
            out(f"      files: {', '.join(t['target_files'])}")
        for c in t.get("acceptance_criteria") or []:
            out(f"      - {c}")
        if t.get("verify_command") and info.get("mode") != "create":
            out(f"      verify: {t['verify_command']}")
    for w in info.get("warnings", []):
        out(f"  note: {w}")


def ask_plan_decision(ask: Callable[[str], str]) -> dict[str, Any]:
    while True:
        raw = ask("Plan: [a]pprove / [r]evise with feedback / re[m]ove items then approve / a[b]ort: ").strip().lower()
        if raw[:1] in ("a", "r", "m", "b"):
            break
    if raw[0] == "a":
        return plan_decision("approve")
    if raw[0] == "b":
        return plan_decision("abort")
    if raw[0] == "m":
        return plan_decision("approve", remove=[x.strip() for x in ask("Task ids or file paths to remove (comma separated): ").split(",") if x.strip()])
    return plan_decision("revise", ask("Feedback for the planner: ").strip())
