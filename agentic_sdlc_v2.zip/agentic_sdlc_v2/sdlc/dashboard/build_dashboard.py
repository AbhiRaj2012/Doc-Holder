from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from ..core.config import MetricsConfig, Settings, load_metrics
from ..evals.benchmark_writer import benchmark_path, read_benchmark

TEMPLATE = Path(__file__).with_name("template.html")
MARKER = "/*__DATA__*/"
LABELS = {
    "plan_quality": "Plan Quality", "plan_adherence": "Plan Adherence", "tool_correctness": "Tool Correctness",
    "argument_correctness": "Argument Correctness", "step_efficiency": "Step Efficiency", "task_completion": "Task Completion",
}


def build_data(records: list[dict[str, Any]], mcfg: MetricsConfig) -> dict[str, Any]:
    runs: dict[str, dict[str, Any]] = {}
    for r in records:
        if r.get("type") == "run_summary":
            runs[r["run_id"]] = {**r, "tasks": [], "violations": []}
    for r in records:
        run = runs.get(r.get("run_id", ""))
        if run is None:
            continue
        if r.get("type") == "task":
            run["tasks"].append({k: r.get(k) for k in ("task_id", "title", "status", "language", "kind", "files", "verify_source", "parent_id", "iterations", "suspensions", "escalations", "splits")})
        elif r.get("type") == "policy_violation":
            run["violations"].append({k: r.get(k) for k in ("task_id", "command", "kind", "reason")})
    order = [n for n in LABELS if n in mcfg.metrics]
    specs = {n: {"label": LABELS[n], "bad_max": mcfg.metrics[n].bad_max, "good_min": mcfg.metrics[n].good_min, "threshold": mcfg.metrics[n].threshold} for n in order}
    return {"order": order, "specs": specs, "runs": sorted(runs.values(), key=lambda x: (x.get("ts", ""), x["run_id"]))}


def render_html(data: dict[str, Any]) -> str:
    blob = json.dumps(data, ensure_ascii=False, default=str).replace("</", "<\\/").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    return TEMPLATE.read_text(encoding="utf-8").replace(MARKER, blob, 1)


def build_dashboard(benchmark_file: Path, out_file: Path, mcfg: MetricsConfig | None = None) -> Path:
    data = build_data(read_benchmark(benchmark_file), mcfg or load_metrics())
    out_file.parent.mkdir(parents=True, exist_ok=True)
    tmp = out_file.with_suffix(".html.tmp")
    tmp.write_text(render_html(data), encoding="utf-8")
    os.replace(tmp, out_file)
    return out_file


def rebuild(settings: Settings) -> Path:
    root = settings.benchmark_root()
    return build_dashboard(benchmark_path(root), root / "dashboard.html")
