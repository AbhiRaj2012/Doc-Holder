from __future__ import annotations

from pathlib import Path
from typing import Any, Callable

from langgraph.types import interrupt

from ..core.plan_review import plan_view, remove_tasks
from ..core.schemas import PlanDecision
from .schemas import Blueprint, Requirements


def feedback_for(state: dict[str, Any], hint: str) -> str:
    rows = "\n".join(f"- {t['target_files'][0]}: {t['description']}" for t in state.get("tasks", []))
    return f"{hint.strip()}\n\nPREVIOUS BLUEPRINT FILES:\n{rows}"


def make_approve_plan(rt: Any, save_stack: Callable[[Any, list], None]) -> Callable[[dict], dict[str, Any]]:
    def approve_plan(state: dict[str, Any]) -> dict[str, Any]:
        bp = Blueprint.model_validate(state["blueprint"])
        tasks = [dict(t) for t in state.get("tasks", [])]
        rnd = state.get("plan_round", 0)
        req = Requirements.model_validate(state["requirements"])
        raw = interrupt({
            "type": "approve_plan", "mode": "create", "run_id": rt.run_id, "round": rnd, "summary": bp.summary, "language": bp.language, "entry": bp.entry,
            "run_command": bp.run_command, "test_command": bp.test_command, "warnings": bp.assumptions, "requirements": req.as_text(),
            "tasks": [plan_view(t) for t in tasks],
        })
        d = PlanDecision.model_validate(raw)
        rt.logger({"type": "plan_decision", "action": d.action, "hint": d.hint[:500], "remove": d.remove, "round": rnd})
        if d.action == "abort":
            return {"status": "aborted", "queue": [], "plan_review": False}
        if d.action == "revise":
            return {"plan_feedback": feedback_for(state, d.hint or "improve the blueprint"), "plan_round": rnd + 1, "plan_review": True}
        by_path = {t["target_files"][0]: t["id"] for t in tasks}
        ids = [by_path.get(x.strip(), x.strip()) for x in d.remove]
        protected = {t["id"] for t in tasks if t["status"] == "completed" or t["target_files"][0] == bp.entry}
        kept, gone = remove_tasks(tasks, ids, protected)
        kept_paths = {Path(t["target_files"][0]).as_posix() for t in kept}
        bp.files = [f for f in bp.files if Path(f.path).as_posix() in kept_paths]
        (rt.run_dir / "blueprint.json").write_text(bp.model_dump_json(indent=2), encoding="utf-8")
        save_stack(rt, kept)
        rt.logger({"type": "plan_approved", "tasks": len(kept), "removed": gone, "round": rnd})
        return {"blueprint": bp.model_dump(), "tasks": kept, "queue": [t["id"] for t in kept if t["status"] == "pending"], "plan_review": False}

    return approve_plan
