from __future__ import annotations

import re
from pathlib import Path, PurePosixPath
from typing import Any

from ..agents import context_select, prompts
from ..core import symbols as sym
from ..core.budget import Section, estimate_tokens, fit_sections
from ..core.command_policy import CommandPolicy
from ..core.config import Settings
from . import templates
from .schemas import Blueprint, Requirements, Verdict

LANGUAGE_RULES = {
    "python": "Python 3 standard library only unless the user asked for a package. Entry main.py with an if __name__ == '__main__' guard. Modules import each other with plain imports. Add tests/test_*.py and test_command 'python -m pytest -q' only when the user asked for tests.",
    "c": "C11. Sources and headers under src/; the template Makefile compiles every .c under src/. Each .c that is used elsewhere has a .h declaring what it provides. test_command: make.",
    "cpp": "C++17. Sources and headers under src/; the template CMakeLists.txt compiles every .cpp under src/. Each class used by another file has a header. test_command: empty unless tests were requested.",
    "java": "Java 17, no build tool: sources under src/, entry src/Main.java with a main method, one public class per file. test_command: empty.",
    "js": "Node.js with CommonJS require and module.exports, standard library only. Include package.json with a start script. Entry index.js.",
    "web": "Plain HTML, CSS and JavaScript, no frameworks, no build step. Use exactly index.html, style.css and script.js unless more files are clearly needed. index.html links style.css and loads script.js at the end of body. Every element id used by script.js is listed in provides of index.html.",
}
FENCE = re.compile(r"```[^\n]*\n(.*?)```", re.S)


def clean_path(p: str) -> str:
    p = p.strip().strip("`'\"").replace("\\", "/")
    parts = [x for x in PurePosixPath(p).parts if x not in ("", ".")]
    if not parts or ".." in parts or p.startswith("/") or re.match(r"^[A-Za-z]:", p):
        return ""
    return "/".join(parts)


def normalise(bp: Blueprint, max_files: int) -> tuple[Blueprint, list[str]]:
    notes: list[str] = []
    seen: dict[str, Any] = {}
    for f in bp.files:
        path = clean_path(f.path)
        if not path:
            notes.append(f"dropped invalid path {f.path!r}")
            continue
        if path in seen:
            continue
        f.path = path
        seen[path] = f
    files = list(seen.values())[:max_files]
    names = {f.path for f in files}
    for f in files:
        f.depends_on = [d for d in (clean_path(x) for x in f.depends_on) if d in names and d != f.path]
        if not f.acceptance:
            f.acceptance = [f.purpose]
    ordered: list[Any] = []
    pending = list(files)
    while pending:
        ready = [f for f in pending if all(d in {o.path for o in ordered} for d in f.depends_on)] or [pending[0]]
        for f in ready:
            ordered.append(f)
            pending.remove(f)
    bp.files = ordered
    entry = clean_path(bp.entry)
    if entry not in names:
        entry = ordered[-1].path if ordered else entry
        notes.append(f"entry set to {entry}")
    bp.entry = entry
    return bp, notes


def check_command(repo: Path, language: str, command: str) -> str:
    if not command.strip():
        return ""
    res = CommandPolicy(repo, language).check(command)
    return res.command if res.ok else ""


def requirements(client: Any, settings: Settings, request: str) -> Requirements:
    msgs = [{"role": "system", "content": prompts.load("create_requirements")}, {"role": "user", "content": f"USER REQUEST:\n{request}"}]
    out, _ = client.structured("planner", msgs, Requirements, max_tokens=1500)
    return out


LANG_WORDS = {"web": r"\bhtml5?\b|\bcss3?\b|\bjavascript\b|\bvanilla js\b|\bbrowser\b", "python": r"\bpython\b|\bflask\b|\bdjango\b",
              "cpp": r"\bc\+\+\b|\bqt\b|\bcmake\b", "c": r"\bin c\b|\bansi c\b|\bc11\b", "java": r"\bjava\b(?!script)", "js": r"\bnode(?:\.js)?\b"}


def request_languages(request: str) -> set[str]:
    from .checks import file_language
    found = {x for m in re.finditer(r"\b[\w./-]+\.(?:py|js|mjs|html?|css|cpp|cc|hpp|h|c|java)\b", request)
             if (x := file_language(m.group(0), "")) and x not in ("header", "other", "config")}
    low = request.lower()
    found |= {k for k, rx in LANG_WORDS.items() if re.search(rx, low)}
    if "web" in found:
        found.discard("js")
    return found


def architect(client: Any, settings: Settings, repo: Path, req: Requirements, request: str, language_hint: str = "") -> tuple[Blueprint, list[str]]:
    lang = language_hint if language_hint in LANGUAGE_RULES else ""
    asked = request_languages(request)
    early: list[str] = []
    if lang and asked and lang not in asked:
        early.append(f"language {lang} ignored: the request itself asks for {', '.join(sorted(asked))}")
        lang = ""
    rules = LANGUAGE_RULES[lang] if lang else " ".join(f"If {k}: {v}" for k, v in LANGUAGE_RULES.items())
    tools = CommandPolicy(repo, lang or "python").allowed_for_prompt()
    system = prompts.render("create_architect", allowed_tools=", ".join(tools), max_files=str(settings.limits.max_tasks), language_rules=rules)
    user = f"USER REQUEST:\n{request}\n\nREQUIREMENTS:\n{req.as_text()}" + (f"\n\nLANGUAGE: {lang}" if lang else "")
    tpl = templates.load(lang) if lang else None
    if tpl:
        user += f"\n\nSTARTER TEMPLATE (these files already exist; keep their paths and roles and include them in files):\n{tpl.describe()}"
    out, _ = client.structured("planner", [{"role": "system", "content": system}, {"role": "user", "content": user}], Blueprint, max_tokens=3000)
    if lang:
        out.language = lang  # type: ignore[assignment]
    out, notes = normalise(out, settings.limits.max_tasks)
    notes = early + notes
    if not lang:
        from collections import Counter
        from .checks import file_language
        seen = Counter(x for f in out.files if (x := file_language(f.path, out.language)) and x not in ("header", "other", "config"))
        if seen and out.language not in seen:
            picked = seen.most_common(1)[0][0]
            notes.append(f"language {out.language} -> {picked}: none of the planned files is {out.language}")
            out.language = picked  # type: ignore[assignment]
    tpl = templates.load(out.language)
    if tpl:
        out, more = templates.merge(out, tpl)
        notes += more
    out.test_command = check_command(repo, out.language, out.test_command)
    return out, notes


def outline(path: str, text: str, language: str) -> str:
    return "(outline: line: signature)\n" + context_select.outline(path, text)


def context_sections(repo: Path, bp: Blueprint, path: str, budget: int) -> str:
    spec = bp.spec(path)
    secs = []
    for d in spec.depends_on:
        p = repo / d
        if p.exists():
            text = p.read_text(encoding="utf-8", errors="replace")
            secs.append(Section(d, text, 5, 120, "head"))
    fitted = fit_sections(secs, budget) if secs else {}
    out = []
    for s in secs:
        body = fitted.get(s.name, "")
        if body != s.text:
            body = outline(s.name, s.text, bp.language)
        out.append(f"--- {s.name} ---\n{body}")
    return "\n".join(out)


MAX_CONTINUATIONS = 4
CONTINUE = ("Your previous answer was cut off by the length limit. Continue the file exactly after the last line shown below. "
            "Output only the remaining lines in one fenced block. Do not repeat lines that are already written.")


def extract_code(text: str) -> str:
    stripped = text.strip("\n")
    if stripped.lstrip().startswith("```"):
        lines = stripped.lstrip().splitlines()[1:]
        if lines and lines[-1].strip().startswith("```"):
            lines = lines[:-1]
        body = "\n".join(lines)
    else:
        m = FENCE.search(text)
        body = m.group(1) if m else text
    return body.strip("\n") + "\n"


def join_continuation(head: str, more: str) -> str:
    tail = head.rstrip("\n").splitlines()
    new = extract_code(more).rstrip("\n").splitlines()
    for n in range(min(12, len(tail), len(new)), 0, -1):
        if [x.rstrip() for x in tail[-n:]] == [x.rstrip() for x in new[:n]]:
            new = new[n:]
            break
    return "\n".join(tail + new) + "\n"


def write_file(client: Any, settings: Settings, repo: Path, bp: Blueprint, req: Requirements, path: str, current: str = "", feedback: str = "") -> tuple[str, Any]:
    spec = bp.spec(path)
    system = prompts.load("create_writer")
    budget = settings.prompt_tokens_for("editor") - estimate_tokens(system) - 300
    deps = context_sections(repo, bp, path, budget // 2)
    head = (f"MANIFEST:\n{bp.as_text()}\n\nREQUIREMENTS:\n{req.as_text()}\n\nFILE TO WRITE: {path}\nPurpose: {spec.purpose}\n"
            f"Must provide: {', '.join(spec.provides) or '-'}\nAcceptance:\n" + "\n".join(f"- {a}" for a in spec.acceptance))
    parts = fit_sections([Section("head", head, 9, 600, "head"), Section("deps", deps, 6, 0, "head"),
                          Section("current", current, 7, 0, "middle"), Section("feedback", feedback, 8, 0, "head")], budget)
    user = parts["head"]
    if parts["deps"]:
        user += f"\n\nFILES IT USES (already written):\n{parts['deps']}"
    if current and not feedback:
        user += f"\n\nSTARTING POINT (from the project template; extend it and keep its structure):\n```\n{parts['current']}\n```"
    if current and feedback:
        user += f"\n\nYOUR PREVIOUS VERSION:\n```\n{parts['current']}\n```\n\nPROBLEMS TO FIX (change only what is needed, keep the rest):\n{parts['feedback']}"
    resp = client.chat("editor", [{"role": "system", "content": system}, {"role": "user", "content": user}], think=False)
    text = extract_code(resp.text)
    rounds = 0
    while getattr(resp, "truncated", False) and rounds < MAX_CONTINUATIONS and text.strip():
        rounds += 1
        kept = text.rstrip("\n").splitlines()
        if len(kept) > 1:
            text = "\n".join(kept[:-1]) + "\n"
        last = "\n".join(text.rstrip("\n").splitlines()[-40:])
        lang = sym.lang_for(path, "c" if bp.language == "c" else "cpp")
        done = sym.names(sym.extract(lang, text)) if lang else []
        ask = (f"FILE TO WRITE: {path}\nPurpose: {spec.purpose}\nMust provide: {', '.join(spec.provides) or '-'}\n\n"
               f"{CONTINUE}\n" + (f"Already defined above, do NOT define again: {', '.join(done)}\n" if done else "")
               + f"\nLAST LINES WRITTEN SO FAR:\n```\n{last}\n```")
        resp = client.chat("editor", [{"role": "system", "content": system}, {"role": "user", "content": ask}], think=False)
        text = join_continuation(text, resp.text)
    return text, resp


def review_file(client: Any, settings: Settings, repo: Path, bp: Blueprint, path: str, text: str) -> Verdict:
    spec = bp.spec(path)
    system = prompts.load("create_reviewer")
    budget = settings.prompt_tokens_for("reviewer") - estimate_tokens(system) - 200
    deps = context_sections(repo, bp, path, budget // 3)
    parts = fit_sections([Section("man", bp.as_text(), 8, 300, "head"), Section("deps", deps, 4, 0, "head"), Section("code", text, 9, 400, "middle")], budget)
    user = (f"MANIFEST:\n{parts['man']}\n\nFILE: {path}\nPurpose: {spec.purpose}\nMust provide: {', '.join(spec.provides) or '-'}\n"
            f"Acceptance:\n" + "\n".join(f"- {a}" for a in spec.acceptance)
            + (f"\n\nFILES IT USES:\n{parts['deps']}" if parts["deps"] else "") + f"\n\nCODE:\n```\n{parts['code']}\n```")
    out, _ = client.structured("reviewer", [{"role": "system", "content": system}, {"role": "user", "content": user}], Verdict, max_tokens=1500)
    return out


def apply_patches(text: str, verdict: Verdict) -> tuple[str, list[str]]:
    left: list[str] = []
    for i in verdict.issues:
        if i.find and i.find != i.replace and text.count(i.find) == 1:
            text = text.replace(i.find, i.replace)
        else:
            left.append(i.problem + (f" (replace `{i.find[:120]}` with `{i.replace[:120]}`)" if i.find else ""))
    return text, left



REPAIR = ("Fix the problem in the excerpt below. Return ONLY the corrected excerpt lines (same start and end, same indentation), "
          "in one fenced code block, with no explanation. Do not add or remove anything outside the problem.")


def repair_excerpt(client: Any, path: str, text: str, line: int, problem: str, before: int = 25, after: int = 12) -> str | None:
    lines = text.splitlines()
    if not lines or line < 1 or line > len(lines) + 1:
        return None
    start, end = max(0, line - 1 - before), min(len(lines), line + after)
    excerpt = "\n".join(lines[start:end])
    user = f"FILE: {path} (lines {start + 1}-{end} of {len(lines)})\nPROBLEM: {problem}\n\nEXCERPT:\n```\n{excerpt}\n```"
    resp = client.chat("editor", [{"role": "system", "content": REPAIR}, {"role": "user", "content": user}], think=False)
    if getattr(resp, "truncated", False):
        return None
    fixed = extract_code(resp.text).rstrip("\n").splitlines()
    if not fixed or len(fixed) > (end - start) * 2 + 10:
        return None
    return "\n".join([*lines[:start], *fixed, *lines[end:]]) + "\n"
