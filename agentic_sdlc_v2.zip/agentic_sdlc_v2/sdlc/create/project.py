from __future__ import annotations

from ..core.config import Settings
from ..core.project_store import Project, ProjectStore, slugify

GITIGNORE = "build/\ndist/\n__pycache__/\n*.pyc\n*.o\n*.class\nnode_modules/\n.venv/\n"


def new_project(settings: Settings, name: str, run_id: str) -> Project:
    store = ProjectStore(settings)
    scratch = store.root / "_new" / f"{slugify(name)}-{run_id}"
    scratch.mkdir(parents=True, exist_ok=True)
    (scratch / ".gitignore").write_text(GITIGNORE, encoding="utf-8")
    project = store.open(scratch, name)
    project.run_dir(run_id)
    return project
