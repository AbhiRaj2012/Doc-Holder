from __future__ import annotations

import re
from pathlib import Path, PurePosixPath

from ..core import guards
from ..core.schemas import CheckResult, Failure
from ..runners.registry import get_runner, load_languages

BUILD_FILES = {"CMakeLists.txt", "Makefile", "makefile", "package.json", "pom.xml", "build.gradle", "pyproject.toml", "requirements.txt", "setup.py"}


def file_language(path: str, project_language: str) -> str:
    ext = PurePosixPath(path).suffix.lower()
    lang = load_languages()["extensions"].get(ext, "")
    if lang == "header":
        return project_language if project_language in ("c", "cpp") else "cpp"
    if lang == "web" or (project_language == "web" and ext in (".js", ".mjs")):
        return "web"
    return lang


def syntax(repo: Path, path: str, project_language: str, timeout: int) -> CheckResult:
    from ..core.guards import wrong_language
    if (repo / path).is_file():
        wrong = wrong_language(path, (repo / path).read_text(encoding="utf-8", errors="replace"))
        if wrong:
            return CheckResult(name="syntax", ok=False, failures=[Failure(kind="syntax", file=path, message=wrong)], output_tail=wrong)
    lang = file_language(path, project_language)
    if not lang:
        return CheckResult(name="syntax", ok=True, skipped=True, output_tail="no checker for this file type")
    runner = get_runner(lang, repo, timeout)
    scoped = runner.scoped([path])
    return runner.syntax(scoped) if scoped else CheckResult(name="syntax", ok=True, skipped=True, output_tail="no checker for this file type")


def referenced(repo: Path, path: str, files: list[str]) -> bool:
    p = PurePosixPath(path)
    keys = {p.name, p.stem} if p.suffix not in (".h", ".hpp") else {p.name}
    if p.suffix == ".java":
        keys = {p.stem}
    for other in files:
        if other == path:
            continue
        try:
            text = (repo / other).read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        if any(re.search(rf"(?<![\w]){re.escape(k)}(?![\w])", text) for k in keys):
            return True
    return False


def integration(repo: Path, files: list[str], entry: str, project_language: str) -> dict[str, list[str]]:
    problems: dict[str, list[str]] = {}
    for f in files:
        p = repo / f
        if not p.is_file():
            problems.setdefault(f, []).append("file was not written")
            continue
        text = p.read_text(encoding="utf-8", errors="replace")
        for m in guards.unresolved_imports(repo, f, text):
            problems.setdefault(f, []).append(m)
        if f.endswith((".js", ".mjs")):
            problems.setdefault(f, []).extend(guards.web_contract(repo, f, text))
            if not problems[f]:
                problems.pop(f)
        name = PurePosixPath(f).name
        if f != entry and name not in BUILD_FILES and not name.startswith(("README", "test_")) and "/test" not in f and not referenced(repo, f, files):
            problems.setdefault(entry, []).append(f"{f} is never used: connect it from {entry} or the build file")
    return problems


BLOCKING = ("syntax", "build", "test")


def dependencies(repo: Path, files: list[str]) -> dict[str, list[str]]:
    out: dict[str, list[str]] = {}
    for f in files:
        p = repo / f
        if p.is_file():
            pkgs = guards.external_packages(repo, f, p.read_text(encoding="utf-8", errors="replace"))
            if pkgs:
                guards.note_dependencies(repo, f, pkgs)
                out[f] = pkgs
    return out


def full_check(repo: Path, files: list[str], project_language: str, test_command: str, timeout: int) -> tuple[list[CheckResult], dict[str, list[str]], list[str]]:
    runner = get_runner(project_language, repo, timeout)
    results = runner.run_all(files, verify_command=test_command or None)
    per_file: dict[str, list[str]] = {}
    general: list[str] = []
    for r in results:
        if r.ok or r.skipped or r.name not in BLOCKING:
            continue
        for fl in r.failures[:20] or [Failure(kind=r.name, message=r.output_tail[-600:])]:
            target = next((f for f in files if fl.file and (fl.file == f or fl.file.endswith("/" + f) or f.endswith(fl.file))), "")
            (per_file.setdefault(target, []) if target else general).append(fl.short())
    return results, per_file, general
