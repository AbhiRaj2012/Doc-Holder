from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from ..core.config import CONFIG_DIR
from .schemas import Blueprint, FileSpec

ROOT = CONFIG_DIR / "templates"


@dataclass
class Template:
    language: str
    entry: str
    purposes: dict[str, str]
    fixed: set[str]
    files: dict[str, str] = field(default_factory=dict)

    def describe(self) -> str:
        return "\n".join(f"- {p}: {d}" for p, d in self.purposes.items())


def load(language: str) -> Template | None:
    d = ROOT / language
    meta = d / "template.yaml"
    if not meta.exists():
        return None
    cfg = yaml.safe_load(meta.read_text(encoding="utf-8")) or {}
    files = {p.relative_to(d).as_posix(): p.read_text(encoding="utf-8") for p in d.rglob("*") if p.is_file() and p.name != "template.yaml"}
    return Template(language, cfg.get("entry", ""), dict(cfg.get("files") or {}), set(cfg.get("fixed") or []), files)


def merge(bp: Blueprint, tpl: Template) -> tuple[Blueprint, list[str]]:
    notes: list[str] = []
    paths = {f.path for f in bp.files}
    head: list[FileSpec] = []
    for path, purpose in tpl.purposes.items():
        if path in paths:
            continue
        if path in tpl.fixed or path == tpl.entry:
            head.append(FileSpec(path=path, purpose=purpose, acceptance=[purpose]))
            notes.append(f"added {path} from the starter template")
    if head:
        fixed = [f for f in head if f.path in tpl.fixed]
        rest = [f for f in head if f.path not in tpl.fixed]
        bp.files = fixed + bp.files + rest
    if bp.entry not in {f.path for f in bp.files}:
        bp.entry = tpl.entry
    return bp, notes


def render(text: str, name: str) -> str:
    ident = re.sub(r"\W+", "_", name).strip("_") or "app"
    slug = re.sub(r"[^a-z0-9-]+", "-", name.lower()).strip("-") or "app"
    return text.replace("{{name}}", name).replace("{{ident}}", ident).replace("{{slug}}", slug)


def renames(bp: Blueprint, tpl: Template) -> dict[str, str]:
    planned = [f.path for f in bp.files]
    out: dict[str, str] = {}
    for path in tpl.files:
        if path in planned:
            continue
        suffix = Path(path).suffix
        same = [p for p in planned if Path(p).suffix == suffix and p not in tpl.files]
        if len(same) == 1:
            out[path] = same[0]
    return out


def write(repo: Path, bp: Blueprint, tpl: Template, name: str) -> list[str]:
    written = []
    moved = renames(bp, tpl)
    for f in bp.files:
        src = tpl.files.get(f.path)
        target = repo / f.path
        if src is None or target.exists():
            continue
        text = render(src, name)
        for old, new in moved.items():
            rel_old = Path(old).name if Path(old).parent == Path(f.path).parent else old
            rel_new = Path(new).name if Path(new).parent == Path(f.path).parent else new
            text = re.sub(rf"(?<![\w./-]){re.escape(rel_old)}(?![\w-])", rel_new, text)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding="utf-8")
        written.append(f.path)
    return written
