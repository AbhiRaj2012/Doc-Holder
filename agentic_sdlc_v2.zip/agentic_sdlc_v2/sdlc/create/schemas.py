from __future__ import annotations

from pydantic import BaseModel, Field

from ..core.schemas import Language


class Requirements(BaseModel):
    title: str
    description: str
    functional: list[str] = Field(min_length=1)
    non_functional: list[str] = Field(default_factory=list)
    use_cases: list[str] = Field(default_factory=list)

    def as_text(self) -> str:
        parts = [f"# {self.title}", self.description, "## Functional requirements", *[f"- {x}" for x in self.functional]]
        if self.non_functional:
            parts += ["## Non-functional requirements", *[f"- {x}" for x in self.non_functional]]
        if self.use_cases:
            parts += ["## Use cases", *[f"- {x}" for x in self.use_cases]]
        return "\n".join(parts)


class FileSpec(BaseModel):
    path: str
    purpose: str
    provides: list[str] = Field(default_factory=list)
    depends_on: list[str] = Field(default_factory=list)
    acceptance: list[str] = Field(default_factory=list)


class Blueprint(BaseModel):
    project_name: str
    language: Language
    summary: str
    entry: str
    files: list[FileSpec] = Field(min_length=1)
    run_command: str = ""
    test_command: str = ""
    assumptions: list[str] = Field(default_factory=list)

    def as_text(self, detail: bool = True) -> str:
        lines = [f"Project: {self.project_name} ({self.language}). {self.summary}", f"Entry point: {self.entry}"]
        for f in self.files:
            line = f"- {f.path}: {f.purpose}"
            if detail and f.provides:
                line += f" | provides: {', '.join(f.provides)}"
            if detail and f.depends_on:
                line += f" | uses: {', '.join(f.depends_on)}"
            lines.append(line)
        if self.run_command:
            lines.append(f"Run: {self.run_command}")
        return "\n".join(lines)

    def spec(self, path: str) -> FileSpec:
        return next(f for f in self.files if f.path == path)


class ReviewIssue(BaseModel):
    problem: str
    find: str = ""
    replace: str = ""


class Verdict(BaseModel):
    passed: bool
    issues: list[ReviewIssue] = Field(default_factory=list)
