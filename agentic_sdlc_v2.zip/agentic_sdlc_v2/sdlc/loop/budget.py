from __future__ import annotations

from ..core.config import LimitsCfg, LoopCfg


MECHANICAL = ("ambiguous", "overlap", "not_found", "format", "other")


def over_budget(limits: LimitsCfg, loop: LoopCfg, iteration: int, mechanical: int) -> bool:
    cap = limits.max_iterations_per_task
    if not loop.split_budgets:
        return iteration >= cap
    return iteration - mechanical >= cap or iteration >= cap + loop.mechanical_allowance
