from __future__ import annotations

import hashlib
from typing import Any

from ..core.schemas import ExitReason, ReviewResult

WEIGHTS = {"syntax": 50, "build": 50, "typecheck": 8, "lint": 3, "test": 10}
COUNTED = ("test", "lint", "typecheck")


def score(review: ReviewResult) -> int:
    if review.approved:
        return 0
    total = 0
    for c in review.checks:
        if c.skipped or c.ok:
            continue
        n = min(max(len(c.failures), 1), 20) if c.name in COUNTED else 1
        total += WEIGHTS.get(c.name, 5) * n
    if review.llm is not None and not review.llm.approved:
        total += 4 * max(1, len(review.llm.unmet_criteria))
    return max(total, 1)


def signature(review: ReviewResult) -> str:
    parts = sorted(f"{f.kind}|{f.file}|{f.name}" if f.name else f"{f.kind}|{f.file}|{(f.message.splitlines() or [''])[0][:80]}" for f in review.all_failures())
    parts += sorted(review.llm.unmet_criteria) if review.llm else []
    return hashlib.sha1("\n".join(parts).encode("utf-8")).hexdigest()[:12]


def track(rt: Any, state: dict[str, Any], review: ReviewResult, feedback: str) -> dict[str, Any]:
    cfg = rt.settings.loop
    sc, sig = score(review), signature(review)
    best = state.get("best_score")
    if review.approved or best is None or sc < best:
        return {"best_score": sc, "best_snapshot": rt.git.snapshot(), "best_feedback": feedback, "no_improve": 0, "fail_sigs": [sig]}
    seen = list(state.get("fail_sigs", []))
    worse = sc > best
    no_improve = state.get("no_improve", 0) + (1 if worse or sig in seen else 0)
    out: dict[str, Any] = {"fail_sigs": [*seen, sig][-12:], "no_improve": no_improve}
    task_id = state.get("current_task_id", "")
    if worse and cfg.rollback_worse and state.get("best_snapshot"):
        cur = rt.git.snapshot()
        paths = rt.git.changed_between(state["best_snapshot"], cur)
        rt.git.restore_paths(state["best_snapshot"], paths)
        rt.logger({"type": "rolled_back_to_best", "task_id": task_id, "score": sc, "best": best, "files": paths,
                   "why": "the last attempt scored worse than the best earlier attempt, so the best attempt was restored before retrying"})
        out["edit_error"] = (f"Your last attempt scored worse ({sc} vs {best}; lower is better) and was reverted. The best earlier attempt is restored. "
                             f"Its remaining problems:\n{state.get('best_feedback', '')[:700]}\nWhat the reverted attempt got wrong:\n{feedback[:400]}")
        out["rolled_back"] = True
    if no_improve >= cfg.stall_window:
        out["gate_reason"] = ExitReason.NO_PROGRESS.value
        rt.logger({"type": "no_improvement", "task_id": task_id, "reviews_without_progress": no_improve, "best": best,
                   "why": "several reviews in a row did not get better than the best attempt"})
    return out
