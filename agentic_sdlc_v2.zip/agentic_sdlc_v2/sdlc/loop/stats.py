from __future__ import annotations

from typing import Any


def bump(state: dict[str, Any], key: str, n: int = 1, base: dict[str, int] | None = None) -> dict[str, int]:
    stats = dict(base if base is not None else state.get("loop_stats", {}))
    stats[key] = stats.get(key, 0) + n
    return stats


def summary(state: dict[str, Any]) -> dict[str, Any]:
    tasks = state.get("tasks", [])
    done = [t for t in tasks if t["status"] == "completed"]
    per = state.get("task_stats", {})
    first = sum(1 for t in done if per.get(t["id"], {}).get("iterations", 1) <= 1)
    return {**state.get("loop_stats", {}), "first_pass_tasks": first, "first_pass_rate": round(first / len(done), 3) if done else 0.0}
