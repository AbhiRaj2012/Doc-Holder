from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from ..core.schemas import CheckResult, Failure, Task
from ..runners.registry import get_runner

STOP = {"must", "should", "return", "returns", "that", "with", "when", "this", "from", "have", "does", "every", "tests", "test", "code", "file", "files", "function", "value", "values", "works", "work"}


def key(f: Failure) -> str:
    return f"{f.file}|{f.name}|{(f.message.splitlines() or [''])[0][:120]}"


def terms(task: Task) -> set[str]:
    words = {w.lower() for w in re.findall(r"[A-Za-z_]\w{3,}", " ".join([task.title, task.description, *task.acceptance_criteria]))} - STOP
    stems = {Path(f).stem.lower() for f in task.target_files if Path(f).stem}
    syms = {re.split(r"::|\.", s.split("(")[0])[-1].lower() for s in task.symbol_targets}
    return {t for t in words | stems | syms if t}


def related(task: Task, f: Failure) -> bool:
    text = f"{f.file} {f.name} {f.message}".lower()
    return any(t in text for t in terms(task))


def capture(rt: Any, task: Task) -> list[str]:
    runner = get_runner(task.language, rt.ctx.repo, rt.settings.limits.subprocess_timeout_s)
    if not (task.verify_command or runner.commands().get("test")):
        return []
    check = runner.finish_test(runner.run_kind("test", [], command=task.verify_command))
    if check.ok or check.skipped:
        return []
    rt.logger({"type": "tool_call", "node": "baseline", "tool": "run_test", "task_id": task.id, "iteration": 0,
               "args": {"command": check.command}, "ok": False, "failures": len(check.failures)})
    return sorted({key(f) for f in check.failures})


def apply(checks: list[CheckResult], known: list[str], log: Any = None, task: Task | None = None) -> list[CheckResult]:
    if not known:
        return checks
    pre = set(known)
    out: list[CheckResult] = []
    for c in checks:
        if c.name != "test" or c.ok or c.skipped or not c.failures:
            out.append(c)
            continue
        fresh = [f for f in c.failures if key(f) not in pre or (task is not None and related(task, f))]
        ignored = len(c.failures) - len(fresh)
        if not ignored:
            out.append(c)
            continue
        if log:
            log({"type": "baseline_ignored", "tests": ignored, "remaining": len(fresh), "why": "these tests were already failing before the task started and do not relate to it"})
        if not fresh:
            out.append(CheckResult(name="test", ok=True, command=c.command, duration_s=c.duration_s,
                                   output_tail=f"{ignored} unrelated test failure(s) existed before this task and are not used as a gate"))
        else:
            out.append(c.model_copy(update={"failures": fresh}))
    return out
