from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from pydantic import BaseModel, Field

from ..agents import prompts
from ..core.budget import Section, estimate_tokens, fit_sections
from ..core.config import Settings
from ..core.schemas import Task


@dataclass
class Escalation:
    level: int = 0
    diagnose: bool = False
    temp_bump: float = 0.0
    effort: str | None = None
    model: str | None = None


class Diagnosis(BaseModel):
    root_cause: str
    fix_plan: list[str] = Field(default_factory=list)
    avoid: str = ""


def plan(settings: Settings, rejections: int) -> Escalation:
    c = settings.loop
    if not c.escalation or rejections < c.diagnose_after:
        return Escalation()
    e = Escalation(level=1, diagnose=True)
    if rejections >= c.boost_after:
        e.level, e.temp_bump, e.effort = 2, 0.2 * (rejections - c.boost_after + 1), c.boost_effort or None
    if rejections >= c.fallback_after:
        fallback = settings.ollama.fallback_models.get("editor")
        if fallback:
            e.level, e.model = 3, fallback
    return e


def diagnose(rt: Any, task: Task, feedback: str, diff: str) -> str:
    system = prompts.load("diagnose")
    criteria = "\n".join(f"{n}. {c}" for n, c in enumerate(task.acceptance_criteria, 1))
    head = f"TASK {task.id}: {task.title}\n{task.description}\n\nACCEPTANCE CRITERIA:\n{criteria}\n\nREVIEW FINDINGS:\n{feedback}\n"
    budget = rt.settings.prompt_tokens_for("reviewer") - estimate_tokens(system) - 100
    parts = fit_sections([Section("head", head, 9, 300, "head"), Section("diff", diff, 5, 300, "middle")], budget)
    msgs = [{"role": "system", "content": system}, {"role": "user", "content": f"{parts['head']}\nDIFF SO FAR:\n{parts['diff']}"}]
    try:
        d, _ = rt.ctx.client.structured("reviewer", msgs, Diagnosis, max_tokens=900, retries=1)
    except Exception as exc:
        rt.logger({"type": "diagnose_unavailable", "task_id": task.id, "error": str(exc)[:200]})
        return ""
    text = f"ROOT CAUSE: {d.root_cause.strip()}\nFIX PLAN:\n" + "\n".join(f"{n}. {s.strip()}" for n, s in enumerate(d.fix_plan[:4], 1))
    if d.avoid.strip():
        text += f"\nDO NOT REPEAT: {d.avoid.strip()}"
    rt.logger({"type": "diagnosis", "task_id": task.id, "root_cause": d.root_cause[:300], "steps": len(d.fix_plan)})
    return text
