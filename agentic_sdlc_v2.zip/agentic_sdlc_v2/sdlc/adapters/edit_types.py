from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class EditRequest:
    repo: Path
    files: list[str]
    message: str
    run_dir: Path
    tag: str
    read_files: list[str] = field(default_factory=list)
    edit_format: str = "diff"
    allow_new: bool = True
    focus_symbols: dict[str, list[str]] = field(default_factory=dict)
    temperature: float | None = None
    temp_bump: float = 0.0
    effort: str | None = None
    model: str | None = None
