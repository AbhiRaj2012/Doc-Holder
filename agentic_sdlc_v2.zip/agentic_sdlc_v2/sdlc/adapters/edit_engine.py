from __future__ import annotations

import re
from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path

from ..core.paths import posix, posix_list

HEAD = re.compile(r"^<{3,9}\s*(?:SEARCH|ORIGINAL|FIND|HEAD)\b[\s:]*$", re.I)
DIV = re.compile(r"^={3,9}\s*(?:REPLACE\s*:?)?\s*$", re.I)
TAIL = re.compile(r"^>{3,9}\s*(?:REPLACE|UPDATED|NEW|END)?\b[\s:]*$", re.I)
HUNK = re.compile(r"^@@ .*@@")
FENCE = re.compile(r"^```")
PATH_PREFIX = re.compile(r"^(?:file|path)\s*:\s*", re.I)
FUZZY_MIN = 0.90
FUZZY_MARGIN = 0.03
FUZZY_MAX_FILE_LINES = 4000


@dataclass
class Block:
    path: str
    search: str
    replace: str


@dataclass
class BlockResult:
    path: str
    ok: bool
    mode: str = ""
    error: str = ""
    hint: str = ""
    search_lines: int = 0
    replace_lines: int = 0

    def trace(self) -> dict:
        return {"path": self.path, "ok": self.ok, "mode": self.mode, "error": self.error[:200],
                "search_lines": self.search_lines, "replace_lines": self.replace_lines}


def _clean_path(raw: str) -> str:
    p = PATH_PREFIX.sub("", raw.strip()).strip("`*#: ").strip()
    return posix(p)


def parse_blocks(text: str, default_path: str = "") -> list[Block]:
    lines = text.splitlines()
    blocks: list[Block] = []
    i = 0
    while i < len(lines):
        if not HEAD.match(lines[i].strip()):
            i += 1
            continue
        path = ""
        for j in range(i - 1, max(-1, i - 4), -1):
            cand = lines[j].strip()
            if cand and not FENCE.match(cand):
                path = _clean_path(cand)
                break
        k, search = i + 1, []
        while k < len(lines) and not DIV.match(lines[k].strip()):
            search.append(lines[k])
            k += 1
        k += 1
        replace = []
        while k < len(lines) and not TAIL.match(lines[k].strip()):
            replace.append(lines[k])
            k += 1
        if k >= len(lines):
            break
        if default_path and (not path or "path/to/" in path or path.endswith("file.ext")):
            path = default_path
        blocks.append(Block(path or default_path, "\n".join(search), "\n".join(replace)))
        i = k + 1
    return blocks


def parse_unified(text: str, default_path: str = "") -> list[Block]:
    lines = text.splitlines()
    blocks: list[Block] = []
    path = default_path
    i = 0
    while i < len(lines):
        ln = lines[i]
        if ln.startswith("+++ "):
            cand = ln[4:].strip().split("\t")[0]
            cand = cand[2:] if cand.startswith(("a/", "b/")) else cand
            if cand and cand != "/dev/null":
                path = posix(cand)
            i += 1
            continue
        if HUNK.match(ln):
            search, replace = [], []
            i += 1
            while i < len(lines) and not HUNK.match(lines[i]) and not lines[i].startswith(("--- ", "+++ ", "```", "diff ")):
                body = lines[i]
                if body.startswith("-"):
                    search.append(body[1:])
                elif body.startswith("+"):
                    replace.append(body[1:])
                else:
                    ctx = body[1:] if body.startswith(" ") else body
                    search.append(ctx)
                    replace.append(ctx)
                i += 1
            while search and replace and search[-1] == replace[-1] == "":
                search.pop()
                replace.pop()
            if search != replace:
                blocks.append(Block(path, "\n".join(search), "\n".join(replace)))
            continue
        i += 1
    return blocks


def single_fenced(text: str) -> str | None:
    m = re.findall(r"```[^\n]*\n(.*?)```", text, re.S)
    if len(m) == 1:
        return m[0]
    return None


def parse_whole(text: str) -> dict[str, str]:
    lines = text.splitlines()
    out: dict[str, str] = {}
    i = 0
    while i < len(lines):
        if FENCE.match(lines[i].strip()) and i > 0:
            path = ""
            for j in range(i - 1, max(-1, i - 3), -1):
                if lines[j].strip():
                    path = _clean_path(lines[j])
                    break
            k, body = i + 1, []
            while k < len(lines) and lines[k].rstrip() != "```":
                body.append(lines[k])
                k += 1
            if path and ("." in path or "/" in path) and " " not in path:
                out[path] = "\n".join(body) + "\n"
            i = k + 1
        else:
            i += 1
    return out


def _norm(s: str) -> str:
    return " ".join(s.split())


def _trim_blank(lines: list[str]) -> list[str]:
    a, b = 0, len(lines)
    while a < b and not lines[a].strip():
        a += 1
    while b > a and not lines[b - 1].strip():
        b -= 1
    return lines[a:b]


def _find_all(hay: list[str], needle: list[str], key) -> list[int]:
    n = len(needle)
    hk, nk = [key(x) for x in hay], [key(x) for x in needle]
    return [i for i in range(len(hay) - n + 1) if hk[i:i + n] == nk]


def _numbered(orig: list[str], start: int, end: int, limit: int = 14) -> str:
    return "\n".join(f"{n + 1}: {orig[n]}" for n in range(start, min(end, start + limit)))


def _fuzzy(orig: list[str], search: list[str]) -> tuple[tuple[int, int] | None, str]:
    if len(orig) > FUZZY_MAX_FILE_LINES or not search or len(search) > 200:
        return None, ""
    norm = [_norm(x) for x in orig]
    target = "\n".join(_norm(x) for x in search)
    n = len(search)
    scored: list[tuple[float, int, int]] = []
    for size in range(max(1, n - 2), n + 3):
        for i in range(0, len(orig) - size + 1):
            sm = SequenceMatcher(None, "\n".join(norm[i:i + size]), target, autojunk=False)
            if sm.real_quick_ratio() < 0.6 or sm.quick_ratio() < 0.6:
                continue
            scored.append((sm.ratio(), i, size))
    if not scored:
        return None, ""
    scored.sort(reverse=True)
    top, ti, ts = scored[0]
    hint = f"Closest existing text (lines {ti + 1}-{ti + ts}, similarity {top:.2f}):\n{_numbered(orig, ti, ti + ts)}"
    if top < FUZZY_MIN:
        return None, hint if top >= 0.5 else ""
    second = next((s for s, i, z in scored[1:] if i + z <= ti or i >= ti + ts), 0.0)
    if top - second < FUZZY_MARGIN:
        return None, "Several regions match about equally; add more surrounding lines to make SEARCH unique."
    return (ti, ti + ts), hint


def _lead(s: str) -> str:
    return s[:len(s) - len(s.lstrip(" \t"))]


def _restyle(lines: list[str], use_tabs: bool) -> list[str]:
    out = []
    for ln in lines:
        lead = _lead(ln)
        if use_tabs and " " in lead and "\t" not in lead:
            lead = "\t" * (len(lead) // 4) + " " * (len(lead) % 4)
        elif not use_tabs and "\t" in lead:
            lead = lead.replace("\t", "    ")
        out.append(lead + ln[len(_lead(ln)):])
    return out


def _conform(replace: list[str], search: list[str], matched: list[str]) -> list[str]:
    tabs = sum(1 for m in matched if m.startswith("\t"))
    spaces = sum(1 for m in matched if m.startswith("  "))
    if tabs or spaces:
        replace, search = _restyle(replace, tabs > spaces), _restyle(search, tabs > spaces)
    ss = _lead(next((x for x in search if x.strip()), ""))
    ms = _lead(next((x for x in matched if x.strip()), ""))
    if ss == ms:
        return replace
    if ms.endswith(ss):
        add = ms[:len(ms) - len(ss)]
        return [add + x if x.strip() else x for x in replace]
    if ss.endswith(ms):
        cut = ss[:len(ss) - len(ms)]
        return [x[len(cut):] if x.startswith(cut) else x for x in replace]
    return replace


def _locate(orig: list[str], search: list[str]) -> tuple[tuple[int, int, str] | None, str, str]:
    for mode, key in (("exact", lambda s: s), ("whitespace", _norm)):
        hits = _find_all(orig, search, key)
        if len(hits) == 1:
            return (hits[0], hits[0] + len(search), mode), "", ""
        if len(hits) > 1:
            return None, f"SEARCH matches {len(hits)} places; add more surrounding lines to make it unique.", ""
    span, hint = _fuzzy(orig, search)
    if span:
        return (span[0], span[1], "fuzzy"), "", ""
    return None, "SEARCH text not found in the file.", hint


def _resolve(orig: list[str], block: Block) -> tuple[tuple[int, int, list[str], str] | None, str, str]:
    search = _trim_blank(block.search.split("\n"))
    replace = _trim_blank(block.replace.split("\n"))
    marks = [i for i, x in enumerate(search) if x.strip() == "..."]
    if marks:
        k = marks[0]
        rmarks = [i for i, x in enumerate(replace) if x.strip() == "..."]
        if len(marks) > 1 or not rmarks:
            return None, "Use exactly one '...' line in SEARCH and the same in REPLACE.", ""
        head, tail = search[:k], search[k + 1:]
        rhead, rtail = replace[:rmarks[0]], replace[rmarks[0] + 1:]
        hs = _locate(orig, head) if head else ((0, 0, "exact"), "", "")
        if hs[0] is None:
            return None, "Start of elided SEARCH not found. " + hs[1], hs[2]
        after = hs[0][1]
        if tail:
            rest = _locate(orig[after:], tail)
            if rest[0] is None:
                return None, "End of elided SEARCH not found. " + rest[1], rest[2]
            ts, te = after + rest[0][0], after + rest[0][1]
        else:
            ts = te = len(orig)
        new = rhead + orig[after:ts] + rtail
        return (hs[0][0], te, new, "elision"), "", ""
    if _norm("\n".join(search)) == _norm("\n".join(replace)):
        return (0, 0, [], "noop"), "", ""
    loc, err, hint = _locate(orig, search)
    if loc is None:
        return None, err, hint
    start, end, mode = loc
    if mode != "exact":
        replace = _conform(replace, search, orig[start:end])
    return (start, end, replace, mode), "", ""


def _safe(repo: Path, rel: str) -> Path | None:
    if not rel or rel.startswith(("/", "~")) or ".." in Path(rel).parts or Path(rel).parts[:1] == (".git",):
        return None
    full = (repo / rel).resolve()
    return full if full == repo or repo in full.parents else None


def _read(path: Path) -> tuple[str, bool, bool]:
    raw = path.read_bytes().decode("utf-8")
    crlf = "\r\n" in raw
    text = raw.replace("\r\n", "\n")
    return text, crlf, text.endswith("\n")


def _write(path: Path, lines: list[str], crlf: bool, trailing_nl: bool) -> None:
    text = "\n".join(lines) + ("\n" if trailing_nl else "")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((text.replace("\n", "\r\n") if crlf else text).encode("utf-8"))


def apply_blocks(
    repo: str | Path, blocks: list[Block], allowed: list[str] | None = None, allow_new: bool = True,
) -> tuple[list[BlockResult], list[str]]:
    root = Path(repo).resolve()
    allowed = posix_list(allowed) if allowed is not None else None
    results: list[BlockResult | None] = [None] * len(blocks)
    by_path: dict[str, list[int]] = {}
    for idx, b in enumerate(blocks):
        res = BlockResult(path=b.path, ok=False, search_lines=len(b.search.splitlines()), replace_lines=len(b.replace.splitlines()))
        full = _safe(root, b.path)
        if full is None:
            res.error = "invalid or missing file path"
        elif allowed is not None and b.path not in allowed and (full.exists() or not allow_new):
            res.error = f"file not in task scope; allowed: {', '.join(allowed)}"
        else:
            by_path.setdefault(b.path, []).append(idx)
        results[idx] = res
    changed: list[str] = []
    for rel, idxs in by_path.items():
        full = root / rel
        exists = full.exists()
        text, crlf, trailing = _read(full) if exists else ("", False, True)
        orig = text.split("\n")
        if orig and orig[-1] == "":
            orig.pop()
        plans: list[tuple[int, int, list[str], int]] = []
        created: list[str] | None = None
        for idx in idxs:
            b, res = blocks[idx], results[idx]
            assert res is not None
            if not b.search.strip():
                if exists and orig:
                    res.error = "empty SEARCH for an existing file; include the lines to replace."
                else:
                    created = (created or []) + _trim_blank(b.replace.split("\n"))
                    res.ok, res.mode = True, "create"
                continue
            if not exists:
                res.error = "file does not exist; use an empty SEARCH to create it."
                continue
            found, err, hint = _resolve(orig, b)
            if found is None:
                res.error, res.hint = err, hint
                continue
            start, end, new, mode = found
            res.mode = mode
            if mode == "noop":
                res.ok = True
                continue
            if any(start < pe and ps < end for ps, pe, _, _ in plans):
                res.error = "block overlaps another block in the same file."
                continue
            plans.append((start, end, new, idx))
            res.ok = True
        if created is not None:
            _write(full, created, False, True)
            changed.append(rel)
            continue
        if plans:
            lines = list(orig)
            for start, end, new, _ in sorted(plans, key=lambda p: p[0], reverse=True):
                lines[start:end] = new
            if lines != orig:
                _write(full, lines, crlf, trailing)
                changed.append(rel)
    return [r for r in results if r is not None], changed


def apply_whole(repo: str | Path, files: dict[str, str], allowed: list[str] | None, allow_new: bool = True) -> tuple[list[BlockResult], list[str]]:
    root = Path(repo).resolve()
    allowed = posix_list(allowed) if allowed is not None else None
    results, changed = [], []
    for rel, content in files.items():
        rel = posix(rel)
        res = BlockResult(path=rel, ok=False, mode="whole", replace_lines=len(content.splitlines()))
        full = _safe(root, rel)
        if full is None:
            res.error = "invalid file path"
        elif allowed is not None and rel not in allowed and (full.exists() or not allow_new):
            res.error = f"file not in task scope; allowed: {', '.join(allowed)}"
        else:
            old_crlf = full.exists() and b"\r\n" in full.read_bytes()
            lines = content.rstrip("\n").split("\n")
            before = full.read_bytes() if full.exists() else None
            _write(full, lines, old_crlf, True)
            res.ok = True
            if full.read_bytes() != before:
                changed.append(rel)
        results.append(res)
    return results, changed


def classify(error: str, truncated: bool = False) -> str:
    low = error.lower()
    if truncated or "output truncated" in low:
        return "length"
    if "timed out" in low:
        return "timeout"
    if "matches" in low and "places" in low:
        return "ambiguous"
    if "not in task scope" in low:
        return "scope"
    if "overlaps" in low:
        return "overlap"
    if "not found" in low:
        return "not_found"
    if "no search/replace" in low or "no blocks" in low or "did not conform" in low:
        return "format"
    if "no changes" in low:
        return "no_change"
    return "other" if error.strip() else ""


def describe_failures(results: list[BlockResult]) -> str:
    parts = []
    for n, r in enumerate(results, 1):
        if not r.ok:
            parts.append(f"Block {n} ({r.path or 'no path'}): {r.error}" + (f"\n{r.hint}" if r.hint else ""))
    return "\n".join(parts)
