from __future__ import annotations

from ..core.config import Settings
from ..core.schemas import EditResult
from .aider_cli import AiderCliBackend
from .edit_types import EditRequest
from .git_ops import GitRepo
from .native_editor import NativeEditor
from .ollama_client import OllamaClient


class HybridEditor:
    def __init__(self, settings: Settings, client: OllamaClient, git: GitRepo, use_aider: bool = True):
        self.settings = settings
        self.git = git
        self.aider = AiderCliBackend(settings, git)
        self.native = NativeEditor(settings, client, git)
        self.use_aider = use_aider and self.aider.available()
        self.disabled_reason = ""
        self.just_disabled = False

    def plan(self, req: EditRequest, failures: int) -> tuple[str, str]:
        a = self.settings.aider
        if self.use_aider and failures < a.fallback_after_failures:
            return "aider", a.edit_format
        small = all(
            (req.repo / f).exists() and (req.repo / f).stat().st_size <= a.whole_max_bytes for f in req.files
        ) and bool(req.files)
        fits = all(
            (req.repo / f).exists() and (req.repo / f).stat().st_size / 3.5 * 1.25 <= 0.7 * self.settings.budget.max_output_tokens.get("editor", 2000)
            for f in req.files
        ) if req.files else False
        small = small and fits
        creating = not req.files or any(not (req.repo / f).exists() for f in req.files)
        if creating or (failures >= 1 and small) or (failures > a.fallback_after_failures and small):
            return "native", a.fallback_format
        return "native", "diff"

    def edit(self, req: EditRequest, failures: int = 0) -> EditResult:
        self.just_disabled = False
        backend, fmt = self.plan(req, failures)
        req.edit_format = fmt
        bump = 0.2 * failures + req.temp_bump
        req.temperature = min(0.7, self.settings.ollama.temperature + bump) if bump else None
        result = (self.aider if backend == "aider" else self.native).edit(req)
        if backend == "aider" and not result.ok and result.tokens_in == 0 and result.tokens_out == 0:
            self.use_aider = False
            self.just_disabled = True
            tail = " | ".join(result.stdout_tail.strip().splitlines()[-4:])[:400]
            self.disabled_reason = f"aider never reached the model (exit without any token usage); disabled for this run: {tail or result.error[:200]}"
        return result
