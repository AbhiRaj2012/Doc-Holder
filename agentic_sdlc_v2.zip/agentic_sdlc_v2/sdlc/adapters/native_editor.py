from __future__ import annotations

import time

from ..core import symbols as sym
from ..core.budget import Section, estimate_tokens, fit_sections
from ..core.config import CONFIG_DIR, Settings
from ..core.schemas import EditResult
from . import edit_engine
from .edit_types import EditRequest
from .git_ops import GitRepo
from .ollama_client import LLMError, OllamaClient


def _prompt(name: str) -> str:
    return (CONFIG_DIR / "prompts" / name).read_text(encoding="utf-8")


class NativeEditor:
    name = "native"

    def __init__(self, settings: Settings, client: OllamaClient, git: GitRepo):
        self.settings, self.client, self.git = settings, client, git

    def edit(self, req: EditRequest) -> EditResult:
        fmt = req.edit_format if req.edit_format in ("diff", "whole") else "diff"
        system = _prompt("native_edit_whole.md" if fmt == "whole" else "native_edit_diff.md").replace("path/to/file.ext", req.files[0] if req.files else "src/module.py")
        sections = [Section("task", req.message, priority=9, min_tokens=800, keep="head")]
        for f in req.files:
            text = (req.repo / f).read_text(encoding="utf-8") if (req.repo / f).exists() else "(new file)"
            wanted = req.focus_symbols.get(f)
            if wanted and len(text.encode("utf-8")) > min(self.settings.budget.max_file_prompt_bytes // 4, int(self.settings.prompt_tokens_for("editor") * 0.4 * 3.5)):
                text = sym.excerpt(text, sym.extract(sym.lang_for(f), text), wanted)
            sections.append(Section(f"edit:{f}", text, 6, 500, "middle"))
        for f in req.read_files:
            sections.append(Section(f"read:{f}", (req.repo / f).read_text(encoding="utf-8", errors="replace"), 2, 0, "head"))
        budget = self.settings.prompt_tokens_for("editor") - estimate_tokens(system) - 200
        fitted = fit_sections(sections, budget)
        partial = any(fitted[f"edit:{f}"] != s.text or s.text.startswith("[... lines") or "\n[... lines" in s.text for f, s in zip(req.files, sections[1:]))
        if fmt == "whole" and partial:
            return EditResult(ok=False, edit_format="native-whole", error="file too large for whole-file rewrite within the context budget")
        parts = [fitted["task"], "\nFILES TO EDIT:"]
        parts += [f"\n{f}\n```\n{fitted[f'edit:{f}']}\n```" for f in req.files]
        if req.read_files:
            parts.append("\nREAD-ONLY CONTEXT:")
            parts += [f"\n{f}\n```\n{fitted[f'read:{f}']}\n```" for f in req.read_files]
        before = self.git.snapshot()
        start = time.monotonic()
        try:
            extra = {k: v for k, v in (("model", req.model), ("effort", req.effort)) if v}
            resp = self.client.chat("editor", [{"role": "system", "content": system}, {"role": "user", "content": "\n".join(parts)}], temperature=req.temperature, **extra)
        except LLMError as exc:
            return EditResult(ok=False, edit_format=f"native-{fmt}", error=f"LLM call failed: {exc}")
        salvage = bool(resp.truncated and fmt == "diff" and edit_engine.parse_blocks(resp.text, req.files[0] if len(req.files) == 1 else ""))
        if resp.truncated and not salvage:
            return EditResult(ok=False, truncated=True, edit_format=f"native-{fmt}", error="output truncated (length limit reached; the model's reasoning may have used the output budget)",
                              tokens_in=resp.prompt_tokens, tokens_out=resp.completion_tokens)
        default = req.files[0] if len(req.files) == 1 else ""
        fmt_used = fmt
        if fmt == "whole":
            files = edit_engine.parse_whole(resp.text)
            results, _ = edit_engine.apply_whole(req.repo, files, req.files, req.allow_new) if files else ([], [])
            if not files:
                blocks = edit_engine.parse_blocks(resp.text, default) or edit_engine.parse_unified(resp.text, default)
                if blocks:
                    results, _ = edit_engine.apply_blocks(req.repo, blocks, req.files, req.allow_new)
                    fmt_used = "search-replace"
        else:
            blocks = edit_engine.parse_blocks(resp.text, default)
            parsed = "search-replace"
            if not blocks:
                blocks = edit_engine.parse_unified(resp.text, default)
                parsed = "unified-diff"
            results, _ = edit_engine.apply_blocks(req.repo, blocks, req.files, req.allow_new) if blocks else ([], [])
            if not blocks:
                files = {f: c for f, c in edit_engine.parse_whole(resp.text).items() if f in req.files}
                if not files and default:
                    whole = edit_engine.single_fenced(resp.text)
                    files = {default: whole} if whole is not None else {}
                safe = {}
                for f, content in files.items():
                    orig = (req.repo / f).read_text(encoding="utf-8", errors="replace") if (req.repo / f).exists() else ""
                    if not orig or len(content.splitlines()) >= 0.6 * len(orig.splitlines()):
                        safe[f] = content.rstrip("\n") + "\n"
                if safe:
                    results, _ = edit_engine.apply_whole(req.repo, safe, req.files, req.allow_new)
                    parsed = "whole-file"
            if results:
                fmt_used = parsed
        after = self.git.snapshot()
        applied = sum(1 for r in results if r.ok)
        failed = len(results) - applied
        error = edit_engine.describe_failures(results) if failed else ""
        if salvage:
            error = (error + "\n" if error else "") + "The model output was cut off; only the complete blocks were applied. Continue with the remaining changes."
        if not results:
            start_txt = " ".join(resp.text.strip().split())[:220]
            error = ("no SEARCH/REPLACE blocks (or file sections) found in the model output. Your reply began with: "
                     f"\"{start_txt}\". Reply ONLY with blocks: the file path on its own line, then <<<<<<< SEARCH, the exact current lines, =======, the new lines, >>>>>>> REPLACE.")
        return EditResult(
            ok=applied > 0, files_changed=self.git.changed_between(before, after), diff=self.git.diff_trees(before, after),
            stdout_tail=resp.text[-1500:], error=error, edit_format=f"native-{fmt}",
            duration_s=round(time.monotonic() - start, 2), tokens_in=resp.prompt_tokens, tokens_out=resp.completion_tokens,
            blocks_applied=applied, blocks_failed=failed, blocks=[r.trace() for r in results],
            invocation={"backend": "native", "format": fmt, "parsed_as": fmt_used, "temperature": req.temperature, "files": req.files, "read_files": req.read_files},
        )
