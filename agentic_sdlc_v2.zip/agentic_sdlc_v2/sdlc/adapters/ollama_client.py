from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import Any, Callable, TypeVar

import httpx
from pydantic import BaseModel

from ..core.budget import RunGuard, estimate_tokens, truncate_to_tokens
from ..core.config import Settings
from ..core.offline_env import assert_local_url

T = TypeVar("T", bound=BaseModel)


class LLMError(RuntimeError):
    pass


@dataclass
class LLMResponse:
    text: str
    thinking: str = ""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    model: str = ""
    node: str = ""
    duration_s: float = 0.0
    done_reason: str = ""
    has_content: bool = True

    @property
    def truncated(self) -> bool:
        return self.done_reason == "length"


def extract_json(text: str) -> Any:
    decoder = json.JSONDecoder()
    for i, ch in enumerate(text):
        if ch in "{[":
            try:
                obj, _ = decoder.raw_decode(text, i)
            except ValueError:
                continue
            if isinstance(obj, (dict, list)):
                return obj
    raise ValueError("no JSON object found in model output")


class OllamaClient:
    def __init__(
        self,
        settings: Settings,
        guard: RunGuard | None = None,
        on_call: Callable[[dict[str, Any]], None] | None = None,
        on_start: Callable[[dict[str, Any]], None] | None = None,
        transport: httpx.BaseTransport | None = None,
    ):
        assert_local_url(settings.ollama.base_url)
        self.settings = settings
        self.guard = guard
        self.on_call = on_call
        self.on_start = on_start
        self._no_think: set[str] = set()
        self._gpu_checked: dict[str, float | None] = {}
        self.http = httpx.Client(
            base_url=settings.ollama.base_url,
            timeout=httpx.Timeout(settings.ollama.request_timeout_s, connect=10),
            transport=transport,
        )

    def list_models(self) -> list[str]:
        r = self.http.get("/api/tags")
        r.raise_for_status()
        return sorted(m["name"] for m in r.json().get("models", []))

    def model_sizes(self) -> dict[str, int]:
        r = self.http.get("/api/tags")
        r.raise_for_status()
        return {m["name"]: int(m.get("size", 0)) for m in r.json().get("models", [])}

    def show(self, model: str) -> dict[str, Any]:
        r = self.http.post("/api/show", json={"model": model})
        r.raise_for_status()
        return r.json()

    def running(self) -> list[dict[str, Any]]:
        r = self.http.get("/api/ps")
        r.raise_for_status()
        return r.json().get("models", [])

    def require_model(self, name: str) -> None:
        if name not in self.list_models():
            raise LLMError(f"model '{name}' is not pulled in Ollama")

    def _fit(self, messages: list[dict[str, str]], node: str) -> list[dict[str, str]]:
        budget = self.settings.prompt_tokens_for(node)
        msgs = [dict(m) for m in messages]
        for _ in range(6):
            sizes = [estimate_tokens(m["content"]) for m in msgs]
            excess = sum(sizes) - budget
            if excess <= 0:
                break
            idx = max(range(len(msgs)), key=lambda i: sizes[i])
            msgs[idx]["content"] = truncate_to_tokens(msgs[idx]["content"], max(256, sizes[idx] - excess), "middle")
        return msgs

    def _post(self, payload: dict[str, Any]) -> dict[str, Any]:
        last = ""
        for attempt in range(3):
            try:
                r = self.http.post("/api/chat", json=payload)
            except (httpx.TransportError, httpx.TimeoutException) as exc:
                last = repr(exc)
                time.sleep(2 * (attempt + 1))
                continue
            if r.status_code == 400 and "think" in r.text.lower() and "think" in payload:
                self._no_think.add(payload["model"])
                payload = {k: v for k, v in payload.items() if k != "think"}
                continue
            if r.status_code >= 500:
                last = f"HTTP {r.status_code}: {r.text[:200]}"
                time.sleep(2 * (attempt + 1))
                continue
            if r.status_code >= 400:
                raise LLMError(f"HTTP {r.status_code}: {r.text[:300]}")
            return r.json()
        raise LLMError(f"Ollama request failed: {last}")

    def _gpu_share(self, model: str) -> float | None:
        if model in self._gpu_checked:
            return None
        share = None
        try:
            entry = next((m for m in self.running() if m.get("name") == model), None)
            if entry and int(entry.get("size", 0)):
                share = round(int(entry.get("size_vram", 0)) / int(entry["size"]), 2)
        except Exception:
            share = None
        self._gpu_checked[model] = share
        return share

    def chat(
        self,
        node: str,
        messages: list[dict[str, str]],
        schema: dict[str, Any] | None = None,
        max_tokens: int | None = None,
        model: str | None = None,
        temperature: float | None = None,
        think: bool | None = None,
        effort: str | None = None,
    ) -> LLMResponse:
        if self.guard:
            self.guard.check()
        cfg = self.settings
        effort_in = effort
        effort: Any = (effort_in or cfg.effort_for(node)) if think is not False else False
        if effort == "off":
            effort = False
        budget = max_tokens or cfg.budget.max_output_tokens.get(node, 2000)
        resp = self._chat_once(node, messages, schema, budget, model, temperature, effort, retry=False)
        if resp.truncated and not resp.has_content:
            cap = max(budget, cfg.ollama.num_ctx // 3)
            retry_budget = min(int(budget * 2), cap)
            retry_effort = effort if effort is False else "low"
            if retry_budget > budget or retry_effort != effort:
                resp = self._chat_once(node, messages, schema, retry_budget, model, temperature, retry_effort, retry=True)
        return resp

    def _chat_once(
        self, node: str, messages: list[dict[str, str]], schema: dict[str, Any] | None, max_tokens: int,
        model: str | None, temperature: float | None, effort: str, retry: bool,
    ) -> LLMResponse:
        cfg = self.settings
        model = model or cfg.model_for(node)
        fitted = self._fit(messages, node)
        payload: dict[str, Any] = {
            "model": model,
            "messages": fitted,
            "stream": False,
            "keep_alive": cfg.ollama.keep_alive,
            "options": {
                "num_ctx": cfg.ollama.num_ctx,
                "temperature": cfg.ollama.temperature if temperature is None else temperature,
                "num_predict": max_tokens,
            },
        }
        if model not in self._no_think:
            payload["think"] = effort
        if schema:
            payload["format"] = schema
        if self.on_start:
            self.on_start({"node": node, "model": model, "prompt_tokens_est": sum(estimate_tokens(m["content"]) for m in fitted),
                           "max_tokens": max_tokens, "effort": effort, "retry": retry})
        start = time.monotonic()
        data = self._post(payload)
        msg = data.get("message", {})
        content, thinking = msg.get("content", "") or "", msg.get("thinking", "") or ""
        text = content if content.strip() else thinking
        resp = LLMResponse(
            text=text, thinking=thinking, model=model, node=node,
            prompt_tokens=int(data.get("prompt_eval_count", 0)),
            completion_tokens=int(data.get("eval_count", 0)),
            duration_s=round(time.monotonic() - start, 2), done_reason=data.get("done_reason", "") or "",
            has_content=bool(content.strip()),
        )
        if self.guard:
            self.guard.add_tokens(resp.prompt_tokens + resp.completion_tokens)
        gpu_share = self._gpu_share(model)
        if self.on_call:
            self.on_call({"gpu_share": gpu_share,
                "node": node, "model": model, "prompt_tokens": resp.prompt_tokens,
                "completion_tokens": resp.completion_tokens, "duration_s": resp.duration_s,
                "done_reason": resp.done_reason, "effort": effort, "max_tokens": max_tokens, "retry": retry,
                "output": content[:1800], "thinking": thinking[:900], "thinking_chars": len(thinking),
            })
        return resp

    def structured(
        self, node: str, messages: list[dict[str, str]], model_cls: type[T],
        max_tokens: int | None = None, retries: int | None = None, think: bool | None = None,
    ) -> tuple[T, LLMResponse]:
        retries = self.settings.limits.json_retries if retries is None else retries
        schema = model_cls.model_json_schema()
        msgs = list(messages)
        err = ""
        for _ in range(retries + 1):
            resp = self.chat(node, msgs, schema=schema, max_tokens=max_tokens, think=think)
            try:
                return model_cls.model_validate(extract_json(resp.text)), resp
            except ValueError as exc:
                err = str(exc)[:800]
                msgs = [
                    *messages,
                    {"role": "assistant", "content": resp.text[:2000]},
                    {"role": "user", "content": f"That JSON was invalid for the required schema: {err}\nReturn only the corrected JSON."},
                ]
        raise LLMError(f"no valid {model_cls.__name__} after {retries + 1} attempts: {err}")
