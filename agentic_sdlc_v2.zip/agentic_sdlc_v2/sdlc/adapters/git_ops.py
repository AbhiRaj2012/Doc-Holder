from __future__ import annotations

import os
import subprocess
from pathlib import Path

EXCLUDES = (".aider*", "__pycache__/", "*.pyc", ".pytest_cache/", ".ruff_cache/", ".mypy_cache/")


class GitError(RuntimeError):
    pass


class GitRepo:
    def __init__(self, path: str | Path, author_name: str = "sdlc-bot", author_email: str = "sdlc-bot@localhost"):
        self.path = Path(path).resolve()
        self.name = author_name
        self.email = author_email

    def run(self, *args: str, check: bool = True) -> str:
        env = {**os.environ, "GIT_TERMINAL_PROMPT": "0", "GIT_OPTIONAL_LOCKS": "0"}
        cmd = ["git", "-c", "core.quotepath=off", "-c", f"user.name={self.name}", "-c", f"user.email={self.email}",
               "-c", "commit.gpgsign=false", *args]
        r = subprocess.run(cmd, cwd=self.path, env=env, capture_output=True, text=True, errors="replace")
        if check and r.returncode != 0:
            raise GitError(f"git {' '.join(args)} failed: {r.stderr.strip()[:400]}")
        return r.stdout

    def ensure_repo(self) -> bool:
        created = False
        if not (self.path / ".git").exists():
            self.run("init", "-q")
            created = True
        self._exclude()
        if self.run("rev-parse", "--verify", "-q", "HEAD", check=False).strip() == "":
            self.commit_all("sdlc: initial snapshot", allow_empty=True)
        return created

    def _exclude(self, extra: tuple[str, ...] = ()) -> None:
        p = self.path / ".git" / "info" / "exclude"
        p.parent.mkdir(parents=True, exist_ok=True)
        existing = p.read_text(encoding="utf-8") if p.exists() else ""
        missing = [e for e in (*EXCLUDES, *extra) if e not in existing.splitlines()]
        if missing:
            p.write_text(existing.rstrip("\n") + "\n" + "\n".join(missing) + "\n", encoding="utf-8")

    def add_excludes(self, patterns: list[str]) -> None:
        self._exclude(tuple(patterns))

    def head(self) -> str:
        return self.run("rev-parse", "HEAD").strip()

    def current_branch(self) -> str:
        return self.run("rev-parse", "--abbrev-ref", "HEAD").strip()

    def is_dirty(self) -> bool:
        return bool(self.run("status", "--porcelain").strip())

    def create_run_branch(self, prefix: str, run_id: str) -> tuple[str, str]:
        branch = f"{prefix}{run_id}"
        if self.run("rev-parse", "--verify", "-q", f"refs/heads/{branch}", check=False).strip():
            self.run("checkout", "-q", branch)
        else:
            self.run("checkout", "-q", "-b", branch)
        if self.is_dirty():
            self.commit_all("sdlc: baseline snapshot")
        return branch, self.head()

    def commit_all(self, message: str, allow_empty: bool = False) -> str | None:
        self.run("add", "-A")
        if not allow_empty and not self.run("diff", "--cached", "--name-only").strip():
            return None
        args = ["commit", "-q", "--no-verify", "-m", message]
        if allow_empty:
            args.append("--allow-empty")
        self.run(*args)
        return self.head()

    def snapshot(self) -> str:
        self.run("add", "-A")
        return self.run("write-tree").strip()

    @staticmethod
    def _cap(text: str, max_chars: int) -> str:
        return text if len(text) <= max_chars else text[:max_chars] + "\n...[diff truncated]...\n"

    def diff_trees(self, a: str, b: str, max_chars: int = 60000) -> str:
        return self._cap(self.run("diff", "--no-color", a, b), max_chars)

    def changed_between(self, a: str, b: str) -> list[str]:
        return [x for x in self.run("diff", "--name-only", a, b).splitlines() if x]

    def diff_since(self, commit: str, paths: list[str] | None = None, max_chars: int = 60000) -> str:
        self.run("add", "-A")
        args = ["diff", "--cached", "--no-color", commit]
        if paths:
            args += ["--", *paths]
        return self._cap(self.run(*args), max_chars)

    def changed_since(self, commit: str) -> list[str]:
        self.run("add", "-A")
        return [x for x in self.run("diff", "--cached", "--name-only", commit).splitlines() if x]

    def reset_to(self, commit: str) -> None:
        self.run("reset", "-q", "--hard", commit)
        self.run("clean", "-fdq")

    def restore_paths(self, tree: str, paths: list[str]) -> None:
        for rel in paths:
            exists = subprocess.run(
                ["git", "cat-file", "-e", f"{tree}:{rel}"], cwd=self.path, capture_output=True,
            ).returncode == 0
            if exists:
                self.run("checkout", tree, "--", rel)
            else:
                (self.path / rel).unlink(missing_ok=True)
        self.run("add", "-A")

    def exists_in(self, tree: str, rel: str) -> bool:
        return subprocess.run(["git", "cat-file", "-e", f"{tree}:{rel}"], cwd=self.path, capture_output=True).returncode == 0

    def show_file(self, commit: str, rel: str) -> str:
        return self.run("show", f"{commit}:{rel}", check=False)
