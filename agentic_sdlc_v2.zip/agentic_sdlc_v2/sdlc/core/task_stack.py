from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from .config import LimitsCfg
from .schemas import SuspendReason, TaskFrame
from .state import mark_blocked_dependents

TERMINAL = ("completed", "skipped", "blocked")
SHRINK_ACTIONS = {1: "trim", 2: "narrow", 3: "split"}


class StackManager:
    def __init__(self, tasks: list[dict[str, Any]], frames: list[dict[str, Any]], limits: LimitsCfg):
        self.tasks = tasks
        self.frames = frames
        self.limits = limits

    @classmethod
    def from_state(cls, state: dict[str, Any], limits: LimitsCfg) -> "StackManager":
        return cls([dict(t) for t in state.get("tasks", [])], [dict(f) for f in state.get("suspended", [])], limits)

    def to_state(self) -> dict[str, Any]:
        return {"tasks": self.tasks, "suspended": self.frames}

    def save(self, path: Path) -> None:
        path.write_text(json.dumps(self.to_state(), indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: Path, limits: LimitsCfg) -> "StackManager":
        data = json.loads(path.read_text(encoding="utf-8"))
        return cls(data["tasks"], data["suspended"], limits)

    def get(self, task_id: str) -> dict[str, Any] | None:
        return next((t for t in self.tasks if t["id"] == task_id), None)

    def _deps_done(self, task: dict[str, Any]) -> bool:
        return all((self.get(d) or {}).get("status") == "completed" for d in task.get("depends_on", []))

    def reconcile(self) -> None:
        changed = True
        while changed:
            changed = False
            for t in self.tasks:
                if t["status"] != "split":
                    continue
                kids = [k for k in self.tasks if k.get("parent_id") == t["id"]]
                if kids and all(k["status"] == "completed" for k in kids):
                    t["status"] = "completed"
                    changed = True
                elif any(k["status"] in ("skipped", "blocked") for k in kids):
                    t["status"] = "skipped"
                    changed = True
            mark_blocked_dependents(self.tasks)

    def pick_next(self) -> tuple[str, dict[str, Any] | None, dict[str, Any] | None]:
        self.reconcile()
        while self.frames:
            frame = self.frames.pop()
            task = self.get(frame["task_id"])
            if task is None or task["status"] in TERMINAL or task["status"] == "split":
                continue
            task["status"] = "in_progress"
            return "frame", task, frame
        for t in self.tasks:
            if t["status"] == "pending" and self._deps_done(t):
                t["status"] = "in_progress"
                return "task", t, None
        for t in self.tasks:
            if t["status"] == "pending":
                t["status"] = "blocked"
        return "none", None, None

    def suspend(
        self, task_id: str, reason: SuspendReason, step: str = "edit", iteration: int = 0, base_tree: str = "",
        open_issue_ids: list[str] | None = None, scope_files: list[str] | None = None,
        scope_symbols: list[str] | None = None, note: str = "", shrink: bool = True,
    ) -> TaskFrame | None:
        task = self.get(task_id)
        if task is None:
            return None
        level = task.get("shrink_level", 0) + (1 if shrink else 0)
        if level > self.limits.max_shrink_level or len(self.frames) >= self.limits.max_suspended_frames:
            return None
        attempts = 1 + sum(1 for f in self.frames if f["task_id"] == task_id)
        frame = TaskFrame(
            task_id=task_id, step=step, reason=reason, iteration=iteration, base_tree=base_tree,  # type: ignore[arg-type]
            open_issue_ids=open_issue_ids or [], scope_files=scope_files or [], scope_symbols=scope_symbols or [],
            shrink_level=level, attempts=attempts, note=note, created_at=time.strftime("%Y-%m-%dT%H:%M:%S"),
        )
        task["shrink_level"] = level
        task["status"] = "suspended"
        self.frames.append(frame.model_dump(mode="json"))
        return frame

    @staticmethod
    def action_for(frame: dict[str, Any]) -> str:
        return SHRINK_ACTIONS.get(frame.get("shrink_level", 0), "resume")

    def split(self, task_id: str, subtasks: list[dict[str, Any]]) -> list[str]:
        parent = self.get(task_id)
        if parent is None or not subtasks:
            return []
        ids: list[str] = []
        prev: str | None = None
        for n, sub in enumerate(subtasks, 1):
            child = dict(sub)
            child["id"] = f"{task_id}.{n}"
            child["parent_id"] = task_id
            child["status"] = "pending"
            child["shrink_level"] = 0
            child["depends_on"] = list(parent.get("depends_on", [])) + ([prev] if prev else [])
            ids.append(child["id"])
            prev = child["id"]
            self.tasks.insert(self.tasks.index(parent) + n, child)
        parent["status"] = "split"
        self.frames = [f for f in self.frames if f["task_id"] != task_id]
        return ids

    def complete(self, task_id: str) -> None:
        task = self.get(task_id)
        if task:
            task["status"] = "completed"
            self.frames = [f for f in self.frames if f["task_id"] != task_id]
            self.reconcile()

    def skip(self, task_id: str) -> None:
        affected = {task_id} | {t["id"] for t in self.tasks if t.get("parent_id") == task_id}
        for t in self.tasks:
            if t["id"] in affected and t["status"] not in ("completed",):
                t["status"] = "skipped"
        self.frames = [f for f in self.frames if f["task_id"] not in affected]
        self.reconcile()

    def recover_crash(self) -> int:
        n = 0
        for t in self.tasks:
            if t["status"] == "in_progress":
                if self.suspend(t["id"], SuspendReason.CRASH, note="recovered after restart", shrink=False):
                    n += 1
        return n

    def finished(self) -> bool:
        self.reconcile()
        return not self.frames and all(t["status"] in TERMINAL or t["status"] == "split" for t in self.tasks)

    def counts(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for t in self.tasks:
            out[t["status"]] = out.get(t["status"], 0) + 1
        out["frames"] = len(self.frames)
        return out
