from __future__ import annotations

import json
import re
import shlex
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from .config import CONFIG_DIR
from .offline_env import default_python

OPERATORS = {"&&", "||", ";", "|", "&"}
ASSIGN = re.compile(r"^[A-Za-z_]\w*=")
REDIRECT_OK = {"/dev/null", "1", "2", "&1", "&2"}
NPM_SUBCOMMANDS = {"test", "t", "run", "run-script"}
NON_VERIFYING = {"cat", "ls", "echo", "true", "head", "tail", "type", "dir", "pwd", "printf", "less", "more"}


def load_policy_config() -> dict[str, Any]:
    return yaml.safe_load((CONFIG_DIR / "command_allowlist.yaml").read_text(encoding="utf-8"))


def load_approved(path: Path) -> set[str]:
    if not path.exists():
        return set()
    return set(json.loads(path.read_text(encoding="utf-8")))


def save_approved(path: Path, approved: set[str]) -> None:
    path.write_text(json.dumps(sorted(approved), indent=2), encoding="utf-8")


@dataclass
class PolicyResult:
    ok: bool
    command: str
    kind: str = "ok"
    reason: str = ""
    executable: str = ""
    notes: list[str] = field(default_factory=list)

    def feedback(self, allowed: list[str]) -> str:
        return (
            f"The verify command was rejected ({self.kind}): {self.reason}\n"
            f"Use only these tools: {', '.join(allowed)}. Prefer the project's own test command."
        )


@dataclass
class Resolution:
    command: str | None
    source: str
    event: dict[str, Any] | None = None
    needs_human: bool = False
    proposals: list[str] = field(default_factory=list)


class CommandPolicy:
    def __init__(self, repo: str | Path, language: str, python: str | None = None,
                 extra_allow: list[str] | None = None, approved: set[str] | None = None):
        self.repo = Path(repo).resolve()
        self.language = language
        self.python = python or default_python()
        self.cfg = load_policy_config()
        self.allowed = set(self.cfg["common"]) | set(self.cfg.get(language, [])) | set(extra_allow or []) | set(approved or [])
        self.denied = set(self.cfg["deny_executables"])
        self.patterns = [re.compile(p) for p in self.cfg["deny_patterns"]]
        self.scripts = set(self.cfg["script_runners"])

    def allowed_for_prompt(self) -> list[str]:
        return sorted(self.allowed)

    def _inside(self, rel: str) -> Path | None:
        p = (self.repo / rel).resolve()
        return p if p == self.repo or self.repo in p.parents else None

    def _tokenize(self, command: str) -> tuple[list[dict[str, Any]], str]:
        lex = shlex.shlex(command, posix=True, punctuation_chars=True)
        lex.whitespace_split = True
        tokens = list(lex)
        segments: list[dict[str, Any]] = []
        cur: dict[str, Any] = {"args": [], "redir": [], "op": ""}
        i = 0
        while i < len(tokens):
            t = tokens[i]
            if t in OPERATORS:
                cur["op"] = t
                segments.append(cur)
                cur = {"args": [], "redir": [], "op": ""}
            elif t in ("(", ")"):
                return [], "subshells are not supported"
            elif set(t) <= set("<>&") and ("<" in t or ">" in t):
                target = tokens[i + 1] if i + 1 < len(tokens) else ""
                if target not in REDIRECT_OK:
                    return [], "redirects are only allowed to /dev/null or 2>&1"
                prefix = cur["args"].pop() if cur["args"] and cur["args"][-1].isdigit() else ""
                cur["redir"].append(f"{prefix}{t}{target}")
                i += 1
            else:
                cur["args"].append(t)
            i += 1
        segments.append(cur)
        return [s for s in segments if s["args"]], ""

    def _normalise(self, args: list[str], notes: list[str]) -> list[str]:
        exe, rest = args[0], args[1:]
        if exe in ("python", "python3", "py"):
            if exe != self.python:
                notes.append(f"{exe} -> {self.python}")
            return [self.python, *rest]
        if exe == "pytest":
            notes.append("pytest -> python -m pytest")
            return [self.python, "-m", "pytest", *rest]
        if exe in ("gradle", "./gradlew", "gradlew"):
            wrapper = (self.repo / "gradlew").exists()
            out = ["bash", "./gradlew", *rest] if wrapper else ["gradle", *rest]
            if "--offline" not in out:
                out.append("--offline")
                notes.append("added --offline")
            return out
        if exe == "mvn" and "-o" not in rest and "--offline" not in rest:
            notes.append("added -o")
            return ["mvn", "-o", *rest]
        if exe == "npx" and "--no-install" not in rest:
            notes.append("added --no-install")
            return ["npx", "--no-install", *rest]
        return args

    def _check_segment(self, args: list[str]) -> tuple[str, str, str]:
        exe = args[0]
        if exe in self.denied:
            return "denied", f"'{exe}' is never allowed in verify commands", exe
        if exe == "cd":
            target = args[1] if len(args) > 1 else ""
            return ("ok", "", exe) if target and self._inside(target) else ("denied", "cd must stay inside the repository", exe)
        if exe in self.scripts:
            script = next((a for a in args[1:] if not a.startswith("-")), "")
            p = self._inside(script) if script else None
            if p and p.is_file():
                return "ok", "", exe
            return "denied", f"'{exe}' may only run an existing script inside the repository", exe
        if "/" in exe:
            if exe == self.python:
                return "ok", "", exe
            p = self._inside(exe)
            if p and p.exists():
                return "ok", "", exe
            return "not_allowed", f"executable path '{exe}' is not inside the repository", exe
        if exe not in self.allowed:
            return "not_allowed", f"'{exe}' is not in the allowlist for {self.language}", exe
        if exe == "npm":
            sub = next((a for a in args[1:] if not a.startswith("-")), "")
            if sub not in NPM_SUBCOMMANDS:
                return "not_allowed", f"'npm {sub}' is not allowed; use npm test or npm run <script>", f"npm {sub}".strip()
        for a in args[1:]:
            if a.startswith("-") or not a:
                continue
            if a.startswith(("/", "~")) or ".." in Path(a).parts:
                if a == "/dev/null":
                    continue
                return "denied", f"path '{a}' escapes the repository", exe
        return "ok", "", exe

    def check(self, command: str) -> PolicyResult:
        raw = (command or "").strip()
        if not raw:
            return PolicyResult(False, "", "empty", "no command given")
        if "`" in raw or "$(" in raw:
            return PolicyResult(False, raw, "denied", "command substitution is not allowed")
        for pat in self.patterns:
            if pat.search(raw):
                return PolicyResult(False, raw, "denied", f"matches blocked pattern {pat.pattern}")
        try:
            segments, err = self._tokenize(raw)
        except ValueError:
            return PolicyResult(False, raw, "denied", "malformed quoting")
        if err or not segments:
            return PolicyResult(False, raw, "denied", err or "no executable found")
        notes: list[str] = []
        parts: list[str] = []
        exes: list[str] = []
        ops: list[str] = []
        for seg in segments:
            args = list(seg["args"])
            env: list[str] = []
            while args and ASSIGN.match(args[0]):
                env.append(args.pop(0))
            if not args:
                return PolicyResult(False, raw, "denied", "environment assignment without a command")
            args = self._normalise(args, notes)
            script = next((a for a in args[1:] if a.endswith(".py")), "") if "python" in args[0] and "-m" not in args else ""
            if script and (self.repo / script).parent.joinpath("__init__.py").exists():
                return PolicyResult(False, raw, "not_a_check", f"{script} is a module inside a package; run directly its package imports fail, so it cannot verify anything", notes=notes)
            kind, reason, exe = self._check_segment(args)
            if kind != "ok":
                return PolicyResult(False, raw, kind, reason, exe, notes)
            exes.append(exe)
            ops.append(seg["op"] or "")
            parts.append(" ".join([*env, shlex.join(args), *seg["redir"]]))
        if exes and all(e in NON_VERIFYING for e in exes):
            return PolicyResult(False, raw, "not_a_check", "this command only prints output and can never fail; use a build, compile or test command", notes=notes)
        if any(e in NON_VERIFYING for e in exes) and set(ops) <= {"&&", ";", ""}:
            dropped = [p for p, e in zip(parts, exes) if e in NON_VERIFYING]
            notes.append("dropped print-only steps: " + "; ".join(dropped))
            final = " && ".join(p for p, e in zip(parts, exes) if e not in NON_VERIFYING)
        else:
            final = " ".join(p + (f" {o}" if o else "") for p, o in zip(parts, ops))
        for pat in self.patterns:
            if pat.search(final):
                return PolicyResult(False, raw, "denied", f"matches blocked pattern {pat.pattern}", notes=notes)
        return PolicyResult(True, final, notes=notes)

    def resolve_verify(self, command: str | None, default_test: str | None) -> Resolution:
        if not (command or "").strip():
            return Resolution(default_test, "default" if default_test else "none")
        res = self.check(command or "")
        if res.ok:
            return Resolution(res.command, "planner")
        event = {"type": "policy_violation", "command": command, "kind": res.kind, "reason": res.reason, "executable": res.executable}
        if res.kind == "not_a_check":
            return Resolution(default_test, "default" if default_test else "none", event, False, [])
        proposals = [res.executable] if res.kind == "not_allowed" and res.executable else []
        if default_test:
            return Resolution(default_test, "default", event, False, proposals)
        return Resolution(None, "none", event, True, proposals)
