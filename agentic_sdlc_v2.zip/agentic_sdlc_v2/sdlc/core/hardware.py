from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import yaml

from .config import CONFIG_DIR, Settings, _deep_merge

GIB = 1024 ** 3
MIN_CTX = 4096
CTX_STEP = 1024
KV_BYTES = {"f16": 2.0, "q8_0": 1.0625, "q4_0": 0.5625}


@dataclass
class ModelArch:
    name: str
    weights_gb: float
    layers: int
    kv_heads: int
    head_dim: int
    max_ctx: int

    def kv_per_token(self, kv_type: str) -> float:
        return 2 * self.layers * self.kv_heads * self.head_dim * KV_BYTES[kv_type]


def parse_arch(name: str, show: dict[str, Any], size_bytes: int) -> ModelArch:
    info = show.get("model_info", {})
    arch = info.get("general.architecture", "")

    def get(key: str, default: float = 0) -> float:
        return float(info.get(f"{arch}.{key}", default))

    layers = int(get("block_count"))
    heads = int(get("attention.head_count"))
    kv_heads = int(get("attention.head_count_kv", heads))
    head_dim = int(get("attention.key_length", 0)) or (int(get("embedding_length")) // max(heads, 1))
    if not (layers and kv_heads and head_dim):
        raise ValueError(f"cannot read model architecture for {name} from /api/show")
    return ModelArch(name, size_bytes / GIB, layers, kv_heads, head_dim, int(get("context_length", 131072)))


def derive_context(gpu_gb: float, arch: ModelArch, kv_type: str, overhead_gb: float, override: int | None = None) -> tuple[int, list[str]]:
    warnings: list[str] = []
    free = gpu_gb - arch.weights_gb - overhead_gb
    if free <= 0 and overhead_gb > 0.5:
        warnings.append(f"tight fit: {arch.name} ({arch.weights_gb:.1f} GB) leaves little room in {gpu_gb:g} GB; assuming 0.5 GB overhead")
        free = gpu_gb - arch.weights_gb - 0.5
    if free <= 0:
        return 0, [f"{arch.name} ({arch.weights_gb:.1f} GB) does not fit in {gpu_gb:g} GB; set the model GPU footprint if only part of it sits in VRAM"]
    fit = int(0.90 * free * GIB / arch.kv_per_token(kv_type)) // CTX_STEP * CTX_STEP
    fit = min(fit, arch.max_ctx)
    if fit < MIN_CTX:
        warnings.append(f"only {fit} tokens of context fit; choose a smaller model, lower-bit KV cache or more VRAM")
        return fit, warnings
    ctx = fit
    if override:
        ctx = min(max(MIN_CTX, override // CTX_STEP * CTX_STEP), arch.max_ctx)
        if ctx > fit:
            warnings.append(f"requested context {ctx} exceeds the estimated fit {fit}; expect CPU offload")
    return ctx, warnings


def _clamp(v: float, lo: int, hi: int) -> int:
    return int(max(lo, min(hi, v)))


def derive_budgets(ctx: int) -> dict[str, Any]:
    step_lines = 200 if ctx >= 24000 else 120 if ctx >= 12000 else 60
    return {
        "ollama": {"num_ctx": ctx},
        "budget": {
            "max_output_tokens": {
                "planner": _clamp(0.18 * ctx, 512, 8000),
                "editor": _clamp(0.22 * ctx, 1500, 6000),
                "reviewer": _clamp(0.12 * ctx, 800, 3000),
                "judge": _clamp(0.10 * ctx, 400, 4000),
            },
            "max_file_prompt_bytes": int(ctx * 0.35 * 3.5),
            "step_max_lines": step_lines,
        },
        "aider": {"map_tokens": _clamp(0.04 * ctx, 256, 2048), "whole_max_bytes": min(12000, int(ctx * 0.15 * 3.5))},
    }


def apply_profile(settings: Settings, arch: ModelArch) -> tuple[Settings, list[str]]:
    hw = settings.hardware
    ctx, warnings = derive_context(hw.gpu_vram_gb, arch, hw.kv_cache_type, hw.overhead_gb, hw.context_override)
    if ctx < MIN_CTX:
        ctx = 2 * MIN_CTX
        warnings.append(f"starting from num_ctx={ctx} and letting calibration adjust it")
    merged = _deep_merge(settings.model_dump(), derive_budgets(ctx))
    return Settings.model_validate(merged), warnings


def offload_reduction(ps_entry: dict[str, Any], ctx: int) -> int | None:
    size, vram = int(ps_entry.get("size", 0)), int(ps_entry.get("size_vram", 0))
    if size and vram < size * 0.97:
        return max(MIN_CTX, (ctx * 3 // 4) // CTX_STEP * CTX_STEP)
    return None


def sizing_arch(client: Any, settings: Settings) -> tuple[ModelArch, list[str]]:
    hw = settings.hardware
    best: tuple[int, ModelArch] | None = None
    notes: list[str] = []
    for model in settings.run_models():
        arch = fetch_arch(client, model, hw.model_gpu_gb if model == settings.ollama.main_model else None)
        ctx, _ = derive_context(hw.gpu_vram_gb, arch, hw.kv_cache_type, hw.overhead_gb, hw.context_override)
        notes.append(f"{model}: fits num_ctx={ctx}")
        if best is None or ctx < best[0]:
            best = (ctx, arch)
    assert best is not None
    if len(notes) > 1:
        notes.append(f"context sized for the most demanding model: {best[1].name}")
    return best[1], notes


def calibrate(client: Any, settings: Settings, max_rounds: int = 6, model: str | None = None) -> tuple[Settings, list[str]]:
    notes: list[str] = []
    current = settings
    prev: tuple[float, Settings] | None = None
    model = model or settings.ollama.main_model
    for _ in range(max_rounds):
        client.settings = current
        client.chat("analyser", [{"role": "user", "content": "ok"}], max_tokens=1, model=model)
        entry = next((m for m in client.running() if m.get("name") == model), None)
        new_ctx = offload_reduction(entry, current.ollama.num_ctx) if entry else None
        if new_ctx is None or new_ctx >= current.ollama.num_ctx:
            return current, notes
        frac = int(entry.get("size_vram", 0)) / max(int(entry.get("size", 1)), 1)
        if prev is not None and frac <= prev[0] + 0.01:
            notes.append(f"CPU share does not shrink with context (part of the model is CPU-resident); keeping num_ctx={prev[1].ollama.num_ctx}")
            return prev[1], notes
        notes.append(f"CPU offload detected at num_ctx={current.ollama.num_ctx} ({frac:.0%} on GPU); reducing to {new_ctx}")
        prev = (frac, current)
        current = Settings.model_validate(_deep_merge(current.model_dump(), derive_budgets(new_ctx)))
    return current, notes


def fetch_arch(client: Any, model: str, weights_gb: float | None = None) -> ModelArch:
    arch = parse_arch(model, client.show(model), client.model_sizes().get(model, 0))
    if weights_gb:
        arch.weights_gb = float(weights_gb)
    return arch


def load_presets() -> list[dict[str, Any]]:
    return yaml.safe_load((CONFIG_DIR / "hardware_presets.yaml").read_text(encoding="utf-8"))["presets"]
