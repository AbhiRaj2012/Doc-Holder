from __future__ import annotations

from typing import Any

VIEW_KEYS = ("id", "title", "description", "kind", "language", "target_files", "acceptance_criteria", "verify_command", "depends_on")


def plan_view(task: dict[str, Any]) -> dict[str, Any]:
    return {k: task.get(k) for k in VIEW_KEYS}


def remove_tasks(tasks: list[dict[str, Any]], ids: list[str], protected: set[str] | None = None) -> tuple[list[dict[str, Any]], list[str]]:
    gone = {i.strip() for i in ids if i and i.strip()} - (protected or set())
    gone &= {t["id"] for t in tasks}
    kept = []
    for t in tasks:
        if t["id"] in gone:
            continue
        t = dict(t)
        t["depends_on"] = [d for d in t.get("depends_on", []) if d not in gone]
        kept.append(t)
    return kept, sorted(gone)


def feedback_block(hint: str, previous: list[dict[str, Any]]) -> str:
    rows = "\n".join(f"- {t['id']}: {t['title']} (files: {', '.join(t.get('target_files') or []) or 'none'})" for t in previous)
    return f"\n\nHUMAN FEEDBACK ON THE PREVIOUS PLAN (must be addressed in the new plan):\n{hint.strip()}\n\nPREVIOUS PLAN:\n{rows}"
