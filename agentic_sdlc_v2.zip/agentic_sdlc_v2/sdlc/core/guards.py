from __future__ import annotations

import ast
import importlib.util
import re
import sys
from collections import Counter
from pathlib import Path, PurePosixPath

from ..runners.registry import config_files, source_files
from . import py_contracts
from . import symbols as sym

FRAMEWORK_HEADERS = ("gtest/", "gmock/", "catch2/", "catch.hpp", "doctest")
JS_EXT = ("", ".js", ".mjs", ".cjs", ".ts", ".jsx", ".tsx", ".json", "/index.js", "/index.ts")


def _leaf(name: str) -> str:
    return re.split(r"[.:]+", name)[-1]


def _norm(name: str) -> str:
    return re.sub(r"::|\.", ".", name).strip(".")


def removed_symbols(path: str, old: str, new: str) -> list[str]:
    lang = sym.lang_for(path)
    if not lang or not old:
        return []
    before = {_norm(s.name) for s in sym.extract(lang, old)}
    after = {_norm(s.name) for s in sym.extract(lang, new)}
    return sorted(n for n in before - after if len(_leaf(n)) > 2)


def referenced_in(repo: Path, name: str, skip_comments: bool = True) -> str:
    pat = re.compile(rf"\b{re.escape(name)}\b")
    for rel in source_files(repo):
        try:
            text = (repo / rel).read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        if skip_comments:
            text = re.sub(r"//[^\n]*|#(?!include)[^\n]*|/\*.*?\*/", "", text, flags=re.S)
        if pat.search(text):
            return rel
    return ""


def project_names(repo: Path, exclude: str = "") -> set[str]:
    names: set[str] = set()
    for rel in source_files(repo)[:1500]:
        if rel == exclude:
            continue
        lang = sym.lang_for(rel)
        if not lang or lang in ("css", "html"):
            continue
        try:
            text = (repo / rel).read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        names |= {_leaf(s.name) for s in sym.extract(lang, text)}
    return {n for n in names if len(n) > 2}


def dropped_uses(repo: Path, task_text: str, changes: list[tuple[str, str, str]]) -> list[str]:
    problems = []
    low = task_text.lower()
    for path, old, new in changes:
        lang = sym.lang_for(path)
        if not old or not lang or lang in ("css", "html"):
            continue
        gone = sym.identifiers(lang, old) - sym.identifiers(lang, new)
        if not gone:
            continue
        lost = sorted(n for n in gone & project_names(repo, exclude=path) if not re.search(rf"\b{re.escape(n.lower())}\b", low))
        if lost:
            problems.append(f"{path} no longer uses {', '.join(f'`{n}`' for n in lost[:6])} (used before this edit); keep the existing lines and only add what the task asks")
    return problems


def destructive(repo: Path, task_text: str, changes: list[tuple[str, str, str]]) -> list[str]:
    problems = []
    low = task_text.lower()
    for path, old, new in changes:
        for name in removed_symbols(path, old, new):
            owner, leaf = (name.split(".")[0], _leaf(name)) if "." in name else ("", name)
            used = referenced_in(repo, owner or leaf)
            name = name.replace(".", "::") if sym.lang_for(path) in ("c", "cpp") else name
            mentioned = re.search(rf"\b{re.escape(leaf.lower())}\b", low) or name.lower() in low
            if used or not mentioned:
                why = f"still used in {used}" if used else "not mentioned by the task"
                problems.append(f"`{name}` was removed from {path} ({why}); keep existing code and only add or change what the task asks")
    return problems


def _declared(repo: Path, word: str) -> bool:
    for rel in config_files(repo):
        try:
            if word.lower() in (repo / rel).read_text(encoding="utf-8", errors="ignore").lower():
                return True
        except OSError:
            continue
    return False


HEADER_EXT = (".h", ".hh", ".hpp", ".hxx")


def _headers_for(repo: Path, text: str, limit: int = 2) -> list[str]:
    used = set(re.findall(r"\b[A-Z]\w{2,}\b", text))
    hits: list[str] = []
    for f in source_files(repo):
        if not f.endswith(HEADER_EXT):
            continue
        lang = sym.lang_for(f)
        names = {s.name.split("::")[-1] for s in sym.extract(lang, (repo / f).read_text(encoding="utf-8", errors="ignore"))} if lang else set()
        if used & names:
            hits.append(f)
    return hits[:limit]


def _include_path(repo: Path, path: str, header: str) -> str:
    here = PurePosixPath(path).parent
    try:
        return str(PurePosixPath(*([".."] * len(here.parts)), header)) if here.parts else header
    except ValueError:
        return header


def _c_includes(repo: Path, path: str, text: str) -> list[str]:
    out = []
    here = (repo / path).parent
    files = None
    for m in re.finditer(r'^\s*#\s*include\s*([<"])([^>"]+)[>"]', text, re.M):
        kind, inc = m.groups()
        if kind == "<" or any(f in inc for f in FRAMEWORK_HEADERS):
            continue
        if (here / inc).exists() or (repo / inc).exists():
            continue
        if files is None:
            files = [f for f in source_files(repo)]
        if not any(f == inc or f.endswith("/" + inc) for f in files):
            hint = ", ".join(f'"{_include_path(repo, path, h)}" ({h})' for h in _headers_for(repo, text))
            out.append(f'#include "{inc}": no such file in the project' + (f"; the names you use are declared in {hint}" if hint else ""))
    return out


def _py_local_tops(repo: Path) -> dict[str, list[str]]:
    tops: dict[str, list[str]] = {}
    for f in source_files(repo):
        if not f.endswith(".py"):
            continue
        root = _py_root(repo, f)
        rel = PurePosixPath(f).relative_to(root) if root else PurePosixPath(f)
        name = rel.parts[0][:-3] if rel.parts[0].endswith(".py") else rel.parts[0]
        if root not in tops.setdefault(name, []):
            tops[name].append(root)
    return tops


def local_module_names(repo: Path) -> set[str]:
    names = set(_py_local_tops(repo))
    for f in source_files(repo):
        p = PurePosixPath(f)
        names.update(p.parts[:-1])
        names.add(p.stem)
    return names


def _py_root(repo: Path, path: str) -> str:
    parent = PurePosixPath(path).parent
    while str(parent) not in ("", ".") and (repo / str(parent) / "__init__.py").exists():
        parent = parent.parent
    return "" if str(parent) == "." else str(parent)


def _py_resolve(repo: Path, path: str, module: str) -> tuple[Path | None, bool]:
    parts = module.split(".")
    roots = [repo, repo / "src", repo / _py_root(repo, path), (repo / path).parent]
    local = False
    for root in roots:
        base = root.joinpath(*parts)
        if base.with_suffix(".py").is_file():
            return base.with_suffix(".py"), True
        if (base / "__init__.py").is_file():
            return base / "__init__.py", True
        if base.is_dir():
            return base, True
        local = local or (root / parts[0]).is_dir() or (root / f"{parts[0]}.py").is_file()
    return None, local


def _py_names(file: Path) -> set[str] | None:
    try:
        tree = ast.parse(file.read_text(encoding="utf-8", errors="replace"))
    except (SyntaxError, OSError):
        return None
    names: set[str] = set()

    def visit(body: list[ast.stmt]) -> bool:
        for node in body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                names.add(node.name)
            elif isinstance(node, (ast.Assign, ast.AnnAssign)):
                for t in (node.targets if isinstance(node, ast.Assign) else [node.target]):
                    names.update(n.id for n in ast.walk(t) if isinstance(n, ast.Name))
            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                if isinstance(node, ast.ImportFrom) and any(a.name == "*" for a in node.names):
                    return False
                names.update((a.asname or a.name).split(".")[0] for a in node.names)
            elif isinstance(node, (ast.If, ast.Try, ast.With)):
                subs = [node.body, getattr(node, "orelse", []), getattr(node, "finalbody", []), *[h.body for h in getattr(node, "handlers", [])]]
                if not all(visit(b) for b in subs):
                    return False
        return True

    return names if visit(tree.body) else None


def _py_module_of(repo: Path, rel: str) -> str:
    root = _py_root(repo, rel)
    p = PurePosixPath(rel).relative_to(root) if root else PurePosixPath(rel)
    parts = list(p.with_suffix("").parts)
    if parts[-1] == "__init__":
        parts.pop()
    return ".".join(parts)


def _py_definers(repo: Path, name: str, limit: int = 2) -> list[str]:
    hits = []
    for f in source_files(repo):
        if f.endswith(".py") and name in (_py_names(repo / f) or set()) and not re.search(r"(^|/)test_[^/]*\.py$", f):
            text = (repo / f).read_text(encoding="utf-8", errors="ignore")
            if re.search(rf"^(?:class|def|async def)\s+{re.escape(name)}\b|^{re.escape(name)}\s*[:=]", text, re.M):
                hits.append(f)
    return hits[:limit]


def _py_symbol_imports(repo: Path, path: str, tree: ast.AST, flexible: bool) -> list[str]:
    out = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and not node.level and node.module:
            target, local = _py_resolve(repo, path, node.module)
            wanted = [a.name for a in node.names if a.name != "*"]
            if target is None:
                if local and not flexible:
                    hint = "; ".join(f"`{n}` is in {d} (from {_py_module_of(repo, d)} import {n})" for n in wanted for d in _py_definers(repo, n)[:1])
                    out.append(f"`from {node.module} import ...`: no module {node.module} in the project" + (f"; {hint}" if hint else ""))
                continue
            if target.is_dir():
                continue
            have = _py_names(target)
            if have is None:
                continue
            for n in wanted:
                if n in have or (target.parent / f"{n}.py").is_file() or (target.parent / n).is_dir():
                    continue
                where = [d for d in _py_definers(repo, n) if (repo / d).resolve() != target.resolve()]
                rel = target.relative_to(repo).as_posix()
                out.append(f"`{n}` is not defined in {rel}" + (f"; it is in {where[0]} (from {_py_module_of(repo, where[0])} import {n})" if where else "; it does not exist anywhere in the project, so use only names that exist"))
    return out


def _py_contracts(repo: Path, path: str, tree: ast.Module) -> list[str]:
    classes = dict(py_contracts.classes_in(tree))
    here = (repo / path).parent
    for node in tree.body:
        if not isinstance(node, ast.ImportFrom):
            continue
        if node.level:
            base = here
            for _ in range(node.level - 1):
                base = base.parent
            target = base.joinpath(*(node.module or "").split(".")) if node.module else base / "__init__"
            target = target.with_suffix(".py") if target.with_suffix(".py").is_file() else target / "__init__.py"
        elif node.module:
            target, _local = _py_resolve(repo, path, node.module)
        else:
            continue
        if target is None or not target.is_file():
            continue
        other = py_contracts.classes_in(t) if (t := py_contracts._parse(target)) else {}
        for a in node.names:
            if a.name in other:
                classes[a.asname or a.name] = other[a.name]
    known: set[str] = set()
    for f in source_files(repo):
        if f.endswith(".py") and f != path:
            known.update(re.findall(r"[A-Za-z_]\w*", (repo / f).read_text(encoding="utf-8", errors="ignore")))
    return py_contracts.violations(tree, classes) + py_contracts.self_attribute_violations(tree, classes, known)


def _py_imports(repo: Path, path: str, text: str) -> list[str]:
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return []
    out = []
    here = (repo / path).parent
    tops = None
    flexible = "sys.path" in text or any(f.endswith("conftest.py") for f in source_files(repo)) or any("pythonpath" in (repo / c).read_text(encoding="utf-8", errors="ignore") for c in ("pytest.ini", "pyproject.toml", "setup.cfg", "tox.ini") if (repo / c).is_file())
    reachable = {"", "src", _py_root(repo, path)}
    for node in ast.walk(tree):
        names = [node.module] if isinstance(node, ast.ImportFrom) and not node.level and node.module else [a.name for a in node.names] if isinstance(node, ast.Import) else []
        for full in names:
            top = full.split(".")[0]
            if flexible or top in sys.stdlib_module_names:
                continue
            if tops is None:
                tops = _py_local_tops(repo)
            where = tops.get(top)
            if where and not reachable & set(where):
                out.append(f"`import {full}`: {top} lives in {where[0] or 'the project root'}/ and cannot be imported from {PurePosixPath(path).parent}/; put this file directly in {where[0] or 'the project root'}/")
        if isinstance(node, ast.ImportFrom) and node.level:
            base = here
            for _ in range(node.level - 1):
                base = base.parent
            mod = (node.module or "").split(".")[0]
            if mod and not ((base / f"{mod}.py").exists() or (base / mod).is_dir()):
                out.append(f"relative import `{node.module}`: no such module")
            continue
    return out + _py_symbol_imports(repo, path, tree, flexible) + _py_contracts(repo, path, tree)


def relocation(repo: Path, path: str, text: str) -> str | None:
    if sym.lang_for(path) != "python" or "cannot be imported" not in " ".join(_py_imports(repo, path, text)):
        return None
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return None
    tops = _py_local_tops(repo)
    wanted = {r for node in ast.walk(tree) if isinstance(node, (ast.Import, ast.ImportFrom)) and not getattr(node, "level", 0)
              for full in ([node.module] if isinstance(node, ast.ImportFrom) and node.module else [a.name for a in node.names] if isinstance(node, ast.Import) else [])
              for r in tops.get(full.split(".")[0], [])[:1]}
    if len(wanted) != 1:
        return None
    dest = str(PurePosixPath(next(iter(wanted)), PurePosixPath(path).name)) if next(iter(wanted)) else PurePosixPath(path).name
    return None if (repo / dest).exists() or str(dest) == path else str(dest)


def _py_packages(repo: Path, path: str, text: str) -> list[str]:
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return []
    here = (repo / path).parent
    roots = [repo, repo / "src", here]
    out: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.level:
            continue
        names = [node.module] if isinstance(node, ast.ImportFrom) and node.module else [a.name for a in node.names] if isinstance(node, ast.Import) else []
        for full in names:
            top = full.split(".")[0]
            if top in out or top in sys.stdlib_module_names or any((r / f"{top}.py").exists() or (r / top).is_dir() for r in roots) or top in _py_local_tops(repo) or _declared(repo, top):
                continue
            try:
                if importlib.util.find_spec(top) is not None:
                    continue
            except (ImportError, ValueError):
                pass
            out.append(top)
    return out


def _js_imports(repo: Path, path: str, text: str) -> list[str]:
    out = []
    here = (repo / path).parent
    for m in re.finditer(r"""(?:require\(\s*|from\s+|import\s+)['"](\.{1,2}/[^'"]+)['"]""", text):
        rel = m.group(1)
        if not any((here / (rel + e)).exists() for e in JS_EXT):
            out.append(f"import '{rel}': no such file")
    for m in re.finditer(r"""import\s*\{([^}]*)\}\s*from\s*['"](\.{1,2}/[^'"]+)['"]""", text):
        target = next((here / (m.group(2) + e) for e in JS_EXT if (here / (m.group(2) + e)).is_file()), None)
        if target is None:
            continue
        src = target.read_text(encoding="utf-8", errors="ignore")
        exported = set(re.findall(r"export\s+(?:default\s+)?(?:async\s+)?(?:function\*?|class|const|let|var)\s+([A-Za-z_$][\w$]*)", src))
        for block in re.findall(r"export\s*\{([^}]*)\}", src):
            exported.update(x.split(" as ")[-1].strip() for x in block.split(",") if x.strip())
        if re.search(r"module\.exports|export\s*\*", src):
            continue
        for name in (x.split(" as ")[0].strip() for x in m.group(1).split(",") if x.strip()):
            if name not in exported:
                out.append(f"`{name}` is not exported by {target.relative_to(repo).as_posix()}; exported names: {', '.join(sorted(exported)[:12]) or 'none'}")
    return out


def _js_packages(repo: Path, path: str, text: str) -> list[str]:
    out: list[str] = []
    for m in re.finditer(r"""(?:require\(\s*|from\s+|import\s+)['"]([^./'"][^'"]*)['"]""", text):
        name = m.group(1)
        top = "/".join(name.split("/")[:2]) if name.startswith("@") else name.split("/")[0]
        if top.startswith("node:") or top in out or (repo / "node_modules" / top).exists() or _declared(repo, top):
            continue
        out.append(top)
    return out


def external_packages(repo: Path, path: str, text: str) -> list[str]:
    lang = sym.lang_for(path)
    if lang == "python":
        return _py_packages(repo, path, text)
    if lang == "js":
        return _js_packages(repo, path, text)
    if lang in ("c", "cpp"):
        return sorted({m.group(1).split("/")[0].split(".")[0] for m in re.finditer(r'^\s*#\s*include\s*[<"]([^>"]+)[>"]', text, re.M)
                       if any(f in m.group(1) for f in FRAMEWORK_HEADERS) and not _declared(repo, m.group(1).split("/")[0].split(".")[0])})
    return []


def note_dependencies(repo: Path, path: str, packages: list[str]) -> str:
    if not packages or sym.lang_for(path) != "python":
        return ""
    req = repo / "requirements.txt"
    have = req.read_text(encoding="utf-8").splitlines() if req.exists() else []
    names = {re.split(r"[<>=~!\[ ;]", h.strip())[0].lower() for h in have if h.strip() and not h.startswith("#")}
    new = [p for p in packages if p.lower() not in names]
    if not new:
        return ""
    text = "\n".join(have).rstrip("\n")
    req.write_text((text + "\n" if text else "") + "\n".join(new) + "\n", encoding="utf-8")
    return "requirements.txt"


def duplicate_definitions(path: str, old: str, new: str) -> list[str]:
    lang = sym.lang_for(path)
    if not lang or lang in ("css", "html"):
        return []
    count = lambda text: Counter(_norm(s.name) for s in sym.extract(lang, text) if s.kind not in ("id",))  # noqa: E731
    before, after = count(old) if old else Counter(), count(new)
    macro = re.compile(r"^[A-Z][A-Z0-9_]*$") if lang in ("c", "cpp") else None
    return sorted(n for n, c in after.items() if c > 1 and c > before.get(n, 0) and not (macro and macro.match(n.split("::")[-1])))


ID_USE = re.compile(r"""getElementById\(\s*['"]([\w-]+)['"]\s*\)|querySelector(?:All)?\(\s*['"]#([\w-]+)['"]""")
CLASS_USE = re.compile(r"""classList\.(?:add|remove|toggle|contains)\(\s*['"]([\w-]+)['"]""")


def web_contract(repo: Path, js_path: str, text: str) -> list[str]:
    htmls = [f for f in source_files(repo) if f.endswith((".html", ".htm"))]
    if not htmls:
        return []
    markup = "\n".join((repo / f).read_text(encoding="utf-8", errors="ignore") for f in htmls)
    styles = "\n".join((repo / f).read_text(encoding="utf-8", errors="ignore") for f in source_files(repo) if f.endswith(".css"))
    ids = set(re.findall(r"""\bid\s*=\s*["']([^"']+)["']""", markup)) | set(re.findall(r"""\bid\s*=\s*["']([^"'$]+)["']""", text))
    out = []
    for m in ID_USE.finditer(text):
        i = m.group(1) or m.group(2)
        if i not in ids and f"#{i}" not in out:
            out.append(f"#{i}")
    problems = [f"{js_path} uses element id '{i[1:]}' that does not exist in {', '.join(htmls)}" for i in out]
    for c in dict.fromkeys(CLASS_USE.findall(text)):
        if not re.search(rf"\.{re.escape(c)}(?![\w-])", styles) and not re.search(rf"""class(?:Name)?\s*=\s*["'`][^"'`]*\b{re.escape(c)}\b""", markup + text):
            words = [w for w in re.split(r"[-_]", c.lower()) if len(w) > 2]
            near = sorted({s for s in re.findall(r"(\.[A-Za-z_][\w-]*|\[[\w-]+(?:=['\"]?[\w-]+['\"]?)?\])", styles) if any(w in s.lower() for w in words)})[:5]
            hint = f"; the stylesheet styles {', '.join(near)} instead" if near else ""
            attr = next((n for n in near if n.startswith("[")), "")
            how = f" (set it with element.setAttribute('{attr[1:].split('=')[0]}', '{attr.split('=')[1].strip(chr(39) + chr(34) + ']')}'))" if attr and "=" in attr else ""
            problems.append(f"{js_path} toggles class '{c}' but no CSS rule styles .{c}{hint}{how}; use exactly the selector the stylesheet defines")
    return problems


def unresolved_imports(repo: Path, path: str, text: str) -> list[str]:
    lang = sym.lang_for(path)
    if lang in ("c", "cpp"):
        return _c_includes(repo, path, text)
    if lang == "python":
        return _py_imports(repo, path, text)
    if lang == "js":
        return _js_imports(repo, path, text)
    return []


def not_in_build(repo: Path, path: str) -> bool:
    if sym.lang_for(path) not in ("c", "cpp") or not Path(path).suffix.lower() in (".c", ".cc", ".cpp", ".cxx"):
        return False
    cfgs = config_files(repo)
    if not cfgs:
        return False
    name = Path(path).name
    for rel in cfgs:
        text = (repo / rel).read_text(encoding="utf-8", errors="ignore")
        if name in text or re.search(r"GLOB|wildcard", text):
            return False
    return True


PLACEHOLDER = re.compile(r"(?:#|//|/\*|\*|<!--).*\b(placeholder|for now|for demonstration|demo only|dummy|stub|todo|fixme|not (?:yet )?implemented|arbitrary (?:value|damping|constant|number)|hard-?coded|example implementation|for illustration|we'll use|replace (?:this|with)|fixed (?:value|decay) for now)\b", re.I)
EXAMPLE_COMMENT = re.compile(r"^\s*(?:#|//|/\*|\*)\s*(?:an? )?(?:example|sample|dummy|simple)\b(?!s? (?:of|for) usage)", re.I)
STUB_BODY = re.compile(r"^\s*(?:raise NotImplementedError|throw\s+(?:std::)?(?:logic_error|runtime_error)\(\s*\"not implemented|pass\s*(?:#.*)?$)", re.I)


def placeholders(old: str, new: str, limit: int = 3) -> list[str]:
    before = set(old.splitlines())
    hits = []
    for ln in new.splitlines():
        if ln in before:
            continue
        m = PLACEHOLDER.search(ln) or EXAMPLE_COMMENT.match(ln)
        if m or STUB_BODY.match(ln):
            hits.append(ln.strip()[:140])
    return hits[:limit]


def _stem(name: str) -> str:
    words = re.findall(r"[A-Z]?[a-z0-9]+|[A-Z]+(?![a-z])", name)
    return (words[0] if words else name).lower()


def _sibling_list(line: str, olds: set[str]) -> bool:
    for m in re.finditer(r"[\{\[\(]([^\{\}\[\]\(\)]*)[\}\]\)]", line):
        items = [x.strip() for x in m.group(1).split(",") if x.strip()]
        if len(items) < 3 or not all(re.fullmatch(r"[&*]?[A-Za-z_][\w.]*(?:->\w+)*(?:\(\))?", x) for x in items):
            continue
        if any(re.search(rf"(?:^|[.&*>]){re.escape(o)}(?:\(\))?$", x) for x in items for o in olds):
            return True
    return False


def _mirror_shape(line: str, fam: set[str]) -> str:
    out = re.sub(r"[A-Za-z_]\w*", lambda m: "§" if m.group(0) in fam else m.group(0), line)
    return re.sub(r"\s+", "", re.sub(r"\b\d+(?:\.\d+)?\b|\"[^\"]*\"|'[^']*'", "#", out))


def mirror_gaps(text: str, old: str, new: str, limit: int = 5) -> list[str]:
    from difflib import SequenceMatcher
    so, sn = _stem(old), _stem(new)
    if len(so) < 3 or len(sn) < 3 or so == sn:
        return []
    lines = text.splitlines()
    ids = [set(re.findall(r"[A-Za-z_]\w*", re.sub(r"\"(?:\\.|[^\"\\])*\"|'(?:\\.|[^'\\])*'", "", ln))) for ln in lines]
    every = set().union(*ids) if ids else set()
    fam_old = {i for i in every if so in i.lower() and sn not in i.lower()}
    fam_new = {i for i in every if sn in i.lower() and so not in i.lower()}
    news = [_mirror_shape(lines[k], fam_new) for k in range(len(lines)) if ids[k] & fam_new]
    gaps = []
    for k, ln in enumerate(lines):
        if not ids[k] & fam_old or ids[k] & fam_new:
            continue
        listed = _sibling_list(ln, ids[k] & fam_old)
        assigned = re.match(rf"^\s*[\w.\->\[\]]*\b{re.escape(old)}\b\s*(?:\[[^\]]*\])?\s*=(?!=)", ln)
        if not (assigned or listed):
            continue
        shape = _mirror_shape(ln, fam_old)
        if any(SequenceMatcher(None, shape, n).ratio() >= 0.7 for n in news):
            continue
        hint = _mirror_suggestion(ln, ids[k] & fam_old, fam_new, old, new, bool(listed))
        gaps.append(f"line {k + 1}: `{ln.strip()[:120]}`" + (f" -> suggested: `{hint}`" + ("" if listed else "  (adapt any scale factor or unit)") if hint else ""))
    return gaps[:limit]


def _mirror_map(o: str, fam_new: set[str], old: str, new: str) -> str | None:
    if o == old:
        return new
    so, sn = _stem(old), _stem(new)
    i = o.lower().find(so)
    prefix, rest = o[:i], o[i + len(so):]
    rest_words = [w for w in re.findall(r"[A-Z]?[a-z0-9]+", rest)]
    old_rest = [w.lower() for w in re.findall(r"[A-Z]?[a-z0-9]+", old)][1:]
    suffix = "".join(w for w in rest_words if w.lower() not in old_rest)
    for n in sorted(fam_new, key=len):
        if n.startswith(prefix) and n.endswith(suffix) and sn in n.lower():
            return n
    return None


def _mirror_suggestion(line: str, olds: set[str], fam_new: set[str], old: str, new: str, listed: bool) -> str:
    if listed:
        f = next(iter(sorted(olds)))
        n = _mirror_map(f, fam_new, old, new)
        if not n:
            return ""
        end = re.search(rf"([\w.\->&*]*?)\b{re.escape(f)}\b(\s*[\}}\]\)])", line)
        if end:
            pre = end.group(1)
            return line.strip().replace(end.group(0), f"{pre}{f}, {pre}{n}{end.group(2)}", 1)
        mid = re.search(rf"([\w.\->&*]*?)\b{re.escape(f)}\b\s*,", line)
        if not mid:
            return ""
        pre = mid.group(1)
        return line.strip().replace(mid.group(0), f"{pre}{f}, {pre}{n},", 1)
    out = line.strip()
    for o in sorted(olds, key=len, reverse=True):
        n = _mirror_map(o, fam_new, old, new)
        if not n:
            return ""
        out = re.sub(rf"\b{re.escape(o)}\b", n, out)
    return out



def removed_fields(repo: Path, path: str, old: str, new: str, limit: int = 4) -> list[str]:
    from ..agents.analogues import _field
    had = {n for ln in old.splitlines() if (n := _field(ln, path))}
    has = {n for ln in new.splitlines() if (n := _field(ln, path))}
    out = []
    for name in sorted(had - has):
        if len(name) < 3 or re.search(rf"\b{re.escape(name)}\b\s*[:=]?", new) and re.search(rf"^\s*(?:[\w:<>,*&]+\s+)+[*&]?{re.escape(name)}\b", new, re.M):
            continue
        rx = re.compile(rf"\b{re.escape(name)}\b")
        users = [f for f in source_files(repo) if f != path and rx.search((repo / f).read_text(encoding="utf-8", errors="ignore"))][:2]
        if rx.search(new) or users:
            out.append(f"`{name}` was removed from {path} but is still used" + (f" in {', '.join(users)}" if users else " in this file") + "; keep existing members and only add new ones")
    return out[:limit]



def mirror_autofix(text: str, old: str, new: str) -> tuple[str, list[str]]:
    lines = text.splitlines(keepends=True)
    fixed: list[str] = []
    for gap in mirror_gaps(text, old, new, limit=20):
        m = re.match(r"line (\d+): `.*?` -> suggested: `(.+?)`(?:  \(adapt any scale factor or unit\))?$", gap)
        if not m:
            continue
        k, suggestion = int(m.group(1)) - 1, m.group(2)
        if k >= len(lines):
            continue
        indent = re.match(r"\s*", lines[k]).group(0)
        eol = "\n" if lines[k].endswith("\n") else ""
        if "(adapt any scale factor" in gap:
            suggestion = re.sub(r"\s*[*/]\s*\d+(?:\.\d+)?\s*(?=[;,]?$)", "", suggestion)
            lines[k] = lines[k] + indent + suggestion + eol
        else:
            lines[k] = indent + suggestion + eol
        fixed.append(suggestion)
    return "".join(lines), fixed



LANG_SNIFF = {
    "python": re.compile(r"^\s*(?:def \w+\(.*\)\s*(?:->.*)?:\s*$|class \w+(?:\(.*\))?:\s*$|from [\w.]+ import \w|import [\w.]+\s*$|if __name__ == )"),
    "js": re.compile(r"^\s*(?:function\s+\w+\s*\(|(?:const|let|var)\s+\w+\s*=|document\.\w+|module\.exports|export (?:default |function |const ))"),
    "cpp": re.compile(r"^\s*(?:#include\s*[<\"]|(?:std::|namespace\s+\w+\s*\{)|int main\s*\()"),
}
EXT_LANG = {".py": "python", ".js": "js", ".mjs": "js", ".ts": "js", ".c": "cpp", ".cc": "cpp", ".cpp": "cpp", ".h": "cpp", ".hpp": "cpp", ".css": "css", ".html": "html", ".htm": "html"}


def wrong_language(path: str, text: str) -> str:
    want = EXT_LANG.get(Path(path).suffix.lower())
    if not want:
        return ""
    lines = text.splitlines()
    counts = {lang: sum(1 for ln in lines if rx.match(ln)) for lang, rx in LANG_SNIFF.items()}
    own = counts.get(want, 0)
    other, n = max(((k, v) for k, v in counts.items() if k != want), key=lambda kv: kv[1], default=("", 0))
    if n >= 3 and n > 2 * own and not (want == "html" and other == "js"):
        names = {"python": "Python", "js": "JavaScript", "cpp": "C/C++"}
        return f"{path} contains {names.get(other, other)} code, but a {Path(path).suffix} file must contain {names.get(want, want)}; write this file in its own language"
    return ""



def restore_removed_fields(repo: Path, path: str, old: str, new: str) -> tuple[str, list[str]]:
    from ..agents.analogues import _field
    gone = {m.split("`")[1] for m in removed_fields(repo, path, old, new, limit=50)}
    if not gone:
        return new, []
    old_lines = old.splitlines()
    out = new.splitlines()
    restored = []
    for i, ln in enumerate(old_lines):
        name = _field(ln, path)
        if name not in gone or name in restored:
            continue
        anchor = next((old_lines[j] for j in range(i - 1, -1, -1) if old_lines[j].strip() and old_lines[j] in out), None)
        pos = out.index(anchor) + 1 if anchor is not None else None
        if pos is None:
            continue
        while pos < len(out) and out[pos] in old_lines[i + 1:i + 1] or (pos < len(out) and _field(out[pos], path) in restored):
            pos += 1
        out.insert(pos, ln)
        restored.append(name)
    return "\n".join(out) + ("\n" if new.endswith("\n") else ""), restored
