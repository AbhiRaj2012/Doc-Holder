from __future__ import annotations


def posix(path: str) -> str:
    p = str(path).strip().replace("\\", "/")
    while p.startswith("./"):
        p = p[2:]
    return p


def posix_list(paths: list[str]) -> list[str]:
    seen: list[str] = []
    for p in paths:
        q = posix(p)
        if q and q not in seen:
            seen.append(q)
    return seen
