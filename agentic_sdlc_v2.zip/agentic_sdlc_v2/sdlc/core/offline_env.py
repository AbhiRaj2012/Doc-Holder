from __future__ import annotations

import os
import shutil
import subprocess
from functools import lru_cache
from pathlib import Path
from urllib.parse import urlparse

OFFLINE_ENV: dict[str, str] = {
    "LITELLM_LOCAL_MODEL_COST_MAP": "True",
    "LITELLM_LOG": "ERROR",
    "DEEPEVAL_TELEMETRY_OPT_OUT": "YES",
    "DEEPEVAL_GRPC_LOGGING": "NO",
    "HF_HUB_OFFLINE": "1",
    "TRANSFORMERS_OFFLINE": "1",
    "ANONYMIZED_TELEMETRY": "false",
    "AIDER_ANALYTICS_DISABLE": "true",
    "AIDER_CHECK_UPDATE": "false",
    "STREAMLIT_BROWSER_GATHER_USAGE_STATS": "false",
    "NO_PROXY": "localhost,127.0.0.1",
    "PYTHONDONTWRITEBYTECODE": "1",
}

PASSTHROUGH = ("PATH", "HOME", "LANG", "LC_ALL", "TMPDIR", "JAVA_HOME", "M2_HOME", "GRADLE_USER_HOME", "NODE_PATH", "CC", "CXX")
WINDOWS_PASSTHROUGH = (
    "SYSTEMROOT", "SYSTEMDRIVE", "WINDIR", "TEMP", "TMP", "COMSPEC", "PATHEXT", "USERPROFILE", "USERNAME", "HOMEDRIVE", "HOMEPATH",
    "APPDATA", "LOCALAPPDATA", "PROGRAMDATA", "PROGRAMFILES", "PROGRAMFILES(X86)", "PROGRAMW6432", "COMMONPROGRAMFILES",
    "COMMONPROGRAMFILES(X86)", "NUMBER_OF_PROCESSORS", "PROCESSOR_ARCHITECTURE", "PROCESSOR_IDENTIFIER", "OS", "PUBLIC", "ALLUSERSPROFILE",
    "COMPUTERNAME", "QTDIR", "QT_PLUGIN_PATH", "MSYSTEM", "MINGW_PREFIX", "VCINSTALLDIR", "INCLUDE", "LIB", "LIBPATH", "WINDOWSSDKDIR",
)
LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1"}


def apply(tiktoken_dir: Path | None = None, ollama_base_url: str | None = None) -> None:
    for k, v in OFFLINE_ENV.items():
        os.environ[k] = v
    if tiktoken_dir is not None:
        os.environ["TIKTOKEN_CACHE_DIR"] = str(tiktoken_dir)
        os.environ["DATA_GYM_CACHE_DIR"] = str(tiktoken_dir)
    if ollama_base_url:
        assert_local_url(ollama_base_url)
        os.environ["OLLAMA_API_BASE"] = ollama_base_url
        os.environ["OLLAMA_HOST"] = ollama_base_url


def assert_local_url(url: str) -> None:
    host = urlparse(url).hostname or ""
    if host not in LOCAL_HOSTS:
        raise RuntimeError(f"Refusing non-local endpoint in air-gapped mode: {url}")


def child_env(extra: dict[str, str] | None = None) -> dict[str, str]:
    keys = PASSTHROUGH + (WINDOWS_PASSTHROUGH if os.name == "nt" else ())
    env = {k: os.environ[k] for k in keys if k in os.environ}
    env.update(OFFLINE_ENV)
    if extra:
        env.update(extra)
    return env


@lru_cache(maxsize=1)
def default_python() -> str:
    return "python" if os.name == "nt" else "python3"


def netns_available() -> bool:
    if not shutil.which("unshare"):
        return False
    try:
        r = subprocess.run(["unshare", "-rn", "true"], capture_output=True, timeout=10)
        return r.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def sandbox_prefix(no_network: bool = True) -> list[str]:
    if no_network and netns_available():
        return ["unshare", "-rn"]
    return []


def ulimit_wrap(command: str, cpu_seconds: int | None = None, mem_mb: int | None = None) -> str:
    parts: list[str] = []
    if cpu_seconds:
        parts.append(f"ulimit -t {cpu_seconds}")
    if mem_mb:
        parts.append(f"ulimit -v {mem_mb * 1024}")
    parts.append(command)
    return "; ".join(parts)
