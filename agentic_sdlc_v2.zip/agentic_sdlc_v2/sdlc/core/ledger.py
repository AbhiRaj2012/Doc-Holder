from __future__ import annotations

import hashlib
import json
import os
import re
from enum import Enum
from pathlib import Path

from pydantic import BaseModel

from .schemas import ReviewResult


class IssueStatus(str, Enum):
    OPEN = "open"
    RESOLVED = "resolved"
    REGRESSED = "regressed"
    WAIVED = "waived"


class Finding(BaseModel):
    kind: str
    message: str
    file: str = ""
    symbol: str = ""
    line: int = 0
    detail: str = ""


class Issue(BaseModel):
    id: str
    task_id: str
    fingerprint: str
    kind: str
    message: str
    file: str = ""
    symbol: str = ""
    line: int = 0
    detail: str = ""
    status: IssueStatus = IssueStatus.OPEN
    first_iter: int = 1
    last_iter: int = 1
    resolved_iter: int | None = None
    occurrences: int = 1
    regressions: int = 0

    @property
    def is_open(self) -> bool:
        return self.status in (IssueStatus.OPEN, IssueStatus.REGRESSED)


_NUM = re.compile(r"0x[0-9a-fA-F]+|\d+")
_PATH = re.compile(r"(?:[\w.\-]+/)+")


def fingerprint_of(f: Finding) -> str:
    msg = _PATH.sub("", f.message.lower())
    msg = " ".join(_NUM.sub("N", msg).split())[:160]
    raw = f"{f.kind}|{f.file}|{f.symbol.lower()}|{msg}"
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:12]


def findings_from_review(review: ReviewResult) -> list[Finding]:
    out = [
        Finding(kind=f.kind, file=f.file, line=f.line, symbol=f.name, message=f.message or f.name)
        for f in review.all_failures()
    ]
    if review.llm and not review.llm.approved:
        for u in review.llm.unmet_criteria:
            out.append(Finding(kind="criteria", message=u, detail=review.llm.feedback))
    return out


class IssueLedger:
    def __init__(self, run_dir: Path):
        self.path = run_dir / "issues.jsonl"
        self.md_path = run_dir / "issue.md"
        self.issues: dict[str, Issue] = {}
        self._seq = 0
        self._load()

    def _load(self) -> None:
        if not self.path.exists():
            return
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            issue = Issue.model_validate(json.loads(line))
            self.issues[issue.id] = issue
            self._seq = max(self._seq, int(issue.id.split("-")[-1]))

    def _save(self, issue: Issue) -> None:
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(issue.model_dump_json() + "\n")
            fh.flush()
            os.fsync(fh.fileno())

    def _task_issues(self, task_id: str) -> list[Issue]:
        return [i for i in self.issues.values() if i.task_id == task_id]

    def ingest(self, task_id: str, iteration: int, findings: list[Finding], resolve: bool = True) -> dict[str, int]:
        stats = {"new": 0, "repeated": 0, "regressed": 0, "resolved": 0}
        by_fp = {i.fingerprint: i for i in self._task_issues(task_id)}
        seen: set[str] = set()
        for f in findings:
            fp = fingerprint_of(f)
            if fp in seen:
                continue
            seen.add(fp)
            issue = by_fp.get(fp)
            if issue is None:
                self._seq += 1
                issue = Issue(
                    id=f"ISS-{self._seq:04d}", task_id=task_id, fingerprint=fp, kind=f.kind,
                    message=f.message[:600], file=f.file, symbol=f.symbol, line=f.line,
                    detail=f.detail[:600], first_iter=iteration, last_iter=iteration,
                )
                self.issues[issue.id] = issue
                stats["new"] += 1
            else:
                if issue.status == IssueStatus.RESOLVED:
                    issue.status = IssueStatus.REGRESSED
                    issue.regressions += 1
                    issue.resolved_iter = None
                    stats["regressed"] += 1
                elif issue.status == IssueStatus.WAIVED:
                    issue.status = IssueStatus.OPEN
                    stats["repeated"] += 1
                else:
                    stats["repeated"] += 1
                issue.occurrences += 1
                issue.last_iter = iteration
                issue.line = f.line or issue.line
                issue.detail = f.detail[:600] or issue.detail
            self._save(issue)
        for issue in by_fp.values() if resolve else []:
            if issue.is_open and issue.fingerprint not in seen:
                issue.status = IssueStatus.RESOLVED
                issue.resolved_iter = iteration
                stats["resolved"] += 1
                self._save(issue)
        self.write_md()
        return stats

    def open_issues(self, task_id: str) -> list[Issue]:
        found = [i for i in self._task_issues(task_id) if i.is_open]
        return sorted(found, key=lambda i: (i.status != IssueStatus.REGRESSED, -i.occurrences, i.id))

    def resolved_issues(self, task_id: str) -> list[Issue]:
        return [i for i in self._task_issues(task_id) if i.status == IssueStatus.RESOLVED]

    def oscillating(self, task_id: str, limit: int = 2) -> bool:
        return any(i.regressions >= limit for i in self._task_issues(task_id))

    def waive(self, task_id: str) -> int:
        n = 0
        for i in self.open_issues(task_id):
            i.status = IssueStatus.WAIVED
            self._save(i)
            n += 1
        self.write_md()
        return n

    def prompt_block(self, task_id: str, max_open: int = 5, max_guard: int = 8) -> str:
        lines: list[str] = []
        open_ = self.open_issues(task_id)[:max_open]
        if open_:
            lines.append("OPEN ISSUES (fix all):")
            for n, i in enumerate(open_, 1):
                loc = f"{i.file}:{i.line}" if i.file else ""
                tag = " [REGRESSED]" if i.status == IssueStatus.REGRESSED else ""
                head = " ".join(p for p in (i.kind.upper(), loc, i.symbol) if p)
                lines.append(f"{n}. {head} - {i.message[:240]}{tag} (seen {i.occurrences}x)")
        guard = self.resolved_issues(task_id)[-max_guard:]
        if guard:
            lines.append("MUST STAY FIXED (do not reintroduce):")
            lines += [f"- {i.kind}: {i.message[:140]}" for i in guard]
        return "\n".join(lines)

    def render_md(self) -> str:
        by_task: dict[str, list[Issue]] = {}
        for i in self.issues.values():
            by_task.setdefault(i.task_id, []).append(i)
        out = ["# Issue ledger (generated view, source of truth is issues.jsonl)", ""]
        for tid in sorted(by_task):
            out.append(f"## {tid}")
            for i in sorted(by_task[tid], key=lambda x: x.id):
                loc = f" `{i.file}:{i.line}`" if i.file else ""
                out.append(
                    f"- **{i.id}** [{i.status.value}] {i.kind}{loc} - {i.message[:200]} "
                    f"(iter {i.first_iter}-{i.last_iter}, seen {i.occurrences}x, regressions {i.regressions})"
                )
            out.append("")
        return "\n".join(out)

    def write_md(self) -> None:
        self.md_path.write_text(self.render_md(), encoding="utf-8")
