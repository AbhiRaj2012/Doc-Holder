from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import shutil
import time
from dataclasses import dataclass
from pathlib import Path

import yaml

from ..adapters.git_ops import GitRepo
from .config import Settings
from .schemas import Manifest

DEFAULT_LINK_DIRS = ("node_modules", ".venv", "venv")
IGNORE_FOR_FINGERPRINT = {".git", "__pycache__", "node_modules", ".venv", "venv", "build", "dist", "target", ".gradle"}


class ProjectError(RuntimeError):
    pass


@dataclass
class Project:
    id: str
    root: Path
    code: Path
    workspace: Path
    source: Path
    meta: dict

    def run_dir(self, run_id: str) -> Path:
        d = self.workspace / "runs" / run_id
        d.mkdir(parents=True, exist_ok=True)
        return d

    @property
    def manifest_path(self) -> Path:
        return self.workspace / "manifest.json"

    @property
    def approved_commands_path(self) -> Path:
        return self.workspace / "approved_commands.json"

    def has_runs(self) -> bool:
        runs = self.workspace / "runs"
        return runs.exists() and any(runs.iterdir())


def slugify(name: str) -> str:
    slug = re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("._")
    return slug or "project"


def new_run_id() -> str:
    return f"{time.strftime('%Y%m%d-%H%M%S')}-{secrets.token_hex(2)}"


def fingerprint(path: Path) -> str:
    h = hashlib.sha256()
    for dirpath, dirs, files in os.walk(path):
        dirs[:] = sorted(d for d in dirs if d not in IGNORE_FOR_FINGERPRINT)
        for name in sorted(files):
            p = Path(dirpath) / name
            try:
                st = p.stat()
            except OSError:
                continue
            h.update(f"{p.relative_to(path)}|{st.st_size}|{int(st.st_mtime)}\n".encode())
    return h.hexdigest()[:16]


def code_tree_hash(path: Path, files: list[str]) -> str:
    h = hashlib.sha256()
    for rel in sorted(files):
        try:
            h.update(rel.encode() + hashlib.sha1((path / rel).read_bytes()).digest())
        except OSError:
            continue
    return h.hexdigest()[:16]


def _repo_cfg(src: Path) -> dict:
    p = src / ".sdlc.yaml"
    return (yaml.safe_load(p.read_text(encoding="utf-8")) or {}) if p.exists() else {}


class ProjectStore:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.root = settings.projects_root().resolve()

    def _read_meta(self, root: Path) -> dict:
        p = root / "workspace" / "project.json"
        return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}

    def _write_meta(self, root: Path, meta: dict) -> None:
        (root / "workspace").mkdir(parents=True, exist_ok=True)
        (root / "workspace" / "project.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")

    def _import_code(self, src: Path, code: Path) -> list[str]:
        cfg = _repo_cfg(src)
        links = [d for d in cfg.get("link_dirs", DEFAULT_LINK_DIRS) if (src / d).is_dir()]
        excluded = set(cfg.get("copy_exclude", [])) | set(links)

        def ignore(directory: str, names: list[str]) -> set[str]:
            return {n for n in names if Path(directory) == src and n in excluded}

        shutil.copytree(src, code, symlinks=True, ignore=ignore)
        for d in links:
            os.symlink((src / d).resolve(), code / d)
        git = GitRepo(code, self.settings.git.author_name, self.settings.git.author_email)
        git.ensure_repo()
        git.add_excludes(links)
        git.commit_all("sdlc: imported project")
        return links

    def open(self, source: str | Path, name: str | None = None, fresh: bool = False) -> Project:
        src = Path(source).resolve()
        if not src.is_dir():
            raise ProjectError(f"source is not a directory: {src}")
        base = slugify(name or src.name)
        self.root.mkdir(parents=True, exist_ok=True)
        n, pid = 1, base
        while True:
            root = self.root / pid
            meta = self._read_meta(root) if root.exists() else {}
            if not root.exists() or not meta:
                break
            if meta.get("source_path") == str(src):
                break
            n += 1
            pid = f"{base}_{n}"
        root = self.root / pid
        code = root / pid
        meta = self._read_meta(root) if root.exists() else {}
        if meta and fresh:
            shutil.rmtree(code, ignore_errors=True)
            meta = {}
        if not meta or not code.exists():
            root.mkdir(parents=True, exist_ok=True)
            if code.exists():
                shutil.rmtree(code)
            links = self._import_code(src, code)
            baseline = GitRepo(code).head()
            meta = {
                "id": pid, "name": name or src.name, "source_path": str(src),
                "source_fingerprint": fingerprint(src), "created_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                "baseline_commit": baseline, "link_dirs": links,
            }
            self._write_meta(root, meta)
        (root / "workspace").mkdir(parents=True, exist_ok=True)
        return Project(id=pid, root=root, code=code, workspace=root / "workspace", source=src, meta=meta)

    def get(self, project_id: str) -> Project:
        root = self.root / project_id
        meta = self._read_meta(root)
        if not meta:
            raise ProjectError(f"unknown project: {project_id}")
        return Project(id=project_id, root=root, code=root / project_id, workspace=root / "workspace", source=Path(meta["source_path"]), meta=meta)

    def list_projects(self) -> list[str]:
        if not self.root.exists():
            return []
        return sorted(p.name for p in self.root.iterdir() if (p / "workspace" / "project.json").exists())

    def source_changed(self, project: Project) -> bool:
        return fingerprint(project.source) != project.meta.get("source_fingerprint")

    def sync(self, project: Project, force: bool = False) -> Project:
        if project.has_runs() and not force:
            raise ProjectError("runs exist for this project; re-importing would discard their edits. Use force=True.")
        shutil.rmtree(project.code, ignore_errors=True)
        links = self._import_code(project.source, project.code)
        project.meta.update(
            source_fingerprint=fingerprint(project.source), baseline_commit=GitRepo(project.code).head(), link_dirs=links,
        )
        self._write_meta(project.root, project.meta)
        if project.manifest_path.exists():
            project.manifest_path.unlink()
        return project

    def load_manifest(self, project: Project) -> Manifest | None:
        if not project.manifest_path.exists():
            return None
        try:
            m = Manifest.model_validate_json(project.manifest_path.read_text(encoding="utf-8"))
        except ValueError:
            return None
        if m.project_id != project.id or m.root != str(project.code):
            return None
        return m

    def save_manifest(self, project: Project, manifest: Manifest) -> None:
        manifest.project_id = project.id
        manifest.root = str(project.code)
        project.manifest_path.write_text(manifest.model_dump_json(indent=2), encoding="utf-8")

    def export(self, project: Project, dest: str | Path | None = None) -> Path:
        git = GitRepo(project.code, self.settings.git.author_name, self.settings.git.author_email)
        base = project.meta["baseline_commit"]
        if dest is None:
            out = project.workspace / f"export_{time.strftime('%Y%m%d-%H%M%S')}.patch"
            out.write_text(git.diff_since(base, max_chars=50_000_000), encoding="utf-8")
            return out
        target = Path(dest).resolve()
        for rel in git.changed_since(base):
            src = project.code / rel
            if src.exists():
                (target / rel).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, target / rel)
            else:
                (target / rel).unlink(missing_ok=True)
        return target
