from __future__ import annotations

import ast
import json
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

from .offline_env import child_env, default_python


@dataclass
class ClassInfo:
    name: str
    params: set[str] | None
    members: set[str] = field(default_factory=set)
    open: bool = False
    ext_bases: list[tuple[str, str]] = field(default_factory=list)


def _parse(path: Path) -> ast.Module | None:
    try:
        return ast.parse(path.read_text(encoding="utf-8", errors="replace"))
    except (SyntaxError, OSError):
        return None


def _decorated_dataclass(node: ast.ClassDef) -> bool:
    for d in node.decorator_list:
        target = d.func if isinstance(d, ast.Call) else d
        if (isinstance(target, ast.Name) and target.id == "dataclass") or (isinstance(target, ast.Attribute) and target.attr == "dataclass"):
            return True
    return False


def imports_of(tree: ast.Module) -> dict[str, str]:
    out: dict[str, str] = {}
    for node in tree.body:
        if isinstance(node, ast.ImportFrom) and not node.level and node.module:
            for a in node.names:
                out[a.asname or a.name] = f"{node.module}:{a.name}"
        elif isinstance(node, ast.Import):
            for a in node.names:
                out[a.asname or a.name.split(".")[0]] = a.name if a.asname else a.name.split(".")[0]
    return out


def _external(base: ast.expr, imports: dict[str, str]) -> tuple[str, str] | None:
    if isinstance(base, ast.Name) and ":" in imports.get(base.id, ""):
        mod, name = imports[base.id].split(":", 1)
        return mod, name
    if isinstance(base, ast.Attribute) and isinstance(base.value, ast.Name) and base.value.id in imports and ":" not in imports[base.value.id]:
        return imports[base.value.id], base.attr
    return None


def class_info(node: ast.ClassDef, known: dict[str, ClassInfo], imports: dict[str, str] | None = None) -> ClassInfo:
    imports = imports or {}
    ext = [e for b in node.bases if not (isinstance(b, ast.Name) and (b.id in known or b.id == "object")) and (e := _external(b, imports))]
    members: set[str] = set()
    params: set[str] | None = None
    fields: list[str] = []
    is_open = any(not (isinstance(b, ast.Name) and (b.id in known or b.id == "object")) for b in node.bases) or bool(node.keywords)
    for b in node.bases:
        if isinstance(b, ast.Name) and b.id in known:
            base = known[b.id]
            members |= base.members
            ext += base.ext_bases
            is_open = is_open or base.open
            if base.params is not None:
                fields += sorted(base.params)
    for item in node.body:
        if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
            members.add(item.name)
            if item.name == "__init__":
                a = item.args
                if a.kwarg is not None:
                    is_open = True
                params = {x.arg for x in [*a.posonlyargs, *a.args, *a.kwonlyargs][1:]}
            if item.name in ("__getattr__", "__getattribute__", "__setattr__"):
                is_open = True
            for sub in ast.walk(item):
                if isinstance(sub, ast.Attribute) and isinstance(sub.value, ast.Name) and sub.value.id == "self" and isinstance(sub.ctx, ast.Store):
                    members.add(sub.attr)
        elif isinstance(item, ast.AnnAssign) and isinstance(item.target, ast.Name):
            members.add(item.target.id)
            fields.append(item.target.id)
        elif isinstance(item, ast.Assign):
            for t in item.targets:
                if isinstance(t, ast.Name):
                    members.add(t.id)
                    if t.id == "__slots__":
                        is_open = True
    if params is None and _decorated_dataclass(node):
        params = set(fields)
    elif params is None and not node.bases:
        params = set()
    elif params is None:
        params = known[node.bases[0].id].params if isinstance(node.bases[0], ast.Name) and node.bases[0].id in known else None
    unresolved = any(not (isinstance(b, ast.Name) and (b.id in known or b.id == "object")) and not _external(b, imports) for b in node.bases)
    return ClassInfo(node.name, params, members, is_open, ext if not unresolved else [])


def classes_in(tree: ast.Module) -> dict[str, ClassInfo]:
    imports = imports_of(tree)
    known: dict[str, ClassInfo] = {}
    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            known[node.name] = class_info(node, known, imports)
    return known


def missing_on_external(queries: dict[tuple[str, str], set[str]], timeout: int = 30) -> dict[tuple[str, str], set[str]] | None:
    if not queries:
        return {}
    script = (
        "import importlib, json, sys\n"
        "q = json.loads(sys.argv[1]); out = {}\n"
        "for key, attrs in q.items():\n"
        "    mod, name = key.split(':', 1)\n"
        "    try:\n"
        "        cls = getattr(importlib.import_module(mod), name)\n"
        "    except Exception:\n"
        "        continue\n"
        "    out[key] = [a for a in attrs if not hasattr(cls, a)]\n"
        "print(json.dumps(out))\n"
    )
    payload = json.dumps({f"{m}:{n}": sorted(a) for (m, n), a in queries.items()})
    try:
        res = subprocess.run([default_python(), "-c", script, payload], capture_output=True, text=True, timeout=timeout, env=child_env())
        lines = res.stdout.strip().splitlines()
        data = json.loads(lines[-1]) if res.returncode == 0 and lines else None
    except (OSError, subprocess.TimeoutExpired, ValueError):
        return None
    if data is None:
        return None
    return {tuple(k.split(":", 1)): set(v) for k, v in data.items()}  # type: ignore[misc]


def self_attribute_violations(tree: ast.Module, classes: dict[str, ClassInfo], known_names: set[str]) -> list[str]:
    out: list[str] = []
    pending: list[tuple[ClassInfo, str, str]] = []
    for cls in (n for n in tree.body if isinstance(n, ast.ClassDef)):
        typed: dict[str, str] = {}
        for sub in ast.walk(cls):
            if isinstance(sub, ast.Assign) and isinstance(sub.value, ast.Call) and isinstance(sub.value.func, ast.Name) and sub.value.func.id in classes:
                for t in sub.targets:
                    if isinstance(t, ast.Attribute) and isinstance(t.value, ast.Name) and t.value.id == "self":
                        typed[t.attr] = sub.value.func.id
        if not typed:
            continue
        for sub in ast.walk(cls):
            if (isinstance(sub, ast.Attribute) and isinstance(sub.ctx, ast.Load) and isinstance(sub.value, ast.Attribute)
                    and isinstance(sub.value.value, ast.Name) and sub.value.value.id == "self" and sub.value.attr in typed):
                info = classes[typed[sub.value.attr]]
                name = sub.attr
                if name in info.members or name.startswith("__"):
                    continue
                if not info.open:
                    out.append(_member_msg(sub.value.attr, info, name))
                elif info.ext_bases:
                    pending.append((info, sub.value.attr, name))
                elif name not in known_names:
                    out.append(_member_msg(sub.value.attr, info, name))
    if pending:
        queries: dict[tuple[str, str], set[str]] = {}
        for info, _o, name in pending:
            for b in info.ext_bases:
                queries.setdefault(b, set()).add(name)
        missing = missing_on_external(queries)
        for info, owner, name in pending:
            if missing is None or any(b not in missing for b in info.ext_bases):
                if name not in known_names:
                    out.append(_member_msg(owner, info, name))
            elif all(name in missing[b] for b in info.ext_bases):
                out.append(_member_msg(owner, info, name))
    return sorted(set(out))


def _member_msg(owner: str, info: ClassInfo, name: str) -> str:
    bases = f" or its base {', '.join(n for _, n in info.ext_bases)}" if info.ext_bases else ""
    return f"`self.{owner}.{name}`: {info.name} has no member `{name}` (not defined in {info.name}{bases}); add it to {info.name} first or use an existing one: {', '.join(sorted(m for m in info.members if not m.startswith('_'))[:15])}"


def violations(tree: ast.Module, classes: dict[str, ClassInfo]) -> list[str]:
    out: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in classes:
            info = classes[node.func.id]
            if info.open or info.params is None:
                continue
            for kw in node.keywords:
                if kw.arg and kw.arg not in info.params:
                    out.append(f"`{info.name}(...)` has no parameter `{kw.arg}`; it accepts: {', '.join(sorted(info.params)) or 'no keyword arguments'}")
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            typed = {a.arg: a.annotation.id for a in [*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs]
                     if isinstance(a.annotation, ast.Name) and a.annotation.id in classes}
            if not typed:
                continue
            for sub in ast.walk(node):
                if (isinstance(sub, ast.Call) and isinstance(sub.func, ast.Name) and sub.func.id in ("getattr", "hasattr") and len(sub.args) >= 2
                        and isinstance(sub.args[0], ast.Name) and sub.args[0].id in typed and isinstance(sub.args[1], ast.Constant) and isinstance(sub.args[1].value, str)):
                    info = classes[typed[sub.args[0].id]]
                    if not info.open and sub.args[1].value not in info.members:
                        out.append(f"`{sub.func.id}({sub.args[0].id}, '{sub.args[1].value}', ...)` hides a missing attribute: {info.name} has no attribute `{sub.args[1].value}`. Add the field to {info.name} instead of guessing a default")
                if isinstance(sub, ast.Attribute) and isinstance(sub.value, ast.Name) and sub.value.id in typed and isinstance(sub.ctx, ast.Load):
                    info = classes[typed[sub.value.id]]
                    if not info.open and sub.attr not in info.members and not sub.attr.startswith("__"):
                        out.append(f"`{sub.value.id}.{sub.attr}`: {info.name} has no attribute `{sub.attr}`; it has: {', '.join(sorted(m for m in info.members if not m.startswith('_'))[:15])}")
    return sorted(set(out))
