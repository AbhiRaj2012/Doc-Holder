from __future__ import annotations

import ast
import re
from dataclasses import dataclass

from . import ts_symbols

C_SKIP = ("if", "for", "while", "switch", "return", "else", "do", "typedef", "extern", "case", "sizeof")
C_SKIP_RE = re.compile(r"(?:" + "|".join(C_SKIP) + r")\b")
C_FUNC = re.compile(r"^(?!\s|#|//|/\*|\*)[A-Za-z_][\w \t\*&:<>,~]*?[ \t\*&](~?[A-Za-z_][\w:]*)\s*\([^;]*$")
C_TYPE = re.compile(r"^(?:typedef\s+)?(struct|class|enum|union)\s+(\w+)")
JAVA_TYPE = re.compile(r"^\s*(?:(?:public|protected|private|abstract|static|final|sealed|strictfp)\s+)*(class|interface|enum|record)\s+(\w+)")
JAVA_METHOD = re.compile(r"^\s*(?:(?:public|protected|private|static|final|abstract|synchronized|native|default)\s+)+(?:<[^>]+>\s+)?[\w<>\[\],.? ]+?\s+(\w+)\s*\([^;]*$")
JS_FUNC = re.compile(r"^\s*(?:export\s+)?(?:default\s+)?(?:async\s+)?function\s*\*?\s*(\w+)\s*\(")
JS_CLASS = re.compile(r"^\s*(?:export\s+)?(?:default\s+)?(?:abstract\s+)?class\s+(\w+)")
JS_ARROW = re.compile(r"^\s*(?:export\s+)?(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?(?:\([^)]*\)|\w+)\s*(?::[^=]+)?=>")
JS_EXPR = re.compile(r"^\s*(?:export\s+)?(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?function\b")
JS_METHOD = re.compile(r"^\s{2,}(?:static\s+)?(?:async\s+)?(?:get\s+|set\s+)?(\w+)\s*\([^)]*\)\s*(?::\s*[^{]+)?\{\s*$")
JS_EXPORT = re.compile(r"^(?:module\.)?exports\.(\w+)\s*=")
JS_NOT_METHOD = {"if", "for", "while", "switch", "catch", "function", "return", "constructor_"}
CSS_RULE = re.compile(r"^([^{}@\s/][^{}]*?|@[\w-]+[^{}]*?)\s*\{")
HTML_ID = re.compile(r"""\bid\s*=\s*["']([^"']+)["']""")
SYMBOL_LANG = {".py": "python", ".c": "c", ".cc": "cpp", ".cpp": "cpp", ".cxx": "cpp", ".hpp": "cpp", ".hh": "cpp", ".hxx": "cpp",
               ".java": "java", ".js": "js", ".mjs": "js", ".cjs": "js", ".jsx": "js", ".ts": "js", ".tsx": "js",
               ".css": "css", ".html": "html", ".htm": "html"}
TYPE_KINDS = {"class", "struct", "interface", "enum", "union", "record"}


@dataclass
class Symbol:
    name: str
    kind: str
    start: int
    end: int


def _brace_end(lines: list[str], idx: int) -> int:
    depth, seen = 0, False
    for j in range(idx, min(len(lines), idx + 4000)):
        code = re.sub(r"//.*$|\"(?:\\.|[^\"\\])*\"|'(?:\\.|[^'\\])*'", "", lines[j])
        for ch in code:
            if ch == "{":
                depth, seen = depth + 1, True
            elif ch == "}":
                depth -= 1
        if seen and depth <= 0:
            return j + 1
        if not seen and j - idx >= 6:
            return idx + 1
    return idx + 1


def _python(text: str) -> list[Symbol]:
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return [Symbol(m.group(2), m.group(1), i, i) for i, ln in enumerate(text.splitlines(), 1) if (m := re.match(r"^\s*(def|class)\s+(\w+)", ln))]
    out: list[Symbol] = []

    def visit(node: ast.AST, prefix: str) -> None:
        for child in ast.iter_child_nodes(node):
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                start = min([d.lineno for d in child.decorator_list] + [child.lineno])
                kind = "class" if isinstance(child, ast.ClassDef) else "def"
                out.append(Symbol(prefix + child.name, kind, start, child.end_lineno or child.lineno))
                if isinstance(child, ast.ClassDef):
                    visit(child, prefix + child.name + ".")

    visit(tree, "")
    return out


def _c_like(lines: list[str]) -> list[Symbol]:
    out: list[Symbol] = []
    for i, ln in enumerate(lines):
        m = C_TYPE.match(ln)
        if m and not ln.rstrip().endswith(";"):
            out.append(Symbol(m.group(2), m.group(1), i + 1, _brace_end(lines, i)))
            continue
        m = C_FUNC.match(ln)
        if m and not ln.rstrip().endswith(";") and m.group(1) not in C_SKIP and not C_SKIP_RE.match(ln.lstrip()):
            out.append(Symbol(m.group(1), "def", i + 1, _brace_end(lines, i)))
    return out


def _java(lines: list[str]) -> list[Symbol]:
    out: list[Symbol] = []
    for i, ln in enumerate(lines):
        m = JAVA_TYPE.match(ln)
        if m:
            out.append(Symbol(m.group(2), m.group(1), i + 1, _brace_end(lines, i)))
            continue
        m = JAVA_METHOD.match(ln)
        if m and m.group(1) not in ("if", "for", "while", "switch", "catch", "return", "new"):
            out.append(Symbol(m.group(1), "def", i + 1, _brace_end(lines, i)))
    return out


def _js(lines: list[str]) -> list[Symbol]:
    out: list[Symbol] = []
    for i, ln in enumerate(lines):
        for rx, kind in ((JS_CLASS, "class"), (JS_FUNC, "def"), (JS_ARROW, "def"), (JS_EXPR, "def"), (JS_EXPORT, "def")):
            m = rx.match(ln)
            if m:
                out.append(Symbol(m.group(1), kind, i + 1, _brace_end(lines, i)))
                break
        else:
            m = JS_METHOD.match(ln)
            if m and m.group(1) not in JS_NOT_METHOD:
                out.append(Symbol(m.group(1), "method", i + 1, _brace_end(lines, i)))
    return out


def _css(lines: list[str]) -> list[Symbol]:
    out: list[Symbol] = []
    depth = 0
    for i, ln in enumerate(lines):
        if depth == 0:
            m = CSS_RULE.match(ln.strip())
            if m:
                out.append(Symbol(" ".join(m.group(1).split()), "rule", i + 1, _brace_end(lines, i)))
        depth += ln.count("{") - ln.count("}")
        depth = max(depth, 0)
    return out


def _html(lines: list[str]) -> list[Symbol]:
    return [Symbol(f"#{m.group(1)}", "id", i + 1, i + 1) for i, ln in enumerate(lines) for m in HTML_ID.finditer(ln)]


def _qualify(symbols: list[Symbol]) -> list[Symbol]:
    types = [s for s in symbols if s.kind in TYPE_KINDS]
    out: list[Symbol] = []
    for s in symbols:
        if s.kind in TYPE_KINDS:
            out.append(s)
            continue
        owner = min((t for t in types if t.start < s.start <= t.end), key=lambda t: t.end - t.start, default=None)
        if s.kind == "method" and owner is None:
            continue
        out.append(Symbol(f"{owner.name}.{s.name}" if owner and "." not in s.name else s.name, s.kind, s.start, s.end))
    return out


def lang_for(path: str, header_lang: str = "cpp") -> str:
    dot = path.rfind(".")
    ext = path[dot:].lower() if dot >= 0 else ""
    return header_lang if ext == ".h" else SYMBOL_LANG.get(ext, "")


def backend(language: str) -> str:
    if language == "python":
        return "python-ast"
    return "tree-sitter" if ts_symbols.available(language) else "regex"


def extract(language: str, text: str) -> list[Symbol]:
    if language != "python":
        try:
            found = ts_symbols.extract(language, text)
        except Exception:
            found = None
        if found is not None:
            return sorted((Symbol(*f) for f in found), key=lambda s: s.start)
    return regex_extract(language, text)


def identifiers(language: str, text: str) -> set[str]:
    if language == "python":
        try:
            return {n.id for n in ast.walk(ast.parse(text)) if isinstance(n, ast.Name)} | {n.attr for n in ast.walk(ast.parse(text)) if isinstance(n, ast.Attribute)}
        except SyntaxError:
            pass
    else:
        try:
            found = ts_symbols.identifiers(language, text)
        except Exception:
            found = None
        if found is not None:
            return found
    return set(re.findall(r"\b[A-Za-z_]\w*\b", re.sub(r"//[^\n]*|#[^\n]*|/\*.*?\*/|\"(?:\\.|[^\"\\])*\"|'(?:\\.|[^'\\])*'", " ", text, flags=re.S)))


def regex_extract(language: str, text: str) -> list[Symbol]:
    lines = text.splitlines()
    if language == "python":
        syms = _python(text)
    elif language in ("c", "cpp"):
        syms = _qualify(_c_like(lines))
    elif language == "java":
        syms = _qualify(_java(lines))
    elif language == "js":
        syms = _qualify(_js(lines))
    elif language == "css":
        syms = _css(lines)
    elif language == "html":
        syms = _html(lines)
    else:
        syms = []
    return sorted(syms, key=lambda s: s.start)


def names(symbols: list[Symbol]) -> list[str]:
    return [f"{s.kind} {s.name}" if s.kind in TYPE_KINDS else s.name for s in symbols]


def find(symbols: list[Symbol], name: str) -> Symbol | None:
    exact = next((s for s in symbols if s.name == name), None)
    return exact or next((s for s in symbols if s.name.endswith("." + name) or s.name.split("::")[-1] == name), None)


def excerpt(text: str, symbols: list[Symbol], wanted: list[str], context: int = 6) -> str:
    lines = text.splitlines()
    ranges: list[list[int]] = []
    for w in wanted:
        s = find(symbols, w)
        if s:
            ranges.append([max(1, s.start - context), min(len(lines), s.end + context)])
    if not ranges:
        return text
    ranges.sort()
    merged = [ranges[0]]
    for a, b in ranges[1:]:
        if a <= merged[-1][1] + 1:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    out: list[str] = []
    prev_end = 0
    for a, b in merged:
        if a > prev_end + 1:
            out.append(f"[... lines {prev_end + 1}-{a - 1} omitted ...]")
        out += lines[a - 1:b]
        prev_end = b
    if prev_end < len(lines):
        out.append(f"[... lines {prev_end + 1}-{len(lines)} omitted ...]")
    return "\n".join(out) + "\n"
