from __future__ import annotations

import importlib
import re
from functools import lru_cache
from typing import Any, Callable

GRAMMARS = {"c": ("tree_sitter_c", "language"), "cpp": ("tree_sitter_cpp", "language"), "java": ("tree_sitter_java", "language"),
            "js": ("tree_sitter_javascript", "language"), "css": ("tree_sitter_css", "language"), "html": ("tree_sitter_html", "language")}
C_TYPES = {"class_specifier": "class", "struct_specifier": "struct", "union_specifier": "union", "enum_specifier": "enum"}
JAVA_TYPES = {"class_declaration": "class", "interface_declaration": "interface", "enum_declaration": "enum", "record_declaration": "record"}
JS_FUNCS = ("function_declaration", "generator_function_declaration")
JS_VALUES = ("arrow_function", "function_expression", "function", "generator_function")
IDENT = {"identifier", "type_identifier", "field_identifier", "property_identifier", "namespace_identifier"}


@lru_cache(maxsize=None)
def parser(language: str) -> Any:
    if language not in GRAMMARS:
        return None
    try:
        import tree_sitter as ts

        mod, fn = GRAMMARS[language]
        return ts.Parser(ts.Language(getattr(importlib.import_module(mod), fn)()))
    except Exception:
        return None


def available(language: str) -> bool:
    return parser(language) is not None


def _text(node: Any) -> str:
    return node.text.decode("utf-8", errors="replace") if node is not None else ""


def _span(node: Any) -> tuple[int, int]:
    return node.start_point[0] + 1, node.end_point[0] + 1


def _c_func_name(decl: Any) -> str:
    while decl is not None and decl.type not in ("identifier", "qualified_identifier", "field_identifier", "destructor_name", "operator_name", "template_function"):
        nxt = decl.child_by_field_name("declarator")
        if nxt is None:
            nxt = next((c for c in decl.named_children if c.type.endswith("declarator") or c.type in IDENT or c.type == "qualified_identifier"), None)
        decl = nxt
    return re.sub(r"\s+", "", _text(decl))


def _c(root: Any, add: Callable[[str, str, Any], None]) -> None:
    def visit(node: Any, owner: str) -> None:
        for ch in node.named_children:
            t = ch.type
            if t in C_TYPES and ch.child_by_field_name("body") is not None and ch.child_by_field_name("name") is not None:
                name = _text(ch.child_by_field_name("name"))
                add(name, C_TYPES[t], ch)
                visit(ch.child_by_field_name("body"), name)
            elif t == "function_definition":
                name = _c_func_name(ch.child_by_field_name("declarator"))
                if name:
                    add(f"{owner}.{name}" if owner and "::" not in name else name, "def", ch)
            elif t not in ("compound_statement", "comment", "string_literal"):
                visit(ch, owner)

    visit(root, "")


def _java(root: Any, add: Callable[[str, str, Any], None]) -> None:
    def visit(node: Any, owner: str) -> None:
        for ch in node.named_children:
            t = ch.type
            if t in JAVA_TYPES:
                name = _text(ch.child_by_field_name("name"))
                add(name, JAVA_TYPES[t], ch)
                body = ch.child_by_field_name("body")
                if body is not None:
                    visit(body, name)
            elif t in ("method_declaration", "constructor_declaration"):
                name = _text(ch.child_by_field_name("name"))
                add(f"{owner}.{name}" if owner else name, "def", ch)
            elif t not in ("block", "comment"):
                visit(ch, owner)

    visit(root, "")


def _js(root: Any, add: Callable[[str, str, Any], None]) -> None:
    def visit(node: Any, owner: str) -> None:
        for ch in node.named_children:
            t = ch.type
            if t in ("class_declaration", "class") and ch.child_by_field_name("name") is not None:
                name = _text(ch.child_by_field_name("name"))
                add(name, "class", ch)
                body = ch.child_by_field_name("body")
                if body is not None:
                    visit(body, name)
                continue
            if t == "method_definition" and owner:
                add(f"{owner}.{_text(ch.child_by_field_name('name'))}", "method", ch)
                body = ch.child_by_field_name("body")
                if body is not None:
                    visit(body, "")
                continue
            if t in JS_FUNCS and ch.child_by_field_name("name") is not None:
                add(_text(ch.child_by_field_name("name")), "def", ch)
            elif t == "variable_declarator":
                value = ch.child_by_field_name("value")
                if value is not None and value.type in JS_VALUES and ch.child_by_field_name("name") is not None:
                    add(_text(ch.child_by_field_name("name")), "def", ch)
            elif t == "assignment_expression":
                left = ch.child_by_field_name("left")
                m = re.match(r"^(?:module\.)?exports\.(\w+)$", _text(left)) if left is not None else None
                if m:
                    add(m.group(1), "def", ch)
            if t != "comment":
                visit(ch, "")

    visit(root, "")


def _css(root: Any, add: Callable[[str, str, Any], None]) -> None:
    for ch in root.named_children:
        if ch.type == "rule_set":
            sel = next((c for c in ch.named_children if c.type == "selectors"), None)
            add(" ".join(_text(sel).split()), "rule", ch)
        elif ch.type.endswith("_statement") and ch.type != "import_statement":
            head = _text(ch).split("{", 1)[0]
            add(" ".join(head.split()), "rule", ch)


def _html(root: Any, add: Callable[[str, str, Any], None]) -> None:
    def visit(node: Any) -> None:
        for ch in node.named_children:
            if ch.type == "attribute":
                name = next((c for c in ch.named_children if c.type == "attribute_name"), None)
                if name is not None and _text(name).lower() == "id":
                    val = next((c for c in ch.named_children if c.type in ("attribute_value", "quoted_attribute_value")), None)
                    v = _text(val).strip("\"'")
                    if v:
                        add(f"#{v}", "id", ch)
            else:
                visit(ch)

    visit(root)


WALKERS = {"c": _c, "cpp": _c, "java": _java, "js": _js, "css": _css, "html": _html}


def extract(language: str, text: str) -> list[tuple[str, str, int, int]] | None:
    p = parser(language)
    if p is None:
        return None
    root = p.parse(text.encode("utf-8")).root_node
    out: list[tuple[str, str, int, int]] = []

    def add(name: str, kind: str, node: Any) -> None:
        if name:
            out.append((name, kind, *_span(node)))

    WALKERS[language](root, add)
    return out


def identifiers(language: str, text: str) -> set[str] | None:
    p = parser(language)
    if p is None:
        return None
    found: set[str] = set()
    stack = [p.parse(text.encode("utf-8")).root_node]
    while stack:
        n = stack.pop()
        if n.type in IDENT:
            found.add(_text(n))
        stack.extend(n.children)
    return found
