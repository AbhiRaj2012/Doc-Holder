from __future__ import annotations

import hashlib
import heapq
from enum import Enum
from typing import Literal

from pydantic import BaseModel, Field, field_validator, model_validator

from .paths import posix_list

Language = Literal["python", "c", "cpp", "java", "js", "web"]
TaskKind = Literal["feature", "bugfix", "refactor", "test", "scaffold"]
CheckKind = Literal["syntax", "build", "test", "lint", "typecheck"]


class TaskStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    SKIPPED = "skipped"
    BLOCKED = "blocked"
    SUSPENDED = "suspended"
    SPLIT = "split"


class ExitReason(str, Enum):
    APPROVED = "approved"
    MAX_ITER = "max_iterations"
    NO_PROGRESS = "no_progress"
    ABORTED = "aborted"
    BUDGET = "budget_exceeded"
    OSCILLATION = "oscillation"
    CANNOT_SPLIT = "cannot_split"
    SUSPEND_LIMIT = "suspend_limit"


class Task(BaseModel):
    id: str
    title: str
    description: str
    language: Language
    kind: TaskKind = "feature"
    target_files: list[str] = Field(default_factory=list)
    symbol_targets: list[str] = Field(default_factory=list)
    acceptance_criteria: list[str] = Field(min_length=1)
    verify_command: str | None = None
    depends_on: list[str] = Field(default_factory=list)
    priority: int = Field(default=3, ge=1, le=5)
    reference_files: list[str] = Field(default_factory=list)
    status: TaskStatus = TaskStatus.PENDING
    parent_id: str | None = None
    shrink_level: int = 0
    verify_source: Literal["planner", "default", "none"] = "planner"
    mirror: dict[str, str] | None = None
    optional: bool = False

    @field_validator("target_files", "reference_files", mode="after")
    @classmethod
    def _posix_paths(cls, v: list[str]) -> list[str]:
        return posix_list(v)


class Plan(BaseModel):
    summary: str
    tasks: list[Task] = Field(min_length=1)

    @model_validator(mode="after")
    def _validate_graph(self) -> "Plan":
        ids = [t.id for t in self.tasks]
        if len(set(ids)) != len(ids):
            raise ValueError("duplicate task ids")
        known = set(ids)
        for t in self.tasks:
            missing = [d for d in t.depends_on if d not in known]
            if missing:
                raise ValueError(f"task {t.id} depends on unknown ids {missing}")
            if t.id in t.depends_on:
                raise ValueError(f"task {t.id} depends on itself")
        if len(self.ordered()) != len(self.tasks):
            raise ValueError("dependency cycle detected")
        return self

    def ordered(self) -> list[Task]:
        index = {t.id: i for i, t in enumerate(self.tasks)}
        indeg = {t.id: len(t.depends_on) for t in self.tasks}
        children: dict[str, list[str]] = {t.id: [] for t in self.tasks}
        for t in self.tasks:
            for d in t.depends_on:
                children[d].append(t.id)
        by_id = {t.id: t for t in self.tasks}
        heap = [(by_id[i].priority, index[i], i) for i, n in indeg.items() if n == 0]
        heapq.heapify(heap)
        out: list[Task] = []
        while heap:
            _, _, tid = heapq.heappop(heap)
            out.append(by_id[tid])
            for c in children[tid]:
                indeg[c] -= 1
                if indeg[c] == 0:
                    heapq.heappush(heap, (by_id[c].priority, index[c], c))
        return out


class FileInfo(BaseModel):
    path: str
    language: str
    sha256: str
    size: int
    symbols: list[str] = Field(default_factory=list)


class Manifest(BaseModel):
    project_id: str = ""
    code_tree_hash: str = ""
    project_name: str
    root: str
    is_empty: bool = False
    has_tests: bool = False
    languages: list[str] = Field(default_factory=list)
    primary_language: str = "python"
    build_system: str = ""
    commands: dict[str, str] = Field(default_factory=dict)
    dependencies: dict[str, list[str]] = Field(default_factory=dict)
    entry_points: list[str] = Field(default_factory=list)
    files: list[FileInfo] = Field(default_factory=list)
    repo_map: str = ""
    parser: str = ""
    generated_at: str = ""


class Failure(BaseModel):
    kind: CheckKind
    file: str = ""
    line: int = 0
    name: str = ""
    message: str = ""

    def short(self, limit: int = 400) -> str:
        loc = f"{self.file}:{self.line}" if self.file else ""
        head = " ".join(p for p in (self.kind.upper(), loc, self.name) if p)
        return f"{head} - {self.message}"[:limit]


class CheckResult(BaseModel):
    name: CheckKind
    ok: bool
    skipped: bool = False
    exit_code: int = 0
    duration_s: float = 0.0
    command: str = ""
    failures: list[Failure] = Field(default_factory=list)
    output_tail: str = ""


class EditResult(BaseModel):
    ok: bool
    files_changed: list[str] = Field(default_factory=list)
    diff: str = ""
    stdout_tail: str = ""
    error: str = ""
    edit_format: str = "diff"
    duration_s: float = 0.0
    tokens_in: int = 0
    tokens_out: int = 0
    truncated: bool = False
    blocks_applied: int = 0
    blocks_failed: int = 0
    blocks: list[dict] = Field(default_factory=list)
    invocation: dict = Field(default_factory=dict)


class LLMVerdict(BaseModel):
    approved: bool
    unmet_criteria: list[str] = Field(default_factory=list)
    feedback: str = ""


class ReviewResult(BaseModel):
    checks: list[CheckResult] = Field(default_factory=list)
    llm: LLMVerdict | None = None
    approved: bool = False
    fingerprint: str = ""

    @property
    def deterministic_ok(self) -> bool:
        return all(c.ok or c.skipped for c in self.checks)

    def all_failures(self) -> list[Failure]:
        return [f for c in self.checks for f in c.failures]

    def feedback_text(self, max_failures: int = 5) -> str:
        lines = [f.short() for f in self.all_failures()[:max_failures]]
        if self.llm and not self.llm.approved:
            lines += [f"UNMET: {u}" for u in self.llm.unmet_criteria]
            if self.llm.feedback:
                lines.append(f"REVIEW: {self.llm.feedback}")
        return "\n".join(lines)


def fingerprint(diff: str, failures_text: str) -> str:
    return hashlib.sha256(f"{diff}\n---\n{failures_text}".encode("utf-8")).hexdigest()[:16]


class SuspendReason(str, Enum):
    TOKEN_EXHAUSTED = "token_exhausted"
    CONTEXT_OVERFLOW = "context_overflow"
    STEP_TIMEOUT = "step_timeout"
    EDIT_LADDER = "edit_ladder_exhausted"
    NO_PROGRESS = "no_progress"
    HUMAN_PAUSE = "human_pause"
    CRASH = "crash_recovery"


class TaskFrame(BaseModel):
    task_id: str
    step: Literal["locate", "edit", "verify", "review"] = "edit"
    reason: SuspendReason
    iteration: int = 0
    base_tree: str = ""
    open_issue_ids: list[str] = Field(default_factory=list)
    scope_files: list[str] = Field(default_factory=list)
    scope_symbols: list[str] = Field(default_factory=list)
    shrink_level: int = 0
    attempts: int = 1
    note: str = ""
    created_at: str = ""


class HumanDecision(BaseModel):
    action: Literal["work", "proceed", "abort", "accept", "restart", "replan", "replan_all"]
    hint: str = ""


class PlanDecision(BaseModel):
    action: Literal["approve", "revise", "abort"]
    hint: str = ""
    remove: list[str] = Field(default_factory=list)


class IssueRecord(BaseModel):
    run_id: str
    task: Task
    iteration: int
    reason: ExitReason
    diff: str = ""
    review: ReviewResult | None = None
    history: list[str] = Field(default_factory=list)
    explanation: dict = Field(default_factory=dict)
    created_at: str = ""
