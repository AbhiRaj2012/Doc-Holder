from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, Field

PROJECT_ROOT = Path(__file__).resolve().parents[2]
CONFIG_DIR = Path(os.environ.get("SDLC_CONFIG_DIR", PROJECT_ROOT / "config"))

Effort = Literal["off", "low", "medium", "high"]
NODES = ("analyser", "planner", "editor", "reviewer", "judge")


class OllamaCfg(BaseModel):
    base_url: str = "http://localhost:11434"
    main_model: str = "gpt-oss:20b"
    judge_model: str = "gpt-oss:20b"
    role_models: dict[str, str] = Field(default_factory=dict)
    fallback_models: dict[str, str] = Field(default_factory=dict)
    num_ctx: int = 32768
    temperature: float = 0.1
    request_timeout_s: int = 900
    keep_alive: str = "30m"


class ReasoningCfg(BaseModel):
    analyser: Effort = "low"
    planner: Effort = "high"
    editor: Effort = "off"
    reviewer: Effort = "low"
    judge: Effort = "medium"


class BudgetCfg(BaseModel):
    context_safety: float = 0.85
    max_output_tokens: dict[str, int] = Field(
        default_factory=lambda: {"planner": 6000, "editor": 4000, "reviewer": 2500, "judge": 3000}
    )
    max_file_prompt_bytes: int = 40000
    step_max_lines: int = 200


class LimitsCfg(BaseModel):
    max_iterations_per_task: int = 5
    no_progress_repeats: int = 2
    max_wall_seconds: int = 14400
    max_total_tokens: int = 3_000_000
    subprocess_timeout_s: int = 600
    max_failures_fed_back: int = 5
    max_tasks: int = 40
    json_retries: int = 2
    max_suspended_frames: int = 8
    max_shrink_level: int = 3
    max_split_depth: int = 2
    max_ladder_suspends: int = 1


class LoopCfg(BaseModel):
    split_budgets: bool = True
    mechanical_allowance: int = 2
    best_snapshot: bool = True
    rollback_worse: bool = True
    stall_window: int = 3
    test_baseline: bool = True
    escalation: bool = True
    diagnose_after: int = 2
    boost_after: int = 3
    boost_effort: str = ""
    fallback_after: int = 4


class AiderCfg(BaseModel):
    binary: str = "aider"
    edit_format: str = "diff"
    fallback_format: str = "whole"
    fallback_after_failures: int = 2
    whole_max_bytes: int = 12000
    timeout_s: int = 900
    map_tokens: int = 1024
    extra_args: list[str] = Field(default_factory=list)


class GitCfg(BaseModel):
    branch_prefix: str = "sdlc/run-"
    author_name: str = "sdlc-bot"
    author_email: str = "sdlc-bot@localhost"


class HardwareCfg(BaseModel):
    gpu_vram_gb: float = 16.0
    kv_cache_type: Literal["f16", "q8_0", "q4_0"] = "q8_0"
    context_override: int | None = None
    overhead_gb: float = 1.5
    model_gpu_gb: float | None = None


class FeaturesCfg(BaseModel):
    plan_critic: bool = True
    llm_drift: bool = True
    regression_gate: bool = True
    baseline_build: bool = True
    plan_approval: bool = False


class EvalCfg(BaseModel):
    llm_metrics: bool = True
    max_arg_cases: int = 4
    max_tool_calls_per_case: int = 8
    step_efficiency_cross_check: bool = False


class PathsCfg(BaseModel):
    projects_root: str = "projects"
    benchmark_dir: str = "data/benchmark"
    tiktoken_cache: str = "deploy/tiktoken_cache"
    toolchain: list[str] = Field(default_factory=list)


class Settings(BaseModel):
    ollama: OllamaCfg = Field(default_factory=OllamaCfg)
    reasoning: ReasoningCfg = Field(default_factory=ReasoningCfg)
    budget: BudgetCfg = Field(default_factory=BudgetCfg)
    limits: LimitsCfg = Field(default_factory=LimitsCfg)
    loop: LoopCfg = Field(default_factory=LoopCfg)
    aider: AiderCfg = Field(default_factory=AiderCfg)
    git: GitCfg = Field(default_factory=GitCfg)
    paths: PathsCfg = Field(default_factory=PathsCfg)
    hardware: HardwareCfg = Field(default_factory=HardwareCfg)
    features: FeaturesCfg = Field(default_factory=FeaturesCfg)
    evals: EvalCfg = Field(default_factory=EvalCfg)

    @staticmethod
    def _abs(p: str) -> Path:
        q = Path(p)
        return q if q.is_absolute() else PROJECT_ROOT / q

    def projects_root(self) -> Path:
        return self._abs(self.paths.projects_root)

    def benchmark_root(self) -> Path:
        return self._abs(self.paths.benchmark_dir)

    def tiktoken_dir(self) -> Path:
        p = Path(self.paths.tiktoken_cache)
        return p if p.is_absolute() else PROJECT_ROOT / p

    def prompt_tokens_for(self, node: str) -> int:
        usable = int(self.ollama.num_ctx * self.budget.context_safety)
        return max(1024, usable - self.budget.max_output_tokens.get(node, 2000))

    def effort_for(self, node: str) -> Effort:
        return getattr(self.reasoning, node)

    def model_for(self, node: str) -> str:
        if node == "judge":
            return self.ollama.judge_model
        return self.ollama.role_models.get(node) or self.ollama.main_model

    def run_models(self) -> list[str]:
        return list(dict.fromkeys([self.ollama.main_model, *[m for m in self.ollama.role_models.values() if m]]))


def _deep_merge(base: dict[str, Any], over: dict[str, Any]) -> dict[str, Any]:
    out = dict(base)
    for k, v in over.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def load_settings(path: str | Path | None = None, overrides: dict[str, Any] | None = None) -> Settings:
    p = Path(path) if path else CONFIG_DIR / "settings.yaml"
    data: dict[str, Any] = {}
    if p.exists():
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    if overrides:
        data = _deep_merge(data, overrides)
    return Settings.model_validate(data)


class MetricSpec(BaseModel):
    bad_max: float
    good_min: float
    threshold: float


class MetricsConfig(BaseModel):
    metrics: dict[str, MetricSpec]

    def band(self, name: str, score: float) -> Literal["bad", "acceptable", "good"]:
        spec = self.metrics[name]
        s = round(score, 2)
        if s <= spec.bad_max:
            return "bad"
        if s >= spec.good_min:
            return "good"
        return "acceptable"

    def passed(self, name: str, score: float) -> bool:
        return score >= self.metrics[name].threshold


def load_metrics(path: str | Path | None = None) -> MetricsConfig:
    p = Path(path) if path else CONFIG_DIR / "metrics.yaml"
    return MetricsConfig.model_validate(yaml.safe_load(p.read_text(encoding="utf-8")))
