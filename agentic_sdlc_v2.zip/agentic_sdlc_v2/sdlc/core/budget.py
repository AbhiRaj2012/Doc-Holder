from __future__ import annotations

import math
import time
from dataclasses import dataclass
from typing import Literal

CHARS_PER_TOKEN = 3.5
SAFETY_MARGIN = 1.15
TRUNC_MARKER = "\n...[truncated]...\n"

Keep = Literal["head", "tail", "middle"]


class BudgetExceeded(Exception):
    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


def estimate_tokens(text: str) -> int:
    if not text:
        return 0
    return math.ceil(len(text) / CHARS_PER_TOKEN * SAFETY_MARGIN)


def truncate_to_tokens(text: str, max_tokens: int, keep: Keep = "head") -> str:
    if estimate_tokens(text) <= max_tokens:
        return text
    max_chars = max(0, int(max_tokens * CHARS_PER_TOKEN / SAFETY_MARGIN) - len(TRUNC_MARKER))
    if max_chars == 0:
        return TRUNC_MARKER.strip()
    if keep == "head":
        return text[:max_chars] + TRUNC_MARKER
    if keep == "tail":
        return TRUNC_MARKER + text[-max_chars:]
    half = max_chars // 2
    return text[:half] + TRUNC_MARKER + text[len(text) - (max_chars - half):]


@dataclass
class Section:
    name: str
    text: str
    priority: int
    min_tokens: int = 0
    keep: Keep = "head"


def fit_sections(sections: list[Section], budget_tokens: int) -> dict[str, str]:
    texts = {s.name: s.text for s in sections}
    sizes = {s.name: estimate_tokens(s.text) for s in sections}
    total = sum(sizes.values())
    for s in sorted(sections, key=lambda x: x.priority):
        excess = total - budget_tokens
        if excess <= 0:
            break
        target = max(s.min_tokens, sizes[s.name] - excess)
        if target >= sizes[s.name]:
            continue
        texts[s.name] = truncate_to_tokens(s.text, target, s.keep)
        new_size = estimate_tokens(texts[s.name])
        total -= sizes[s.name] - new_size
        sizes[s.name] = new_size
    return texts


class RunGuard:
    def __init__(self, max_wall_seconds: int, max_total_tokens: int, started_at: float | None = None, tokens_used: int = 0):
        self.max_wall = max_wall_seconds
        self.max_tokens = max_total_tokens
        self.started_at = started_at if started_at is not None else time.time()
        self.tokens_used = tokens_used

    def add_tokens(self, n: int) -> None:
        self.tokens_used += max(0, n)

    def elapsed(self) -> float:
        return time.time() - self.started_at

    def check(self) -> None:
        if self.elapsed() > self.max_wall:
            raise BudgetExceeded(f"wall-clock limit {self.max_wall}s exceeded")
        if self.tokens_used > self.max_tokens:
            raise BudgetExceeded(f"token limit {self.max_tokens} exceeded")
