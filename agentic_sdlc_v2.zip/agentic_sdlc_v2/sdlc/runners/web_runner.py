from __future__ import annotations

import shlex
import time
from html.parser import HTMLParser

from ..core.schemas import CheckResult, Failure
from .js_runner import JsRunner

VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}
OPTIONAL_END = {"p", "li", "dt", "dd", "tr", "td", "th", "option", "optgroup", "thead", "tbody", "tfoot", "colgroup", "rt", "rp"}
JS_EXT = (".js", ".mjs", ".cjs")


class _Balance(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.stack: list[tuple[str, int]] = []
        self.errors: list[tuple[int, str]] = []

    def handle_starttag(self, tag: str, attrs: list) -> None:
        if tag not in VOID:
            self.stack.append((tag, self.getpos()[0]))

    def handle_startendtag(self, tag: str, attrs: list) -> None:
        return

    def handle_endtag(self, tag: str) -> None:
        line = self.getpos()[0]
        if tag in VOID:
            return
        names = [t for t, _ in self.stack]
        if tag not in names:
            self.errors.append((line, f"unexpected closing tag </{tag}>"))
            return
        while self.stack and self.stack[-1][0] != tag:
            open_tag, open_line = self.stack.pop()
            if open_tag not in OPTIONAL_END:
                self.errors.append((open_line, f"<{open_tag}> opened here is closed by </{tag}> at line {line}"))
        self.stack.pop()


def html_check(text: str) -> list[tuple[int, str]]:
    p = _Balance()
    p.feed(text)
    p.close()
    errors = list(p.errors)
    for tag, line in p.stack:
        if tag not in OPTIONAL_END:
            errors.append((line, f"<{tag}> is never closed"))
    return errors


def css_check(text: str) -> list[tuple[int, str]]:
    errors: list[tuple[int, str]] = []
    depth_lines: list[int] = []
    i, line, n = 0, 1, len(text)
    while i < n:
        c = text[i]
        if c == "\n":
            line += 1
        elif text.startswith("/*", i):
            end = text.find("*/", i + 2)
            if end == -1:
                errors.append((line, "unterminated comment"))
                return errors
            line += text.count("\n", i, end)
            i = end + 1
        elif c in "\"'":
            j = i + 1
            while j < n and text[j] != c and text[j] != "\n":
                j += 2 if text[j] == "\\" else 1
            if j >= n or text[j] == "\n":
                errors.append((line, "unterminated string"))
            i = j
        elif c == "{":
            depth_lines.append(line)
        elif c == "}":
            if depth_lines:
                depth_lines.pop()
            else:
                errors.append((line, "unexpected }"))
        i += 1
    errors += [(ln, "{ opened here is never closed") for ln in depth_lines]
    return errors


class WebRunner(JsRunner):
    language = "web"
    extensions = (".html", ".htm", ".css", ".js", ".mjs", ".cjs", ".jsx", ".ts", ".tsx")
    markers = ("index.html", "package.json")

    def defaults(self) -> dict[str, str]:
        if not (self.repo / "package.json").exists():
            return {}
        deps = self.deps()
        cmds = {k: v for k, v in super().defaults().items() if k != "lint"}
        lint: list[str] = []
        if "eslint" in deps:
            lint.append("npx --no-install eslint -f unix {js}")
        if "stylelint" in deps:
            lint.append("npx --no-install stylelint --formatter unix {css}")
        if lint:
            cmds["lint"] = " && ".join(lint)
        return cmds

    def render(self, command: str, files: list[str]) -> str:
        def pick(*exts: str, glob: str) -> str:
            chosen = [f for f in files if f.endswith(exts)]
            return " ".join(shlex.quote(f) for f in chosen) if chosen else glob

        out = command.replace("{js}", pick(*JS_EXT, glob="."))
        out = out.replace("{css}", pick(".css", glob="'**/*.css'")).replace("{html}", pick(".html", ".htm", glob="'**/*.html'"))
        return super().render(out, files)

    def syntax(self, files: list[str]) -> CheckResult:
        start = time.monotonic()
        failures: list[Failure] = []
        checked = 0
        for f in files:
            if f.endswith((".html", ".htm")):
                checker = html_check
            elif f.endswith(".css"):
                checker = css_check
            else:
                continue
            checked += 1
            text = (self.repo / f).read_text(encoding="utf-8", errors="replace")
            failures += [Failure(kind="syntax", file=f, line=ln, message=msg) for ln, msg in checker(text)]
        js = super().syntax([f for f in files if f.endswith(JS_EXT)])
        failures += js.failures
        if not checked and js.skipped:
            return CheckResult(name="syntax", ok=True, skipped=True, output_tail="no html/css/js files to check")
        return CheckResult(
            name="syntax", ok=not failures, duration_s=round(time.monotonic() - start, 2),
            failures=failures[:50], output_tail="\n".join(x.short() for x in failures[:10]),
        )
