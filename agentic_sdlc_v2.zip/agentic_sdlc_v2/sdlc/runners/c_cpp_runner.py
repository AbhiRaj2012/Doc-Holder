from __future__ import annotations

import glob
import json
import os
import re
import shutil
import shlex
import subprocess
import time
from pathlib import Path

from ..core.schemas import CheckKind, CheckResult, Failure
from . import parsers
from .base import Runner
from .sandbox import run_command

SOURCE_EXT = (".c", ".cc", ".cpp", ".cxx")
CPPCHECK_TEMPLATE = "'{file}:{line}:{column}: {severity}: {message}'"


def _has(dirs: list[str], exe: str) -> bool:
    return shutil.which(exe, path=os.pathsep.join(dirs)) is not None


def toolchain_kits() -> list[list[str]]:
    kits: list[list[str]] = []
    for root in ("C:/msys64/ucrt64", "C:/msys64/mingw64", "C:/msys64/clang64"):
        if Path(root, "bin").is_dir():
            kits.append([str(Path(root, "bin"))])
    for qt_bin in sorted(glob.glob("C:/Qt/*/mingw*/bin"), reverse=True):
        tools = sorted(glob.glob("C:/Qt/Tools/mingw*/bin"), reverse=True)
        kits.append([str(Path(qt_bin)), *([str(Path(tools[0]))] if tools else [])])
    return kits


def toolchain_dirs(current_path: str = "", need_qmake: bool = False) -> list[str]:
    explicit = os.environ.get("SDLC_TOOLCHAIN", "").strip()
    if explicit:
        return [d for d in explicit.split(os.pathsep) if d]
    if os.name != "nt":
        return []
    have = current_path.split(os.pathsep) if current_path else []
    if _has(have, "g++") and (not need_qmake or _has(have, "qmake")):
        return []
    for kit in toolchain_kits():
        if _has(kit, "g++") and (not need_qmake or _has(kit, "qmake")):
            return kit
    return []


class CCppRunner(Runner):
    language = "cpp"
    extensions = (".c", ".h", ".cc", ".cpp", ".cxx", ".hpp", ".hh", ".hxx")
    markers = ("CMakeLists.txt", "Makefile", "makefile", "meson.build")
    mem_mb = 8192

    def __init__(self, repo: str | Path, timeout: int = 600, language: str | None = None):
        super().__init__(repo, timeout, language)
        extra = [d for d in toolchain_dirs(self.env["PATH"], bool(self._pro_file())) if d not in self.env["PATH"]]
        if extra:
            self.env["PATH"] = os.pathsep.join([*extra, self.env["PATH"]])
        self.toolchain = extra

    def _which(self, exe: str) -> str | None:
        return shutil.which(exe, path=self.env["PATH"])

    def _pro_file(self) -> str:
        pros = sorted(p.name for p in self.repo.glob("*.pro"))
        return pros[0] if pros else ""

    def _make_tool(self) -> str:
        return next((m for m in ("mingw32-make", "make", "nmake", "jom") if self._which(m)), "make")

    def system(self) -> str:
        r = self.repo
        if self._pro_file() and self._which("qmake"):
            return "qmake"
        if (r / "CMakeLists.txt").exists():
            return "cmake"
        if (r / "meson.build").exists():
            return "meson"
        if (r / "Makefile").exists() or (r / "makefile").exists():
            return "make"
        return ""

    def _generator(self) -> str:
        for exe, gen in (("ninja", "Ninja"), ("mingw32-make", "MinGW Makefiles"), ("make", "Unix Makefiles")):
            if self._which(exe):
                return f'-G "{gen}" '
        return ""

    def _makefile_text(self) -> str:
        for n in ("Makefile", "makefile"):
            p = self.repo / n
            if p.exists():
                return p.read_text(encoding="utf-8", errors="ignore")
        return ""

    def _make_test_target(self) -> str:
        text = self._makefile_text()
        for target in ("test", "check"):
            if re.search(rf"^{target}\s*:", text, re.M):
                return target
        return ""

    def defaults(self) -> dict[str, str]:
        s = self.system()
        lint = f"cppcheck --enable=warning,performance,portability --inline-suppr --quiet --error-exitcode=1 --template={CPPCHECK_TEMPLATE} {{files}}"
        if s == "qmake":
            make = self._make_tool()
            jobs = " -j{jobs}" if make != "nmake" else ""
            return {"build": f"qmake -o build/Makefile {self._pro_file()} && {make} -C build{jobs}", "lint": lint}
        if s == "cmake":
            return {
                "build": f"cmake -S . -B build {self._generator()}-Wno-dev -DCMAKE_EXPORT_COMPILE_COMMANDS=ON && cmake --build build --parallel {{jobs}}",
                "test": "ctest --test-dir build --output-on-failure",
                "lint": lint,
            }
        if s == "meson":
            setup = "" if (self.repo / "build").is_dir() else "meson setup build && "
            return {"build": f"{setup}meson compile -C build", "test": "meson test -C build --print-errorlogs", "lint": lint}
        if s == "make":
            target = self._make_test_target() or "test"
            return {"build": "make -j{jobs}", "test": f"make {target}", "lint": lint}
        return {"lint": lint}

    def enabled(self, kind: CheckKind) -> bool:
        s = self.system()
        if kind == "test":
            if s == "make":
                return bool(self._make_test_target())
            if s == "cmake":
                text = (self.repo / "CMakeLists.txt").read_text(encoding="utf-8", errors="ignore")
                return "enable_testing" in text or "add_test" in text or "include(CTest)" in text
        return True

    def _compile_db(self) -> dict[Path, dict]:
        for p in (self.repo / "build" / "compile_commands.json", self.repo / "compile_commands.json"):
            if p.exists():
                try:
                    entries = json.loads(p.read_text(encoding="utf-8"))
                except (OSError, ValueError):
                    continue
                return {(Path(e["directory"]) / e["file"]).resolve(): e for e in entries}
        return {}

    def _qt_includes(self) -> list[str]:
        pro = self._pro_file()
        if not pro or not self._which("qmake"):
            return []
        try:
            res = subprocess.run(["qmake", "-query", "QT_INSTALL_HEADERS"], capture_output=True, text=True, timeout=30, env={**os.environ, **self.env})
        except (OSError, subprocess.SubprocessError):
            return []
        base = Path(res.stdout.strip())
        if not base.is_dir():
            return []
        text = (self.repo / pro).read_text(encoding="utf-8", errors="ignore")
        mods = {"core", "gui"} | {m.lower() for line in re.findall(r"^\s*QT\s*\+?=\s*(.+)$", text, re.M) for m in line.split()}
        dirs = [str(base)] + [str(base / f"Qt{m.capitalize()}") for m in sorted(mods) if (base / f"Qt{m.capitalize()}").is_dir()]
        return dirs

    def _fallback_syntax(self, files: list[str]) -> CheckResult:
        targets = [f for f in files if f.endswith(SOURCE_EXT)]
        is_c = all(f.endswith(".c") for f in targets)
        compiler = next((c for c in (("gcc", "clang", "cc") if is_c else ("g++", "clang++", "c++")) if self._which(c)), "")
        if not targets or not compiler:
            return CheckResult(name="syntax", ok=True, skipped=True, output_tail="no compile database entry and no compiler found")
        hdr_dirs = sorted({str((self.repo / p).parent) for p in (q.relative_to(self.repo).as_posix() for q in self.repo.rglob("*") if q.suffix in (".h", ".hpp", ".hh") and "build" not in q.parts)})[:30]
        flags = ["-std=c11"] if is_c else ["-std=c++17", "-fPIC"]
        inc = [f"-I{d}" for d in [str(self.repo), *hdr_dirs, *self._qt_includes()]]
        start = time.monotonic()
        failures: list[Failure] = []
        inconclusive = True
        for f in targets:
            res = run_command(shlex.join([compiler, *flags, *inc, "-fsyntax-only", f]), self.repo, self.timeout, self.env, cpu_s=self.cpu_s, mem_mb=self.mem_mb)
            if res.exit_code == 0:
                inconclusive = False
                continue
            found = parsers.colon_lines(res.output, str(self.repo), "syntax", errors_only=True) or parsers.generic(res.output, "syntax")
            missing_hdr = all(re.search(r"No such file or directory|file not found", x.message) for x in found)
            if not missing_hdr:
                inconclusive = False
                failures += found
        if inconclusive and not failures:
            return CheckResult(name="syntax", ok=True, skipped=True, output_tail="headers of external libraries not found; syntax check inconclusive")
        return CheckResult(name="syntax", ok=not failures, duration_s=round(time.monotonic() - start, 2), command=f"{compiler} -fsyntax-only",
                           failures=failures[:50], output_tail="\n".join(x.short() for x in failures[:10]))

    def syntax(self, files: list[str]) -> CheckResult:
        db = self._compile_db()
        targets = [f for f in files if f.endswith(SOURCE_EXT) and (self.repo / f).resolve() in db]
        if not targets:
            return self._fallback_syntax(files)
        start = time.monotonic()
        failures: list[Failure] = []
        for f in targets:
            entry = db[(self.repo / f).resolve()]
            argv = entry.get("arguments") or shlex.split(entry["command"])
            cleaned: list[str] = []
            skip = False
            for a in argv:
                if skip:
                    skip = False
                elif a == "-o":
                    skip = True
                elif a != "-c":
                    cleaned.append(a)
            cmd = shlex.join([*cleaned, "-fsyntax-only"])
            res = run_command(cmd, entry["directory"], self.timeout, self.env, cpu_s=self.cpu_s, mem_mb=self.mem_mb)
            if res.exit_code != 0:
                found = parsers.colon_lines(res.output, str(self.repo), "syntax", errors_only=True)
                failures += found or parsers.generic(res.output, "syntax")
        return CheckResult(
            name="syntax", ok=not failures, duration_s=round(time.monotonic() - start, 2),
            failures=failures[:50], output_tail="\n".join(x.short() for x in failures[:10]),
        )

    def parse(self, kind: CheckKind, output: str) -> list[Failure]:
        root = str(self.repo)
        if kind == "lint":
            return parsers.colon_lines(output, root, kind)
        if kind == "test":
            gtest = [f for f in parsers.colon_lines(output, root, kind) if f.message.startswith("Failure")]
            return gtest + parsers.ctest(output)
        return parsers.colon_lines(output, root, kind, errors_only=True) + parsers.linker(output, kind)
