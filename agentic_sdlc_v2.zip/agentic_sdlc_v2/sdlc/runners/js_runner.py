from __future__ import annotations

import json
import re
import shlex
import time

from ..core.schemas import CheckKind, CheckResult, Failure
from . import parsers
from .js_balance import js_balance_check
from .base import Runner, any_file
from .sandbox import run_command

NODE_CHECKABLE = (".js", ".mjs", ".cjs")
TEST_FILE = re.compile(r"\.(test|spec)\.[cm]?[jt]sx?$|^test.*\.[cm]?js$")


class JsRunner(Runner):
    language = "js"
    extensions = (".js", ".mjs", ".cjs", ".jsx", ".ts", ".tsx")
    markers = ("package.json",)
    mem_mb = None

    def pkg(self) -> dict:
        p = self.repo / "package.json"
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    def deps(self) -> set[str]:
        pkg = self.pkg()
        return set(pkg.get("dependencies", {})) | set(pkg.get("devDependencies", {}))

    def defaults(self) -> dict[str, str]:
        deps, scripts = self.deps(), self.pkg().get("scripts", {})
        if "vitest" in deps:
            test = "npx --no-install vitest run"
        elif "jest" in deps:
            test = "npx --no-install jest --ci"
        elif scripts.get("test") and "no test specified" not in scripts["test"]:
            test = "npm test --silent"
        else:
            test = "node --test"
        cmds = {"test": test}
        if "eslint" in deps:
            cmds["lint"] = "npx --no-install eslint -f unix {files}"
        if (self.repo / "tsconfig.json").exists():
            cmds["typecheck"] = "npx --no-install tsc --noEmit -p ."
        return cmds

    def enabled(self, kind: CheckKind) -> bool:
        if kind == "test":
            custom = self.pkg().get("scripts", {}).get("test", "")
            return bool(custom and "no test specified" not in custom) or any_file(self.repo, TEST_FILE)
        return True

    def syntax(self, files: list[str]) -> CheckResult:
        targets = [f for f in files if f.endswith(NODE_CHECKABLE)]
        if not targets:
            return CheckResult(name="syntax", ok=True, skipped=True, output_tail="no node-checkable files")
        if self.missing_tool("node"):
            failures = [Failure(kind="syntax", file=f, line=ln, message=f"{msg} (bracket/string check; node is not installed)")
                        for f in targets for ln, msg in js_balance_check((self.repo / f).read_text(encoding="utf-8", errors="replace"))]
            return CheckResult(name="syntax", ok=not failures, failures=failures, output_tail="\n".join(x.short() for x in failures))
        start = time.monotonic()
        failures: list[Failure] = []
        for f in targets:
            res = run_command(f"node --check {shlex.quote(f)}", self.repo, self.timeout, self.env, cpu_s=self.cpu_s)
            if res.exit_code != 0:
                loc = next((ln.strip() for ln in res.output.splitlines() if re.search(r"\.(?:js|mjs|cjs):\d+$", ln.strip())), "")
                lineno = int(loc.rsplit(":", 1)[-1]) if loc else 0
                msg = next((ln.strip() for ln in res.output.splitlines() if "Error" in ln), "syntax error")
                failures.append(Failure(kind="syntax", file=f, line=lineno, message=msg[:300]))
        return CheckResult(
            name="syntax", ok=not failures, duration_s=round(time.monotonic() - start, 2),
            failures=failures, output_tail="\n".join(x.short() for x in failures),
        )

    def parse(self, kind: CheckKind, output: str) -> list[Failure]:
        root = str(self.repo)
        if kind == "test":
            return parsers.jest(output, root)
        if kind == "typecheck":
            return parsers.paren_lines(output, root, kind) or parsers.colon_lines(output, root, kind, errors_only=True)
        return parsers.colon_lines(output, root, kind)
