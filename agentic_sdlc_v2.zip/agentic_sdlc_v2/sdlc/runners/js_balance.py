from __future__ import annotations

PAIRS = {")": "(", "]": "[", "}": "{"}
REGEX_PREV = set("(,=:[!&|?{};+-*%<>~^") | {""}
REGEX_WORDS = {"return", "typeof", "case", "do", "else", "in", "of", "void", "yield", "await", "delete", "throw", "new"}


def js_balance_check(text: str) -> list[tuple[int, str]]:
    stack: list[tuple[str, int]] = []
    i, n, line = 0, len(text), 1
    prev, word = "", ""
    while i < n:
        c = text[i]
        if c == "\n":
            line += 1
            i += 1
            continue
        if c in " \t\r":
            i += 1
            continue
        if text.startswith("//", i):
            j = text.find("\n", i)
            i = n if j < 0 else j
            continue
        if text.startswith("/*", i):
            j = text.find("*/", i + 2)
            if j < 0:
                return [(line, "unterminated comment")]
            line += text.count("\n", i, j)
            i = j + 2
            continue
        if c in "'\"":
            j = i + 1
            while j < n and text[j] != c:
                if text[j] == "\\":
                    j += 1
                elif text[j] == "\n":
                    return [(line, "unterminated string")]
                j += 1
            if j >= n:
                return [(line, "unterminated string")]
            i, prev, word = j + 1, "a", ""
            continue
        if c == "`":
            stack.append(("`", line))
            i += 1
            while i < n:
                ch = text[i]
                if ch == "\\":
                    i += 2
                    continue
                if ch == "\n":
                    line += 1
                if ch == "`":
                    stack.pop()
                    i += 1
                    break
                if text.startswith("${", i):
                    stack.append(("${", line))
                    i += 2
                    break
                i += 1
            else:
                return [(stack[-1][1], "unterminated template literal")]
            prev, word = "a", ""
            continue
        if c == "/" and (prev in REGEX_PREV or word in REGEX_WORDS):
            j, cls = i + 1, False
            while j < n and text[j] != "\n":
                if text[j] == "\\":
                    j += 2
                    continue
                if text[j] == "[":
                    cls = True
                elif text[j] == "]":
                    cls = False
                elif text[j] == "/" and not cls:
                    break
                j += 1
            if j < n and text[j] == "/":
                i, prev, word = j + 1, "a", ""
                continue
        if c in "([{":
            stack.append((c, line))
        elif c in ")]}":
            if c == "}" and stack and stack[-1][0] == "${":
                stack.pop()
                i += 1
                while i < n:
                    ch = text[i]
                    if ch == "\\":
                        i += 2
                        continue
                    if ch == "\n":
                        line += 1
                    if ch == "`":
                        stack.pop()
                        i += 1
                        break
                    if text.startswith("${", i):
                        stack.append(("${", line))
                        i += 2
                        break
                    i += 1
                prev, word = "a", ""
                continue
            if not stack or stack[-1][0] != PAIRS[c]:
                return [(line, f"unexpected '{c}'" + (f" (open '{stack[-1][0]}' from line {stack[-1][1]})" if stack else ""))]
            stack.pop()
        if c.isalnum() or c in "_$":
            j = i
            while j < n and (text[j].isalnum() or text[j] in "_$"):
                j += 1
            word, prev = text[i:j], "a"
            i = j
            continue
        prev, word = c, ""
        i += 1
    return [(ln, f"'{ch}' is never closed") for ch, ln in stack[:3]]
