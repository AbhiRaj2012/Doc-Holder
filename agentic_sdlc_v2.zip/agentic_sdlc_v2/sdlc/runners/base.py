from __future__ import annotations

import os
import re
import shlex
import shutil
from abc import ABC, abstractmethod
from pathlib import Path

import yaml

from ..core.offline_env import default_python
from ..core.schemas import CheckKind, CheckResult, Failure
from . import parsers
from .sandbox import run_command

ORDER: tuple[CheckKind, ...] = ("syntax", "build", "lint", "typecheck", "test")
SHELL_BUILTINS = {"test", "cd", "[", "echo", "true", "false", ":", "export", "exit", "source", ".", "set", "ulimit", "eval", "exec", "pushd", "popd", "unset", "read"}
TAIL_CHARS = 3000
SHELL_MISSING = re.compile(r"'([^']+)' is not recognized as an internal or external command|(?:^|\s)([\w.\-]+): (?:command )?not found", re.M)
COLLECT_ERROR = re.compile(r"\b\d+ errors?\b|ERROR collecting|Error: Cannot find module|SyntaxError|ImportError|ModuleNotFoundError")
MISSING_PKG = re.compile(r"ModuleNotFoundError: No module named '([\w.]+)'|Cannot find module '([^'./][^']*)'")
NO_TESTS = re.compile(r"No test configuration file found|No tests were found|no tests ran|collected 0 items|No tests found|Ran 0 tests")
SCAN_IGNORE = {".git", "node_modules", ".venv", "venv", "__pycache__", "build", "dist", "target", ".gradle", ".mypy_cache"}


def any_file(repo: Path, pattern: re.Pattern[str], limit: int = 20000) -> bool:
    seen = 0
    for _, dirs, files in os.walk(repo):
        dirs[:] = [d for d in dirs if d not in SCAN_IGNORE]
        for name in files:
            seen += 1
            if pattern.search(name):
                return True
            if seen >= limit:
                return False
    return False


def load_repo_config(repo: Path) -> dict:
    p = repo / ".sdlc.yaml"
    if not p.exists():
        return {}
    return yaml.safe_load(p.read_text(encoding="utf-8")) or {}


def build_jobs() -> str:
    return os.environ.get("SDLC_BUILD_JOBS") or str(os.cpu_count() or 2)


class Runner(ABC):
    language: str = ""
    extensions: tuple[str, ...] = ()
    markers: tuple[str, ...] = ()
    cpu_s: int | None = 1800
    mem_mb: int | None = None

    def __init__(self, repo: str | Path, timeout: int = 600, language: str | None = None):
        self.repo = Path(repo).resolve()
        self.timeout = timeout
        self.cfg = load_repo_config(self.repo)
        if language:
            self.language = language
        prepend = self.cfg.get("path_prepend", [])
        path = os.pathsep.join([*map(str, prepend), os.environ.get("PATH", "")])
        self.env = {**{str(k): str(v) for k, v in (self.cfg.get("env") or {}).items()}, "PATH": path}

    @classmethod
    def detect(cls, repo: str | Path) -> bool:
        r = Path(repo)
        return any((r / m).exists() for m in cls.markers)

    @abstractmethod
    def defaults(self) -> dict[str, str]:
        ...

    @abstractmethod
    def parse(self, kind: CheckKind, output: str) -> list[Failure]:
        ...

    def commands(self) -> dict[str, str]:
        merged = dict(self.defaults())
        merged.update({k: v for k, v in (self.cfg.get("commands") or {}).items() if k in ORDER})
        return merged

    def enabled(self, kind: CheckKind) -> bool:
        return True

    def syntax(self, files: list[str]) -> CheckResult:
        return CheckResult(name="syntax", ok=True, skipped=True, output_tail="no syntax checker")

    def scoped(self, files: list[str]) -> list[str]:
        out: list[str] = []
        for f in files:
            rel = f[len(str(self.repo)) + 1:] if f.startswith(str(self.repo) + "/") else f
            if rel.endswith(self.extensions) and (self.repo / rel).exists():
                out.append(rel)
        return out

    def render(self, command: str, files: list[str]) -> str:
        quoted = " ".join(shlex.quote(f) for f in files) if files else "."
        return command.replace("{python}", self.cfg.get("python", default_python())).replace("{files}", quoted).replace("{jobs}", build_jobs())

    def missing_tool(self, command: str) -> str | None:
        try:
            tokens = [t for t in shlex.split(command)]
        except ValueError:
            return None
        while tokens and re.match(r"^\w+=", tokens[0]):
            tokens.pop(0)
        if not tokens:
            return None
        first = tokens[0]
        if first in SHELL_BUILTINS or (self.repo / first).exists():
            return None
        if first == "{python}":
            first = self.cfg.get("python", default_python())
        return None if shutil.which(first, path=self.env["PATH"]) else first

    def run_kind(self, kind: CheckKind, files: list[str], command: str | None = None) -> CheckResult:
        strict = command is not None
        cmd = command or self.commands().get(kind, "")
        if not cmd or (not strict and not self.enabled(kind)):
            return CheckResult(name=kind, ok=True, skipped=True, output_tail="not configured")
        missing = self.missing_tool(cmd)
        if missing:
            msg = f"tool not found: {missing}; this check cannot run on this machine, so it is not used as a gate"
            return CheckResult(name=kind, ok=True, skipped=True, command=cmd, output_tail=msg)
        final = self.render(cmd, files)
        res = run_command(final, self.repo, self.timeout, self.env, cpu_s=self.cpu_s, mem_mb=self.mem_mb)
        ok = res.exit_code == 0 and not res.timed_out
        failures: list[Failure] = []
        if res.timed_out:
            failures = [Failure(kind=kind, message=f"timed out after {self.timeout}s")]
        elif not ok:
            gone = SHELL_MISSING.search(res.output)
            tool = (gone.group(1) or gone.group(2)) if gone else ""
            mod = re.search(r"-m\s+([\w.]+)", final)
            if not tool and mod and re.search(rf"No module named '?{re.escape(mod.group(1).split('.')[0])}'?\s*$", res.output.strip(), re.M):
                tool = mod.group(1)
            if tool:
                return CheckResult(name=kind, ok=True, skipped=True, command=final, output_tail=f"tool not found: {tool}; this check cannot run on this machine, so it is not used as a gate")
            failures = self.parse(kind, res.output) or parsers.generic(res.output, kind)
        return CheckResult(
            name=kind, ok=ok, exit_code=res.exit_code, duration_s=res.duration_s, command=final,
            failures=failures, output_tail=res.output[-TAIL_CHARS:],
        )

    def run_all(self, files: list[str], verify_command: str | None = None, ignore_build_failure: str = "") -> list[CheckResult]:
        scoped = self.scoped(files)
        results: list[CheckResult] = []
        for kind in ("syntax", "build"):
            r = self.syntax(scoped) if kind == "syntax" else self.run_kind("build", scoped)
            if kind == "build" and ignore_build_failure and not r.ok and not r.skipped:
                r = CheckResult(name="build", ok=True, skipped=True, command=r.command, output_tail=f"build already failed before any change, so it is not used as a gate: {ignore_build_failure}")
            results.append(r)
            if not r.ok and not r.skipped:
                return results
        for kind in ("lint", "typecheck"):
            results.append(self.run_kind(kind, scoped))
        r = self.finish_test(self.run_kind("test", scoped, command=verify_command))
        if not r.ok and not r.skipped:
            again = self.finish_test(self.run_kind("test", scoped, command=verify_command))
            if again.ok:
                r = again.model_copy(update={"output_tail": "passed on the second run (the first run failed: the test is flaky)\n" + (again.output_tail or "")})
        results.append(r)
        return results

    def finish_test(self, r: CheckResult) -> CheckResult:
        missing = self.missing_package(r.output_tail or "") if not r.ok and not r.skipped else None
        if missing:
            r = CheckResult(name="test", ok=True, skipped=True, command=r.command, output_tail=f"package not installed: {missing}; installing is outside this workflow, so the test is not used as a gate")
        elif not r.ok and not r.skipped and NO_TESTS.search(r.output_tail or "") and not COLLECT_ERROR.search(r.output_tail or ""):
            r = CheckResult(name="test", ok=True, skipped=True, command=r.command, output_tail="no tests were found or run, so this test command cannot be used as a gate")
        return r

    def missing_package(self, output: str) -> str | None:
        from ..core.guards import local_module_names
        local = local_module_names(self.repo)
        for m in MISSING_PKG.finditer(output):
            name = (m.group(1) or m.group(2) or "").split(".")[0].split("/")[0]
            if name and name not in local:
                return name
        return None

    def preflight(self) -> list[str]:
        problems: list[str] = []
        for kind, cmd in self.commands().items():
            if cmd and self.enabled(kind):  # type: ignore[arg-type]
                missing = self.missing_tool(cmd)
                if missing:
                    problems.append(f"{self.language}/{kind}: {missing} not found")
        return problems
