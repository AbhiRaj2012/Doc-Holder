from __future__ import annotations

import os
import signal
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path

from ..core.offline_env import child_env, sandbox_prefix, ulimit_wrap


@dataclass
class ProcResult:
    exit_code: int
    output: str
    duration_s: float
    timed_out: bool


def run_command(
    command: str,
    cwd: str | Path,
    timeout: int,
    env_extra: dict[str, str] | None = None,
    no_network: bool = True,
    cpu_s: int | None = None,
    mem_mb: int | None = None,
    max_output: int = 200_000,
) -> ProcResult:
    windows = os.name == "nt"
    argv: list[str] | str = command if windows else [*sandbox_prefix(no_network), "bash", "-c", ulimit_wrap(command, cpu_s, mem_mb)]
    start = time.monotonic()
    proc = subprocess.Popen(
        argv, cwd=str(cwd), env=child_env(env_extra), stdout=subprocess.PIPE, shell=windows,
        stderr=subprocess.STDOUT, text=True, errors="replace",
        **({"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW} if windows else {"start_new_session": True}),
    )
    timed_out = False
    try:
        out, _ = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        if windows:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)], capture_output=True)
        else:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        out, _ = proc.communicate()
    out = out or ""
    if len(out) > max_output:
        out = out[:max_output // 4] + "\n...[output truncated]...\n" + out[-(max_output * 3 // 4):]
    code = proc.returncode if proc.returncode is not None else -9
    return ProcResult(exit_code=code, output=out, duration_s=round(time.monotonic() - start, 2), timed_out=timed_out)
