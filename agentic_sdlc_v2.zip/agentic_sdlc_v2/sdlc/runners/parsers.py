from __future__ import annotations

import re

from ..core.schemas import CheckKind, Failure

_COLON = re.compile(r"^(?P<file>[^\s:][^:\n]*?):(?P<line>\d+)(?::\d+)?:\s*(?P<msg>.+)$")
_PAREN = re.compile(r"^(?P<file>[^\s(][^(\n]*?)\((?P<line>\d+),\d+\):\s*(?P<msg>.+)$")
_PYTEST_SUM = re.compile(r"^(?:FAILED|ERROR)\s+(?P<file>[^\s:]+?)(?:::(?P<name>\S+))?\s+-\s+(?P<msg>.*)$")
_CTEST = re.compile(r"^\s*\d+/\d+\s+Test\s+#\d+:\s+(?P<name>\S+)\s+\.+\s*\**\s*(?:Failed|Exception|Timeout)")
_MVN_COMPILE = re.compile(r"\[ERROR\]\s+(?P<file>\S+\.java):\[(?P<line>\d+),\d+\]\s+(?P<msg>.*)")
_MVN_TEST = re.compile(r"\[ERROR\]\s+(?P<cls>[\w.$]+)\.(?P<m>\w+):(?P<line>\d+)\s+(?P<msg>.*)")
_MVN_STYLE = re.compile(r"\[(?:WARN|ERROR)\]\s+(?P<file>\S+\.java):(?P<line>\d+)(?::\d+)?:\s*(?P<msg>.*)")
_JS_LOC = re.compile(r"\(?([^()\s]+\.(?:js|jsx|ts|tsx|mjs|cjs)):(\d+):\d+\)?")
_UNDEF = re.compile(r"undefined reference to .*")


def rel(path: str, root: str) -> str:
    p = path.strip()
    root = root.rstrip("/") + "/"
    return p[len(root):] if p.startswith(root) else p


def colon_lines(text: str, root: str, kind: CheckKind, errors_only: bool = False, limit: int = 50) -> list[Failure]:
    out: list[Failure] = []
    for ln in text.splitlines():
        m = _COLON.match(ln.strip())
        if not m:
            continue
        msg = m.group("msg")
        low = msg.lower()
        if low.startswith("note:") or low.startswith("note "):
            continue
        if errors_only and "error" not in low:
            continue
        out.append(Failure(kind=kind, file=rel(m.group("file"), root), line=int(m.group("line")), message=msg[:300]))
        if len(out) >= limit:
            break
    return out


def paren_lines(text: str, root: str, kind: CheckKind, limit: int = 50) -> list[Failure]:
    out: list[Failure] = []
    for ln in text.splitlines():
        m = _PAREN.match(ln.strip())
        if m and "error" in m.group("msg").lower():
            out.append(Failure(kind=kind, file=rel(m.group("file"), root), line=int(m.group("line")), message=m.group("msg")[:300]))
            if len(out) >= limit:
                break
    return out


def pytest(text: str, root: str) -> list[Failure]:
    text = strip_warnings(text)
    locs: dict[str, tuple[str, int, str]] = {}
    for ln in text.splitlines():
        m = _COLON.match(ln.strip())
        if m and m.group("file").endswith(".py") and not WARNING_LINE.search(ln):
            f = rel(m.group("file"), root)
            locs.setdefault(f, (f, int(m.group("line")), m.group("msg")))
    out: list[Failure] = []
    for ln in text.splitlines():
        m = _PYTEST_SUM.match(ln.strip())
        if not m:
            continue
        f = m.group("file")
        loc = locs.get(f)
        out.append(Failure(kind="test", file=f, line=loc[1] if loc else 0, name=m.group("name") or "", message=m.group("msg")[:300]))
    if not out:
        out = [Failure(kind="test", file=f, line=ln_, message=msg[:300]) for f, ln_, msg in locs.values()]
    errors = [ln.strip()[1:].strip() for ln in text.splitlines() if ln.startswith("E ") and ln[1:].strip()]
    if errors:
        if not out:
            out = [Failure(kind="test", message=errors[-1][:300])]
        for f in out:
            if errors[-1] not in f.message and (f.message.strip().startswith("in ") or len(f.message.strip()) < 40):
                f.message = f"{f.message.strip()}: {errors[-1]}"[:300]
    return out[:50]


def ctest(text: str) -> list[Failure]:
    return [Failure(kind="test", name=m.group("name"), message="ctest failed") for m in map(_CTEST.match, text.splitlines()) if m][:50]


def linker(text: str, kind: CheckKind = "build") -> list[Failure]:
    return [Failure(kind=kind, message=m.group(0)[:300]) for m in map(_UNDEF.search, text.splitlines()) if m][:20]


def maven(text: str, root: str, kind: CheckKind) -> list[Failure]:
    out: list[Failure] = []
    for ln in text.splitlines():
        if kind == "lint":
            m = _MVN_STYLE.search(ln)
            if m:
                out.append(Failure(kind=kind, file=rel(m.group("file"), root), line=int(m.group("line")), message=m.group("msg")[:300]))
            continue
        m = _MVN_COMPILE.search(ln)
        if m:
            out.append(Failure(kind=kind, file=rel(m.group("file"), root), line=int(m.group("line")), message=m.group("msg")[:300]))
            continue
        m = _MVN_TEST.search(ln)
        if m and kind == "test":
            out.append(Failure(kind=kind, file=m.group("cls").split(".")[-1] + ".java", line=int(m.group("line")),
                               name=f"{m.group('cls')}.{m.group('m')}", message=m.group("msg")[:300]))
    return out[:50]


def jest(text: str, root: str) -> list[Failure]:
    out: list[Failure] = []
    cur: Failure | None = None
    for ln in text.splitlines():
        m = re.match(r"^\s*●\s+(.+?)\s*$", ln)
        if m and "Console" not in m.group(1):
            if cur:
                out.append(cur)
            cur = Failure(kind="test", name=m.group(1)[:200])
            continue
        if cur is None:
            continue
        s = ln.strip()
        if not cur.message and s and not s.startswith(("at ", "|", ">")):
            cur.message = s[:300]
        loc = _JS_LOC.search(ln)
        if loc and not cur.file and "node_modules" not in loc.group(1):
            cur.file, cur.line = rel(loc.group(1), root), int(loc.group(2))
    if cur:
        out.append(cur)
    if out:
        return out[:50]
    return [Failure(kind="test", name=m.group(1)[:200], message="not ok") for m in re.finditer(r"^not ok \d+ - (.*)$", text, re.M)][:50]


WARNING_LINE = re.compile(r"\b\w*Warning\b|site-packages[\\/]|^\s*warnings\.warn")


def strip_warnings(text: str) -> str:
    out, skip = [], False
    for ln in text.splitlines():
        if re.match(r"^=+ warnings summary =+", ln.strip()):
            skip = True
            continue
        if skip and ln.startswith("-- Docs:"):
            skip = False
            continue
        if skip and re.match(r"^=+ ", ln.strip()):
            skip = False
        if not skip:
            out.append(ln)
    return "\n".join(out)


def generic(text: str, kind: CheckKind, lines: int = 12) -> list[Failure]:
    text = strip_warnings(text)
    tail = [ln for ln in text.splitlines() if ln.strip() and not WARNING_LINE.search(ln)][-lines:]
    return [Failure(kind=kind, message=" | ".join(tail)[:600] or "command failed with no output")]
