from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path

import yaml

from ..core.config import CONFIG_DIR
from .base import Runner, load_repo_config
from .c_cpp_runner import CCppRunner
from .java_runner import JavaRunner
from .js_runner import JsRunner
from .python_runner import PythonRunner
from .web_runner import WebRunner

RUNNERS: dict[str, type[Runner]] = {
    "python": PythonRunner,
    "c": CCppRunner,
    "cpp": CCppRunner,
    "java": JavaRunner,
    "js": JsRunner,
    "web": WebRunner,
}

BUILD_MARKERS = (
    ("CMakeLists.txt", "cmake"), ("meson.build", "meson"), ("Makefile", "make"), ("makefile", "make"),
    ("pom.xml", "maven"), ("build.gradle", "gradle"), ("build.gradle.kts", "gradle"),
    ("package.json", "npm"), ("index.html", "static-site"), ("pyproject.toml", "pyproject"), ("setup.py", "setuptools"),
    ("requirements.txt", "pip"),
)


@lru_cache(maxsize=1)
def load_languages() -> dict:
    return yaml.safe_load((CONFIG_DIR / "languages.yaml").read_text(encoding="utf-8"))


def source_files(repo: str | Path) -> list[str]:
    cfg = load_languages()
    ignore = set(cfg["ignore_dirs"])
    exts = cfg["extensions"]
    root = Path(repo).resolve()
    out: list[str] = []
    for dirpath, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in ignore and not d.startswith(".")]
        for name in files:
            if Path(name).suffix.lower() in exts:
                out.append((Path(dirpath) / name).relative_to(root).as_posix())
                if len(out) >= cfg["max_scan_files"]:
                    return out
    return out


def config_files(repo: str | Path) -> list[str]:
    cfg = load_languages()
    ignore = set(cfg["ignore_dirs"])
    names, exts = set(cfg.get("config_names", [])), set(cfg.get("config_extensions", []))
    root = Path(repo).resolve()
    out: list[str] = []
    for dirpath, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in ignore and not d.startswith(".")]
        for name in files:
            if name in names or Path(name).suffix.lower() in exts:
                out.append((Path(dirpath) / name).relative_to(root).as_posix())
                if len(out) >= 300:
                    return out
    return out


def detect_languages(repo: str | Path) -> dict[str, int]:
    exts = load_languages()["extensions"]
    counts: dict[str, int] = {}
    for f in source_files(repo):
        lang = exts[Path(f).suffix.lower()]
        counts[lang] = counts.get(lang, 0) + 1
    headers = counts.pop("header", 0)
    if headers:
        target = "cpp" if counts.get("cpp", 0) >= counts.get("c", 0) else "c"
        if counts.get("c", 0) or counts.get("cpp", 0):
            counts[target] = counts.get(target, 0) + headers
    return dict(sorted(counts.items(), key=lambda kv: -kv[1]))


def detect_build_system(repo: str | Path) -> str:
    found: list[str] = []
    for marker, name in BUILD_MARKERS:
        if (Path(repo) / marker).exists() and name not in found:
            found.append(name)
    return ",".join(found)


def primary_language(repo: str | Path) -> str:
    forced = load_repo_config(Path(repo)).get("language")
    if forced in RUNNERS:
        return forced
    langs = detect_languages(repo)
    return next(iter(langs), "python")


def get_runner(language: str, repo: str | Path, timeout: int = 600) -> Runner:
    if language not in RUNNERS:
        raise ValueError(f"unsupported language: {language}")
    return RUNNERS[language](repo, timeout=timeout, language=language)


def preflight(repo: str | Path, languages: list[str] | None = None, timeout: int = 600) -> list[str]:
    langs = languages or list(detect_languages(repo)) or [primary_language(repo)]
    problems: list[str] = []
    for lang in langs:
        problems += get_runner(lang, repo, timeout).preflight()
    return problems
