from __future__ import annotations

import re

from ..core.schemas import CheckKind, Failure
from . import parsers
from .base import Runner

_GRADLE_TEST = re.compile(r"^(?P<cls>\S+) > (?P<name>.+?) FAILED$")


class JavaRunner(Runner):
    language = "java"
    extensions = (".java",)
    markers = ("pom.xml", "build.gradle", "build.gradle.kts")
    mem_mb = None

    def system(self) -> str:
        return "maven" if (self.repo / "pom.xml").exists() else "gradle"

    def _gradle(self) -> str:
        return "bash ./gradlew" if (self.repo / "gradlew").exists() else "gradle"

    def _build_text(self) -> str:
        for n in ("pom.xml", "build.gradle", "build.gradle.kts"):
            p = self.repo / n
            if p.exists():
                return p.read_text(encoding="utf-8", errors="ignore")
        return ""

    def defaults(self) -> dict[str, str]:
        if self.system() == "maven":
            return {
                "build": "mvn -o -B -q -DskipTests compile",
                "test": "mvn -o -B -q test",
                "lint": "mvn -o -B -q checkstyle:check",
            }
        g = f"{self._gradle()} --offline --no-daemon -q"
        return {"build": f"{g} compileJava", "test": f"{g} test", "lint": f"{g} checkstyleMain"}

    def enabled(self, kind: CheckKind) -> bool:
        if kind == "lint":
            return "checkstyle" in self._build_text()
        return True

    def parse(self, kind: CheckKind, output: str) -> list[Failure]:
        root = str(self.repo)
        found = parsers.maven(output, root, kind)
        if kind == "lint":
            return found
        found += parsers.colon_lines(output, root, kind, errors_only=True)
        if kind == "test":
            for ln in output.splitlines():
                m = _GRADLE_TEST.match(ln.strip())
                if m:
                    found.append(Failure(kind="test", name=f"{m.group('cls')}.{m.group('name')}", message="test failed"))
        return found[:50]
