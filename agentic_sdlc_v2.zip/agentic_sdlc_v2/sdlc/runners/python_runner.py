from __future__ import annotations

import re
import time

from ..core.schemas import CheckKind, CheckResult, Failure
from . import parsers
from .base import Runner, any_file

MYPY_MARKERS = ("mypy.ini", ".mypy.ini")
TEST_FILE = re.compile(r"^(test_.*|.*_test)\.py$")


class PythonRunner(Runner):
    language = "python"
    extensions = (".py",)
    markers = ("pyproject.toml", "setup.py", "setup.cfg", "requirements.txt", "pytest.ini", "tox.ini")

    def defaults(self) -> dict[str, str]:
        return {
            "lint": "ruff check --output-format=concise --no-cache {files}",
            "typecheck": "{python} -m mypy --ignore-missing-imports --no-error-summary --cache-dir=/dev/null {files}",
            "test": "{python} -m pytest -x -q --tb=short -rf -p no:cacheprovider",
        }

    def enabled(self, kind: CheckKind) -> bool:
        if kind == "typecheck":
            has_cfg = any((self.repo / m).exists() for m in MYPY_MARKERS)
            pyproject = self.repo / "pyproject.toml"
            return has_cfg or (pyproject.exists() and "[tool.mypy]" in pyproject.read_text(encoding="utf-8", errors="ignore"))
        if kind == "test":
            return any_file(self.repo, TEST_FILE)
        return True

    def syntax(self, files: list[str]) -> CheckResult:
        start = time.monotonic()
        failures: list[Failure] = []
        for f in files:
            try:
                source = (self.repo / f).read_text(encoding="utf-8")
                compile(source, f, "exec", dont_inherit=True)
            except SyntaxError as exc:
                failures.append(Failure(kind="syntax", file=f, line=exc.lineno or 0, message=f"{exc.msg}"[:300]))
            except UnicodeDecodeError as exc:
                failures.append(Failure(kind="syntax", file=f, message=f"not valid utf-8: {exc.reason}"))
        return CheckResult(
            name="syntax", ok=not failures, skipped=not files, duration_s=round(time.monotonic() - start, 3),
            failures=failures, output_tail="\n".join(x.short() for x in failures),
        )

    def parse(self, kind: CheckKind, output: str) -> list[Failure]:
        root = str(self.repo)
        if kind == "test":
            return parsers.pytest(output, root)
        return parsers.colon_lines(output, root, kind)
