from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path
from typing import Any


class EventLogger:
    def __init__(self, path: Path, run_id: str, project_id: str = ""):
        self.path = path
        self.run_id = run_id
        self.project_id = project_id
        self._lock = threading.Lock()
        path.parent.mkdir(parents=True, exist_ok=True)
        self._seq = sum(1 for _ in path.open(encoding="utf-8")) if path.exists() else 0

    def __call__(self, event: dict[str, Any]) -> None:
        with self._lock:
            self._seq += 1
            rec = {"ts": round(time.time(), 3), "seq": self._seq, "run_id": self.run_id, "project_id": self.project_id, **event}
            with self.path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(rec, default=str, ensure_ascii=False) + "\n")
                fh.flush()
                os.fsync(fh.fileno())


def read_events(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    out: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            try:
                out.append(json.loads(line))
            except ValueError:
                continue
    return out


def log_llm(logger: "EventLogger", e: dict[str, Any]) -> None:
    logger({"type": "llm_call", **e})
    share = e.get("gpu_share")
    if share is not None and share < 0.97:
        logger({"type": "gpu_offload", "model": e.get("model"), "gpu_share": share,
                "why": "part of the model runs on the CPU, which makes every call several times slower; lower the context size or KV cache precision, or use a smaller model for this role"})
