from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from ..ui.live_model import describe
from .jsonl_logger import read_events

FILES = ("timeline.txt", "plan.md", "failures.md")


def _ts(ts: float) -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts))


def _load(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    except (OSError, ValueError):
        return {}


def timeline_text(events: list[dict[str, Any]]) -> str:
    lines = []
    for e in events:
        t = e["type"]
        if t in ("node_start", "llm_start"):
            continue
        if t == "node":
            line = f"   · node {e.get('node')} done in {e.get('duration_s')}s" + (f" [{e.get('task_id')}]" if e.get("task_id") else "")
            out = e.get("output") or {}
            if out:
                line += "  " + json.dumps(out, ensure_ascii=False, default=str)[:300]
        elif t == "llm_call":
            line = (f"   · llm {e.get('node')} {e.get('model')} {e.get('prompt_tokens')}→{e.get('completion_tokens')} tok "
                    f"{e.get('duration_s')}s {e.get('done_reason') or ''}{' retry' if e.get('retry') else ''}"
                    + (f"  ⚠ only {round(e['gpu_share'] * 100)}% of the model is on the GPU (rest on CPU: slow)" if e.get("gpu_share") is not None and e["gpu_share"] < 0.97 else "")
                    + (f"  ({round(e['completion_tokens'] / e['duration_s'])} tok/s)" if e.get("duration_s") and e.get("completion_tokens") else ""))
        else:
            line = describe(e)
        lines.append(f"{_ts(e['ts'])}  {line}")
    return "\n".join(lines) + "\n"


def _task_events(events: list[dict[str, Any]], tid: str) -> list[dict[str, Any]]:
    return [e for e in events if e.get("task_id") == tid]


def plan_text(run_dir: Path, events: list[dict[str, Any]]) -> str:
    summary = _load(run_dir / "run_summary.json")
    stack = _load(run_dir / "stack.json")
    tasks = stack.get("tasks") or summary.get("tasks") or []
    stats = summary.get("task_stats", {})
    start = next((e for e in events if e["type"] == "run_start"), {})
    out = [f"# Plan and task stack — run {run_dir.name}", ""]
    out.append(f"- Mode: {start.get('mode', 'edit')}")
    out.append(f"- Project: {start.get('project_name', summary.get('project_name', ''))}")
    out.append(f"- Status: {summary.get('final_status', 'running or paused')}")
    out.append(f"- Objective: {(start.get('objective') or summary.get('objective') or '').strip()[:1500]}")
    blueprint = _load(run_dir / "blueprint.json")
    if blueprint:
        out += ["", f"## Manifest ({blueprint.get('language')}, entry {blueprint.get('entry')})", ""]
        for f in blueprint.get("files", []):
            out.append(f"- `{f['path']}`: {f.get('purpose', '')}" + (f" — provides {', '.join(f.get('provides') or [])}" if f.get("provides") else ""))
    out += ["", "## Tasks", "", "| Task | Status | Kind | Files | Iterations | Verify |", "|---|---|---|---|---|---|"]
    for t in tasks:
        it = stats.get(t["id"], {}).get("iterations", "")
        out.append(f"| {t['id']} | {t['status']} | {t.get('kind', '')} | {', '.join(t.get('target_files') or [])} | {it} | `{t.get('verify_command') or '-'}` |")
    if stack.get("suspended"):
        out += ["", f"Suspended frames: {len(stack['suspended'])}"]
    for t in tasks:
        out += ["", f"### {t['id']} — {t['title']}", "", t.get("description", "")]
        if t.get("depends_on"):
            out.append(f"\nDepends on: {', '.join(t['depends_on'])}")
        if t.get("acceptance_criteria"):
            out += ["", "Acceptance criteria:"] + [f"- {c}" for c in t["acceptance_criteria"]]
        reviews = [e for e in _task_events(events, t["id"]) if e["type"] == "review"]
        if reviews:
            last = reviews[-1]
            out += ["", f"Last review: {'approved' if last.get('approved') else 'rejected'}"]
            if last.get("feedback"):
                out.append("```\n" + str(last["feedback"]).strip()[:1500] + "\n```")
        end = next((e for e in reversed(_task_events(events, t["id"])) if e["type"] == "task_end"), None)
        if end:
            out.append(f"\nEnded: {end.get('status')} after {end.get('iterations')} iteration(s); files {', '.join(end.get('files') or []) or 'none'}")
    expl = _load(run_dir / "run_explanation.json")
    if expl:
        out += ["", "## Why the run did not fully succeed", "", f"- What happened: {expl.get('what_happened', '')}", f"- Likely cause: {expl.get('why', '')}"]
    return "\n".join(out) + "\n"


def failures_text(events: list[dict[str, Any]]) -> str:
    out = ["# Failures and rejections", ""]
    n = 0
    for e in events:
        t = e["type"]
        body = ""
        if t == "tool_call" and not e.get("ok"):
            body = (e.get("error") or "") + (f"\n--- tail ---\n{e['tail']}" if e.get("tail") else "")
            head = f"tool {e.get('tool')} failed"
        elif t == "review" and not e.get("approved"):
            body, head = e.get("feedback") or "", "review rejected"
        elif t in ("guard_rejected", "repeat_problem", "no_change_loop", "suspend_refused", "split_refused", "budget_exceeded", "error", "explanation"):
            body = json.dumps({k: v for k, v in e.items() if k not in ("ts", "seq", "run_id", "project_id", "type")}, indent=2, ensure_ascii=False, default=str)
            head = t
        else:
            continue
        n += 1
        out += [f"## {n}. {_ts(e['ts'])} — {head} — task {e.get('task_id') or '-'} it{e.get('iteration', '')}", "", "```", str(body).strip()[:4000], "```", ""]
    if n == 0:
        out.append("No failures were recorded.")
    return "\n".join(out) + "\n"


def write_debug_files(run_dir: Path) -> list[Path]:
    events = read_events(run_dir / "events.jsonl")
    if not events:
        return []
    paths = []
    for name, text in (("timeline.txt", timeline_text(events)), ("plan.md", plan_text(run_dir, events)), ("failures.md", failures_text(events))):
        p = run_dir / name
        p.write_text(text, encoding="utf-8")
        paths.append(p)
    return paths
