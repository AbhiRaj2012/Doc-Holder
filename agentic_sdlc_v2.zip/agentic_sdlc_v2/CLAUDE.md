# Agentic SDLC pipeline (air-gapped)

Offline pipeline: existing codebase + requirements (feature/bugfix) -> plan (task stack) -> implement each task with a local LLM -> verify with real tools -> human gate -> DeepEval scoring -> one global `benchmark.jsonl` + one offline `dashboard.html`.
Full design, decisions, metric tables, risks: `project.md` (read it before changing architecture).

## Setup note
Native Windows works for the UI launch and verify commands (best effort); WSL2 is recommended for the full sandbox (unshare network block, ulimit).

Unzip so the project root is the folder containing `CLAUDE.md`, `sdlc/`, `config/`. Do not unzip into an existing copy (creates nested duplicates). Open that folder in VS Code.

## Windows blocks native DLLs
Symptom: `ImportError: DLL load failed while importing ormsgpack: An Application Control policy has blocked this file`. Smart App Control or a WDAC/AppLocker policy blocks unsigned `.pyd` files (ormsgpack, pydantic_core, numpy, pyarrow...). LangGraph cannot run without ormsgpack.
Fixes, best first: 1) run in WSL2 Ubuntu (also gives the real sandbox); 2) Settings > Privacy & security > Windows Security > App & browser control > Smart App Control > Off (cannot be turned back on without reinstalling Windows); 3) if the PC is managed, ask IT to allow the Python site-packages folder; 4) try another ormsgpack version (`pip install --force-reinstall --no-cache-dir ormsgpack==<other>`), since blocking is per file.

## Hard rules
- 100% offline at runtime. No network calls except Ollama on localhost (`offline_env.assert_local_url`). No CDN/fetch in the dashboard.
- Modular: many small files per package. Never a monolithic script.
- Full working code only: no pseudo-code, no placeholder `pass`. Comments only when necessary.
- When patching, give the exact replace location or the whole file. Keep talk minimal.
- The runtime never imports DeepEval; evals rebuild the trace from `events.jsonl`.
- The LLM review verdict can never override a failing deterministic check.
- `issue.json` is the human-gate source; `issue.md` is a generated view only.
- Tests must never write to the real `data/benchmark/` or `projects/` (override `paths.*` to tmp, see `tests/test_graph.py::Env`).

## Commands
```
python -m venv .venv && .venv/bin/pip install -r requirements.in && .venv/bin/pip install -e .
python -m pytest tests -q                      # 177 pass, 2 skipped (jsdom DOM tests need node+jsdom)
python -m sdlc preflight [--repo PATH]         # env check
python -m sdlc run PATH --name N --requirements "..." [--auto-context --gpu 16 --kv q8_0 --ctx N --no-aider --no-critic --no-eval --no-plan-approval --non-interactive]
python -m sdlc create --name N --request "..." [--language python|c|cpp|java|js|web --auto-context --no-eval --no-plan-approval --non-interactive]
python -m sdlc resume RUN_ID --action approve|revise|abort|work|restart|replan|replan_all|accept|proceed --hint "..." --remove T2,T3 --approve exe1,exe2
python -m sdlc report RUN_ID                    # timeline.txt, plan.md, failures.md
python -m sdlc status|eval RUN_ID | projects | dashboard | sync P | export P
streamlit run sdlc/ui/streamlit_app.py
deploy/build_bundle.sh (online, once) -> deploy/install_offline.sh (air-gapped) -> deploy/selftest.py
```
Dev venv Python is 3.12 (pyproject pins `<3.13`); tests also pass on 3.13.

## Layout (`sdlc/`)
- `core/` config, schemas, state, budget, hardware (VRAM->context), ledger (issues.jsonl), task_stack, command_policy, project_store, offline_env, symbols
- `runners/` per-language verify (python, c_cpp, java, js, web) + sandbox (`unshare -rn`), parsers, registry
- `adapters/` ollama_client, git_ops, edit_engine (search/replace), native_editor, aider_cli, editor_backend (Aider default, native fallback after 2 failures)
- `agents/` analyser, planner, critic, splitter, editor, reviewer, prompts, context
- `graph/` LangGraph builder, routing, runtime, human_gate, `nodes/` (setup, tasks, work, gate, finish); SqliteSaver checkpoints, thread_id = run_id
- `create/` create mode (separate workflow, from `loop_workflow_main.py`): requirements -> architect manifest (Blueprint) -> per file write <-> review (syntax + LLM verdict, find/replace patches) -> save (git commit) -> project check (syntax/build/test + unresolved imports + orphan files, max 2 fix rounds) -> finish; same events/run_summary format as edit mode so DeepEval/dashboard work unchanged; `mode: create` in summary
- `evals/` judge (Ollama), trace, metrics (DeepEval + deterministic), benchmark_writer, run_evals
- `dashboard/` build_dashboard.py + template.html (inline JSON, hand-written SVG)
- `telemetry/` EventLogger (`events.jsonl`)
- `cli/main.py`, `ui/` (jobs.py runs the CLI as a background process; views/ = Streamlit pages; common.py = settings from session state)
- `config/` settings.yaml, metrics.yaml, languages.yaml, command_allowlist.yaml, hardware_presets.yaml, prompts/, skills/
- Data (git-ignored): `projects/<name>/<name>/` code copy + `projects/<name>/workspace/` (runs, manifest, approved_commands.json); `data/benchmark/{benchmark.jsonl,dashboard.html}`

## Key decisions
Aider CLI default editor; plan critic on by default (UI toggle); file-level drift always on, LLM drift in eval; `_2` suffix for same-name different projects; node_modules/.venv symlinked not copied; `web` is its own language id; Planner may propose commands approved at the human gate; metric thresholds in `config/metrics.yaml` (threshold 0.70 for all).

## Status
Everything in the original scope is built and tested with mocked LLM/fake Aider.
Not yet verified on real systems (do these first on the target box):
1. Real Ollama + `gpt-oss:20b`: constrained JSON (`format`) may be ignored (parser/repair retries exist), `--reasoning-effort` -> `think` mapping, `/api/show` arch keys used by `hardware.parse_arch`.
2. Real Aider 0.86.2: flags (`check_flags()`), `llm.history` SEARCH/REPLACE parsing, token-line parsing.
3. C/C++/Java/JS toolchains (only parser-level tests).
4. Full `deploy/install_offline.sh` on an actual air-gapped machine; tiktoken cache bundling.
5. DeepEval 4.3.4 agentic metric class names/tracing (pin version; in-house fallbacks exist).
Optional/unbuilt: LLM drift check in the eval phase (`features.llm_drift` flag exists, file-level drift already feeds plan_adherence); CLI/UI tests for the human-gate page with a live paused run.

## Runtime visibility
Events in `events.jsonl`: `node_start`/`node` (with `output` summary), `llm_start`/`llm_call` (with output, reasoning head, effort, retry), `split_refused`. `ui/live_model.py` turns them into the Live page (active node, waiting model, timeline, node outputs, model calls, task tree).
Guards: `limits.max_split_depth` (default 2), reasoning-exhaustion retry in `OllamaClient.chat`, verify commands that cannot fail (`cat`, `ls`, `echo`...) are replaced by the runner default.

## Integration with the existing project
- All paths are POSIX internally (`core/paths.py`; validators on `Task`). Windows backslashes previously made the scope guard revert every edit to an existing file, so only new, isolated files survived.
- Manifest also lists build/config files (`config/languages.yaml` config_names/config_extensions) so the planner can see CMake, .pro, package.json etc.
- `agents/analogues.py`: finds the closest existing symbol for each new name in the requirements, lists every file that uses it, feeds that to the planner, and gives the definition as read-only reference to the editor.
- `graph/nodes/integrate.py`: after all tasks, if a new symbol is not referenced where its analogue is, adds wiring tasks (one round).

## Build checks and run control
- `{jobs}` replaces `$(nproc)` in build commands (portable). A baseline build runs once at analyse time (`baseline.json`); if it already fails, the build is not used as a review gate (shown as skipped with the reason).
- Repeated no-op edits after a rejected review go to the human gate (`no_change_loop`), not the shrink/split ladder.
- UI runs are background processes that survive a Streamlit restart: Live page lists them, can stop (kill tree) or hide runs; newest run is the default.

## Testing notes
`tests/helpers.py` has `FakeClient` and `PY_FILES`; `tests/test_graph.py` has `Env`/`Scripted` for end-to-end graph runs with a scripted editor. `tests/test_cli.py` monkeypatches `cli.main.make_runtime`. UI tests use Streamlit `AppTest`.

- Human gate is a panel on the Live page (p_gate.panel); eval writes eval_status.json; Live starts eval if missing.
- Created files join the task scope; no-target create tasks use whole-file format; characterization-test T1 only for python/js/java; ctest with no config is not a gate.
- Edit guards (core/guards.py, language-neutral): removed-but-used symbols, unresolved imports/includes, unconfigured test framework; build generator auto-picked; task_completion/tool_correctness capped by verified ratio.
- Explainer (agents/explainer.py, prompt explainer.md): one LLM call at every human gate and failed run end; plain-words summary + suggested hint (issue.json, UI, CLI). Repeated guard problem -> escalated text, then gate after 3rd. Repeated identical gate + empty hint -> suggested hint auto-used.
- Guards compare qualified names (A::m); C/C++ symbol scan skip-list is word-bounded (was skipping "double ..." functions). C/C++ runner: qmake build for .pro projects; Windows Qt/MSYS2 toolchain dirs auto-added to PATH.
- Editor reasoning "off" (think=false) by default; create writer continues truncated files (up to 4 continuations, overlap removed). Create: same problem twice -> stop file; identical project-check problems -> stop. Gate "work" resets no_change_streak. Reviewer gets UPCOMING TASKS and may mark criteria deferred. Planner: criteria checkable in own files; code goes where its kind lives (no inline script/style). Explainer hint limited to task files.
- Dependencies are never a failure: third-party imports are recorded (python -> requirements.txt, others -> dependency_needed event); prompts forbid install tasks/criteria. New checks (both modes): duplicate definitions, web contract (JS ids/classes must exist in HTML/CSS). JS syntax fallback without node: runners/js_balance.py.
- Debug files per run (telemetry/report.py): timeline.txt, plan.md, failures.md written by the CLI after every run/resume/create (also on pause); `python -m sdlc report RUN_ID`; download buttons on Live.
- Per-role models: ollama.role_models {planner, editor, reviewer} (CLI --planner-model/--editor-model/--reviewer-model, UI expander); context sized for the most demanding model (hardware.sizing_arch).
- Symbols: tree-sitter (core/ts_symbols.py) for c/cpp/java/js/css/html, python via ast, regex fallback if grammars cannot load; manifest.parser records the engine and invalidates the cache when it changes.
- Context for small windows (agents/context_select.py): related definitions (1-hop signatures) and reference outlines instead of whole files; focus excerpts at shrink 0 when the file is large.
- Create-mode starter templates: config/templates/<lang>/ (template.yaml: entry, file purposes, fixed files); fixed build files are completed without the LLM; existing template files are the writer's starting point.
- Edit parsing is lenient: SEARCH/REPLACE marker variants, unified diffs, and a single fenced whole file for single-file tasks; "no blocks" feedback quotes the start of the reply; retries raise temperature (0.2 per failure, max 0.7); whole format after the first failure when the file fits.
- C/C++ syntax without compile_commands.json: g++/clang++ -fsyntax-only with project header dirs and Qt headers (qmake -query); missing external headers = inconclusive (skipped).
- Baseline build retried with -j1 when the parallel build fails; SDLC_BUILD_JOBS=1 kept for the run (baseline.json jobs).
- Missing verify/build tools are skipped with a note (never a failure). Toolchain: never mix kits; use PATH if it already has g++ (+qmake for .pro), else one consistent kit (MSYS2 ucrt64/mingw64/clang64, or Qt mingw + matching Tools/mingw); override with settings paths.toolchain / SDLC_TOOLCHAIN / UI field. Baseline records the resolved tools.
- Diff prompt answered with whole files (one or several) is accepted when each file keeps >=60% of its lines.
- First call per model checks /api/ps; gpu_offload event + timeline warning when <97% of the model is on the GPU; timeline shows tok/s.
- Windows child processes get the essential environment (SYSTEMROOT, TEMP/TMP, WINDIR, COMSPEC, USERPROFILE, APPDATA, ...): without them gcc crashed (0xC0000409) and asyncio/pytest failed.
- Guard dropped_uses: an edit may not remove all uses of a project symbol from a file unless the task names it (whole-word match; same fix for the destructive guard).
- Prompt example path is the real target file; placeholder paths map to the single target.
- Two no-change edits without prior review -> review the unchanged code (task may already be satisfied).
- Explainer: think off, 1000 tokens, cached by facts (no second call when the gate resumes).
- Tasks without target files: targets inferred (agents/targets.py) from file names in the task text, else files defining the named symbols; for implement/define tasks a header brings its .cpp/.c sibling first. Done at planning (warning) and again before editing (targets_inferred event).
- Gate decision "accept": keep the current change, commit it, mark the task completed (task_end accepted_by=human, human_accept event). UI radio, CLI [c], --action accept. Explainer may recommend accept (gets checks that ran, no-change note and the diff).
- Reviewer gets EXISTING CODE for project symbols named in the title/criteria (unchanged bodies, max 3) and must not reject criteria only because unchanged code is outside the diff.
- Test tasks for python/js with no test file target are moved to a new test file at the import root (planner `characterization_target`). Shell "not recognized"/"command not found" and "no tests ran" are skipped checks, not gates. Print-only steps (ls, cat…) are dropped from compound verify commands. Reviewer EXISTING CODE excludes code added by the diff.
- Integrate also detects classes added during the run (vs the baseline manifest) and their closest existing sibling, so wiring tasks appear even when the request names no CamelCase symbol. Python: local packages are never "external"; imports of a local package from a directory that cannot reach it are rejected, and the planner moves such test files to the import root. Test collection errors are not masked as "no tests"; missing third-party packages at test time skip the test gate. C/C++ test tasks get the build file added; a new test not added to that build file is rejected. Missing #include suggests the header declaring the used names.
- Analysis-only tasks are dropped by the planner. New Python files whose imports only work from the package's import root are moved there automatically (`file_relocated`). Gate explainer is told the editor cannot move files and to stop recommending "work" after a repeat.
- Gate "restart": resets to the commit before the task, waives its findings, clears iteration/failure/repeat state and redoes the task fresh (optional hint).
- Gate "replan": reset to last good commit, keep completed tasks, planner.replan() gets the old plan with statuses, the stuck reason and the human note, new tasks numbered after the highest id. "replan_all": reset to base_commit and plan everything again with the same evidence. Old unfinished tasks end with status "replaced". Planner failure falls back to restarting the stuck task.
- Integrate also detects new fields declared next to an existing field (diff since base_commit) and adds wiring tasks where the sibling is used but the new field is not (e.g. UI controls). Regression gate re-runs only earlier verify commands that actually passed, through runner.finish_test. "python -m X" with X missing and "python pkg/module.py" verify commands are skipped/rejected. Live page shows Task (done/total).
- Python import guard resolves absolute local imports: missing module or a name not defined in the target module is rejected, with the module that really defines the name suggested (`from x.y import name`). JS named imports are checked against the target file exports. Test-only changes failing on assertions get a hint that the expected values are guessed. Characterization tests always reference the tested source. Live page: "T7 (1 of 4)" plus "n of m tasks done · plan revised k×".
- core/py_contracts.py: Python calls to local classes with unknown keyword args, and attribute reads of unknown members on parameters typed with a local class, are rejected with the real parameter/member list (follows relative and absolute imports). Test tasks must actually run their new test (a skipped test check becomes a failure unless the tool or package is missing); CMake tests must use enable_testing()+add_test. Tasks whose files are all tests become kind test. Field wiring tasks mention conditional visibility, the owning new class and a visible default/range.
- Wiring tasks carry task.mirror {old,new}; the reviewer runs guards.mirror_gaps on the target files: every line that uses the old field directly or lists it among siblings (signal lists, registries) must have a matching line for the new one, else a blocking lint failure names the exact lines. Editor rejects placeholder code (comments like "for now", "for demonstration", "placeholder", stub bodies) in added lines.
- agents/scope_hints.extra_targets: compiler/runtime/guard errors about a missing member of a project class (gcc "has no member named", Python "has no attribute"/"has no parameter", TS, Java) or an undeclared name in a .cpp add the defining file / matching header to the task (scope_extended event); "new test was never run" adds the build file. getattr/hasattr with a literal name on a typed param is a contract violation. Mirror gaps include a concrete suggested line. guards.removed_fields rejects dropping member fields still in use. The test-must-run rule only applies when a test command exists.
- Mirror tasks: editor applies guards.mirror_autofix after each edit (adds the new member to sibling lists, adds a value-copy line next to the old one without its numeric scale), logged as mirror_autofix. C/C++ macros in ALL_CAPS (TEST, TEST_F) are not duplicate definitions. C/C++/Java test files that use an unavailable framework (gtest, catch2) are rejected in favour of a self-contained test.
- Create mode: blueprint language follows the planned files when the model picks a language none of them use. Web contract names the selectors the stylesheet really uses (incl. attribute selectors such as [data-theme=dark] and how to set them). Mirror checks only require lines that assign the old field or list it with siblings; list insertions keep the attribute prefix (self., &). Field wiring tasks are created only where mirror gaps exist; Python/header fields need no prior references. py_contracts.self_attribute_violations: self.x = ProjectClass() then self.x.member must exist (for classes with library bases: must at least be a name used somewhere else in the project). pytest warnings summary blocks are dropped from failure text.
- Create mode: request_languages(request) (file names and words like HTML/CSS/JavaScript) overrides a conflicting language dropdown, so no python template lands in a web app. self_attribute_violations confirms library-base classes with hasattr in a subprocess of the project interpreter (falls back to "name used elsewhere in the project"). Sibling lists for mirror checks must contain only names/attribute chains (not call arguments); identifiers inside string literals are ignored. Integrate adds a "make X take effect" task when a new field is never read anywhere (mirror={"read": X}, reviewer requires the target to read it). Comments starting with Example/Sample/Dummy count as placeholders. A failing test is rerun once; a pass on rerun counts and is marked flaky.
- Create mode: template files referencing template names (style.css, script.js) are rewritten to the planned names (styles.css, app.js). Truncated output drops its partial last line before continuing. A syntax error in a long file (>80 lines) is fixed by repairing only the reported excerpt (local_repair) instead of rewriting the file. guards.wrong_language rejects e.g. Python written into a .js file (create syntax check and edit guard). Edit mode: members deleted by an edit but still used are put back automatically (guard_repair) instead of rejecting the edit. Gate explanation and planner are told that reverted problems describe the editor mistake, never code to delete.
- Characterization tests added by the planner are Task.optional (no other task depends on them). If one reaches the gate it is skipped automatically (optional_task_skipped) instead of blocking; a skipped optional task does not make the run partial. Default pytest command uses --tb=short so assertion failures show the actual values.

## v2 branch: plan approval gate
- `features.plan_approval` (settings.yaml true; model default false; UI checkbox; CLI `--no-plan-approval`) pauses before any code is written.
- Edit mode: node `approve_plan` (graph/nodes/plan_gate.py) after plan (+critic), before approve_commands. Create mode: node `approve_plan` (create/plan_gate.py) after architect; create now runs on a SqliteSaver (`run_create(rt, request, lang, checkpointer)`, `resume_create`, `create_result`; run dir has `mode.txt` = create so `resume`/`status`/UI dispatch correctly).
- Interrupt payload `{"type": "approve_plan", "mode": "edit"|"create", ...}`; decision `PlanDecision{action: approve|revise|abort, hint, remove}`. `remove` = task ids (create mode also accepts file paths; entry file and template-provided files are protected). `revise` re-runs planner/architect with the feedback and the previous plan, then pauses again (a failed revision shows the previous plan again). Create revise resets to `start_commit` only after a new blueprint is generated.
- CLI prompts in cli/plan_prompts.py; create flow helpers in cli/create_flow.py; Streamlit panel `p_gate._plan_panel`.
- Tests that must not pause set `features.plan_approval: False` in their settings overrides. New tests: tests/test_plan_gate.py.

## v2 branch: loop engineering (settings.yaml `loop:`; code in sdlc/loop/)
- Split budgets (`loop/budget.py`): edit-format failures (`MECHANICAL` classes) do not use the review budget (`max_iterations_per_task`); hard cap = cap + `mechanical_allowance`.
- Progress score (`loop/progress.py`): build/syntax 50, test 10 per failing test, typecheck 8, lint 3, unmet criteria 4 each; lower is better. The review node keeps the best attempt (git tree id). A worse attempt is rolled back to the best one and the editor is told why (`edit_error`). `stall_window` reviews without improvement (worse, or the same failing set again) -> human gate `no_progress`. A different failing set at an equal score counts as movement.
- Test baseline (`loop/test_baseline.py`): before a task's first edit the verify command runs once; later failures that already failed AND do not relate to the task (target file stems, symbols, title/criteria words) are not a gate. Related failures are never ignored (they are the bug being fixed).
- Escalation on review rejections (`loop/escalation.py`): after `diagnose_after` rejections a diagnose call (prompt `config/prompts/diagnose.md`) puts a root cause and fix plan into the editor message; after `boost_after` temperature rises (and `boost_effort` if set, only for models that support it); after `fallback_after` `ollama.fallback_models.editor` is used when configured. All model-agnostic; every stage is a flag.
- Metrics: `run_summary.json` has `loop` {rollbacks, diagnoses, boosted_attempts, fallback_model_uses, no_improvement_gates, baseline_failing_tests, first_pass_tasks, first_pass_rate} and `first_pass_rate`; shown on the dashboard run detail.
- Counters reset per task in `pick` and `FRESH_TASK`; a human "work" decision resets the review/mechanical/no-improve counters but keeps the best snapshot.
- Not done yet: create-mode loop (stuck files are still saved after the same problem twice), per-task token/time cap.
