# Agentic SDLC pipeline

Air-gapped, local-LLM (Ollama) SDLC automation with LangGraph, Aider, DeepEval, a Streamlit UI and an offline dashboard.

Quick start: see `CLAUDE.md` (commands) and `project.md` (design). Offline install: `deploy/build_bundle.sh` on a connected machine, then `deploy/install_offline.sh` on the target.
