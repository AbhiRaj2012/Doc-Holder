# Air-Gapped Agentic AI SDLC Automation Pipeline

Status legend: ✅ built and tested · 🔧 built, needs change (section 7) · 🆕 planned, new in section 7 · ⏳ planned, original scope

---

## 1. Objective and Constraints

An offline pipeline that takes an existing codebase plus user requirements (feature, change, bug fix), plans the work as a stack of small tasks, implements each task with a local LLM, verifies it with real tools, and records evaluation data for every run.

| Constraint | Value |
|---|---|
| Network | 100% offline (air-gapped). No telemetry, no CDN, no model downloads at runtime |
| OS / Python | Ubuntu 24.04 x86_64, Python 3.12 |
| LLM runtime | Ollama on `localhost:11434` |
| Default model / GPU | `gpt-oss:20b` (MXFP4), 16 GB VRAM, 32k context. **Must scale down to low-end devices** (section 7.2) |
| Ollama flags | `FLASH_ATTENTION=1`, `KV_CACHE_TYPE=q8_0`, `NUM_PARALLEL=1`, `MAX_LOADED_MODELS=1` |
| Target languages | Python, C, C++, Java, HTML/CSS/JS |
| Structure | Modular package (folders and files), never a single script |

---

## 2. Locked Decisions

| Area | Decision |
|---|---|
| Orchestration | LangGraph state machine, `SqliteSaver` checkpoints, dynamic `interrupt()` and `Command(resume=)` for the human gate |
| Editor backend | **Aider CLI** (own venv, pinned `aider-chat==0.86.2`) is the default. The native search/replace engine is the fallback after 2 Aider failures |
| Reviewer | Deterministic checks first (syntax, build, lint, typecheck, test). The LLM verdict is zero-context and can never override a failing check |
| Issue tracking | Append-only ledger (`issues.jsonl`) with fingerprints. `issue.md` is a generated view, never the source of truth |
| Regression safety | Cumulative diff against the task baseline, plus a regression gate that re-runs earlier tasks' verify commands |
| Project layout | `projects/<name>/<name>/` (code copy) + `projects/<name>/workspace/`; `_2`, `_3` suffix for a different project with the same name; `node_modules` and venvs symlinked, not copied |
| Languages | python, c, cpp, java, js, and `web` (HTML/CSS/JS) as its own language id |
| Verify commands | Planner may propose new allowed executables, approved by the human at the gate and remembered per project (`approved_commands.json`); users can also extend `.sdlc.yaml` |
| Plan critic | On by default, UI toggle. One zero-context call after planning |
| Drift check | File-level (planned files vs changed files) always on. LLM drift pass runs in the post-run eval phase |
| Evaluation | DeepEval, post-run, six metrics, bands and 0.70 threshold from `metrics.yaml`, each score tagged `deterministic`, `llm` or `fallback` |
| Judge model | Selectable in Streamlit (main and judge may differ). Evals run in a separate phase so there is at most one model swap |
| UI | Streamlit (pickers, run, live, human gate, evals, dashboard) and a CLI |

---

## 3. Pipeline Flow

```
START
  │
  ▼
open_project ──► workspace + code copy (7.1)
  │
  ▼
Existing project? ── no ──► analyser ──► manifest.json (incremental, hash-based)
  │ yes                          │
  ▼                              │
planner ◄────────────────────────┘     inputs: manifest + requirements + user input
  │  plan (tasks, depends_on, acceptance criteria, verify command)
  ▼
plan critic (zero-context, optional) ──► planner revises once if gaps found
  │
  ▼
TASK STACK (dependency order) ◄──────────────────────────────┐
  │                                                          │
  ▼                                                          │
pick_next ── management stack not empty? ── yes ──► resume suspended task (7.3)
  │ no
  ▼
┌───────────────── per-task micro-steps ─────────────────┐
│ edit (Aider → native diff → native whole)              │
│   └► syntax check; on failure restore, classify (7.4)  │
│ review: runner checks → LLM verdict (zero-context)     │
│   └► ledger.ingest (new / repeated / regressed / fixed)│
└────────────────────────────────────────────────────────┘
  │
  ├─ approved and checks pass ─► regression gate ─► commit ─► pop task ─► pick_next
  ├─ token exhausted / context overflow ─► suspend to management stack ─► shrink or split (7.3)
  ├─ iteration cap, no progress, oscillation ─► human gate: work (with hint) | proceed | abort
  └─ otherwise ─► edit again with OPEN ISSUES + MUST STAY FIXED list
  │
  ▼
Task stack and management stack both empty
  │
  ▼
eval phase (judge model) ─► append to global benchmark.jsonl ─► rebuild global dashboard.html
  │
  ▼
END
```

Exit conditions are explicit, never one ambiguous "threshold met" diamond:
`tests_pass`, `reviewer_approved`, `iter >= max_iter`, `no_progress` (same diff+failure fingerprint twice), `oscillation` (an issue regressed twice), `budget_exceeded`.

Human "Proceed" on a failed task marks it `skipped`, not `completed`. Dependents become `blocked`. The task's changes are reset to the last good commit.

---

## 4. Codebase Structure

```
agentic_sdlc/
├─ project.md                          ✅
├─ pyproject.toml, requirements.in     ✅
├─ config/
│  ├─ settings.yaml                    ✅ projects_root, benchmark_dir, hardware.*, stack limits
│  ├─ metrics.yaml                     ✅ bands and thresholds
│  ├─ languages.yaml                   ✅ .html/.htm/.css → web
│  ├─ command_allowlist.yaml           ✅ per-language allowed executables, deny patterns
│  ├─ hardware_presets.yaml            ✅ GPU/model presets for the UI sliders
│  ├─ prompts/                         native_edit_*, planner, critic, splitter, reviewer, editor_task ✅ · judge ⏳
│  └─ skills/                          bugfix, feature, scaffold, test, refactor + lang_<language> playbooks ✅
├─ sdlc/
│  ├─ core/
│  │  ├─ config.py, schemas.py         ✅ (web language, TaskFrame, split/suspend statuses)
│  │  ├─ state.py                      ✅ project_id, workspace, suspended, allow_proposals
│  │  ├─ budget.py, offline_env.py     ✅
│  │  ├─ ledger.py                     ✅ issue ledger
│  │  ├─ symbols.py                    ✅ symbol extraction (py, c, cpp, java, js, css, html)
│  │  ├─ project_store.py              ✅ workspace isolation, code copy, export (7.1)
│  │  ├─ hardware.py                   ✅ GPU/model profile → context and step budgets (7.2)
│  │  ├─ task_stack.py                 ✅ task stack + management stack (7.3)
│  │  └─ command_policy.py             ✅ verify-command validation and normalisation (7.5)
│  ├─ runners/
│  │  ├─ sandbox, parsers, base        ✅
│  │  ├─ python, c_cpp, java, js       ✅
│  │  ├─ web_runner.py                 ✅ html/css/js (7.6)
│  │  └─ registry.py                   ✅ web registered
│  ├─ adapters/
│  │  ├─ ollama_client.py              ✅ (done_reason/truncated, show, ps, model_sizes)
│  │  ├─ git_ops.py                    ✅
│  │  ├─ edit_types.py                 ✅
│  │  ├─ edit_engine.py                ✅ per-block engine + failure classification (7.4)
│  │  ├─ native_editor.py              ✅
│  │  ├─ aider_cli.py                  ✅
│  │  └─ editor_backend.py             ✅ escalation ladder driven by failure count (7.4)
│  ├─ agents/                          ✅ context, prompts, analyser, planner, critic, splitter, editor, reviewer
│  ├─ graph/                           ✅ builder, routing, runtime, human_gate, nodes/ (setup, tasks, work, gate, finish)
│  ├─ telemetry/jsonl_logger.py        ✅ per-run operational events (fsync per line)
│  ├─ evals/                           ✅ judge (Ollama → DeepEvalBaseLLM), trace (events → DeepEval trace), metrics, benchmark_writer, run_evals
│  ├─ dashboard/                       ✅ build_dashboard.py, template.html (global, offline, 7.7)
│  ├─ ui/                              streamlit_app.py, jobs.py, common.py, views/ ✅ (run, live, gate, evals, dashboard, models and hardware)
│  └─ cli/main.py                      ⏳ run | resume | status | eval | dashboard | projects | preflight | export | sync ✅
├─ deploy/                             build_bundle.sh (online, once), install_offline.sh, selftest.py ✅
├─ tests/                              10 files ✅ (77 tests passing: graph integration, evals, dashboard incl. real-DOM checks via jsdom)
│
├─ projects/                           🆕 one folder per project (runtime data)
│  └─ <project_name>/
│     ├─ <project_name>/               copy of the user's code (a git repo, all edits happen here)
│     └─ workspace/                    manifest.json, project.json, runs/<run_id>/...
└─ data/benchmark/                     🆕 ONE common evaluation store for all projects and runs
   ├─ benchmark.jsonl
   └─ dashboard.html
```

---

## 5. Evaluation and Metrics (DeepEval)

### 5.1 Ranges and thresholds

| Metric | Bad | Good | Threshold | Source |
|---|---|---|---|---|
| Plan Quality | 0 – 0.59 | 0.80 – 1.00 | 0.70 | DeepEval `PlanQualityMetric` (judge). Fallback: heuristic on criteria, atomicity, verifiability |
| Plan Adherence | 0 – 0.59 | 0.80 – 1.00 | 0.70 | DeepEval `PlanAdherenceMetric` (judge), capped at deterministic drift evidence + 0.15. Fallback: drift only |
| Tool Correctness | 0 – 0.69 | 0.90 – 1.00 | 0.70 | DeepEval `ToolCorrectnessMetric` in its deterministic mode (the judge is never called): expected `apply_edit → syntax_check → run_test`, ordering considered |
| Argument Correctness | 0 – 0.69 | 0.90 – 1.00 | 0.70 | Mean of deterministic argument checks (scope, format, block success, verify command allowed) and DeepEval `ArgumentCorrectnessMetric`. Fallback: deterministic only |
| Step Efficiency | 0 – 0.69 | 0.85 – 1.00 | 0.70 | Deterministic: 1 minimal edit step ÷ (iterations + splits + escalations). Optional DeepEval `StepEfficiencyMetric` cross-check (`evals.step_efficiency_cross_check`) |
| Task Completion | 0 – 0.69 | 0.90 – 1.00 | 0.70 | DeepEval `TaskCompletionMetric` (judge), capped by the completed-task ratio when tasks failed. Fallback: ratio only |

The threshold sits inside the gap between "bad" and "good", so there are three bands: `bad`, `acceptable`, `good`. Pass or fail is judged against the threshold separately. All values live in `config/metrics.yaml`.

### 5.2 Rules
- Evaluation runs after all objectives finish (or the run ends), never inline.
- Every score records its `source` (`deterministic`, `llm`, `fallback`), so the dashboard never mixes them silently.
- The judge model is selectable. If it equals the main model, the dashboard flags self-judging bias.
- Cheap unbiased metrics are always logged beside the six: test pass rate, iterations per task, escalations, tokens, wall time, diff size, edit-failure rate.

### 5.3 One common output for every project and run
- `data/benchmark/benchmark.jsonl`: append-only, one file for all projects and runs.
- `data/benchmark/dashboard.html`: one self-contained offline page rebuilt after every run (data embedded as inline JSON, hand-written SVG charts, no CDN, no `fetch`).
- Per-run operational logs (events, ledger, checkpoints) stay in that project's `workspace/`. They exist for resume and debugging and are not the evaluation record.

### 5.4 Run record (one `run_summary` line per run)

| Field | Meaning |
|---|---|
| `run_id`, `timestamp` | Identity |
| `project_name`, `project_id` | Which project |
| `objective` | The requirement text given for the run |
| `num_tasks`, `tasks_completed`, `tasks_skipped`, `tasks_blocked` | Plan size and outcome |
| `total_time_s` | Wall time to complete all tasks |
| `model_main`, `model_judge` | Models used |
| `context_size` | `num_ctx` actually used |
| `gpu_size_gb`, `kv_cache_type` | Hardware profile |
| `iterations_total`, `tokens_total`, `escalations`, `edit_failure_rate` | Effort and friction |
| `final_status` | `completed`, `aborted`, `partial`, `budget_exceeded` |
| `metrics.<name>` | `{score, band, passed, threshold, source, reason}` for each of the six |

Additional line types in the same file: `task` (per-task outcome and iterations) and `policy_violation` (rejected verify commands, section 7.5).

### 5.5 Dashboard views
Run leaderboard with filters (project, model, GPU), band heatmap of the six metrics, trends over time, model and hardware comparison, per-run drill-down (tasks, iterations, escalations, edit modes, policy violations), self-judging flag.

---

## 6. Working Preferences

- Code building: minimal talk, no long explanations or comments in code. Comments only when necessary.
- No pseudo-code and no placeholder `pass` functions. Full working code only.
- When giving patches, specify the exact replace location, or give the whole file.
- Modular layout: multiple folders and files.

---

## 7. Things to Upgrade or Change in the Above

### 7.1 Per-project workspace isolation✅ (core built; agent and graph wiring pending)

**Problem:** project data (manifest and run files) lives in one fixed `workspace` folder. A new project finds it, assumes it is the old project, and follows the old project's manifest.

**Design:**
```
projects/
└─ project_1/
   ├─ project_1/        copy of the user's code (git repo; the only place edited)
   └─ workspace/
      ├─ project.json   name, source_path, source_fingerprint, created_at
      ├─ manifest.json  includes project_id and code_tree_hash
      └─ runs/<run_id>/ events.jsonl, issues.jsonl, issue.md, design_brief.md,
                        checkpoint.sqlite, stack.json, aider/
```
Rules:
1. On start, `ProjectStore` copies the given project directory into `projects/<name>/<name>/` and creates `workspace/` beside it.
2. Identity is `project.json`. If `projects/<name>` exists but `source_path` differs, it is a different project: a suffixed folder is created (`<name>_2`) and nothing is shared. A manifest is never reused unless its `project_id` and `code_tree_hash` match the current code.
3. Same project run again: reuse the copy and the manifest, refreshing incrementally by file hash. `--fresh` re-imports.
4. `sdlc sync` detects changes at the source and re-imports on request. `sdlc export` writes the result back as a `.patch` or copies changed files. The original source is never modified automatically.
5. Heavy dependency folders (`node_modules`, venv, `.m2`) can be symlinked instead of copied via `copy_exclude` and `link_dirs` in `.sdlc.yaml`.
6. `Settings.run_dir()` changes from a global runs folder to `projects/<name>/workspace/runs/<run_id>`.

### 7.2 Low-end devices: hardware profile and small steps✅ (core built; agent and graph wiring pending)

**Principle:** every local-model call is small, has a hard context budget, and does one narrow job. No big open-ended agent loop.

**Hardware profile (Streamlit sliders and dropdowns):**

| Control | Behaviour |
|---|---|
| GPU VRAM (GB) | Slider, roughly 4 – 48 |
| Model | Dropdown of pulled models, size read from `/api/tags` |
| KV cache type | `f16`, `q8_0`, `q4_0` |
| Context size | Auto-calculated, with an override slider (like the token-size slider) |
| Step output size | Slider for max output tokens per step |
| Presets | e.g. 6 GB / ~4B, 8 GB / ~8B, 12 GB / ~14B, 16 GB / 20B (current), 24 GB+ / ~30B. Estimates only, replaced by the calculation below |

**Calculation (`core/hardware.py`):**
```
free_vram  = gpu_vram - model_weights - overhead (about 1.5 GB)
kv_per_tok = 2 x layers x kv_heads x head_dim x bytes(kv_type)    # read from /api/show
num_ctx    = floor(0.90 x free_vram / kv_per_tok), rounded down to 1024, clamped to [4096, model max]
```
This is a conservative upper bound. After the model loads, `ollama ps` is checked: if part of the model sits in CPU RAM (partial offload), `num_ctx` is lowered one step and the model reloaded. If the model leaves under 4096 tokens of context, the UI warns that the model is too large for the GPU.

**Budgets derived from `num_ctx`** (replacing fixed values in `settings.yaml`): per-node output share (planner about 18%, editor 12%, reviewer 8%, judge 10%), per-node prompt cap, repo-map tokens (about 8%, minimum 256), per-file bytes allowed in a prompt, and the size limit for whole-file rewrites.

**Step granularity shrinks with context:** at 32k a task may touch one file and several symbols. At 8k or below an edit targets a single symbol or hunk (about 60 changed lines), and larger tasks are split by the splitter before editing.

**Narrow steps:** plan → critic → per task: locate (symbol and excerpt) → edit → verify → review → commit. Each step builds a fresh prompt from structured inputs (no carried chat history), so each call fits its budget.

The hardware profile is stored in every run record (`gpu_size_gb`, `context_size`, `model_main`).

### 7.3 Task stack with a management stack✅ (core built; agent and graph wiring pending)

Two stacks, both persisted (`stack.json` and LangGraph state), so crashes and restarts keep their place.

| Stack | Holds | Order |
|---|---|---|
| Task stack | Pending tasks | Dependency (topological), then priority |
| Management stack | Suspended `TaskFrame`s | LIFO |

**`TaskFrame`:** `task_id`, `step` (locate, edit, verify, review), `reason`, `iteration`, `base_tree` (git snapshot), `open_issue_ids`, `scope` (files and symbols), `shrink_level`, `attempts`, `created_at`.

**Suspend reasons:** `token_exhausted` (prompt cannot fit after trimming, or output cut off with `done_reason=length`), `context_overflow`, `step_timeout`, `edit_ladder_exhausted`, `no_progress`, `human_pause`, `crash_recovery`.

**Flow:**
1. A step fails on budget. Work so far is snapshotted, a frame is pushed to the management stack, and the task is marked `suspended`.
2. Before popping any new task, `pick_next` checks the management stack. A non-empty stack is resolved first: the top frame is popped, its dependencies checked, and the task resumed at the recorded step with a smaller scope.
3. Shrink levels on resume: **1** trim context (drop read-only files, smaller repo map) · **2** narrow to a single symbol or hunk · **3** split the task via the splitter into subtasks (tiny prompt), pushed on top of the task stack with `depends_on` the parent. The parent completes when its children do.
4. A frame is resolved when its task completes, is skipped, or the run aborts. A new task is popped from the task stack only when the management stack is empty (or holds only frames blocked by skipped dependencies, which are marked `blocked`).
5. Guards: a cap on frames and shrink levels, and cycle detection. Past the caps the human gate is triggered.
6. Crash recovery: on resume, any `in_progress` task becomes a `crash_recovery` frame.

### 7.4 Search and replace: stop the chain reaction 🔧

**Why failures cascade:** one bad edit leaves broken code in the file, the next iteration works on corrupted text, its SEARCH no longer matches, and failures multiply into later tasks.

**Already built in `adapters/edit_engine.py` (✅):** per-block application (matched blocks kept, failed blocks reported), exact → whitespace → fuzzy matching (0.90 minimum, ties rejected), closest-match hints returned to the model, `...` elision, indentation and tab fixes, CRLF preservation, scope and path guards, overlap detection, no-op detection, whole-file mode.

**To add (🔧):**

| Failure class | Detected by | Automatic response |
|---|---|---|
| `not_found` | No match at any level | Retry with the closest real lines as hint, narrowed to the target symbol |
| `ambiguous` | Match count above 1 | Ask for more context lines, include line numbers of candidates |
| `scope` | File outside task scope | Reject, list allowed files |
| `overlap` / `noop` | Engine | Drop the block, continue |
| `syntax_after_edit` | Runner syntax check after the edit | Restore changed files from the pre-edit snapshot, feed the exact error back |
| `format` | No blocks parsed | Retry once with a format reminder |
| `length` | `done_reason=length` | Suspend and shrink (7.3) |

**Escalation ladder per task (`editor_backend.py`):** Aider diff (failures 0–1) → native diff with hints (2) → native whole-file for small files (3+) → splitter creates symbol-level subtasks → human gate.

**Containment rules:**
- Every edit is snapshotted. A failed or syntax-breaking edit is restored before anything else runs.
- A task that ends failed or skipped is reset to its last good commit before the next task begins, so a failure never leaks forward.
- Dependents of a skipped task are marked `blocked`, not attempted.
- A global edit-failure budget triggers the human gate instead of burning iterations.
- Metrics: `edit_failure_rate`, block modes used (exact, whitespace, fuzzy, elision), blocks applied vs failed, backend per attempt.

### 7.5 Verification safety: fix the "command not in allowlist" dead end✅ (core built; agent and graph wiring pending)

**Note:** the "not available in allowlist" message is not in the reference script you uploaded, so I have not seen the code that produces it. The design below is aimed at the likely causes: unknown commands rejected outright, exact-string matching, and no recovery path.

**Two trust levels:**
- **Trusted:** runner defaults and commands you set in `.sdlc.yaml`. They run as-is inside the sandbox and never go through the policy.
- **Untrusted:** LLM-written `verify_command` values. These go through `core/command_policy.py`.

**Policy:**
1. **Normalise first:** `python` and `python3` map to the configured interpreter, `pytest` becomes `{python} -m pytest`, `gradle` becomes the project's `./gradlew` if present, and so on.
2. **Split on `&&`, `;` and `|`**, then check each segment's executable against `config/command_allowlist.yaml` (groups per language, extendable per repo with `allow:` in `.sdlc.yaml`). Executables inside the repo (for example `./build/test_runner`) are allowed when the file exists.
3. **Deny patterns:** `rm -rf`, `sudo`, network tools (`curl`, `wget`, `ssh`, `scp`, `nc`), installers (`pip install`, `npm install`, `apt`), `git push`, `$(...)` and backticks, redirects outside the repo, and paths escaping the repo.
4. **Never a dead end:** if a command is still rejected, (a) the Planner gets one retry with the allowed tools for that language, then (b) the task falls back to the runner's default test command and a `policy_violation` event is logged, and (c) only if no default exists does the human gate open.
5. **Clear messages:** "tool not installed" and "command not allowed" are different errors, and preflight reports each separately.
6. **The sandbox is the real boundary** (no network namespace, timeout, `ulimit`, clean environment). The allowlist is a usability and safety layer on top, not the only protection.

### 7.6 Languages: Python, C, C++, Java, HTML/CSS/JS✅ (core built; agent and graph wiring pending)

| Language id | Runner | Syntax | Build | Test | Lint / typecheck |
|---|---|---|---|---|---|
| `python` ✅ | python | in-process compile | none | pytest | ruff, mypy (if configured) |
| `c`, `cpp` ✅ | c_cpp | `-fsyntax-only` via compile database | cmake / make / meson | ctest / make test / meson test | cppcheck |
| `java` ✅ | java | none | maven / gradle (offline) | surefire / gradle test | checkstyle (if configured) |
| `js` ✅ | js | `node --check` | `tsc --noEmit` (if TS) | jest / vitest / `node --test` | eslint |
| `web` ✅ | web | HTML tag-balance via stdlib parser, CSS brace/comment/string check, JS via `node --check` | none | defers to the js runner when `package.json` exists | `eslint`, `stylelint` when listed in `package.json` |

Static sites without a test runner get syntax and lint checks plus any planner-provided verify command. Headless-browser testing is out of scope for the offline target. Changes needed: add `web` to the `Language` literal, `.html/.htm/.css` to `languages.yaml`, a `web_runner.py`, and registry wiring.

### 7.7 Evaluation output 🆕
Implement exactly as described in section 5: one global `benchmark.jsonl` and one global `dashboard.html` for all projects and runs, produced after all objectives complete, with the extra data fields (project name, objective, number of tasks, total time taken, model used, context size, GPU size).

---

## 8. Build Order and Status

| # | Package | Status |
|---|---|---|
| 1 | `core` (config, schemas, state, budget, offline_env, ledger) | ✅ |
| 2 | `runners` (sandbox, parsers, base, python, c_cpp, java, js, registry) | ✅ |
| 3 | `adapters` (ollama, git, edit_engine, native_editor, aider_cli, editor_backend) | ✅ |
| 4 | `core` additions: `project_store`, `hardware`, `task_stack`, `command_policy`; `web_runner`; config updates | ✅ |
| 5 | `agents` (analyser, planner, splitter, critic, editor, reviewer) plus prompts and skills | ✅ |
| 6 | `graph` (builder, routing, nodes, human gate) | ✅ |
| 7 | `telemetry` ✅ (no `tools/` package: the DeepEval trace is rebuilt from `events.jsonl`, so the runtime never imports DeepEval) |
| 8 | `evals` and global `benchmark.jsonl` | ✅ |
| 9 | `dashboard` (global, offline) | ✅ |
| 10 | `ui` (Streamlit) and `cli` | ✅ |
| 11 | `deploy` (offline installer, wheelhouse, toolchain `.deb`s) | ✅ scripts tested for syntax and self-test; full install not run on a real air-gapped box |

Definition of done per package: unit tests with a mocked LLM pass, an offline self-test (`unshare -rn`) shows no network access, and the package is exercised against a small fixture repo.

---

## 9. Known Risks and Unverified Items

| Item | Status |
|---|---|
| Aider 0.86.2 flags and `llm.history` markers | Tested against a fake binary only. `check_flags()` verifies flags at preflight. Run one real edit to confirm the history format |
| Aider `--reasoning-effort` reaching Ollama's `think` for gpt-oss | Unconfirmed. The native editor sets effort explicitly |
| gpt-oss and Ollama `format` (constrained JSON) | May be ignored. Parser and repair retries cover it |
| C/C++, Java and JS runners | Tested through parsers and detection only. Toolchains must be smoke-tested on the target box |
| KV-cache formula | Conservative estimate. `ollama ps` verification after load is the real check |
| DeepEval agentic metric class names and tracing API | Version-sensitive. Pin the version and verify at build time, with in-house metric classes as the fallback |
| Self-judging bias when judge equals main model | Flagged on the dashboard |

## 10. Decisions (resolved)
1. **Layout:** `projects/<name>/<name>/` plus `workspace/`, with `_2` suffix only for a different project of the same name.
2. **Heavy dependency folders:** `node_modules`, `.venv`, `venv` are symlinked into the copy and git-excluded. Override with `link_dirs` and `copy_exclude` in `.sdlc.yaml`.
3. **`web`** is its own language id.
4. **Allowlist:** the Planner may propose executables. They are shown at the human gate, and approval is stored per project. Denied patterns (network tools, installers, `rm`, `git push`, command substitution) can never be proposed.
