import json
import re
from .state import AgentState, llm, write_log, load_skill

def reviewer_node(state: AgentState):
    current_file = state["pending_files"][0]
    file_code = state["file_system"][current_file]

    print(f"\n🔎 [Reviewer] Auditing {current_file} for logical integrity...")

    file_manifest = json.dumps(state["manifest"].get("files", {}).get(current_file, {}), indent=2)
    grading_skill = load_skill("intent_based_grading.md")

    global_memory = ""
    for filename, content in state["file_system"].items():
        if content and filename != current_file:
            global_memory += f"--- {filename} ---\n{content}\n"

    # PROMPT STRUCTURE REVERSED: Code is at the top to prevent "missing code" hallucinations
    prompt = f"""
    YOU ARE A STRICT QA REVIEWER. YOUR ONLY JOB IS TO AUDIT THE CODE BELOW. DO NOT WRITE THE FULL FILE FROM SCRATCH.

    ====== START OF CURRENT CODE TO REVIEW ({current_file}) ======
    {file_code}
    ====== END OF CURRENT CODE TO REVIEW ======

    BUSINESS REQUIREMENTS:
    {state.get('requirements', '')}

    MANIFEST REQUIREMENTS: 
    {file_manifest}

    FULL PROJECT CONTEXT:
    {global_memory}

    ANTI-SPECIFICATION GAMING RULES (CRITICAL):
        1. DEEP LOGIC AUDIT: Do not just check for DOM tags. You MUST read the internal logic of the JavaScript functions. Are the calculations mathematically correct? Do they handle edge cases? Does the data correctly save to localStorage? If the math/logic is missing or wrong, FAIL IT.
        2. HTML SCRIPT LINKAGE (FATAL): If reviewing HTML, you MUST verify that every .js file listed in the FULL PROJECT CONTEXT is explicitly linked.
        3. UI FAKING CHECK (FATAL): Data-entry sections MUST contain actual `<input>` tags.
        4. DOM SYNCING (FATAL): Ensure `querySelectorAll` or `getElementById` exactly matches the classes/IDs present in the HTML provided in the Full Project Context.
        5. ES6 MODULE BAN (FATAL): Check for `import ` or `export `. If present, FAIL IT immediately. Tell the Coder to use the `window` object.

    CRITICAL PATCHING RULES:
    1. TRUNCATION RECOVERY: Use <APPEND> to add missing code to the bottom.
    2. BUG FIXES: Use <SEARCH> and <REPLACE> for specific bugs. DO NOT output more than TWO (2) patches per review.

    MANDATORY OUTPUT FORMAT:
    You MUST end your review with a strict status tag: either <STATUS>PASS</STATUS> or <STATUS>FAIL</STATUS>.
    """

    review_output = llm.invoke(prompt).content.strip()
    write_log(state["run_dir"], f"Reviewer - {current_file}", review_output)

    # Bulletproof Status Extraction
    status_match = re.search(r"<STATUS>(.*?)</STATUS>", review_output, re.IGNORECASE)
    extracted_status = status_match.group(1).upper().strip() if status_match else ""

    if extracted_status == "PASS" or "NO PATCHES ARE NECESSARY" in review_output.upper():
        print(f"   ✅ {current_file} passed semantic review.")
        status = "PASS"
    else:
        print(f"   ❌ Logic/Syntax issues found in {current_file}. Routing back to Coder.")
        status = "FAIL"

    return {
        "feedback": review_output,
        "status": status,
        "review_attempts": state["review_attempts"] + 1
    }