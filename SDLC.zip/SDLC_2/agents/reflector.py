from .state import AgentState, llm, write_log


def reflector_node(state: AgentState):
    current_file = state["pending_files"][0]
    print(f"\n🧠 [Reflector] Cycle 1 Failed. Analyzing mistakes for {current_file}...")

    prompt = f"""
    The Coder has failed 3 times to fix `{current_file}`.
    Here is the most recent feedback from the Reviewer:
    {state['feedback']}

    Summarize EXACTLY what the Coder is misunderstanding in 2-3 bullet points. 
    Provide a strict directive on how to solve this in the next coding cycle.
    """
    summary = llm.invoke(prompt).content.strip()
    write_log(state["run_dir"], f"Reflector - {current_file}", summary)

    return {"reflection_summary": summary}