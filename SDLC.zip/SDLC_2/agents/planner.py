import json
from pathlib import Path
from .state import AgentState, llm, extract_json, write_log, load_skill


def planner_node(state: AgentState):
    print("\n📐 [Planner] Analyzing complexity and architecting file structure...")

    spa_skill = load_skill("spa_architecture.md")

    file_prompt = f"""
    Analyze these requirements: {state['requirements']}
    APPLY THIS ARCHITECTURE SKILL: {spa_skill}

    List the exact files needed. 
    - For simple utilities: ["index.html", "style.css", "app.js"]
    - For stateful apps: ["index.html", "style.css", "storage.js", "app.js"]

    Return ONLY a JSON array of strings.
    """
    files_to_build = extract_json(llm.invoke(file_prompt).content)

    if not isinstance(files_to_build, list) or len(files_to_build) == 0:
        files_to_build = ["index.html", "style.css", "storage.js", "app.js"]

    master_manifest = {"files": {}}

    for file in files_to_build:
        print(f"   ↳ Generating isolated blueprint for {file}...")

        manifest_prompt = f"""
        Generate a detailed JSON blueprint ONLY for `{file}`.
        REQUIREMENTS: {state['requirements']}

        CRITICAL JAVASCRIPT RULE:
        If `{file}` is a JavaScript file, you MUST define strict function contracts under a "javascript_interface" array.

        Structure example for {file}:
        {{
          "description": "Purpose of the file",
          "dependencies": ["other files it relies on"],
          "javascript_interface": [
            {{
              "signature": "function calculateTotal(operand1, operand2)",
              "description": "Calculates the total and updates the DOM."
            }}
          ],
          "dom_elements": [
            {{ "id": "save-btn", "type": "button" }}
          ],
          "user_flow_tests": [
            "Test 1"
          ]
        }}
        """
        master_manifest["files"][file] = extract_json(llm.invoke(manifest_prompt).content)

    manifest_path = Path(state["run_dir"]) / "manifest.json"
    manifest_path.write_text(json.dumps(master_manifest, indent=2), encoding="utf-8")

    return {
        "manifest": master_manifest,
        "pending_files": files_to_build,
        "file_system": {f: "" for f in files_to_build},
        "review_attempts": 0,
        "feedback": "",
        "incomplete_files": {}
    }