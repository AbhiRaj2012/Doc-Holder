<SYSTEM_SKILL>
  <NAME>Modular SPA Architecture (Global Namespace)</NAME>
  <RULES>
    <RULE>Never use a single monolithic `script.js` file for complex applications.</RULE>
    <RULE>Decouple logic into distinct files: `storage.js` (handles localStorage), `router.js` (handles views), and `app.js` (handles business logic).</RULE>
    <RULE>FATAL ERROR AVOIDANCE: NEVER use ES6 `import` or `export` syntax. Because this is an offline file:// app, ES6 modules will trigger fatal CORS errors.</RULE>
    <RULE>Cross-File Communication: You MUST share functions across files by attaching them to the global `window` object.</RULE>
  </RULES>
  <EXAMPLE>
```javascript
    // In storage.js
    window.StorageApp = {
        saveData: function() { ... }
    };

    // In app.js
    // Access the function directly from the global window object
    window.StorageApp.saveData();