<SYSTEM_SKILL>
  <NAME>Universal Minimalist CSS</NAME>
  <RULES>
    <RULE>Simplicity First: Do not write complex, custom CSS grids for every single component. Keep it universally simple.</RULE>
    <RULE>Basic Layout: Use a standard `.container` class with `max-width: 800px` and `margin: 0 auto;` to center the app.</RULE>
    <RULE>Universal Buttons: Style buttons globally (e.g., `button { padding: 10px; cursor: pointer; border-radius: 5px; }`). Do not create excessive class variants.</RULE>
    <RULE>Visibility Routing: ALWAYS include a `.hidden { display: none !important; }` class so the JavaScript router can hide and show views.</RULE>
  </RULES>
</SYSTEM_SKILL>