<SYSTEM_SKILL>
  <NAME>UI Integrity & SPA Layouts</NAME>
  <RULES>
    <RULE>Active State Routing: You MUST define a `.hidden { display: none !important; }` class in the CSS. All `<section>` views except the default must have the `hidden` class applied in the HTML.</RULE>
    <RULE>Form Integrity: Never hardcode placeholder text as data. Any table or area meant for user input (like Invoice Line Items) MUST contain `<input>` elements.</RULE>
    <RULE>Z-Index & Overlap: Ensure your main `<main>` container has `overflow-x: hidden` and proper padding so elements do not bleed off the screen or overlap.</RULE>
  </RULES>
</SYSTEM_SKILL>