// router.js

// --- State Management (FR 2.3.2) ---
let currentInput = '0';
let previousOperand = null;
let operation = null;
let waitingForSecondOperand = false;

// DOM References
const displayElement = document.getElementById('display');

// --- Core Functions ---

/**
 * Updates the display element with the current value.
 * @param {string} value - The value to display.
 */
function updateDisplay(value) {
    displayElement.textContent = value;
}

/**
 * Captures the value from the clicked button and updates the display field.
 * (handleInputEvent)
 * @param {Event} event - The DOM event object.
 */
function handleInputEvent(event) {
    const target = event.target;
    const action = target.dataset.number;
    const operator = target.dataset.operator;
    const equals = target.dataset.equals;

    if (action) {
        // Handle number input
        if (operator || equals) {
            // If an operator or equals sign is next, treat the input as the new operand
            currentInput = action;
        } else {
            // Standard number input
            if (waitingForSecondOperand) {
                currentInput = action;
                waitingForSecondOperand = false;
            } else {
                // Prevent multiple leading zeros unless it's just '0'
                currentInput = currentInput === '0' ? action : currentInput + action;
            }
        }
    } else if (operator) {
        // Handle operator input
        handleOperator(operator);
    } else if (equals) {
        // Handle equals operation
        executeCalculation();
    } else if (target.dataset.action === 'clear') {
        clearDisplay();
    }
}

/**
 * Triggers the core arithmetic function based on the current state and pending operation.
 * (executeCalculation)
 */
function executeCalculation() {
    if (previousOperand === null || operation === null) {
        return; // Not enough operands to calculate
    }

    const currentDisplayValue = parseFloat(currentInput);
    const firstOperand = parseFloat(previousOperand);
    const secondOperand = currentDisplayValue;

    let result;

    // Retrieve operands from state and call the appropriate function.
    switch (operation) {
        case 'add':
            result = firstOperand + secondOperand;
            break;
        case 'subtract':
            result = firstOperand - secondOperand;
            break;
        case 'multiply':
            result = firstOperand * secondOperand;
            break;
        case 'divide':
            // Handle division by zero error (NFR 2.2.3).
            if (secondOperand === 0) {
                result = 'Error: Division by Zero';
            } else {
                result = firstOperand / secondOperand;
            }
            break;
        default:
            result = secondOperand;
    }

    // Update the display with the result (NFR 2.2.4).
    if (result === 'Error: Division by Zero') {
        currentInput = result;
    } else {
        // Handle decimal precision for results
        currentInput = String(result);
    }

    // Reset state after calculation
    previousOperand = null;
    operation = null;
    waitingForSecondOperand = false;
    updateDisplay(currentInput);
}

/**
 * Resets the display to '0' and clears the internal calculation state.
 * (clearDisplay)
 */
function clearDisplay() {
    currentInput = '0';
    previousOperand = null;
    operation = null;
    waitingForSecondOperand = false;
    updateDisplay(currentInput);
}

/**
 * Handles operator selection and state transition.
 * (handleOperator)
 * @param {string} nextOperation - The operator to be set.
 */
function handleOperator(nextOperation) {
    const inputValue = parseFloat(currentInput);

    if (previousOperand === null) {
        // First operand setup
        previousOperand = inputValue;
    } else if (operation) {
        // Sequential Calculation (FR 2.2.1, FR 2.2.2)
        const result = calculate(previousOperand, inputValue, operation);

        // Handle Division by Zero (FR 2.2.3)
        if (result === 'Error: Division by Zero') {
            currentInput = result;
            previousOperand = null; // Reset state upon error
            operation = null;
            waitingForSecondOperand = true;
            updateDisplay(currentInput);
            return;
        }

        previousOperand = result;
        currentInput = String(result);
    }

    waitingForSecondOperand = true;
    operation = nextOperation;

    // Update display with the current operand for the next operation
    updateDisplay(currentInput);
}

/**
 * Core calculation logic (internal helper).
 * @param {number} firstOperand
 * @param {number} secondOperand
 * @param {string} operator
 * @returns {number|string} The calculated result or an error message.
 */
function calculate(firstOperand, secondOperand, operator) {
    switch (operator) {
        case 'add':
            return firstOperand + secondOperand;
        case 'subtract':
            return firstOperand - secondOperand;
        case 'multiply':
            return firstOperand * secondOperand;
        case 'divide':
            // FR 2.2.3: Division by Zero check
            if (secondOperand === 0) {
                return 'Error: Division by Zero';
            }
            return firstOperand / secondOperand;
        default:
            return secondOperand;
    }
}

// --- Initialization ---

/**
 * Attaches all necessary event listeners to calculator buttons upon initialization.
 * (setupEventListeners)
 */
function setupEventListeners() {
    // Attach a single listener to the parent container for delegation
    document.querySelectorAll('button').forEach(button => {
        button.addEventListener('click', handleInputEvent);
    });
}

/**
 * Initializes the calculator application.
 */
function initialize() {
    // 1. Setup event listeners
    setupEventListeners();

    // 2. Initial display setup (FR 2.3.2)
    updateDisplay(currentInput);
}

// Execute initialization when the DOM is ready
document.addEventListener('DOMContentLoaded', initialize);

// Expose functions to the global scope for cross-file communication
window.CalculatorRouter = {
    setupEventListeners: setupEventListeners,
    handleInputEvent: handleInputEvent,
    executeCalculation: executeCalculation,
    clearDisplay: clearDisplay
};