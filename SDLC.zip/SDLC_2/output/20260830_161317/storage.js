window.StorageApp = {
    /**
     * Serializes a JavaScript object and stores it in Local Storage.
     * @param {object} stateObject - The application state to save.
     * @param {string} storageKey - The key under which to store the data.
     * @returns {boolean} - True if the save operation was successful.
     */
    saveState: function(stateObject, storageKey) {
        try {
            const serializedState = JSON.stringify(stateObject);
            window.localStorage.setItem(storageKey, serializedState);
            return true;
        } catch (error) {
            console.error("StorageApp.saveState failed:", error);
            return false;
        }
    },

    /**
     * Retrieves data from Local Storage using a specified key and parses it back into a JavaScript object.
     * @param {string} storageKey - The key of the data to retrieve.
     * @returns {object|null} - The stored state object, or null if not found or parsing fails.
     */
    loadState: function(storageKey) {
        try {
            const serializedState = window.localStorage.getItem(storageKey);
            if (serializedState === null) {
                return null;
            }
            return JSON.parse(serializedState);
        } catch (error) {
            console.error("StorageApp.loadState failed: Data corruption or parsing error.", error);
            return null;
        }
    },

    /**
     * Checks for application state in Local Storage upon initialization and loads it.
     * Initializes state to default values if no data is found.
     * @param {string} storageKey - The key used to store the state.
     * @param {object} defaultState - The default state object to use if no data is found.
     * @returns {object} - The loaded or default state.
     */
    initializeStorage: function(storageKey, defaultState) {
        let loadedState = null;

        // 1. Attempt to load state using loadState.
        loadedState = window.StorageApp.loadState(storageKey);

        // 2. If state is null, set the current state to defaultState.
        if (loadedState === null) {
            console.log("StorageApp: No state found. Using default state.");
            loadedState = defaultState;
        } else {
            console.log("StorageApp: State successfully loaded.");
        }

        // 3. If state is loaded, set the current state to the loaded state.
        // In a real application, this would typically trigger a global state update.
        // For this module, we return the loaded state.
        return loadedState;
    }
};