const display = document.getElementById('display');
const buttons = document.querySelectorAll('.calculator-button');

let previousOperand = '';
let currentOperand = '';
let operation = '';

/**
 * Updates the calculator display with the current result or error message.
 * Handles NFR 3.2.3 (Error Messaging).
 * @param {string} content The string to display.
 */
function updateDisplay(content) {
    display.innerText = content;
}

/**
 * Processes the numerical input from a button click and updates the display.
 * Handles FR 2.1.1 (Number Input) and FR 2.1.4 (Decimal Handling).
 * @param {string} value The number or decimal entered.
 */
function handleInput(value) {
    if (currentOperand === 'Error') {
        currentOperand = '';
    }
    
    // Handle decimal input
    if (value === '.' && currentOperand.includes('.')) {
        return;
    }

    currentOperand += value;
    updateDisplay(currentOperand);
}

/**
 * Stores the current number and the pending operator for future calculation.
 * Manages FR 2.3.1 (Stored Value).
 * @param {string} operator The selected arithmetic operator (+, -, *, /).
 */
function handleOperator(operator) {
    if (currentOperand === '') {
        // If there is no current operand, do nothing or handle error
        return;
    }

    if (previousOperand === '') {
        previousOperand = currentOperand;
    } else if (operation) {
        // If an operation is pending, perform the calculation immediately
        performCalculation();
    }

    operation = operator;
    currentOperand = ''; // Reset current input for the next number
    updateDisplay(`${previousOperand} ${operation}`);
}

/**
 * Executes the stored arithmetic operation based on the stored operands and operator.
 * Implements FR 2.2.1 (Sequential Calculation), FR 2.2.2 (Operator Precedence), and FR 2.2.3 (Division by Zero).
 */
function performCalculation() {
    const operand1 = parseFloat(previousOperand);
    const operand2 = parseFloat(currentOperand);

    if (isNaN(operand1) || isNaN(operand2)) {
        updateDisplay('Error: Invalid Input');
        previousOperand = '';
        currentOperand = '';
        operation = '';
        return;
    }

    let result;

    if (operation === '+') {
        result = operand1 + operand2;
    } else if (operation === '-') {
        result = operand1 - operand2;
    } else if (operation === '*') {
        result = operand1 * operand2;
    } else if (operation === '/') {
        // Handle division by zero (FR 2.2.3)
        if (operand2 === 0) {
            updateDisplay('Error: Division by Zero');
            previousOperand = '';
            currentOperand = '';
            operation = '';
            return;
        }
        result = operand1 / operand2;
    } else {
        return;
    }

    // Store result and update state
    currentOperand = result.toString();
    previousOperand = '';
    operation = '';
    updateDisplay(currentOperand);
}

/**
 * Resets the calculator state, clearing the display and resetting the stored operands.
 * Implements FR 2.1.3 (Clear Function) and FR 2.3.2 (Initial State).
 */
function clearDisplay() {
    previousOperand = '';
    currentOperand = '';
    operation = '';
    updateDisplay('0');
}

/**
 * Sets up all necessary event listeners for calculator buttons and initializes the starting state.
 * Attaches event listeners to all number and operator buttons defined in the HTML structure.
 */
function initializeCalculator() {
    buttons.forEach(button => {
        button.addEventListener('click', () => {
            const value = button.innerText;

            if (/\d|\./.test(value)) {
                handleInput(value);
            } else if (['+', '-', '*', '/'].includes(value)) {
                handleOperator(value);
            } else if (value === 'AC') {
                clearDisplay();
            }
        });
    });
    updateDisplay('0');
}

// Initialize the calculator when the script loads
initializeCalculator();