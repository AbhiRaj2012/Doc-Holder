/**
 * router.js
 * Manages the user interaction flow, handles input events from the DOM, and coordinates the display of results and pending operations for the calculator application.
 */

// --- Internal State Management ---
let currentInput = '0';
let pendingOperation = null;
let previousValue = null;
let errorState = '';

// --- DOM Element References (To be set during initialization) ---
let displayElement = null;
let operatorButtons = [];
let numberButtons = [];

/**
 * Updates the HTML display element with the current numerical input, pending operation, or error messages.
 * @param {HTMLElement} displayElement - The input field element.
 * @param {string} resultValue - The value to display (number, operator, or error).
 * @param {string} errorState - Any error message to display.
 */
function updateDisplay(displayElement, resultValue, errorState = '') {
    displayElement.value = resultValue;
    
    // Apply specific styling based on the content (optional, but good practice)
    if (errorState) {
        displayElement.style.color = 'var(--color-error)';
    } else {
        displayElement.style.color = 'var(--color-display-text)';
    }
}

/**
 * Resets the current input buffer to zero or clears the entire calculation history.
 * @param {HTMLElement} displayElement - The input field element.
 */
function clearInput(displayElement) {
    currentInput = '0';
    pendingOperation = null;
    previousValue = null;
    errorState = '';
    updateDisplay(displayElement, currentInput, errorState);
}

/**
 * Central function to process button clicks, determine the input type (number or operator), and trigger the appropriate calculation logic.
 * @param {Event} event - The DOM event object triggered by the button click.
 */
function handleInputEvent(event) {
    const target = event.target;
    const value = target.value;

    // 1. Identify clicked element type
    if (!value) return;

    // Check if the input is a number (including decimal point)
    if (/\d|\./.test(value)) {
        // Handle number input
        if (currentInput === '0' || currentInput === 'Error') {
            currentInput = value;
        } else {
            // Prevent multiple decimal points if input is accumulating
            if (value === '.' && currentInput.includes('.')) {
                return;
            }
            currentInput += value;
        }
        
        // Update display immediately
        updateDisplay(displayElement, currentInput, errorState);
        
    } else if (['+', '-', '*', '/'].includes(value)) {
        // Handle operator input
        const inputValue = parseFloat(currentInput);

        if (previousValue === null) {
            // First operation: store the current input as the previous value
            previousValue = inputValue;
        } else {
            // Chaining operations: execute the pending operation first
            window.AppLogic.executeOperation(previousValue, currentInput, pendingOperation);
            previousValue = parseFloat(currentInput);
        }
        
        // Set the new pending operation
        pendingOperation = value;
        
        // Clear the current input buffer for the next number entry
        currentInput = '0'; 
        
        // Update display with the result of the previous operation (or 0 if no previous operation existed)
        updateDisplay(displayElement, previousValue, errorState);

    } else if (value === 'C' || value === 'AC') {
        // Handle Clear function
        clearInput(displayElement);
        
    } else if (value === '=') {
        // Handle Equals function
        if (previousValue !== null && pendingOperation !== null) {
            // Perform the final calculation
            const result = window.AppLogic.executeOperation(previousValue, currentInput, pendingOperation);
            
            // Update state
            currentInput = String(result);
            previousValue = null;
            pendingOperation = null;
            
            // Update display
            updateDisplay(displayElement, currentInput, errorState);
        } else if (previousValue !== null) {
             // If only a number is present, '=' does nothing or just confirms the current value
             currentInput = currentInput;
        }
    }
}

/**
 * Initializes event listeners for all calculator buttons and sets up the initial state of the display.
 * @param {HTMLElement} displayElement - The display input field.
 * @param {NodeListOf<HTMLElement>} operatorButtons - List of operator buttons.
 * @param {NodeListOf<HTMLElement>} numberButtons - List of number buttons.
 */
function initCalculator(displayElement, operatorButtons, numberButtons) {
    displayElement = displayElement;
    operatorButtons = operatorButtons;
    numberButtons = numberButtons;

    // Attach listeners to operator buttons
    operatorButtons.forEach(button => {
        button.addEventListener('click', (e) => handleInputEvent(e));
    });

    // Attach listeners to number buttons
    numberButtons.forEach(button => {
        button.addEventListener('click', (e) => handleInputEvent(e));
    });
    
    // Initialize display state
    updateDisplay(displayElement, currentInput, errorState);
}

// Export the router functions to the global scope
window.router = {
    initCalculator,
    handleInputEvent,
    updateDisplay,
    clearInput
};