```javascript
// app.js

/**
 * app.js
 * Main application controller for the Basic Arithmetic Calculator.
 * Handles all user input events, manages the application state, executes the core mathematical logic, and updates the DOM.
 * 
 * SYSTEM_SKILL: Offline-First Local Data Architecture
 * Rule: The Ledger System: All state mutations MUST be recorded in a centralized JSON structure (a "Ledger") before updating the DOM.
 * Rule: Persistent Storage: Use `localStorage` as the primary database. Save the ledger immediately after every array mutation.
 * Rule: Data Hydration: The application must trigger an `init()` or `hydrate()` function on DOMContentLoaded to parse the JSON from `localStorage` and rebuild the UI state instantly.
 */

// --- Central Application State (The Ledger) ---
let currentOperand = '0';
let pendingOperation = null;
let previousValue = null;
let errorState = '';

// --- Core Logic Functions (Manifest Implementation) ---

/**
 * Executes the stored arithmetic operation based on the stored operands and the selected operator.
 * @param {number} operand1 
 * @param {number} operand2 
 * @param {string} operator 
 * @returns {number|string} The result or an error message.
 */
function performCalculation(operand1, operand2, operator) {
    switch (operator) {
        case '+':
            return operand1 + operand2;
        case '-':
            return operand1 - operand2;
        case '*':
            return operand1 * operand2;
        case '/':
            // FR 2.3.2: Handle division by zero error
            if (operand2 === 0) {
                return 'Error: Division by Zero';
            }
            return operand1 / operand2;
        default:
            return 'Error: Invalid Operator';
    }
}

/**
 * Resets the calculator state, clearing the current input and operation history.
 * @param {HTMLElement} displayElement - The display input field.
 */
function clearDisplay(displayElement) {
    currentOperand = '0';
    pendingOperation = null;
    previousValue = null;
    errorState = '';
    updateDisplay(displayElement, currentOperand, errorState);
}

/**
 * Updates the HTML display element with the current numerical input, pending operation, or error messages.
 * @param {HTMLElement} displayElement - The input field element.
 * @param {string} resultValue - The value to display (number, operator, or error).
 * @param {string} errorState - Any error message to display.
 */
function updateDisplay(displayElement, resultValue, errorState = '') {
    displayElement.value = resultValue;
    
    // Apply specific styling based on the content (NFR 3.2.2)
    if (errorState) {
        displayElement.style.color = 'var(--color-error)';
    } else {
        displayElement.style.color = 'var(--color-display-text)';
    }
}

/**
 * Processes numerical and operator input from user interaction.
 * @param {string} value - The input string (number or operator).
 * @param {string} type - The type of input (number, operator, clear, equals).
 */
function handleInput(value, type) {
    if (type === 'number') {
        // If the current input is an error or reset, start fresh
        if (currentOperand === '0' || currentOperand === 'Error') {
            currentOperand = value;
        } else {
            // Prevent multiple decimal points
            if (value === '.' && currentOperand.includes('.')) {
                return;
            }
            currentOperand += value;
        }
        
        // Update display immediately
        updateDisplay(displayElement, currentOperand, errorState);
        
    } else if (type === 'operator') {
        const inputValue = parseFloat(currentOperand);

        if (previousValue === null) {
            // Store the first operand
            previousValue = inputValue;
        } else {
            // Chaining operations: execute the pending operation first (FR 2.2.3)
            const result = performCalculation(previousValue, currentOperand, pendingOperation);
            
            // Handle potential errors from calculation
            if (typeof result === 'string' && result.startsWith('Error')) {
                errorState = result;
                previousValue = null; // Reset state if error occurs
                pendingOperation = null;
                currentOperand = result;
                updateDisplay(displayElement, currentOperand, errorState);
                return;
            }

            // Update previous value for the next operation
            previousValue = result;
            currentOperand = String(result);
        }
        
        // Set the new pending operation
        pendingOperation = value;
        
        // Clear the current input buffer for the next number entry
        currentOperand = '0'; 
        
        // Update display with the result of the previous operation
        updateDisplay(displayElement, previousValue, errorState);

    } else if (type === 'clear') {
        // Clear function (FR 2.1.4)
        clearDisplay(displayElement);
    }
}


// --- Initialization and Event Binding ---

/**
 * Sets up all necessary event listeners for calculator buttons and initializes the display state upon page load.
 * @param {HTMLElement} displayElement - The display input field.
 * @param {NodeListOf<HTMLElement>} operatorButtons - List of operator buttons.
 * @param {NodeListOf<HTMLElement>} numberButtons - List of number buttons.
 */
function initializeCalculator(displayElement, operatorButtons, numberButtons) {
    // Set references
    displayElement = displayElement;
    operatorButtons = operatorButtons;
    numberButtons = numberButtons;

    // Attach listeners to operator buttons
    operatorButtons.forEach(button => {