/**
 * storage.js
 * Manages the persistence of the calculator's state and calculation history using localStorage.
 * Implements the Offline-First Local Data Architecture principles.
 */

const STORAGE_KEY = 'calculatorHistory';

/**
 * Saves the current calculation state into localStorage.
 * @param {object} calculationData - The calculation object to save (e.g., {operands, operator, result}).
 * @returns {void}
 * Logic Notes: Serializes the calculation object to JSON and stores it under the STORAGE_KEY.
 */
function saveCalculationHistory(calculationData) {
    try {
        const dataToStore = JSON.stringify(calculationData);
        window.localStorage.setItem(STORAGE_KEY, dataToStore);
    } catch (error) {
        console.error("Error saving calculation history to localStorage:", error);
    }
}

/**
 * Retrieves the stored calculation history from localStorage.
 * @param {string} key - The key to look up in localStorage (defaults to STORAGE_KEY).
 * @returns {Array<object>} An array of calculation objects, or an empty array if none found or parsing fails.
 * Logic Notes: Retrieves the data, parses the JSON string, and handles the case where no history exists or data is corrupted.
 */
function loadCalculationHistory(key = STORAGE_KEY) {
    try {
        const storedData = window.localStorage.getItem(key);

        if (!storedData) {
            // Test 3: Empty State - Return empty array if no history exists.
            return [];
        }

        // Safe Parsing: Wrap JSON.parse() in a try/catch block.
        const historyArray = JSON.parse(storedData);
        
        // Ensure the result is an array, even if stored data was malformed
        if (Array.isArray(historyArray)) {
            return historyArray;
        } else {
            console.warn("Loaded data found, but it was not an array. Returning empty array.");
            return [];
        }

    } catch (error) {
        // Safe Parsing: Handle corrupted data gracefully.
        console.error("Error loading or parsing calculation history from localStorage:", error);
        // If parsing fails, treat it as empty history.
        return [];
    }
}

/**
 * Removes all stored calculation history from localStorage.
 * @param {string} key - The key of the data to remove (defaults to STORAGE_KEY).
 * @returns {void}
 * Logic Notes: Uses localStorage.removeItem() to clear the history array.
 */
function clearCalculationHistory(key = STORAGE_KEY) {
    try {
        window.localStorage.removeItem(key);
    } catch (error) {
        console.error("Error clearing calculation history from localStorage:", error);
    }
}

// Export the functions to be used by other modules (e.g., app.js)
window.storage = {
    saveCalculationHistory,
    loadCalculationHistory,
    clearCalculationHistory
};