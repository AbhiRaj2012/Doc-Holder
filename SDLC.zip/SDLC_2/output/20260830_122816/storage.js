/**
 * storage.js
 * Manages all client-side data persistence using the browser's localStorage API
 * for storing and retrieving invoice data, adhering to the Offline-First Local Data Architecture.
 */

const STORAGE_KEY = 'invoices';

/**
 * Initializes the storage structure in localStorage.
 * Ensures the 'invoices' key exists and is initialized as an empty array if not found.
 * @returns {void}
 */
function initializeStorage() {
    try {
        const storedData = localStorage.getItem(STORAGE_KEY);
        if (storedData === null) {
            // Rule: Initialize if not found
            localStorage.setItem(STORAGE_KEY, JSON.stringify([]));
        }
    } catch (error) {
        console.error("Error initializing storage:", error);
    }
}

/**
 * Retrieves the array of all saved invoice objects from localStorage.
 * @returns {Array<Object>} Array of invoice objects (JSON parsed), or an empty array if none found.
 */
function loadInvoices() {
    try {
        const storedData = localStorage.getItem(STORAGE_KEY);
        if (storedData === null) {
            // Test 1: Initial Load - Verify that loadInvoices returns an empty array when localStorage is empty.
            return [];
        }
        // Rule: Safe Parsing
        return JSON.parse(storedData);
    } catch (error) {
        console.error("Error loading invoices from storage:", error);
        // Fallback to empty array on parsing error
        return [];
    }
}

/**
 * Saves the current array of invoice objects back into localStorage.
 * Rule: Persistent Storage - Save immediately after every array mutation.
 * @param {Array<Object>} invoices - The array of invoice objects to save.
 * @returns {boolean} Boolean (success status).
 */
function saveInvoices(invoices) {
    try {
        const dataToStore = JSON.stringify(invoices);
        localStorage.setItem(STORAGE_KEY, dataToStore);
        return true;
    } catch (error) {
        console.error("Error saving invoices to storage:", error);
        return false;
    }
}

/**
 * Saves or updates a single invoice object in the local storage.
 * Rule: The Ledger System - Loads, updates, and saves the entire list.
 * @param {Object} invoiceData - The single invoice object to save.
 * @returns {boolean} Boolean (success status).
 */
function saveSingleInvoice(invoiceData) {
    try {
        // 1. Load current list
        let invoices = loadInvoices();

        // 2. Update the list (find and replace/add)
        const index = invoices.findIndex(inv => inv.id === invoiceData.id);

        if (index !== -1) {
            // Update existing invoice
            invoices[index] = invoiceData;
        } else {
            // Add new invoice
            invoices.push(invoiceData);
        }

        // 3. Save the entire list back
        saveInvoices(invoices);
        return true;
    } catch (error) {
        console.error("Error saving single invoice:", error);
        return false;
    }
}

/**
 * Removes a specific invoice from the local storage record by its ID.
 * Rule: The Ledger System - Loads, filters, and saves the updated list.
 * @param {string} invoiceId - The ID of the invoice to delete.
 * @returns {boolean} Boolean (success status).
 */
function deleteInvoice(invoiceId) {
    try {
        // 1. Load current list
        let invoices = loadInvoices();

        // 2. Filter out the invoice matching the provided ID
        const updatedInvoices = invoices.filter(inv => inv.id !== invoiceId);

        // 3. Save the updated list back
        saveInvoices(updatedInvoices);
        return true;
    } catch (error) {
        console.error("Error deleting invoice:", error);
        return false;
    }
}

// Initialize storage immediately upon script load
document.addEventListener('DOMContentLoaded', () => {
    initializeStorage();
});