```javascript
// router.js

/**
 * router.js
 * Manages the Single Page Application (SPA) view state, handling navigation
 * between different sections and coordinating data loading.
 */

// Import necessary modules
// Note: In a real module environment, we would use 'import'. Since this is a script
// environment, we assume storage.js and app.js are globally available.
// We rely on the functions provided by storage.js.

/**
 * Core navigation logic.
 * Hides all existing views and displays the requested view based on the provided ID.
 * @param {string} viewId - The ID of the view to display (e.g., 'invoice_generator_view').
 * @param {Object} params - Optional parameters to pass to the view (e.g., invoice ID).
 */
/**
 * Core navigation logic.
 * Hides all existing views and displays the requested view based on the provided ID.
 * @param {string} viewId - The ID of the view to display (e.g., 'invoice_generator_view').
 * @param {Object} params - Optional parameters to pass to the view (e.g., invoice ID).
 */
/**
 * Core navigation logic.
 * Hides all existing views and displays the requested view based on the provided ID.
 * @param {string} viewId - The ID of the view to display (e.g., 'invoice_generator_view').
 * @param {Object} params - Optional parameters to pass to the view (e.g., invoice ID).
 */
function navigate(viewId, params = {}) {
    // 1. Hide all views
    const views = document.querySelectorAll('.view');
    views.forEach(view => {
        view.classList.add('hidden');
        view.classList.remove('active');
    });

    // 2. Show the requested view
    const targetView = document.getElementById(viewId);
    if (targetView) {
        targetView.classList.remove('hidden');
        targetView.classList.add('active');
    } else {
        console.error(`Router Error: View with ID "${viewId}" not found.`);
    }

    // 3. Handle view-specific data loading (Delegation to app.js or specific loaders)
    if (viewId === 'invoice_management_view') {
        loadInvoicesList();
    } else if (viewId === 'invoice_display_view') {
        // Load details if an invoiceId is provided
        if (params.invoiceId) {
            loadInvoiceDetails(params.invoiceId);
        }
    }
}

/**
 * Calls the storage module to retrieve the list of all saved invoices
 * and updates the DOM to display the list view.
 */
/**
 * Calls the storage module to retrieve the list of all saved invoices
 * and updates the DOM to display the list view.
 */
function loadInvoicesList() {
    const invoices = loadInvoices();
    const listElement = document.getElementById('invoice-list');
    const noInvoicesMessage = document.querySelector('.no-invoices');

    // Clear previous list items
    listElement.innerHTML = '';

    if (invoices.length === 0) {
        noInvoicesMessage.style.display = 'list-item';
        return;
    }

    noInvoicesMessage.style.display = 'none';

    // Populate the list
    invoices.forEach(invoice => {
        const listItem = document.createElement('li');
        listItem.className = 'invoice-item';
        // Assuming the list item will contain a link to view details
        listItem.innerHTML = `
            <a href="#" class="view-invoice-details" data-invoice-id="${invoice.id}">
                ${invoice.invoice_number}
            </a>
        `;
        listElement.appendChild(listItem);
    });
}

/**
 * Retrieves a specific invoice object from localStorage using the storage module
 * and passes the data to the main application logic for display.
 * @param {string} invoiceId - The ID of the invoice to retrieve.
 */
/**
 * Retrieves a specific invoice object from localStorage using the storage module
 * and passes the data to the main application logic for display.
 * @param {string} invoiceId - The ID of the invoice to retrieve.
 */
function loadInvoiceDetails(invoiceId) {
    const invoice = loadInvoices().find(inv => inv.id === invoiceId);

    if (invoice) {
        // Pass the data to the main application logic (app.js) for rendering
        // We assume app.js has a function to handle this display.
        if (typeof app.loadInvoiceDetails === 'function') {
            app.loadInvoiceDetails(invoice);
        } else {
            console.error("app.loadInvoiceDetails function not found.");
        }
    } else {
        console.error(`Invoice not found with ID: ${invoiceId}`);
        // Optionally navigate back to the list if details are not found
        // navigate('invoice_management_view');
    }
}

/**
 * Central event handler that intercepts clicks on navigation elements
 * and triggers the appropriate `navigate` function.
 * @param {Event} event - The click event object.
 */
/**
 * Central event handler that intercepts clicks on navigation elements
 * and triggers the appropriate `navigate` function.
 * @param {Event} event - The click event object.
 */
function handleNavigationEvents(event) {
    event.preventDefault();

    const target = event.target.closest('.view-invoice-details');

    if (target) {
        const invoiceId = target.getAttribute('data-invoice-id');
        // Trigger navigation to the display view with the invoice ID as a parameter
        navigate('invoice_display_view', { invoiceId: invoiceId });
    }
}