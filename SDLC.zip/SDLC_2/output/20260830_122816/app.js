<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Offline Invoice Manager</title>
    <style>
        /* ==========================================================================
           CSS Styles (Based on provided input)
           ========================================================================== */

        /* CSS Variables (Inferred from context) */
        :root {
            --color-primary: #007bff;
            --color-success: #28a745;
            --color-error: #dc3545; /* Used for error messages */
            --color-text: #333;
            --color-background: #f8f9fa;
            --color-border: #dee2e6;
            --spacing-small: 0.5rem;
            --spacing-medium: 1rem;
            --spacing-large: 1.5rem;
        }

        /* Base Styles & Typography */
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background-color: var(--color-background);
            color: var(--color-text);
            margin: 0;
            padding: 0;
            line-height: 1.6;
        }

        /* UI Integrity & SPA Layouts: Layout Structure */
        .app-container {
            display: grid;
            grid-template-rows: auto auto; /* Stack views vertically */
            min-height: 100vh;
        }

        .view {
            display: none; /* Rule: Hide all views by default */
            padding: var(--spacing-medium);
            background-color: white;
            min-height: 60vh;
        }

        .view.active {
            display: block;
        }

        /* Form & Input Styling */
        input[type="text"],
        input[type="number"],
        input[type="date"],
        textarea {
            width: 100%;
            padding: 0.5rem;
            margin-bottom: var(--spacing-medium);
            border: 1px solid var(--color-border);
            border-radius: 0.375rem;
            box-sizing: border-box;
            font-size: 1rem;
        }

        /* Card Styling */
        .card {
            background-color: #ffffff;
            border: 1px solid var(--color-border);
            border-radius: 0.5rem;
            padding: var(--spacing-medium);
            margin-bottom: var(--spacing-medium);
        }

        /* Buttons & Interactions */
        .action-button {
            display: inline-block;
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 0.375rem;
            cursor: pointer;
            font-weight: 600;
            transition: background-color 0.2s ease;
        }

        .action-button:hover {
            background-color: #e9ecef;
        }

        .remove-item-btn {
            background-color: var(--color-error);
            color: white;
            padding: 0.3rem 0.6rem;
            font-size: 0.85rem;
            border: none;
            border-radius: 0.375rem;
            cursor: pointer;
        }

        .remove-item-btn:hover {
            background-color: #c82333;
        }

        /* Invoice Specific Styles */
        .invoice-header {
            border-bottom: 2px solid #000;
            margin-bottom: 15px;
            padding-bottom: 10px;
        }

        .invoice-items-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .invoice-items-table th,
        .invoice-items-table td {
            border: 1px solid #000; /* High contrast black borders for printing */
            padding: 8px;
            font-size: 14px;
        }

        .totals-section {
            margin-top: 20px;
            border-top: 2px solid #000;
            display: flex;
            justify-content: flex-end;
        }

        /* Utility Classes */
        .no-invoices {
            display: none; /* Hidden by default */
            padding: 1rem;
            text-align: center;
            color: #6c757d;
        }

        /* ==========================================================================
           6. Print Styles (print_styles)
           ========================================================================== */

        @media print {
            /* Hide all non-essential UI elements */
            body {
                background-color: white;
                margin: 0;
                padding: 0;
            }

            /* Hide the main application container and navigation */
            .app-container,
            #invoice-generator-view,
            #invoice-management-view,
            .view,
            .card,
            .action-button,
            .remove-item-btn,
            .invoice-header,
            .invoice-footer {
                display: none !important;
            }

            /* Ensure the invoice content is the only thing visible and formatted cleanly */
            #invoice-display-view {
                display: block !important;
                width: 100%;
                margin: 0;
                padding: 20px;
            }

            /* Ensure the invoice table is fully visible and legible */
            .invoice-items-table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
            }

            .invoice-items-table th,
            .invoice-items-table td {
                border: 1px solid #000; /* High contrast black borders for printing */
                padding: 8px;
                font-size: 14px;
            }

            /* Ensure headers and totals are clearly printed */
            .invoice-header {
                border-bottom: 2px solid #000;
                margin-bottom: 15px;
            }

            /* Ensure totals are prominent */
            .totals-section {
                margin-top: 20px;
                border-top: 2px solid #000;
                display: flex;
                justify-content: flex-end;
            }

            /* Ensure all text is black */
            body, .invoice-items-table {
                color: #000 !important;
            }
        }

        /* ==========================================================================
           7. Responsive Media Queries (responsive_media)
           ========================================================================== */

        /* Tablet View */
        @media (max-width: 992px) {
            .app-container {
                grid-template-rows: auto auto; /* Stack views vertically */
            }

            .invoice-content {
                padding: var(--spacing-medium);
            }

            /* Adjust table layout for smaller screens */
            .invoice-table th,
            .invoice-table td {
                padding: 0.5rem;
                font-size: 0.9rem;
            }
        }

        /* Mobile View */
        @media (max-width: 600px) {
            body {
                padding: var(--spacing-small);
            }

            .card {
                padding: var(--spacing-small);
            }

            /* Ensure input fields remain full width and readable */
            input[type="text"],
            input[type="number"],
            input[type="date"],
            textarea {
                font-size: 0.95rem;
            }
        }
    </style>
</head>
<body>

    <div class="app-container">
        <!-- Invoice Generator View -->
        <section id="invoice_generator_view" class="view active">
            <div class="invoice-content">
                <h1>Invoice Generator</h1>
                <div class="card">
                    <h2>Create New Invoice</h2>
                    <form id="invoice-form">
                        <label for="invoice_number">Invoice Number:</label>
                        <input type="text" id="invoice_number" required>

                        <label for="invoice_date">Invoice Date:</label>
                        <input type="date" id="invoice_date" required>

                        <h3>Line Items</h3>
                        <table class="invoice-items-table">
                            <thead>
                                <tr>
                                    <th>Description</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Total</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="invoice-items-body">
                                <!-- Dynamic rows will be inserted here -->
                            </tbody>
                        </table>

                        <div class="totals-section">
                            <div>
                                <strong>Grand Total:</strong> <span id="grand-total">$0.00</span>
                            </div>
                        </div>

                        <button type="submit" class="action-button" style="margin-top: var(--spacing-medium);">Save Invoice</button>
                    </form>
                </div>
            </div>
        </section>

        <!-- Invoice Management View -->
        <section id="invoice_management_view" class="view hidden">
            <h1>Invoice Management</h1>
            <div class="card">
                <h2>Saved Invoices</h2>
                <ul id="invoice-list">
                    <!-- Invoice list populated by router.js -->
                    <li class="no-invoices" id="no-invoices-message">No invoices found.</li>
                </ul>
            </div>
        </section>

        <!-- Invoice Display View -->
        <section id="invoice_display_view" class="view hidden">
            <div class="invoice-content">
                <div class="invoice-header">
                    <h1 id="display-invoice-number"></h1>
                    <p>Date: <span id="display-invoice-date"></span></p>
                </div>
                <h2>Invoice Details</h2>
                <div class="card">
                    <table class="invoice-items-table">
                        <thead>
                            <tr>
                                <th>Description</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody id="display-items-body">
                            <!-- Invoice items will be displayed here -->
                        </tbody>
                    </table>
                    <div class="totals-section">
                        <div>
                            <strong>Grand Total:</strong> <span id="display-grand-total">$0.00</span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- The actual content of app.js -->
    <script>
        /**
         * Core application logic, business calculations, and DOM manipulation for the Billing Application.
         * This file acts as the central controller, orchestrating data flow between the UI, the storage layer, and the calculation engine.
         */

        const invoiceForm = document.getElementById('invoice-form');
        const invoiceListEl = document.getElementById('invoice-list');
        const invoiceItemsBody = document.getElementById('invoice-items-body');
        const grandTotalEl = document.getElementById('grand-total');
        const displayInvoiceNumberEl = document.getElementById('display-invoice-number');
        const displayInvoiceDateEl = document.getElementById('display-invoice-date');
        const displayItemsBody = document.getElementById('display-items-body');
        const noInvoicesMessage = document.getElementById('no-invoices-message');
        const body = document.body;

        /**
         * Initializes the application: sets up event listeners, loads data, and initializes state.
         * @param {null}
         */
        function initializeApplication() {
            // Set up event delegation for all UI interactions
            setupEventListeners();
            // Load all saved invoices from localStorage and render the list
            loadInvoices();
        }

        /**
         * Sets up all necessary event listeners for the application.
         */
        function setupEventListeners() {
            // Handle form submission
            invoiceForm.addEventListener('submit', handleInvoiceSubmission);

            // Handle invoice selection (delegation for viewing details)
            invoiceListEl.addEventListener('click', handleInvoiceSelection);
        }

        /**
         * Retrieves all invoice data from localStorage and renders the list view (dashboard).
         */
        async function loadInvoices() {
            try {
                const invoices = await storage.loadAllInvoices();
                renderInvoiceList(invoices);
            } catch (error) {
                console.error("Error loading invoices:", error);
                // Display no invoices message if loading fails
                noInvoicesMessage.style.display = 'block';
            }
        }

        /**
         * Renders the list of invoices in the management view.
         * @param {Array<object>} invoices - The list of invoice objects.
         */
        function renderInvoiceList(invoices) {
            invoiceListEl.innerHTML = ''; // Clear existing list
            if (invoices.length === 0) {
                noInvoicesMessage.style.display = 'block';
                return;
            }
            noInvoicesMessage.style.display = 'none';

            invoices.forEach(invoice => {
                const listItem = document.createElement('li');
                listItem.className = 'invoice-item';
                listItem.dataset.invoiceId = invoice.id;
                listItem.innerHTML = `
                    <a href="#" class="action-button" data-id="${invoice.id}">View Details</a>
                    <button class="remove-item-btn" data-id="${invoice.id}">Delete</button>
                `;
                invoiceListEl.appendChild(listItem);
            });
        }

        /**
         * Handles the submission of the new invoice form.
         * Gathers data, performs calculations, and saves the new invoice object.
         * @param {object} invoiceData - Data gathered from the form.
         */
        async function handleInvoiceSubmission(event) {
            event.preventDefault();

            // 1. Gather data
            const invoiceNumber = document.getElementById('invoice_number').value;
            const invoiceDate = document.getElementById('invoice_date').value;
            const lineItems = Array.from(invoiceItemsBody.querySelectorAll('tr')).map(row => {
                const description = row.querySelector('td:nth-child(1)').textContent;
                const quantity = parseFloat(row.querySelector('td:nth-child(2)').textContent);
                const price = parseFloat(row.querySelector('td:nth-child(3)').textContent);
                const total = quantity * price;
                return { description, quantity, price, total };
            });

            // 2. Validate all input fields (NFR 3.3.2)
            if (!invoiceNumber || !invoiceDate || lineItems.length === 0) {
                alert("Please fill in all required fields.");
                return;
            }

            // 3. Calculate line item subtotals (FR 2.1.4)
            let subtotal = 0;
            lineItems.forEach(item => {
                subtotal += item.total;
            });

            // 4. Calculate total tax and grand total (FR 2.1.5)
            // Assuming a fixed tax rate for simplicity, or calculating based on line items.
            // For this implementation, we'll assume a simple 10% tax calculation on the subtotal.
            const taxRate = 0.10;
            const tax = subtotal * taxRate;
            const grandTotal = subtotal + tax;

            // 5. Serialize the final invoice object
            const newInvoice = {
                id: Date.now().toString(), // Simple unique ID
                invoiceNumber,
                invoiceDate,
                items: lineItems,
                subtotal,
                tax,
                grandTotal
            };

            // 6. Call storage.js to save it.
            await storage.saveInvoice(newInvoice);

            alert(`Invoice ${invoiceNumber} saved successfully!`);
            invoiceForm.reset();
            // Reload invoices to update the dashboard
            loadInvoices();
        }

        /**
         * Renders the details of a specific invoice.
         * @param {object} invoiceObject - The invoice data to display.
         */
        function renderInvoiceDetails(invoiceObject) {
            displayInvoiceNumberEl.textContent = invoiceObject.invoiceNumber;
            displayInvoiceDateEl.textContent = new Date(invoiceObject.invoiceDate).toLocaleDateString();

            // Populate line item tables
            displayItemsBody.innerHTML = '';
            let calculatedSubtotal = 0;

            invoiceObject.items.forEach(item => {
                const row = displayItemsBody.insertRow();
                row.insertCell().textContent = item.description;
                row.insertCell().textContent = item.quantity;
                row.insertCell().textContent = `$${item.price.toFixed(2)}`;
                row.insertCell().textContent = `$${item.total.toFixed(2)}`;
                calculatedSubtotal += item.total;
            });

            // Display totals
            grandTotalEl.textContent = `$${invoiceObject.grandTotal.toFixed(2)}`;
        }

        /**
         * Handles the selection of an invoice to view its details.
         * @param {Event} event - The click event.
         */
        function handleInvoiceSelection(event) {
            const target = event.target;
            const invoiceId = target.dataset.id;

            if (!invoiceId) return;

            // Find the invoice in storage (assuming storage.js provides a way to fetch by ID)
            storage.loadInvoice(invoiceId).then(invoice => {
                if (invoice) {
                    renderInvoiceDetails(invoice);
                    // Switch to the display view
                    document.getElementById('invoice_management_view').classList.add('hidden');
                    document.getElementById('invoice_display_view').classList.remove('hidden');
                } else {
                    alert("Invoice not found.");
                }
            });
        }

        /**
         * Handles the deletion of a specific invoice record.
         * @param {string} invoiceId - The ID of the invoice to delete.
         */
        async function deleteInvoice(invoiceId) {
            if (!confirm("Are you sure you want to delete this invoice?")) {
                return;
            }
            try {
                await storage.deleteInvoice(invoiceId);
                // Reload the list to reflect the change
                loadInvoices();
                // Hide the detail view if we were viewing it
                document.getElementById('invoice_display_view').classList.add('hidden');
            } catch (error) {
                console.error("Error deleting invoice:", error);
                alert("Error deleting invoice.");
            }
        }

        /**
         * Triggers the print dialog for a selected invoice.
         * @param {string} invoiceId - The ID of the invoice to print.
         */
        async function triggerPrintDialog(invoiceId) {
            try {
                const invoice = await storage.loadInvoice(invoiceId);
                if (!invoice) {
                    alert("Invoice not found for printing.");
                    return;
                }

                // Generate print-optimized HTML content
                const printHTML = generatePrintHTML(invoice);

                // Create a temporary window for printing
                const printWindow = window.open('', '_blank');
                printWindow.document.write('<html><head><title>Invoice Print</title>');
                printWindow.document.write('<style>' + document.querySelector('style').textContent + '</style>'); // Include CSS
                printWindow.document.write('</head><body>');
                printWindow.document.write(printHTML);
                printWindow.document.write('</body></html>');
                printWindow.document.close();

                // Trigger the print function
                printWindow.focus();
                printWindow.print();

            } catch (error) {
                console.error("Error triggering print:", error);
                alert("Error preparing invoice for printing.");
            }
        }

        /**
         * Generates the HTML content optimized for printing.
         * @param {object} invoice - The invoice data.
         * @returns {string} The HTML string to be printed.
         */
        function generatePrintHTML(invoice) {
            let itemsHTML = '';
            invoice.items.forEach(item => {
                itemsHTML += `<tr>
                    <td>${item.description}</td>
                    <td>${item.quantity}</td>
                    <td>$${item.price.toFixed(2)}</td>
                    <td>$${item.total.toFixed(2)}</td>
                </tr>`;
            });

            return `
                <div class="invoice-header">
                    <h1>Invoice: ${invoice.invoiceNumber}</h1>
                    <p>Date: ${new Date(invoice.invoiceDate).toLocaleDateString()}</p>
                </div>
                <h2>Invoice Details</h2>
                <table class="invoice-items-table">
                    <thead>
                        <tr>
                            <th>Description</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${itemsHTML}
                    </tbody>
                </table>
                <div class="totals-section">
                    <div>
                        <strong>Grand Total:</strong> <span>$${invoice.grandTotal.toFixed(2)}</span>
                    </div>
                </div>
            `;
        }


        // --- Event Handlers for List Actions ---

        /**
         * Handles clicks on the invoice list for viewing details or deletion.
         * @param {Event} event
         */
        function handleInvoiceSelection(event) {
            const target = event.target;
            const invoiceId = target.dataset.id;

            if (target.classList.contains('action-button') && target.textContent.includes('View Details')) {
                triggerPrintDialog(invoiceId);
            } else if (target.classList.contains('remove-item-btn')) {
                deleteInvoice(invoiceId);
            } else if (target.tagName === 'A' && target.href.includes('view')) {
                // This handles the 'View Details' link
                handleInvoiceSelection(event);
            }
        }

        // --- Initialization ---
        document.addEventListener('DOMContentLoaded', initializeApplication);

    </script>
</body>
</html>