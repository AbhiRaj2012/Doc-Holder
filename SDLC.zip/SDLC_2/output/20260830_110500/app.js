```javascript
/**
 * app.js
 * Core application logic for the Client-Side Billing Application.
 * Implements the Offline-First Local Data Architecture and Modern CSS Layouts.
 */

// =============================================================================
// 1. Global State and Data Persistence (Offline-First Local Data Architecture)
// =============================================================================

/**
 * The central state object (The Ledger System)
 * @type {Array<Object>}
 */
let invoices = [];
const STORAGE_KEY = 'billingInvoices';

/**
 * Retrieves the array of invoice objects from localStorage.
 * Implements Safe Parsing rule.
 * @returns {Array<Object>} The loaded invoice array.
 */
function loadInvoicesFromStorage() {
    try {
        const data = localStorage.getItem(STORAGE_KEY);
        if (data) {
            invoices = JSON.parse(data);
            // Ensure invoices is an array, even if stored data is malformed
            if (!Array.isArray(invoices)) {
                invoices = [];
            }
        } else {
            invoices = []; // Handle the case where localStorage is empty gracefully
        }
    } catch (error) {
        console.error("Error loading invoices from localStorage:", error);
        invoices = []; // Handle corrupted data gracefully
    }
    return invoices;
}

/**
 * Persists the current array of invoice objects back to localStorage.
 * Implements Persistent Storage rule.
 */
function saveInvoicesToStorage() {
    try {
        const data = JSON.stringify(invoices);
        localStorage.setItem(STORAGE_KEY, data);
    } catch (error) {
        console.error("Error saving invoices to localStorage:", error);
    }
}

// =============================================================================
// 2. Invoice Management Logic
// =============================================================================

/**
 * Creates a unique, sequential Invoice ID.
 * @returns {string} A unique invoice ID.
 */
function generateInvoiceId() {
    // Simple unique ID based on timestamp and random number for better uniqueness
    return 'INV-' + Date.now() + '-' + Math.random().toString(36).substring(2, 9).toUpperCase();
}

/**
 * Adds a new line item to the currently active invoice.
 * Implements the calculation logic.
 * @param {string} invoiceId - The ID of the invoice to modify.
 * @param {string} description
 * @param {number} quantity
 * @param {number} price
 */
function addLineItem(invoiceId, description, quantity, price) {
    const invoiceIndex = invoices.findIndex(inv => inv.id === invoiceId);

    if (invoiceIndex === -1) {
        console.error("Invoice not found for line item addition.");
        return false;
    }

    const invoice = invoices[invoiceIndex];

    // Calculate line item subtotal
    const subtotal = parseFloat(quantity) * parseFloat(price);

    // Add the new item
    invoice.items.push({ description, quantity: parseFloat(quantity), price: parseFloat(price), subtotal });

    // Recalculate totals
    calculateTotals(invoice);

    // Persist the change immediately (Persistent Storage rule)
    saveInvoicesToStorage();
    return true;
}

/**
 * Calculates all financial totals for a specific invoice.
 * Implements the calculation logic.
 * @param {Object} invoice - The invoice object to calculate.
 */
function calculateTotals(invoice) {
    let subtotal = 0;
    invoice.items.forEach(item => {
        subtotal += item.subtotal;
    });

    // Apply tax (assuming a fixed tax rate for simplicity, e.g., 10%)
    const TAX_RATE = 0.10;
    const tax = subtotal * TAX_RATE;
    const grandTotal = subtotal + tax;

    invoice.subtotal = subtotal.toFixed(2);
    invoice.tax = tax.toFixed(2);
    invoice.total = grandTotal.toFixed(2);
}

/**
 * Finds an invoice by ID.
 * @param {string} id
 * @returns {Object|undefined}
 */
function findInvoiceById(id) {
    return invoices.find(inv => inv.id === id);
}

// =============================================================================
// 3. DOM Manipulation and Rendering
// =============================================================================

/**
 * Renders the list of all saved invoices to the management view.
 * Implements Data Hydration rule.
 */
function renderInvoiceList() {
    const listContainer = document.getElementById('invoice_list');
    listContainer.innerHTML = '';

    if (invoices.length === 0) {
        listContainer.innerHTML = '<li class="invoice-item placeholder">No invoices found. Start by creating a new one!</li>';
        return;
    }

    invoices.forEach(invoice => {
        const listItem = document.createElement('li');
        listItem.className = 'invoice-item';
        listItem.dataset.invoiceId = invoice.id;
        listItem.innerHTML = `
            <strong>ID:</strong> ${invoice.id}<br>
            <strong>Client:</strong> ${invoice.clientName}<br>
            <strong>Total:</strong> $${invoice.total}
        `;
        // Attach event listener for viewing details
        listItem.addEventListener('click', () => viewInvoiceDetails(invoice.id));
        listContainer.appendChild(listItem);
    });
}

/**
 * Loads and displays the full details of a selected invoice.
 * @param {string} invoiceId
 */
function viewInvoiceDetails(invoiceId) {
    const invoice = findInvoiceById(invoiceId);
    if (!invoice) {
        alert("Invoice not found.");
        return;
    }

    // Populate the preview form
    document.getElementById('client_name').value = invoice.clientName;
    document.getElementById('invoice_date').value = invoice.date;
    document.getElementById('total_amount').value = invoice.total;

    // Render line items
    const lineItemsBody = document.getElementById('line_items_body');
    lineItemsBody.innerHTML = '';

    invoice.items.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.description}</td>
            <td>${item.quantity}</td>
            <td>$${item.price.toFixed(2)}</td>
        `;
        lineItemsBody.appendChild(row);
    });

    // Update action button state
    document.getElementById('print_invoice_btn').disabled = false;
    document.getElementById('print_invoice_btn_preview').disabled = false;
}

/**
 * Generates the print-optimized HTML content for a selected invoice.
 * Implements Export Capability rule.
 * @param {Object} invoice - The invoice object to render.
 */
function renderInvoicePrintView(invoice) {
    const table = document.getElementById('invoice_details_table');
    const lineItemsBody = document.getElementById('line_items_body');

    // Clear previous content
    table.innerHTML = '';
    lineItemsBody.innerHTML = '';

    // --- Header Section ---
    let html = `
        <h2>Invoice #${invoice.id}</h2>
        <p><strong>Client:</strong> ${invoice.clientName}</p>
        <p><strong>Date:</strong> ${invoice.date}</p>
        <table style="width: 100%; margin-top: 20px;">
            <tr>
                <th style="text-align: left; padding: 8px; border: 1px solid #000;">Description</th>
                <th style="text-align: right; padding: 8px; border: 1px solid #000;">Qty</th>
                <th style="text-align: right; padding: 8px; border: 1px solid #000;">Price</th>
            </tr>
    `;

    // --- Line Items ---
    invoice.items.forEach(item => {
        html += `
            <tr>
                <td style="padding: 8px; border: 1px solid #000;">${item.description}</td>
                <td style="text-align: right; padding: 8px; border: 1px solid #000;">${item.quantity}</td>
                <td style="text-align: right; padding: 8px; border: 1px solid #000;">$${item.price.toFixed(2)}</td>
            </tr>
        `;
    });

    // --- Totals Section ---
    html += `
        <table style="width: 100%; margin-top: 20px;">
            <tr>
                <td style="text-align: right; padding: 8px; border: 1px solid #000;">Subtotal:</td>
                <td style="text-align: right; padding: 8px; border: 1px solid #000;">$${invoice.subtotal}</td>
            </tr>
            <tr>
                <td style="text-align: right; padding: 8px; border: 1px solid #000;">Tax (10%):</td>
                <td style="text-align: right; padding: 8px; border: 1px solid #000;">$${invoice.tax}</td>
            </tr>
            <tr style="font-weight: bold; border-top: 2px solid #000; margin-top: 10px;">
                <td style="text-align: right; padding: 10px; border: 1px solid #000;">TOTAL DUE:</td>
                <td style="text-align: right; padding: 10px; border: 1px solid #000;">$${invoice.total}</td>
            </tr>
        </table>
    `;

    // Inject the generated HTML into the preview area
    document.getElementById('invoice_preview_area').innerHTML = html;
}

/**
 * Initiates the browser's native print functionality.
 * Implements Trigger Print Dialog rule.
 */
function triggerPrintDialog() {
    // Ensure the print view is visible before printing
    const previewArea = document.getElementById('invoice_preview_area');
    if (previewArea) {
        window.print();
    } else {
        alert("Please view the invoice details before attempting to print.");
    }
}

// =============================================================================
// 4. Event Handlers and Initialization
// =============================================================================

/**
 * Handles input validation for form fields.
 * Implements Handle Input Validation rule.