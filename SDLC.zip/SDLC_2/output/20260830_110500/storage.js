```javascript
/**
 * storage.js
 * Manages all client-side data persistence using the browser's localStorage for storing and retrieving invoice data.
 * Implements the Offline-First Local Data Architecture.
 */

const STORAGE_KEY = 'billingInvoices';

/**
 * Retrieves the array of invoice objects from localStorage and loads them into memory.
 * Implements Data Hydration and Safe Parsing rules.
 * @returns {Array<Object>} The loaded invoice array.
 */
function loadInvoices() {
    try {
        const data = localStorage.getItem(STORAGE_KEY);
        if (data) {
            const invoices = JSON.parse(data);
            // Ensure the loaded data is an array
            if (!Array.isArray(invoices)) {
                console.warn("Corrupted data found in localStorage. Resetting to empty array.");
                return [];
            }
            return invoices;
        }
        // If no data exists, return an empty array (Data Hydration rule)
        return [];
    } catch (error) {
        // Safe Parsing rule: Handle corrupted data gracefully
        console.error("Error loading invoices from localStorage. Data may be corrupted.", error);
        return [];
    }