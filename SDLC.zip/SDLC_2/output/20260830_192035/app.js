/**
 * Task Agenda Dashboard Application Logic (app.js)
 * Handles all data persistence, DOM manipulation, task management, calendar rendering, and theme switching.
 */

// --- Global State ---
let tasks = [];
let currentViewDate = new Date(); // Tracks the currently displayed month for the calendar

// --- DOM Element References ---
const taskForm = document.getElementById('task-input-form');
const taskTitleInput = document.getElementById('task-title');
const taskDateInput = document.getElementById('task-date');
const addTaskBtn = document.getElementById('add-task-btn');
const taskListContainer = document.getElementById('task-list-container');
const calendarView = document.getElementById('calendar-view');
const currentMonthYearSpan = document.getElementById('current-month-year');
const themeToggleBtn = document.getElementById('theme-toggle');
const body = document.body;

// =========================================================================
// 1. Data Persistence Functions (Interacting with window.StorageApp)
// =========================================================================

/**
 * Retrieves the task array from localStorage and populates the application state.
 * (Manifest: loadTasks)
 */
window.loadTasks = function() {
    tasks = window.StorageApp.loadTasks();
    renderTaskList(tasks);
    renderCalendar(tasks);
};

/**
 * Persists the current task array to localStorage.
 * (Manifest: saveTasks)
 * @param {Array<Object>} tasks - The array of task objects to save.
 */
window.saveTasks = function(tasks) {
    window.StorageApp.saveTasks(tasks);
    // Re-render UI after saving
    renderTaskList(tasks);
    renderCalendar(tasks);
};

// =========================================================================
// 2. Task Management Functions
// =========================================================================

/**
 * Dynamically generates and updates the HTML list displaying all current tasks.
 * (Manifest: renderTaskList)
 * @param {Array<Object>} tasks - The array of tasks to display.
 */
window.renderTaskList = function(tasks) {
    taskListContainer.innerHTML = '<h2>My Tasks</h2>'; // Clear previous content

    if (tasks.length === 0) {
        taskListContainer.innerHTML += '<p>No tasks found. Add a new task!</p>';
        return;
    }

    const ul = document.createElement('ul');
    tasks.forEach(task => {
        const li = document.createElement('li');
        li.className = 'task-item';
        li.innerHTML = `
            <span>${task.title} (Date: ${task.date})</span>
            <button class="delete-task" data-id="${task.id}">Delete</button>
        `;
        ul.appendChild(li);
    });
    taskListContainer.appendChild(ul);

    // Attach event listeners for deletion
    document.querySelectorAll('.delete-task').forEach(button => {
        button.addEventListener('click', (e) => {
            window.deleteTask(e.target.dataset.id);
        });
    });
};

/**
 * Removes a task by its ID from the task array, saves the updated list, and refreshes the UI.
 * (Manifest: deleteTask)
 * @param {number} taskId - The ID of the task to delete.
 */
window.deleteTask = function(taskId) {
    tasks = tasks.filter(task => task.id !== parseInt(taskId));
    window.saveTasks(tasks);
};

/**
 * Creates a new task object, saves it, and re-renders the task list and calendar.
 * (Manifest: addTask)
 * @param {string} title - The title of the new task.
 * @param {string} date - The date of the task (YYYY-MM-DD).
 */
window.addTask = function(title, date) {
    if (!title || !date) {
        alert("Please enter both a title and a date.");
        return;
    }

    const newTask = {
        id: Date.now(), // Simple unique ID
        title: title,
        date: date
    };

    tasks.push(newTask);
    window.saveTasks(tasks);
    
    // Clear form and re-render
    taskTitleInput.value = '';
    taskDateInput.value = '';
    window.renderTaskList(tasks);
    window.renderCalendar(tasks);
};

/**
 * Filters the task array to retrieve all tasks scheduled for a specific date string (YYYY-MM-DD).
 * (Manifest: getTasksForDate)
 * @param {string} dateString - The date to filter by (YYYY-MM-DD).
 * @returns {Array<Object>} The tasks matching the date.
 */
window.getTasksForDate = function(dateString) {
    return tasks.filter(task => task.date === dateString);
};

// =========================================================================
// 3. Calendar Rendering Functions
// =========================================================================

/**
 * Generates the monthly calendar grid, calculates task presence, and applies highlighting classes to the calendar cells.
 * (Manifest: renderCalendar)
 * @param {Array<Object>} tasks - The array of tasks to display.
 */
window.renderCalendar = function(tasks) {
    // Clear previous calendar content
    calendarView.innerHTML = '';

    const year = currentViewDate.getFullYear();
    const month = currentViewDate.getMonth();

    // Set header
    currentMonthYearSpan.textContent = currentViewDate.toLocaleString('default', { month: 'long', year: 'numeric' });

    // Calculate start and end dates for the month
    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);

    // Determine the starting day of the week (0=Sun, 6=Sat)
    const startDayOfWeek = firstDayOfMonth.getDay();
    
    // Create the grid container
    const grid = document.createElement('div');
    grid.id = 'calendar-grid';
    grid.className = 'calendar-grid';
    
    // Create the 7 column headers (optional, but good practice)
    const headerRow = document.createElement('div');
    headerRow.style.display = 'grid';
    headerRow.style.gridTemplateColumns = 'repeat(7, 1fr)';
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    days.forEach(day => {
        const header = document.createElement('div');
        header.textContent = day;
        header.style.textAlign = 'center';
        header.style.fontWeight = 'bold';
        headerRow.appendChild(header);
    });
    grid.appendChild(headerRow);


    // Create the calendar cells
    for (let day = 1; day <= lastDayOfMonth.getDate(); day++) {
        const currentDate = new Date(year, month, day);
        const dateString = currentDate.toISOString().split('T')[0]; // YYYY-MM-DD format

        const cell = document.createElement('div');
        cell.className = 'calendar-cell';
        cell.dataset.date = dateString;

        // Check for tasks on this date
        const dayTasks = window.getTasksForDate(dateString);
        if (dayTasks.length > 0) {
            cell.classList.add('has-task');
        }

        cell.innerHTML = `<span>${day}</span>`;
        grid.appendChild(cell);
    }

    // Add empty cells for alignment (padding before the 1st day)
    for (let i = 0; i < startDayOfWeek; i++) {
        const emptyCell = document.createElement('div');
        emptyCell.className = 'calendar-cell';
        grid.appendChild(emptyCell);
    }

    calendarView.appendChild(grid);
};

/**
 * Updates the displayed month on the calendar (previous or next month) and triggers a full calendar re-render.
 * (Manifest: handleDateNavigation)
 * @param {string} direction - 'prev' or 'next'.
 */
window.handleDateNavigation = function(direction) {
    const newDate = new Date(currentViewDate.getFullYear(), currentViewDate.getMonth() + (direction === 'next' ? 1 : -1), 1);
    currentViewDate = newDate;
    window.renderCalendar(tasks);
};

// =========================================================================
// 4. Theme Management Function
// =========================================================================

/**
 * Switches the application theme between Dark Mode and Light Mode, updating the body class and localStorage.
 * (Manifest: toggleTheme)
 * @param {boolean} isDarkMode - True for dark mode, false for light mode.
 */
window.toggleTheme = function(isDarkMode) {
    if (isDarkMode) {
        body.classList.add('dark-mode');
        window.StorageApp.saveTheme('dark');
    } else {
        body.classList.remove('dark-mode');
        window.StorageApp.saveTheme('light');
    }
};


// =========================================================================
// 5. Initialization
// =========================================================================

/**
 * Initializes the application state, loads data from localStorage, sets the initial theme, and renders the initial UI components (tasks and calendar).
 * (Manifest: initializeApp)
 */
window.initializeApp = function() {
    // 1. Load Data
    window.loadTasks();

    // 2. Load Theme
    const savedTheme = window.StorageApp.loadTheme();
    const isDarkMode = savedTheme === 'dark';
    
    // 3. Set Initial Theme
    window.toggleTheme(isDarkMode);

    // 4. Set up Event Listeners
    setupEventListeners();
};

/**
 * Sets up all necessary event listeners for the application.
 */
function setupEventListeners() {
    // Task Addition Handler
    taskForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const title = taskTitleInput.value.trim();
        const date = taskDateInput.value;
        
        // Use the addTask function to handle saving and re-rendering
        window.addTask(title, date);
    });

    // Calendar Navigation Handlers
    document.getElementById('prev-month').addEventListener('click', () => {
        window.handleDateNavigation('prev');
    });

    document.getElementById('next-month').addEventListener('click', () => {
        window.handleDateNavigation('next');
    });

    // Theme Toggle Handler
    themeToggleBtn.addEventListener('click', () => {
        const isCurrentlyDark = body.classList.contains('dark-mode');
        window.toggleTheme(!isCurrentlyDark);
    });
}

// Execute initialization when the script loads
window.initializeApp();