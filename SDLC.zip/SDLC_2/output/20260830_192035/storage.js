window.StorageApp = {
    /**
     * Retrieves the array of task objects from localStorage and parses the JSON string.
     * Returns an empty array if no data is found.
     * @returns {Array<Object>} The array of tasks.
     */
    loadTasks: function() {
        const key = "taskAgendaData";
        const data = localStorage.getItem(key);

        if (data === null) {
            return [];
        }

        try {
            return JSON.parse(data);
        } catch (e) {
            console.error("Error parsing task data from localStorage:", e);
            return [];
        }
    },

    /**
     * Serializes the provided array of task objects and stores it in localStorage.
     * @param {Array<Object>} tasks - The array of task objects to save.
     * @returns {void}
     */
    saveTasks: function(tasks) {
        const key = "taskAgendaData";
        try {
            const data = JSON.stringify(tasks);
            localStorage.setItem(key, data);
        } catch (e) {
            console.error("Error saving task data to localStorage:", e);
        }
    },

    /**
     * Retrieves the saved theme preference ('dark' or 'light') from localStorage.
     * Defaults to 'dark' if no preference is found.
     * @returns {string} The saved theme preference.
     */
    loadTheme: function() {
        const key = "themePreference";
        const theme = localStorage.getItem(key);

        if (theme === null) {
            // Default theme if no preference is found (Test 6)
            return 'dark';
        }

        return theme;
    },

    /**
     * Stores the current theme preference ('dark' or 'light') into localStorage.
     * @param {string} theme - The theme preference to save.
     * @returns {void}
     */
    saveTheme: function(theme) {
        const key = "themePreference";
        try {
            localStorage.setItem(key, theme);
        } catch (e) {
            console.error("Error saving theme data to localStorage:", e);
        }
    }
};