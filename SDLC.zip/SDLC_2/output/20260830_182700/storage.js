/**
 * storage.js
 * Manages all client-side data persistence using window.localStorage.
 * Implements the Model layer for Task Agenda Dashboard data.
 */

// Centralized storage object attached to the global window for cross-file communication.
window.StorageApp = {

    /**
     * Helper function to safely retrieve data from localStorage.
     * @param {string} key - The key to retrieve.
     * @returns {any} The parsed data or null if not found/corrupted.
     */
    _safeGet(key) {
        try {
            const data = window.localStorage.getItem(key);
            if (data === null) {
                return null;
            }
            return JSON.parse(data);
        } catch (error) {
            console.error(`[StorageApp] Error parsing data for key "${key}":`, error);
            return null; // Return null on parsing failure (Safe Parsing rule)
        }
    },

    /**
     * Helper function to safely save data to localStorage.
     * @param {string} key - The key to save.
     * @param {any} data - The data to be saved (will be JSON stringified).
     */
    _safeSet(key, data) {
        try {
            window.localStorage.setItem(key, JSON.stringify(data));
        } catch (error) {
            console.error(`[StorageApp] Error saving data for key "${key}":`, error);
        }
    },

    /**
     * Retrieves all saved task data and the current theme state from localStorage.
     * This is called on application initialization (Data Hydration rule).
     * @returns {object} Unified object containing tasks and theme.
     */
    loadAllData() {
        const tasks = this.getTasksFromStorage();
        const theme = this.loadTheme();
        return { tasks, theme };
    },

    /**
     * Retrieves the raw JSON string of tasks from localStorage and parses it into a JavaScript array.
     * Used for initial data retrieval (FR 2.2.2).
     * @returns {Array<object>} The array of tasks, or an empty array if none exist.
     */
    getTasksFromStorage() {
        const tasksJson = this._safeGet('tasks');
        if (tasksJson) {
            return tasksJson;
        }
        return [];
    },

    /**
     * Saves the provided array of task objects to localStorage.
     * Ensures data synchronization (FR 2.2.3) and implements the Ledger System.
     * @param {Array<object>} tasksArray - The array of task objects to save.
     */
    saveTasks(tasksArray) {
        this._safeSet('tasks', tasksArray);
    },

    /**
     * Saves the current theme state ('dark' or 'light') to localStorage.
     * Used for theme persistence (FR 2.4.1).
     * @param {string} theme - The theme state ('dark' or 'light').
     */
    saveTheme(theme) {
        this._safeSet('theme', theme);
    },

    /**
     * Retrieves the saved theme preference from localStorage and applies the corresponding CSS class to the document body.
     * Used for theme persistence (FR 2.4.1).
     */
    loadTheme() {
        const savedTheme = this._safeGet('theme');
        if (savedTheme) {
            document.body.className = savedTheme;
        } else {
            // Default to light mode if no theme is saved (Test 1)
            document.body.className = 'light-mode';
        }
    },

    /**
     * Adds a new task object to the existing task array, saves it, and triggers a UI refresh.
     * Implements the Ledger System for state mutation.
     * @param {object} task - The new task object to add.
     */
    addTask(task) {
        const tasks = this.getTasksFromStorage();
        if (tasks) {
            tasks.push(task);
            this.saveTasks(tasks); // Save immediately after mutation (Ledger System)
        }
    },

    /**
     * Finds a task by ID, updates its details in the array, saves the array, and triggers a UI refresh.
     * Implements the Ledger System for state mutation.
     * @param {string} taskId - The ID of the task to update.
     * @param {object} updatedTask - The new details for the task.
     */
    updateTask(taskId, updatedTask) {
        let tasks = this.getTasksFromStorage();
        if (tasks) {
            const index = tasks.findIndex(t => t.id === taskId);
            if (index !== -1) {
                tasks[index] = { ...tasks[index], ...updatedTask };
                this.saveTasks(tasks); // Save immediately after mutation (Ledger System)
            }
        }
    },

    /**
     * Removes a task by its ID from the array, saves the array, and triggers a UI refresh.
     * Implements the Ledger System for state mutation.
     * @param {string} taskId - The ID of the task to delete.
     */
    deleteTask(taskId) {
        let tasks = this.getTasksFromStorage();
        if (tasks) {
            tasks = tasks.filter(t => t.id !== taskId);
            this.saveTasks(tasks); // Save immediately after mutation (Ledger System)
        }
    }
};