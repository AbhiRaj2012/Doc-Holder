/**
 * app.js
 * Core client-side logic for the Task Agenda Dashboard.
 * Manages data persistence, calendar rendering, task CRUD operations, and theme switching.
 */

// Access the centralized storage object exposed by storage.js
const StorageApp = window.StorageApp;

/**
 * Retrieves the task array from localStorage.
 * Signature: loadTasksFromStorage(): Array<Object>
 * @returns {Array<Object>} The task data.
 */
function loadTasksFromStorage() {
    return StorageApp.getTasksFromStorage();
}

/**
 * Saves the task array to localStorage.
 * Signature: saveTasksToStorage(tasks: Array<Object>): void
 * @param {Array<Object>} tasks - The array of task objects.
 */
function saveTasksToStorage(tasks) {
    StorageApp.saveTasks(tasks);
}

/**
 * Adds a new task object to the task array, saves it, and triggers a UI re-render.
 * Signature: addTask(taskData: {title: string, description: string, date: string}): void
 * @param {object} taskData - The data for the new task.
 */
function addTask(taskData) {
    const newTask = {
        id: Date.now().toString(), // Simple unique ID generation
        title: taskData.title,
        description: taskData.description,
        date: taskData.date
    };

    const tasks = StorageApp.getTasksFromStorage();
    if (tasks) {
        tasks.push(newTask);
        StorageApp.saveTasks(tasks); // Ledger System: Save immediately
        renderTaskList(tasks); // Trigger UI re-render
    }
}

/**
 * Finds and removes a task by its ID from the task array, saves the array, and triggers a UI re-render.
 * Signature: deleteTask(taskId: string): void
 * @param {string} taskId - The ID of the task to delete.
 */
function deleteTask(taskId) {
    let tasks = StorageApp.getTasksFromStorage();
    if (tasks) {
        tasks = tasks.filter(t => t.id !== taskId);
        StorageApp.saveTasks(tasks); // Ledger System: Save immediately
        renderTaskList(tasks); // Trigger UI re-render
    }
}

/**
 * Updates an existing task's details, saves the array, and triggers a UI re-render.
 * Signature: updateTask(taskId: string, updatedData: Object): void
 * @param {string} taskId - The ID of the task to update.
 * @param {Object} updatedData - The new details for the task.
 */
function updateTask(taskId, updatedData) {
    let tasks = StorageApp.getTasksFromStorage();
    if (tasks) {
        const index = tasks.findIndex(t => t.id === taskId);
        if (index !== -1) {
            tasks[index] = { ...tasks[index], ...updatedData };
            StorageApp.saveTasks(tasks); // Ledger System: Save immediately
            renderTaskList(tasks); // Trigger UI re-render
        }
    }
}

/**
 * Dynamically generates and injects the task list elements into the designated DOM container.
 * Signature: renderTaskList(tasks: Array<Object>): void
 * @param {Array<Object>} tasks - The array of tasks to display.
 */
function renderTaskList(tasks) {
    const container = document.getElementById('task-list-container');
    container.innerHTML = ''; // Clear existing content

    tasks.forEach(task => {
        const listItem = document.createElement('li');
        listItem.className = 'task-item';
        listItem.innerHTML = `
            <strong>${task.title}</strong>
            <p>${task.description}</p>
            <small>Date: ${task.date}</small>
            <button onclick="window.deleteTask('${task.id}')">Delete</button>
            <button onclick="window.updateTask('${task.id}', prompt('Update Task Details for ${task.title}:', '${task.description}'))">Edit</button>
        `;
        container.appendChild(listItem);
    });
}

/**
 * Generates the monthly calendar grid based on the task dates, highlighting dates that contain tasks.
 * Signature: renderCalendar(tasks: Array<Object>): void
 * @param {Array<Object>} tasks - The array of tasks.
 */
function renderCalendar(tasks) {
    const calendarGrid = document.getElementById('calendar-grid');
    calendarGrid.innerHTML = ''; // Clear existing content

    // Determine the range of dates to display (simple monthly view)
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth();

    // Create a map of dates to tasks for quick lookup
    const tasksByDate = tasks.reduce((acc, task) => {
        acc[task.date] = (acc[task.date] || 0) + 1;
        return acc;
    }, {});

    // Generate calendar days (assuming a standard 7-day grid)
    const firstDayOfMonth = new Date(year, month, 1);
    const startingDayOfWeek = firstDayOfMonth.getDay(); // 0 (Sun) to 6 (Sat)

    // Add leading empty cells for alignment
    for (let i = 0; i < startingDayOfWeek; i++) {
        const emptyCell = document.createElement('div');
        emptyCell.className = 'calendar-day empty';
        calendarGrid.appendChild(emptyCell);
    }

    // Add actual days
    for (let day = 1; day <= 31; day++) { // Iterate through potential days
        const date = new Date(year, month, day);
        const dateString = date.toISOString().split('T')[0]; // YYYY-MM-DD format

        const dayCell = document.createElement('div');
        dayCell.className = 'calendar-day';
        dayCell.textContent = day;
        dayCell.dataset.date = dateString;

        // Check if this date has tasks
        if (tasksByDate[dateString] > 0) {
            dayCell.classList.add('has-task');
        }

        calendarGrid.appendChild(dayCell);
    }
}

/**
 * Handles a click event on a date in the calendar. Filters the task list to display only tasks associated with the selected date and updates the main view.
 * Signature: handleDateClick(date: string): void
 * @param {string} date - The date clicked (YYYY-MM-DD format).
 */
function handleDateClick(date) {
    const tasks = StorageApp.getTasksFromStorage();
    if (!tasks) return;

    // Filter tasks for the selected date
    const filteredTasks = tasks.filter(task => task.date === date);

    // Update the task list view
    renderTaskList(filteredTasks);
}

/**
 * Toggles the application theme between 'light' and 'dark' mode.
 * Signature: toggleTheme(): void
 */
function toggleTheme() {
    const body = document.body;
    const isDarkMode = body.classList.toggle('dark-mode');

    // Save the preference to localStorage
    StorageApp.saveTheme(isDarkMode ? 'dark-mode' : 'light-mode');
}

/**
 * The main entry point function. Called on page load.
 * Signature: initializeApplication(): void
 */
function initializeApplication() {
    // 1. Data Hydration: Load data and theme from storage
    const { tasks, theme } = StorageApp.loadAllData();

    // 2. Apply Theme
    document.body.className = theme;

    // 3. Render Views
    renderTaskList(tasks);
    renderCalendar(tasks);

    // 4. Attach Event Listeners
    document.getElementById('theme-toggle').addEventListener('click', toggleTheme);

    // 5. Initialize Application Complete
    console.log("Task Agenda Dashboard initialized successfully.");
}

// Execute the main initialization function when the script loads
document.addEventListener('DOMContentLoaded', initializeApplication);