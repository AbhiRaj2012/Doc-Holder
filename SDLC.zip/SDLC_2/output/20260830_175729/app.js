// app.js

// =============================================================================
// 1. STATE MANAGEMENT & INITIALIZATION
// =============================================================================

/**
 * Central state object for the calculator.
 * Implements the state management required by the manifest.
 */
const CalculatorState = {
    displayValue: '0',
    currentOperand: '0',
    previousOperand: null,
    operation: null,
    error: null
};

/**
 * Updates the DOM display element with the current state.
 * @param {string} value - The value to display.
 */
window.updateDisplay = function(value) {
    const displayElement = document.getElementById('display');
    displayElement.textContent = value;
};

/**
 * Resets the internal state of the calculator.
 * Implements clearCalculatorState().
 */
window.clearCalculatorState = function() {
    CalculatorState.displayValue = '0';
    CalculatorState.currentOperand = '0';
    CalculatorState.previousOperand = null;
    CalculatorState.operation = null;
    CalculatorState.error = null;
    window.updateDisplay(CalculatorState.displayValue);
};

/**
 * Parses the input string, validates it, and updates the display.
 * Implements handleInput(value).
 * @param {string} value - The input string from the button press.
 */
window.handleInput = function(value) {
    if (CalculatorState.error) {
        clearCalculatorState();
    }

    // Handle decimal point input
    if (value === '.') {
        if (CalculatorState.currentOperand.includes('.')) {
            return; // Prevent multiple decimals
        }
    }

    // Handle number input
    if (isNaN(parseFloat(value)) && value !== '.') {
        // Test 6: Invalid Input Error
        CalculatorState.error = 'Error: Invalid Input';
        window.updateDisplay(CalculatorState.error);
        return;
    }

    // Update current operand
    if (CalculatorState.currentOperand === '0' && value !== '.') {
        CalculatorState.currentOperand = value;
    } else {
        CalculatorState.currentOperand = CalculatorState.currentOperand + value;
    }

    // Update display
    window.updateDisplay(CalculatorState.currentOperand);
};

/**
 * Executes the specified arithmetic operation.
 * Implements performCalculation(operand1, operator, operand2).
 * @param {number} operand1 - The first number.
 * @param {string} operator - The operation (+, -, *, /).
 * @param {number} operand2 - The second number.
 * @returns {number|string} The result or an error message.
 */
window.performCalculation = function(operand1, operator, operand2) {
    const num1 = parseFloat(operand1);
    const num2 = parseFloat(operand2);

    if (isNaN(num1) || isNaN(num2)) {
        window.updateDisplay('Error: Invalid Numbers');
        CalculatorState.error = 'Error: Invalid Numbers';
        return 'Error';
    }

    switch (operator) {
        case '+':
            return num1 + num2;
        case '-':
            return num1 - num2;
        case '*':
            return num1 * num2;
        case '/':
            // Test 5: Division by Zero Error
            if (num2 === 0) {
                window.updateDisplay('Error: Division by Zero');
                CalculatorState.error = 'Error: Division by Zero';
                return 'Error';
            }
            return num1 / num2;
        default:
            return 'Error: Invalid Operator';
    }
};

/**
 * Updates the display with the final calculated result.
 * Implements updateDisplay(result).
 * @param {number|string} result - The result or error message.
 */
window.updateDisplay = function(result) {
    if (typeof result === 'string' && result.startsWith('Error')) {
        // Display error messages directly
        CalculatorState.error = result;
        CalculatorState.displayValue = result;
    } else {
        // Display numerical results
        CalculatorState.displayValue = String(result);
    }
    window.updateDisplay(CalculatorState.displayValue);
};


// =============================================================================
// 2. DOM MANIPULATION & EVENT LISTENERS
// =============================================================================

/**
 * Sets up all necessary event listeners for the calculator buttons.
 */
window.initCalculator = function() {
    const numberButtons = document.querySelectorAll('.number');
    const operatorButtons = document.querySelectorAll('.operator');
    const clearButton = document.getElementById('clear_button');

    // Attach listeners to number buttons
    numberButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Use handleInput for number entry
            window.handleInput(button.textContent);
        });
    });

    // Attach listeners to operator buttons
    operatorButtons.forEach(button => {
        button.addEventListener('click', () => {
            const operand1 = CalculatorState.currentOperand;
            const operand2 = CalculatorState.currentOperand;
            const operator = button.textContent;

            // If an operation is pending, calculate the previous result first
            if (CalculatorState.operation && CalculatorState.previousOperand !== null) {
                const result = window.performCalculation(
                    CalculatorState.previousOperand,
                    CalculatorState.operation,
                    operand2
                );
                window.updateDisplay(result);
                CalculatorState.previousOperand = String(result);
            } else {
                // Store the current operand as the first operand
                CalculatorState.previousOperand = CalculatorState.currentOperand;
            }

            // Set the new operation and reset the current operand for the next input
            CalculatorState.operation = operator;
            CalculatorState.currentOperand = operand2;
            CalculatorState.error = null; // Clear error on new operation
        });
    });

    // Attach listener to the clear button
    clearButton.addEventListener('click', () => {
        window.clearCalculatorState();
    });
};

// Initialize the calculator when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Ensure the application logic is ready to run
    if (window.initCalculator) {
        window.initCalculator();
    }
});