```javascript
// router.js

// Assume dependencies are loaded globally or imported:
// const localStorageManager = require('localStorage_manager.js');
// const invoiceRenderer = require('invoice_renderer.js');
// const uiHandler = require('ui_handler.js');

/**
 * Router module responsible for managing the SPA state and navigation.
 */
const router = (() => {
    // --- Internal State and Dependencies ---
    const views = {
        list: document.getElementById('invoice-list-section'),
        create: document.getElementById('invoice-creation-section'),
        view: document.getElementById('invoice-preview-section')
    };

    // --- Core Functions ---

    /**
     * Updates the browser's URL hash to reflect the current application state.
     * @param {string} path - The path to set in the URL hash.
     */
    function updateURLHash(path) {
        window.location.hash = path;
    }

    /**
     * Dynamically updates the main content area of the DOM by hiding all existing views
     * and displaying the requested view.
     * @param {string} viewName - The name of the view to display ('list', 'create', 'view').
     * @param {Object} data - Optional data to pass to the view.
     */
    function renderView(viewName, data = null) {
        // 1. Hide all views
        Object.values(views).forEach(view => {
            view.classList.add('hidden');
            view.classList.remove('active');
        });

        // 2. Show the requested view
        const targetView = views[viewName];
        if (targetView) {
            targetView.classList.remove('hidden');
            targetView.classList.add('active');
        } else {
            console.error(`Router Error: View '${viewName}' not found.`);
            // Fallback to list view if an invalid route is attempted
            renderView('list');
        }

        // 3. Handle specific view loading based on the requested path
        if (viewName === 'list') {
            loadInvoices();
        } else if (viewName === 'view') {
            // Data must be passed via the URL hash or query parameters in a real app.
            // For this manifest, we assume the data is loaded by the navigation handler.
            // We rely on handleNavigation to trigger the specific load functions.
        }
    }

    /**
     * Intercepts navigation requests