/**
 * storage.js
 * Manages all client-side data persistence using the browser's localStorage API
 * for invoices and client details, adhering to the Offline-First Local Data Architecture.
 */

const STORAGE_KEYS = {
    INVOICES: 'invoices',
    CLIENTS: 'clients'
};

/**
 * Helper function to safely retrieve data from localStorage.
 * Implements the Safe Parsing rule.
 * @param {string} key - The localStorage key.
 * @returns {Array|Object|null} The parsed data or null if not found or corrupted.
 */
function safeLoad(key) {
    try {
        const data = localStorage.getItem(key);
        if (data === null) {
            return null;
        }
        return JSON.parse(data);
    } catch (error) {
        console.error(`Error parsing data from localStorage for key "${key}":`, error);
        // Handle corrupted data gracefully (NFR 3.2.3)
        return null;
    }
}

/**
 * Generic function to store any JavaScript object into localStorage.
 * Implements the Persistent Storage rule.
 * @param {string} key - The key to store the data under.
 * @param {Object} data - The JavaScript object to store.
 */
function saveData(key, data) {
    try {
        const jsonString = JSON.stringify(data);
        localStorage.setItem(key, jsonString);
    } catch (error) {
        console.error(`Error saving data to localStorage for key "${key}":`, error);
    }
}

/**
 * Retrieves the entire data structure (invoices and clients) from localStorage.
 * Implements the Data Hydration rule.
 * @returns {Object} The complete data structure { invoices: [], clients: [] }.
 */
function loadAllData() {
    const invoices = safeLoad(STORAGE_KEYS.INVOICES) || [];
    const clients = safeLoad(STORAGE_KEYS.CLIENTS) || [];

    return {
        invoices: invoices,
        clients: clients
    };
}

/**
 * Retrieves the array of invoice objects stored under the 'invoices' key.
 * @returns {Array} The list of invoices.
 */
function loadInvoices() {
    return safeLoad(STORAGE_KEYS.INVOICES) || [];
}

/**
 * Stores the current array of invoice objects back into localStorage.
 * Implements the Persistent Storage rule.
 * @param {Array} invoices - The array of invoice objects to save.
 */
function saveInvoices(invoices) {
    saveData(STORAGE_KEYS.INVOICES, invoices);
}

/**
 * Retrieves the array of client objects stored under the 'clients' key.
 * @returns {Array} The list of clients.
 */
function loadClients() {
    return safeLoad(STORAGE_KEYS.CLIENTS) || [];
}

/**
 * Stores the current array of client objects back into localStorage.
 * Implements the Persistent Storage rule.
 * @param {Array} clients - The array of client objects to save.
 */
function saveClients(clients) {
    saveData(STORAGE_KEYS.CLIENTS, clients);
}

/**
 * Handles the creation of a new invoice object, assigns a unique ID, and adds it to the invoices array before saving.
 * @param {Object} invoiceData - The data for the new invoice (client details, items, totals).
 * @returns {Object} The newly created invoice object.
 */
function addInvoice(invoiceData) {
    const invoices = loadInvoices();
    
    // Assign a unique ID (simple increment for demonstration)
    const newId = invoices.length > 0 ? Math.max(...invoices.map(i => i.id)) + 1 : 1;
    
    const newInvoice = {
        id: newId,
        ...invoiceData,
        date: new Date().toISOString() // Add a timestamp
    };

    invoices.push(newInvoice);
    saveInvoices(invoices);
    
    return newInvoice;
}

/**
 * Locates an existing invoice by ID and updates its properties before saving.
 * Implements the Ledger System rule (mutation before save).
 * @param {number} id - The ID of the invoice to update.
 * @param {Object} updatedData - The new properties to apply to the invoice.
 * @returns {boolean} True if the update was successful, false otherwise.
 */
function updateInvoice(id, updatedData) {
    let invoices = loadInvoices();
    const index = invoices.findIndex(inv => inv.id === id);

    if (index === -1) {
        console.warn(`Invoice with ID ${id} not found for update.`);
        return false;
    }

    // Apply updates to the existing object (Ledger mutation)
    invoices[index] = { ...invoices[index], ...updatedData };

    saveInvoices(invoices);
    return true;
}

/**
 * Removes a specific invoice record from the invoices array and updates localStorage.
 * Implements the Ledger System rule.
 * @param {number} id - The ID of the invoice to delete.
 * @returns {boolean} True if the deletion was successful, false otherwise.
 */
function deleteInvoice(id) {
    let invoices = loadInvoices();
    const initialLength = invoices.length;
    
    // Filter out the invoice to be deleted
    invoices = invoices.filter(inv => inv.id !== id);

    if (invoices.length === initialLength) {
        console.warn(`Invoice with ID ${id} not found for deletion.`);
        return false;
    }

    saveInvoices(invoices);
    return true;
}

/**
 * Returns the complete list of all stored invoice records.
 * @returns {Array} The list of invoices.
 */
function getAllInvoices() {
    return loadInvoices();
}

/**
 * Returns the complete list of all stored client records.
 * @returns {Array} The list of clients.
 */
function getAllClients() {
    return loadClients();
}

// --- Initialization ---

/**
 * Initializes the application state by loading all necessary data from localStorage.
 * This function is called upon application initialization (Data Hydration rule).
 */
function initializeApplicationState() {
    console.log("Initializing application state: Loading data from localStorage...");
    
    // Load all data structures
    const allData = loadAllData();
    
    // In a real application, this data would be passed to a rendering function.
    // For this module, we ensure the data is loaded and ready.
    console.log("Data loaded successfully. Invoices count:", allData.invoices.length, "Clients count:", allData.clients.length);
    
    // Note: The actual DOM manipulation (rendering) is handled by main.js, 
    // which will call these functions after initialization.
}

// Expose the public API
window.storage = {
    loadAllData,
    saveData,
    loadInvoices,
    saveInvoices,
    loadClients,
    saveClients,
    addInvoice,
    updateInvoice,
    deleteInvoice,
    getAllInvoices,
    getAllClients,
    initializeApplicationState
};

// Trigger initialization when the script loads
initializeApplicationState();