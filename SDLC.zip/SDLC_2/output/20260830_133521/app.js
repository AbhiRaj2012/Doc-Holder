```javascript
import {
    loadTasksFromStorage,
    addTaskToStorage,
    deleteTaskFromStorage,
    initializeStorage
} from './storage.js';
import {
    renderCalendar,
    renderTaskList,
    handleAddTask,
    handleDeleteTask,
    toggleTheme
} from './router.js';

/**
 * Global application state object.
 * This object holds the current task data and is the single source of truth.
 * @type {Array<Object>}
 */
let appState = [];

/**
 * Helper function to format dates for display.
 * @param {Date} date - The date object.
 * @returns {string} Formatted date string (e.g., "MM/DD/YYYY").
 */
function formatDate(date) {
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const year = date.getFullYear();
    return `${month}/${day}/${year}`;
}

/**
 * Loads the task data from storage and updates the application state.
 * @returns {void}
 */
async function loadTasks() {
    // Rule: Data Hydration - Load tasks immediately on application load.
    appState = await loadTasksFromStorage();
    console.log("Tasks loaded successfully. Total tasks:", appState.length);
}

/**
 * Initializes the application state, loads data, sets the initial theme, and sets up all necessary event listeners and view rendering functions.
 * @returns {void}
 */
async function initializeApp() {
    await loadTasks();
    
    // Set initial theme based on storage or default
    const savedTheme = localStorage.getItem('theme') || 'light';
    toggleTheme(savedTheme);

    // Initial rendering
    const currentMonth = new Date().getMonth();
    await renderCalendar(currentMonth);
    
    // Render the task list, sorting by due date
    const tasksForList = appState.sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate));
    await renderTaskList(tasksForList);

    // Setup event listeners
    setupEventListeners();
}

// Note: renderCalendar, renderTaskList, handleAddTask, handleDeleteTask, and toggleTheme are assumed to be defined in router.js and are called by initializeApp and setupEventListeners.