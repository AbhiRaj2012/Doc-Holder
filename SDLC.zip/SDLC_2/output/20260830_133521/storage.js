/**
 * storage.js
 * Manages all client-side data persistence using the browser's localStorage API.
 * Implements the Offline-First Local Data Architecture pattern.
 */

const STORAGE_KEY = 'taskAgendaData';

/**
 * Retrieves the consistent key used for storing the task data in localStorage.
 * @returns {string} The storage key.
 */
function getStorageKey() {
    return STORAGE_KEY;
}

/**
 * Retrieves the JSON string from localStorage, parses it, and returns the array of task objects.
 * Handles the case where no data exists (returns an empty array).
 * @returns {Array<Object>} The array of task objects.
 */
function loadTasksFromStorage() {
    try {
        const data = localStorage.getItem(STORAGE_KEY);
        if (data === null) {
            // Test 1: Initial Load Test - Verify that calling loadTasksFromStorage returns an empty array when localStorage is empty.
            return [];
        }
        // Test 4: Safe Parsing - Wrap JSON.parse() in a try/catch block.
        const tasks = JSON.parse(data);
        return tasks;
    } catch (error) {
        console.error("Error loading tasks from storage:", error);
        // Handle corrupted data gracefully by returning an empty array
        return [];
    }
}

/**
 * Takes the current array of task objects, stringifies it to JSON, and stores it in localStorage.
 * Ensures data integrity during saving.
 * @param {Array<Object>} tasks - The array of task objects to save.
 * @returns {void}
 */
function saveTasksToStorage(tasks) {
    try {
        // Rule: Persistent Storage - Save the ledger immediately after every array mutation.
        const dataString = JSON.stringify(tasks);
        localStorage.setItem(STORAGE_KEY, dataString);
    } catch (error) {
        console.error("Error saving tasks to storage:", error);
        // Handle potential storage quota errors
    }
}

/**
 * Loads existing tasks, adds a new task object, and then saves the updated array back to localStorage. (Handles Create operation).
 * @param {Object} newTask - The new task object to add. Must contain an 'id'.
 * @returns {Array<Object>} The updated array of tasks.
 */
function addTaskToStorage(newTask) {
    // 1. Load existing tasks
    let tasks = loadTasksFromStorage();

    // 2. Add the new task
    tasks.push(newTask);

    // 3. Save the updated array
    saveTasksToStorage(tasks);

    return tasks;
}

/**
 * Loads existing tasks, finds the task by ID, updates its properties, and saves the entire updated array back to localStorage. (Handles Update operation).
 * @param {number} taskId - The ID of the task to update.
 * @param {Object} updatedTaskData - The new properties for the task.
 * @returns {Array<Object>} The updated array of tasks.
 */
function updateTaskInStorage(taskId, updatedTaskData) {
    // 1. Load existing tasks
    let tasks = loadTasksFromStorage();

    // 2. Find and update the task
    const index = tasks.findIndex(task => task.id === taskId);

    if (index === -1) {
        console.warn(`Task with ID ${taskId} not found for update.`);
        return tasks;
    }

    // Merge existing task with new data
    tasks[index] = { ...tasks[index], ...updatedTaskData };

    // 3. Save the entire updated array
    saveTasksToStorage(tasks);

    return tasks;
}

/**
 * Loads existing tasks, filters the array to exclude the task with the specified ID, and saves the remaining array back to localStorage. (Handles Delete operation).
 * @param {number} taskId - The ID of the task to delete.
 * @returns {Array<Object>} The remaining array of tasks.
 */
function deleteTaskFromStorage(taskId) {
    // 1. Load existing tasks
    let tasks = loadTasksFromStorage();

    // 2. Filter the array
    const updatedTasks = tasks.filter(task => task.id !== taskId);

    // 3. Save the remaining array
    saveTasksToStorage(updatedTasks);

    return updatedTasks;
}

/**
 * Called on application load. Attempts to load tasks immediately and sets up the initial data state.
 * This function serves as the primary data hydration mechanism.
 * @returns {Array<Object>} The loaded task array.
 */
function initializeStorage() {
    // Rule: Data Hydration - Load tasks immediately on application load.
    const initialTasks = loadTasksFromStorage();
    console.log("Storage initialized. Loaded tasks:", initialTasks.length);
    return initialTasks;
}

// Export the functions for use by other modules (app.js, TaskModel.js)
export {
    getStorageKey,
    loadTasksFromStorage,
    saveTasksToStorage,
    addTaskToStorage,
    updateTaskInStorage,
    deleteTaskFromStorage,
    initializeStorage
};