/**
 * router.js
 * Manages the navigation and visibility of the main dashboard views (Calendar and Task List)
 * and handles theme switching for the split-view layout.
 *
 * Dependencies: app.js, storage.js
 */

// --- Core View Switching Logic ---

/**
 * Core function to display a specific view (e.g., Calendar or Task List) and hide the others.
 * @param {string} viewName - The name of the view to display ('calendar' or 'tasklist').
 */
function showView(viewName) {
    const calendarElement = document.getElementById('calendar-view-container');
    const taskListElement = document.getElementById('task-agenda-view-container');

    if (viewName === 'calendar') {
        calendarElement.style.display = 'block';
        taskListElement.style.display = 'none';
    } else if (viewName === 'tasklist') {
        calendarElement.style.display = 'none';
        taskListElement.style.display = 'block';
    } else {
        console.error(`Invalid view name provided: ${viewName}`);
    }
}

/**
 * Handles the primary view switching logic when a navigation element is clicked.
 * This function is intended to be called by event listeners attached to navigation buttons.
 */
function switchView() {
    // In a real application, this would determine the current state or cycle through views.
    // For this manifest, we assume a simple toggle or selection based on context.
    // Since the manifest implies switching between Calendar and Task List, we'll toggle them.
    const currentView = document.getElementById('calendar-view-container').style.display === 'none' ? 'calendar' : 'tasklist';
    const nextView = currentView === 'calendar' ? 'tasklist' : 'calendar';

    showView(nextView);
}

/**
 * Receives the theme preference (Light/Dark) and applies the corresponding CSS class to the root HTML element.
 * @param {string} theme - The desired theme ('light' or 'dark').
 */
function applyTheme(theme) {
    const root = document.documentElement; // Targets the <html> element
    if (theme === 'dark') {
        root.classList.add('dark');
        document.getElementById('theme-mode-indicator').textContent = 'Dark Mode';
    } else {
        root.classList.remove('dark');
        document.getElementById('theme-mode-indicator').textContent = 'Light Mode';
    }
}

/**
 * Initializes the router by setting up event listeners for view switching and applying the initial theme.
 * @param {HTMLElement} calendarViewElement - The DOM element for the Calendar view.
 * @param {HTMLElement} taskListElement - The DOM element for the Task List view.
 * @param {HTMLElement} themeToggleElement - The DOM element for the theme toggle button.
 */
function initRouter(calendarViewElement, taskListElement, themeToggleElement) {
    console.log("Router initialized. Setting up event listeners.");

    // 1. Setup View Switching Logic
    // Attach the switchView logic to the navigation elements (assuming they exist in the HTML)
    // We will attach it to the theme toggle and assume the main view switch is handled by a separate navigation structure.
    // For demonstration, we'll attach it to the theme toggle for simplicity, but in a full app, this would target tabs.
    themeToggleElement.addEventListener('click', switchView);


    // 2. Setup Theme Application Logic
    themeToggleElement.addEventListener('click', () => {
        const currentTheme = document.documentElement.classList.contains('dark') ? 'dark' : 'light';
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        applyTheme(newTheme);
    });

    // 3. Apply Initial Theme (Load preference from storage if available, otherwise default to light)
    const storedTheme = localStorage.getItem('theme');
    const initialTheme = storedTheme || 'light';
    applyTheme(initialTheme);

    // 4. Initial View State (Test 1: Initial Load Check)
    // Set the initial view state (e.g., default to Calendar)
    showView('calendar');
}

// --- Module Export ---
export {
    initRouter,
    showView,
    switchView,
    applyTheme
};