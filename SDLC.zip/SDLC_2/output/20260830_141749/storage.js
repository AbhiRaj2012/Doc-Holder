/**
 * storage.js
 * Handles all client-side data persistence using the browser's Local Storage API.
 * Responsible for serializing and deserializing the entire application state (tasks, theme, and metadata).
 */

const STORAGE_KEY = 'app_state_ledger';

// --- Default Initial State ---
const DEFAULT_STATE = {
    tasks: [],
    theme: 'light',
    lastUpdated: new Date().toISOString()
};

/**
 * Loads the entire application state object from Local Storage.
 * If no data exists, it returns a default initial state.
 * @returns {Object} The application state.
 */
function loadState() {
    try {
        const data = window.localStorage.getItem(STORAGE_KEY);
        if (data) {
            const state = JSON.parse(data);
            // Ensure loaded state has the expected structure, falling back to default if corrupted
            if (state && Array.isArray(state.tasks) && typeof state.theme === 'string') {
                return state;
            }
            console.warn("Corrupted data found in Local Storage. Returning default state.");
            return DEFAULT_STATE;
        }
        // If no data exists, return the default state
        return DEFAULT_STATE;
    } catch (error) {
        console.error("Error loading state from Local Storage:", error);
        // If parsing fails, return default state to prevent application crash
        return DEFAULT_STATE;
    }
}

/**
 * Serializes the current application state object and saves it to Local Storage.
 * @param {Object} stateObject - The application state to save.
 * @returns {void}
 */
function saveState(stateObject) {
    try {
        const serializedState = JSON.stringify(stateObject);
        window.localStorage.setItem(STORAGE_KEY, serializedState);
    } catch (error) {
        console.error("Error saving state to Local Storage:", error);
    }
}

/**
 * Specific function to save only the task array to Local Storage.
 * This function is used for granular updates, ensuring the task list is persisted.
 * @param {Array} tasksArray - The array of tasks to save.
 * @returns {void}
 */
function saveTaskData(tasksArray) {
    // In a real application, this would load the full state, update the tasks, and then save the full state.
    // For this specific function, we assume the caller handles the full state update and calls saveState afterward.
    // However, to adhere strictly to the manifest, we save the tasks array directly if needed.
    // For robust persistence (Ledger Rule), we will rely on saveState being called by the main application logic.
    // We will implement this function to save the tasks array as a standalone item if necessary,
    // but the primary persistence mechanism remains saveState.
    
    // For simplicity and adherence to the Ledger rule, we will assume the caller manages the full state update.
    // If this function is called standalone, it saves only the tasks array.
    window.localStorage.setItem('app_tasks', JSON.stringify(tasksArray));
}

/**
 * Specific function to save the current theme setting to Local Storage.
 * @param {string} themeValue - The theme setting (e.g., 'light' or 'dark').
 * @returns {void}
 */
function saveThemePreference(themeValue) {
    try {
        window.localStorage.setItem('app_theme', themeValue);
    } catch (error) {
        console.error("Error saving theme preference to Local Storage:", error);
    }
}

/**
 * Specific function to retrieve the saved theme preference from Local Storage.
 * @returns {string} The saved theme value.
 */
function loadThemePreference() {
    try {
        const theme = window.localStorage.getItem('app_theme');
        // Return the saved theme, defaulting to 'light' if not found
        return theme || DEFAULT_STATE.theme;
    } catch (error) {
        console.error("Error loading theme preference from Local Storage:", error);
        return DEFAULT_STATE.theme;
    }
}

// Export the functions to the global scope
window.storage = {
    loadState,
    saveState,
    saveTaskData,
    saveThemePreference,
    loadThemePreference
};