/**
 * router.js
 * Manages the visibility and state of the main dashboard views (Calendar and Task List)
 * based on user interaction, implementing Single Page Application (SPA) routing logic.
 */

// --- Internal State Management ---
let currentView = 'calendar'; // Default view state
let calendarContainerId = null;
let taskListContainerId = null;

/**
 * Initializes the router by setting up initial event listeners and default view state.
 * @param {string} calendarContainerId - The ID of the container for the Calendar view.
 * @param {string} taskListContainerId - The ID of the container for the Task List view.
 */
function initializeRouter(calendarContainerId, taskListContainerId) {
    calendarContainerId = calendarContainerId;
    taskListContainerId = taskListContainerId;

    // 1. Set up event listeners for view switching
    const calendarElement = document.getElementById(calendarContainerId);
    const taskListElement = document.getElementById(taskListContainerId);

    if (!calendarElement || !taskListElement) {
        console.error("Router initialization failed: One or both container elements not found.");
        return;
    }

    // Attach listeners to the view elements themselves (assuming they are clickable)
    calendarElement.addEventListener('click', () => handleViewSwitchEvent({ target: calendarElement }));
    taskListElement.addEventListener('click', () => handleViewSwitchEvent({ target: taskListElement }));

    // 2. Initialize the default view state upon page load (Test 1)
    // We default to the Calendar view as per the user flow tests.
    showCalendarView();
}

/**
 * Hides the Task List view and displays the Calendar view.
 * @action DOM Manipulation
 */
function showCalendarView() {
    const calendarElement = document.getElementById(calendarContainerId);
    const taskListElement = document.getElementById(taskListContainerId);

    if (calendarElement && taskListElement) {
        // Hide Task List
        taskListElement.classList.add('hidden');
        // Show Calendar
        calendarElement.classList.remove('hidden');
        currentView = 'calendar';
        console.log("Router: Switched to Calendar View.");
    }
}

/**
 * Hides the Calendar view and displays the Task List view.
 * @action DOM Manipulation
 */
function showTaskList() {
    const calendarElement = document.getElementById(calendarContainerId);
    const taskListElement = document.getElementById(taskListContainerId);

    if (calendarElement && taskListElement) {
        // Hide Calendar
        calendarElement.classList.add('hidden');
        // Show Task List
        taskListElement.classList.remove('hidden');
        currentView = 'task-list';
        console.log("Router: Switched to Task List View.");
    }
}

/**
 * Central handler for all view switching events (e.g., click on a navigation tab).
 * @param {Event} event - The DOM event object.
 * @logic Determines which view to display based on the event target.
 */
/**
 * Central handler for all view switching events (e.g., click on a navigation tab).
 * @param {Event} event - The DOM event object.
 * @logic Determines which view to display based on the event target.
 */
function handleViewSwitchEvent(event) {
    const target = event.target;

    // Determine which view was clicked based on the target ID
    if (target.id === calendarContainerId) {
        showCalendarView();
    } else if (target.id === taskListContainerId) {
        showTaskList();
    } else {
        console.warn("Router: Clicked outside of defined view containers.");
    }
}

// --- Application Initialization ---
document.addEventListener('DOMContentLoaded', () => {
    // Retrieve IDs from the HTML structure
    const calendarId = 'calendar-module';
    const taskListId = 'task-list-module';

    // Initialize the router
    initializeRouter(calendarId, taskListId);
});

// Export the router functions (optional, depending on module system)
window.router = {
    initializeRouter,
    showCalendarView,
    showTaskList,
    handleViewSwitchEvent
};