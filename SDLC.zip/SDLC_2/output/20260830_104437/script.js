```javascript
/**
 * script.js
 * Core application logic for the client-side billing application.
 * Implements the Offline-First Local Data Architecture using localStorage.
 */

// ==========================================================================
// 1. Data Persistence & Utility Functions
// ==========================================================================

/**
 * Retrieves the JSON array of invoices from localStorage.
 * @returns {Array} The parsed array of invoices, or an empty array if not found or error occurs.
 */
function loadInvoicesFromStorage() {
    try {
        const data = localStorage.getItem('invoices');
        if (data) {
            return JSON.parse(data);
        }
        return [];
    } catch (error) {
        console.error("Error loading invoices from localStorage:", error);
        // Handle potential parsing failure or storage issues
        return [];
    }
}

/**
 * Saves the current array of invoices to localStorage.
 * @param {Array} invoices - The array of invoice objects to save.
 */
function saveInvoiceToStorage(invoices) {
    try {
        localStorage.setItem('invoices', JSON.stringify(invoices));
    } catch (error) {
        console.error("Error saving invoices to localStorage:", error);
        // Handle storage full or other errors
        handleLocalStorageError("Failed to save data to local storage.");
    }
}

/**
 * Helper function to format numerical values into a readable currency string.
 * @param {number} amount - The numerical amount.
 * @returns {string} The formatted currency string.
 */
function formatCurrency(amount) {
    return parseFloat(amount).toFixed(2);
}

/**
 * Handles potential errors during localStorage operations.
 * @param {string} message - The error message to display.
 */
function handleLocalStorageError(message) {
    const errorArea = document.getElementById('error-message-area');
    errorArea.textContent = `Error: ${message}`;
    errorArea.style.display = 'block';
    console.error(message);
}

// ==========================================================================
// 2. Calculation Logic
// ==========================================================================

/**
 * The core calculation function. Iterates through all line items to compute totals.
 * @param {Array} items - The array of line items for the invoice.
 * @returns {{subtotal: number, tax: number, total: number}} The calculated totals.
 */
function calculateTotals(items) {
    let subtotal = 0;
    let tax = 0;

    items.forEach(item => {
        subtotal += item.quantity * item.price;
    });

    // Assuming a fixed tax rate of 10% based on the manifest context
    tax = subtotal * 0.10;
    const total = subtotal + tax;

    return {
        subtotal: subtotal,
        tax: tax,
        total: total
    };
}

/**
 * Updates the HTML elements with the calculated totals.
 * @param {{subtotal: number, tax: number, total: number}} totals - The calculated totals object.
 */
function updateDisplayTotals(totals) {
    document.getElementById('subtotal-display').textContent = formatCurrency(totals.subtotal);
    document.getElementById('tax-display').textContent = formatCurrency(totals.tax);
    document.getElementById('total-display').textContent = formatCurrency(totals.total);
}

// ==========================================================================
// 3. Rendering & Display Functions
// ==========================================================================

/**
 * Dynamically generates the HTML list of saved invoices.
 * @param {Array} invoices - The array of invoice objects.
 */
function renderInvoiceList(invoices) {
    const listContainer = document.getElementById('invoice-list-content');
    listContainer.innerHTML = '';

    if (invoices.length === 0) {
        listContainer.innerHTML = '<p>No invoices found. Start by creating a new one!</p>';
        return;
    }

    invoices.forEach(invoice => {
        const invoiceElement = document.createElement('div');
        invoiceElement.className = 'invoice-item';
        invoiceElement.dataset.invoiceId = invoice.id;
        invoiceElement.innerHTML = `
            <div class="invoice-summary">
                <h3>${invoice.customerName} - #${invoice.id}</h3>
                <p>Date: ${new Date(invoice.date).toLocaleDateString()}</p>
                <p>Total: $${formatCurrency(invoice.total)}</p>
            </div>
            <div class="actions">
                <button class="view-details-btn" data-id="${invoice.id}">View Details</button>
                <button class="delete-btn" data-id="${invoice.id}">Delete</button>
            </div>
        `;
        listContainer.appendChild(invoiceElement);
    });
}

/**
 * Renders the full details of a selected invoice into the main invoice view area.
 * @param {Object} invoice - The invoice object to display.
 */
function displayInvoiceDetails(invoice) {
    const detailsContent = document.getElementById('invoice-details-content');
    detailsContent.innerHTML = `
        <h2>Invoice Details: #${invoice.id}</h2>
        <p><strong>Customer Name:</strong> ${invoice.customerName}</p>
        <p><strong>Address:</strong> ${invoice.customerAddress}</p>
        <p><strong>Date:</strong> ${new Date(invoice.date).toDateString()}</p>
        <h3>Line Items:</h3>
        <table class="invoice-details">
            <thead>
                <tr>
                    <th>Description</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                ${invoice.items.map(item => `
                    <tr>
                        <td>${item.description}</td>
                        <td>${item.quantity}</td>
                        <td>$${formatCurrency(item.price)}</td>
                        <td>$${formatCurrency(item.quantity * item.price)}</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
        <div class="totals-summary">
            <p>Subtotal: $${formatCurrency(invoice.subtotal)}</p>
            <p>Tax (10%): $${formatCurrency(invoice.tax)}</p>
            <p>Total Due: $${formatCurrency(invoice.total)}</p>
        </div>
    `;
}

/**
 * Manages the state and logic flow when an existing invoice is selected for editing.
 * @param {string} id - The ID of the invoice to load.
 */
function handleInvoiceEdit(id) {
    const invoices = loadInvoicesFromStorage();
    const invoice = invoices.find(inv => inv.id === id);

    if (!invoice) {
        handleLocalStorageError("Invoice not found for editing.");
        return;
    }

    // Populate the form fields
    document.getElementById('customer-name').value = invoice.customerName;
    document.getElementById('customer-address').value = invoice.customerAddress;

    // Clear existing line items and rebuild
    const lineItemsContainer = document.getElementById('line-items-container');
    lineItemsContainer.innerHTML = '';

    invoice.items.forEach(item => {
        addLineItemRow(item.description, item.