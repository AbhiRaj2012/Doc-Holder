/**
 * storage.js
 * Manages all client-side data persistence using browser Local Storage.
 * Implements the Offline-First Local Data Architecture and The Ledger System.
 */

// Central storage key
const STORAGE_KEY = 'appState';

/**
 * Internal function to safely retrieve data from Local Storage.
 * @param {string} key - The key to look up in localStorage.
 * @returns {any | null} The parsed data or null if an error occurs.
 */
function safeLoad(key) {
    try {
        const data = localStorage.getItem(key);
        if (data === null) {
            return null;
        }
        return JSON.parse(data);
    } catch (error) {
        console.error(`[Storage Error] Failed to parse data for key "${key}":`, error);
        return null; // Return null on parsing failure (Safe Parsing Rule)
    }
}

/**
 * Internal function to safely save data to Local Storage.
 * @param {string} key - The key to save under.
 * @param {any} data - The data to be saved.
 * @returns {void}
 */
function safeSave(key, data) {
    try {
        const jsonString = JSON.stringify(data);
        localStorage.setItem(key, jsonString);
    } catch (error) {
        console.error(`[Storage Error] Failed to save data for key "${key}":`, error);
    }
}

/**
 * Retrieves all data (tasks and theme) from Local Storage and returns the application state object.
 * @returns {object} The application state.
 */
function loadAppState() {
    const state = safeLoad(STORAGE_KEY);

    if (state) {
        return state;
    }

    // Test 1: Initial load (empty storage) correctly initializes default theme and empty task list.
    console.log("Storage is empty. Initializing default state.");
    return {
        tasks: [],
        theme: 'light' // Default theme
    };
}

/**
 * Serializes the provided application state object and saves it to Local Storage.
 * (The Ledger System: Save state after mutation)
 * @param {object} state - The application state object to save.
 * @returns {void}
 */
function saveAppState(state) {
    safeSave(STORAGE_KEY, state);
}

/**
 * Retrieves the array of tasks from Local Storage.
 * @returns {Array<object>} The array of tasks.
 */
function loadTasks() {
    const state = loadAppState();
    return state ? state.tasks : [];
}

/**
 * Saves the provided array of tasks to Local Storage, ensuring data integrity.
 * (Persistent Storage Rule)
 * @param {Array<object>} tasks - The array of tasks to save.
 * @returns {void}
 */
function saveTasks(tasks) {
    const state = loadAppState();
    if (state) {
        state.tasks = tasks;
        saveAppState(state);
    }
}

/**
 * Retrieves the saved theme preference ('light' or 'dark') from Local Storage.
 * @returns {string} The saved theme.
 */
function loadTheme() {
    const state = loadAppState();
    return state ? state.theme : 'light'; // Default to 'light' if not found
}

/**
 * Saves the current theme preference to Local Storage.
 * (Persistent Storage Rule)
 * @param {string} theme - The theme preference ('light' or 'dark').
 * @returns {void}
 */
function saveTheme(theme) {
    const state = loadAppState();
    if (state) {
        state.theme = theme;
        saveAppState(state);
    }
}

/**
 * The main entry point function called on page load.
 * Loads the state and initializes default values if storage is empty.
 * (Data Hydration Rule)
 * @returns {object} The fully hydrated application state.
 */
function initializeStorage() {
    const state = loadAppState();

    if (!state) {
        // Initialize default state if storage was empty
        const defaultState = {
            tasks: [],
            theme: 'light'
        };
        saveAppState(defaultState);
        return defaultState;
    }

    // Return the loaded state
    return state;
}

// Modular SPA Architecture (Global Namespace Rule)
window.StorageApp = {
    loadAppState: loadAppState,
    saveAppState: saveAppState,
    loadTasks: loadTasks,
    saveTasks: saveTasks,
    loadTheme: loadTheme,
    saveTheme: saveTheme,
    initializeStorage: initializeStorage
};