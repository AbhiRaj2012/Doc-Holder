/**
 * app.js
 * Main application logic for the Task Agenda Dashboard.
 * Handles all data persistence, UI rendering, task CRUD operations, and theme management.
 */

// ==========================================================================
// 1. Core Data Management (Using functions exposed by storage.js)
// ==========================================================================

/**
 * Retrieves the entire application state (tasks, theme, last_updated) from Local Storage.
 * (Manifest function: loadData)
 * @returns {object} The application state.
 */
function loadData() {
    // loadAppState is exposed via window.StorageApp
    return window.StorageApp.loadAppState();
}

/**
 * Saves the provided data object (tasks, theme) back into Local Storage.
 * (Manifest function: saveData)
 * @param {object} data - The application state object to save.
 * @returns {void}
 */
function saveData(data) {
    // saveAppState is exposed via window.StorageApp
    window.StorageApp.saveAppState(data);
}

/**
 * Retrieves the array of tasks from Local Storage.
 * (Manifest function: loadTasks)
 * @returns {Array<object>} The array of tasks.
 */
function loadTasks() {
    return window.StorageApp.loadTasks();
}

/**
 * Saves the provided array of tasks to Local Storage, ensuring data integrity.
 * (Manifest function: saveTasks)
 * @param {Array<object>} tasks - The array of tasks to save.
 * @returns {void}
 */
function saveTasks(tasks) {
    window.StorageApp.saveTasks(tasks);
}

/**
 * Retrieves the saved theme preference ('light' or 'dark') from Local Storage.
 * (Manifest function: loadTheme)
 * @returns {string} The saved theme.
 */
function loadTheme() {
    return window.StorageApp.loadTheme();
}

/**
 * Saves the current theme preference to Local Storage.
 * (Manifest function: saveTheme)
 * @param {string} theme - The theme preference ('light' or 'dark').
 * @returns {void}
 */
function saveTheme(theme) {
    window.StorageApp.saveTheme(theme);
}

// ==========================================================================
// 2. Calendar Logic
// ==========================================================================

/**
 * Core logic function that iterates through all stored tasks and generates a map of dates
 * to identify which calendar days require visual highlighting.
 * (Manifest function: mapTasksToCalendarDates)
 * @param {Array<object>} tasks - The array of tasks.
 * @returns {Map<string, boolean>} A map where keys are 'YYYY-MM-DD' and values are true if a task exists on that date.
 */
function mapTasksToCalendarDates(tasks) {
    const dateMap = new Map();

    tasks.forEach(task => {
        // Assuming task.date is in 'YYYY-MM-DD' format
        const dateKey = task.date;
        if (dateKey) {
            dateMap.set(dateKey, true);
        }
    });

    return dateMap;
}

/**
 * Generates the HTML structure for the monthly calendar grid, dynamically highlighting dates that contain tasks.
 * (Manifest function: renderCalendar)
 * @param {Array<object>} tasks - The array of tasks.
 * @returns {void}
 */
function renderCalendar(tasks) {
    const calendarGrid = document.getElementById('calendar-grid');
    if (!calendarGrid) return;

    // Clear previous content
    calendarGrid.innerHTML = '';

    // Determine the range of dates to display (e.g., current month)
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth();

    const dateMap = mapTasksToCalendarDates(tasks);

    // Generate calendar days for the current month
    for (let day = 1; day <= today.getDate(); day++) {
        const date = new Date(year, month, day);
        const dateString = date.toISOString().split('T')[0]; // YYYY-MM-DD format

        const dayElement = document.createElement('div');
        dayElement.className = 'calendar-day';
        dayElement.textContent = day;

        // Check if this date has a task
        if (dateMap.has(dateString)) {
            dayElement.classList.add('task-highlight');
        }

        // Add click handler for potential future functionality (e.g., viewing tasks for the day)
        dayElement.addEventListener('click', () => {
            console.log(`Clicked date: ${dateString}`);
        });

        calendarGrid.appendChild(dayElement);
    }
}

// ==========================================================================
// 3. Task List Logic
// ==========================================================================

/**
 * Generates the HTML structure for the detailed task list view, displaying all tasks in a sortable format.
 * (Manifest function: renderTaskList)
 * @param {Array<object>} tasks - The array of tasks.
 * @returns {void}
 */
function renderTaskList(tasks) {
    const taskList = document.getElementById('task-list');
    if (!taskList) return;

    // Clear previous content
    taskList.innerHTML = '';

    if (tasks.length === 0) {
        taskList.innerHTML = '<p>No tasks found. Add a new task above!</p>';
        return;
    }

    tasks.forEach(task => {
        const listItem = document.createElement('li');
        listItem.className = 'task-item';
        // Display task details
        listItem.innerHTML = `
            <div><strong>Title:</strong> ${task.title}</div>
            <div><strong>Date:</strong> ${task.date}</div>
            <div><strong>Details:</strong> ${task.details || 'N/A'}</div>
        `;
        taskList.appendChild(listItem);
    });
}

// ==========================================================================
// 4. Application Initialization and Event Handlers
// ==========================================================================

/**
 * Manages the application's visual theme by adding or removing the appropriate CSS class.
 * (Manifest function: applyTheme)
 * @param {string} theme - The theme preference ('light' or 'dark').
 * @returns {void}
 */
function applyTheme(theme) {
    document.body.classList.remove('light-mode', 'dark-mode');
    document.body.classList.add(`${theme}-mode`);
}

/**
 * Flips the current theme state (Light <-> Dark) and persists the new preference to localStorage.
 * (Manifest function: toggleTheme)
 * @returns {void}
 */
function toggleTheme() {
    const currentTheme = loadTheme();
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';

    applyTheme(newTheme);
    saveTheme(newTheme);
}

/**
 * Initializes the application: loads data from Local Storage, sets the initial theme,
 * and renders the initial UI components (calendar and task list).
 * (Manifest function: initializeApp)
 * @returns {void}
 */
function initializeApp() {
    // 1. Load Data (Data Hydration Rule)
    const state = loadData();
    const tasks = state ? state.tasks : [];
    const theme = state ? state.theme : 'light';

    // 2. Set Initial Theme
    applyTheme(theme);

    // 3. Render UI Components
    renderCalendar(tasks);
    renderTaskList(tasks);

    console.log("Application initialized successfully.");
}

/**
 * Creates a new task object, assigns a unique ID, saves it to the task array,
 * and triggers a UI re-render.
 * (Manifest function: addTask)
 * @param {object} taskDetails - Details of the new task (title, date, details).
 * @returns {void}
 */
function addTask(taskDetails) {
    const tasks = loadTasks();

    if (!taskDetails.title || !taskDetails.date) {
        console.error("Task creation failed: Title and Date are required.");
        return;
    }

    // Create new task with a unique ID
    const newTask = {
        id: Date.now(), // Simple unique ID generation
        title: taskDetails.title,
        date: taskDetails.date,
        details: taskDetails.details
    };

    // Update state (The Ledger System)
    tasks.push(newTask);
    saveTasks(tasks);

    // Re-render UI
    initializeApp(); // Re-run initialization to refresh all views
}

/**
 * Finds a task by ID, updates its details, saves the updated task to Local Storage,
 * and refreshes the relevant views.
 * (Manifest function: updateTask)
 * @param {number} taskId - The ID of the task to update.
 * @param {object} updatedDetails - The new details for the task.
 * @returns {void}
 */
function updateTask(taskId, updatedDetails) {
    let tasks = loadTasks();
    const index = tasks.findIndex(t => t.id === taskId);

    if (index !== -1) {
        // Update state (The Ledger System)
        tasks[index] = { ...tasks[index], ...updatedDetails };
        saveTasks(tasks);

        // Re-render UI
        initializeApp();
    } else {
        console.error(`Task update failed: Task with ID ${taskId} not found.`);
    }
}

/**
 * Removes a task from the task array, saves the updated array, and updates the calendar highlighting.
 * (Manifest function: deleteTask)
 * @param {number} taskId - The ID of the task to delete.
 * @returns {void}
 */
function deleteTask(taskId) {
    let tasks = loadTasks();
    const initialLength = tasks.length;

    // Filter out the task
    tasks = tasks.filter(t => t.id !== taskId);

    if (tasks.length < initialLength) {
        // Update state (The Ledger System)
        saveTasks(tasks);

        // Re-render UI
        initializeApp();
    } else {
        console.error(`Task deletion failed: Task with ID ${taskId} not found.`);
    }
}


// ==========================================================================
// 5. Event Listeners and DOM Binding
// ==========================================================================

document.addEventListener('DOMContentLoaded', () => {
    // 1. Initialize the application state and render initial views
    initializeApp();

    // 2. Theme Toggle Listener
    const themeToggleBtn = document.getElementById('theme-toggle');
    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', toggleTheme);
    }

    // 3. Task Form Submission Listener
    const taskForm = document.getElementById('task-form-container');
    if (taskForm) {
        taskForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const title = document.getElementById('task-title').value.trim();
            const date = document.getElementById('task-date').value;
            const details = document.getElementById('task-details').value.trim();

            // Add Task
            addTask({ title, date, details });

            // Clear form fields
            taskForm.reset();
        });
    }
});