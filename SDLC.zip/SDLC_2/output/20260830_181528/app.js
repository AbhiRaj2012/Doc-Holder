// app.js

// --- Global State Management (Ledger System) ---
// We assume window.StorageApp exists and provides methods for localStorage interaction.

// Internal application state
var calculatorState = {
    currentOperand: '0',
    previousOperand: null,
    operation: null
};

// --- Core Functions ---

/**
 * Resets the calculator state, clearing the current input and resetting the display to zero.
 */
function clearDisplay() {
    calculatorState.currentOperand = '0';
    calculatorState.previousOperand = null;
    calculatorState.operation = null;
    updateDisplay();
    saveState(); // Record state change
}

/**
 * Handles the input of a number, updating the display and managing the current operand state.
 * @param {string} number - The number pressed.
 */
function handleNumberInput(number) {
    if (calculatorState.currentOperand === '0' && number !== '.') {
        calculatorState.currentOperand = number;
    } else if (number === '.' && calculatorState.currentOperand.includes('.')) {
        // Prevent multiple decimal points
        return;
    } else {
        calculatorState.currentOperand = calculatorState.currentOperand + number;
    }
    updateDisplay();
    saveState(); // Record state change
}

/**
 * Stores the current display value and the pending operator, preparing for the next calculation.
 * @param {string} operator - The operator pressed (+, -, *, /).
 */
function handleOperatorInput(operator) {
    const inputValue = parseFloat(calculatorState.currentOperand);

    if (calculatorState.previousOperand === null) {
        // First number entered
        calculatorState.previousOperand = inputValue;
    } else if (calculatorState.operation) {
        // Chain calculation: perform pending operation first
        performCalculation(calculatorState.previousOperand, inputValue, calculatorState.operation);
    } else {
        // Store the current value as the first operand
        calculatorState.previousOperand = inputValue;
    }

    calculatorState.currentOperand = '';
    calculatorState.operation = operator;
    
    updateDisplay();
    saveState(); // Record state change
}

/**
 * Executes the core arithmetic operation based on the stored operands and operator, handling division by zero errors.
 * @param {number} operand1 - The first operand.
 * @param {number} operand2 - The second operand.
 * @param {string} operator - The operator (+, -, *, /).
 */
function performCalculation(operand1, operand2, operator) {
    let result;

    switch (operator) {
        case '+':
            result = operand1 + operand2;
            break;
        case '-':
            result = operand1 - operand2;
            break;
        case '*':
            result = operand1 * operand2;
            break;
        case '/':
            if (operand2 === 0) {
                // Handle division by zero error
                calculatorState.currentOperand = 'Error: Division by Zero';
                calculatorState.previousOperand = null;
                calculatorState.operation = null;
                updateDisplay();
                saveState();
                return;
            }
            result = operand1 / operand2;
            break;
        default:
            result = operand2;
    }

    // Update state for the next operation
    calculatorState.currentOperand = result.toString();
    calculatorState.previousOperand = null;
    calculatorState.operation = null;

    updateDisplay();
    saveState(); // Record state change
}

/**
 * Updates the DOM display element with the current state.
 */
function updateDisplay() {
    const displayElement = document.getElementById('display');
    displayElement.textContent = calculatorState.currentOperand;
}

/**
 * Initializes all necessary event listeners on the DOM elements and initializes the application state variables.
 * @param {HTMLElement} displayElement - The display div.
 * @param {HTMLElement} operatorButtons - The container for operator buttons.
 * @param {HTMLElement} numberButtons - The container for number buttons.
 * @param {HTMLElement} clearButton - The clear button.
 */
function initializeCalculator(displayElement, operatorButtons, numberButtons, clearButton) {
    // 1. Set up event listeners for number buttons
    const numberButtonsArray = Array.from(numberButtons.querySelectorAll('.number'));
    numberButtonsArray.forEach(button => {
        button.addEventListener('click', function() {
            handleNumberInput(this.dataset.value);
        });
    });

    // 2. Set up event listeners for operator buttons
    const operatorButtonsArray = Array.from(operatorButtons.querySelectorAll('.operator'));
    operatorButtonsArray.forEach(button => {
        button.addEventListener('click', function() {
            handleOperatorInput(this.textContent);
        });
    });

    // 3. Set up event listener for the clear button
    clearButton.addEventListener('click', clearDisplay);

    // Initial display setup (optional, but good practice)
    updateDisplay();
}

// --- Initialization on Load ---

document.addEventListener('DOMContentLoaded', function() {
    // Get DOM elements
    const displayElement = document.getElementById('display');
    const operatorButtons = document.getElementById('operator-buttons');
    const numberButtons = document.getElementById('number-buttons');
    const clearButton = document.getElementById('clear-btn');

    // Initialize the calculator logic
    initializeCalculator(displayElement, operatorButtons, numberButtons, clearButton);

    // Data Hydration: Load state from localStorage
    try {
        const savedState = window.StorageApp.loadState();
        if (savedState) {
            // Rehydrate the state from storage
            calculatorState.currentOperand = savedState.currentOperand || '0';
            calculatorState.previousOperand = savedState.previousOperand || null;
            calculatorState.operation = savedState.operation || null;
            updateDisplay();
        }
    } catch (error) {
        console.error("Error loading state from localStorage:", error);
        // If loading fails, start with default state
    }
});