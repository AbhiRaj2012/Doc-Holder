import os
import json
from pathlib import Path
from datetime import datetime
from langgraph.graph import StateGraph, END

# Import the decoupled agents and state
from agents.state import AgentState, MAX_REVISIONS
from agents.planner import planner_node
from agents.coder import coder_node
from agents.reviewer import reviewer_node
from agents.requirements import requirement_node
from agents.reflector import reflector_node
from agents.integration import final_integration_node


def save_file_node(state: AgentState):
    """Saves verified file and logs incomplete files."""
    current_file = state["pending_files"][0]
    content = state["file_system"][current_file]
    incomplete = state.get("incomplete_files", {})

    # NEW LOGIC: Check if it hit max revisions and still failed
    if state["status"] == "FAIL":
        incomplete[current_file] = state["feedback"]
        print(f"   ⚠️ [Max Revisions Hit: {current_file} saved with known errors]")

    file_path = Path(state["run_dir"]) / current_file
    file_path.write_text(content, encoding="utf-8")
    print(f"\n💾 Saved file: {file_path}")

    return {
        "pending_files": state["pending_files"][1:],
        "review_attempts": 0,
        "feedback": "",
        "status": "",
        "incomplete_files": incomplete
    }


def finalize_workflow(state: AgentState):
    """Generates the validate.json ledger for any imperfect files."""
    incomplete = state.get("incomplete_files", {})
    if incomplete:
        validate_path = Path(state["run_dir"]) / "validate.json"
        validate_path.write_text(json.dumps(incomplete, indent=2), encoding="utf-8")
        print(f"\n📄 Validation Ledger created: {len(incomplete)} file(s) require manual review.")
    return {}


def route_review(state: AgentState):
    if state["status"] == "PASS":
        return "save_file"

    attempts = state["review_attempts"]
    if attempts == 3:
        return "reflector"  # End of Cycle 1 -> Reflect
    elif attempts >= 6:
        return "save_file"  # End of Cycle 2 -> Force Save as Incomplete

    return "coder"  # Normal looping

def route_next_file(state: AgentState):
    if len(state["pending_files"]) > 0:
        return "coder"
    # Route to the integration sweep first, instead of the finalizer
    return "integration"


# Build the Graph
workflow = StateGraph(AgentState)
workflow.add_node("requirements", requirement_node)
workflow.add_node("planner", planner_node)
workflow.add_node("coder", coder_node)
workflow.add_node("reviewer", reviewer_node)
workflow.add_node("save_file", save_file_node)
workflow.add_node("finalize_workflow", finalize_workflow)
workflow.add_node("reflector", reflector_node)
workflow.add_node("integration", final_integration_node)

workflow.set_entry_point("requirements")
workflow.add_edge("requirements", "planner")
workflow.add_edge("planner", "coder")
workflow.add_edge("coder", "reviewer")
workflow.add_edge("reflector", "coder")

# Route from Reviewer
workflow.add_conditional_edges("reviewer", route_review, {"coder": "coder", "reflector": "reflector", "save_file": "save_file"})

# Route from Save File
workflow.add_conditional_edges("save_file", route_next_file, {"coder": "coder", "integration": "integration"})

# Linear Finish: Integration Sweep -> Validate.json Generation -> END
workflow.add_edge("integration", "finalize_workflow")
workflow.add_edge("finalize_workflow", END)

app = workflow.compile()

if __name__ == "__main__":
    user_input = input("\nWhat application do you want to build?\n> ")
    
    base_dir = Path.cwd() / "output"
    run_dir = base_dir / datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"\n🚀 Starting build in: {run_dir}")
    app.invoke({"user_input": user_input, "run_dir": str(run_dir)})
    print(f"\n🎉 Build Complete! Check execution_log.txt in {run_dir}")