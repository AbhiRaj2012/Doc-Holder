```javascript
const Game = (function() {
    // --- DOM Element References ---
    const canvas = document.getElementById('game-canvas');
    const scoreDisplay = document.getElementById('hud-score');
    const livesDisplay = document.getElementById('hud-lives');
    const gameOverModal = document.getElementById('game-over-modal');
    const restartButton = document.getElementById('restart-button');

    if (!canvas || !scoreDisplay || !livesDisplay || !gameOverModal || !restartButton) {
        console.error("One or more required DOM elements are missing.");
        return;
    }

    // --- Game State ---
    let state = {
        score: 0,
        lives: 3,
        gameState: 'Initial Setup', // 'Initial Setup', 'Playing', 'Game Over'
        fruitSpeed: 1,
        fruitsArray: [],
        bombsArray: []
    };

    // --- Game Constants ---
    const GAME_WIDTH = 400;
    const GAME_HEIGHT = 600;
    const BASKET_WIDTH = 50;
    const BASKET_HEIGHT = 10;
    const FRUIT_SIZE = 20;
    const BOMB_SIZE = 20;
    // Define spawn rate (lower number means higher frequency, used for timing)
    const FRUIT_SPAWN_RATE = 500; // Milliseconds between potential spawns
    const FRUIT_SPAWN_INTERVAL = 100; // How often to attempt spawning
    const BOMB_SPAWN_RATE = 1000; // Slower bomb spawning

    // --- Game Objects ---
    let basket = {
        x: GAME_WIDTH / 2 - BASKET_WIDTH / 2,
        y: GAME_HEIGHT - BASKET_HEIGHT - 10,
        width: BASKET_WIDTH,
        height: BASKET_HEIGHT
    };

    // --- Utility Functions ---

    /**
     * Updates the HUD elements with current score and lives.
     */
    function updateHUD() {
        scoreDisplay.textContent = `Score: ${state.score}`;
        livesDisplay.textContent = `Lives: ${state.lives}`;
    }

    /**
     * Displays the Game Over modal.
     */
    function showGameOverModal() {
        state.gameState = 'Game Over';
        gameOverModal.style.display = 'flex';
    }

    /**
     * Handles player movement based on keyboard input.
     */
    function handlePlayerMovement(event) {
        if (state.gameState !== 'Playing') return;

        const speed = 10;
        if (event.key === 'ArrowLeft' || event.key === 'a') {
            basket.x -= speed;
        } else if (event.key === 'ArrowRight' || event.key === 'd') {
            basket.x += speed;
        }

        // Boundary checks
        if (basket.x < 0) {
            basket.x = 0;
        }
        if (basket.x + basket.width > GAME_WIDTH) {
            basket.x = GAME_WIDTH - basket.width;
        }
    }

    /**
     * Checks for collisions between the basket and falling objects.
     */
    function checkCollisions() {
        // Check Fruits
        state.fruitsArray.forEach((fruit, index) => {
            if (
                basket.x < fruit.x + fruit.width &&
                basket.x + basket.width > fruit.x &&
                basket.y < fruit.y + fruit.height &&
                basket.y + basket.height > fruit.y
            ) {
                // Collision detected: Score +10
                state.score += 10;
                state.fruitsArray.splice(index, 1); // Remove fruit
            }
        });

        // Check Bombs
        state.bombsArray.forEach((bomb, index) => {
            if (
                basket.x < bomb.x + bomb.width &&
                basket.x + basket.width > bomb.x &&
                basket.y < bomb.y + bomb.height &&
                basket.y + basket.height > bomb.y
            ) {
                // Collision detected: Lose a life
                state.lives -= 1;
                state.bombsArray.splice(index, 1); // Remove bomb
            }
        });

        // Check Game Over condition
        if (state.lives <= 0) {
            state.gameState = 'Game Over';
            showGameOverModal();
        }
    }

    /**
     * Generates new fruit and bomb objects.
     */
    function generateObjects() {
        // 1. Generate Fruits
        if (Math.random() < 0.05) { // 5% chance per frame to spawn a fruit
            const fruit = {
                x: Math.random() * (GAME_WIDTH - FRUIT_SIZE),
                y: -FRUIT_SIZE,
                width: FRUIT_SIZE,
                height: FRUIT_SIZE,
                speed: state.fruitSpeed
            };
            state.fruitsArray.push(fruit);
        }

        // 2. Generate Bombs (less frequent)
        if (Math.random() < 0.01) { // 1% chance per frame to spawn a bomb
            const bomb = {
                x: Math.random() * (GAME_WIDTH - BOMB_SIZE),
                y: -BOMB_SIZE,
                width: BOMB_SIZE,
                height: BOMB_SIZE,
                speed: state.fruitSpeed * 1.5 // Bombs fall faster
            };
            state.bombsArray.push(bomb);
        }

        // Gradually increase speed over time
        if (state.score > 0 && state.score % 100 === 0) {
            state.fruitSpeed += 0.01;
        }
    }

    /**
     * Main game loop, driven by requestAnimationFrame.
     */
    function updateGameLoop() {
        if (state.gameState !== 'Playing') {
            return;
        }

        // 1. Update Fruit Positions
        state.fruitsArray.forEach(fruit => {
            fruit.y += fruit.speed;
        });

        // 2. Update Bomb Positions
        state.bombsArray.forEach(bomb => {
            bomb.y += bomb.speed;
        });

        // 3. Remove objects that fall off screen
        state.fruitsArray = state.fruitsArray.filter(fruit => fruit.y < GAME_HEIGHT);
        state.bombsArray = state.bombsArray.filter(bomb => bomb.y < GAME_HEIGHT);

        // 4. Generate new objects
        generateObjects();

        // 5. Check for collisions
        checkCollisions();

        // 6. Update HUD
        updateHUD();

        // Request next frame
        requestAnimationFrame(updateGameLoop);
    }

    /**
     * Resets all game state variables and arrays.
     */
    function restartGame() {
        state = {
            score: 0,
            lives: 3,
            gameState: 'Initial Setup',
            fruitSpeed: 1,
            fruits