```javascript
document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Element References ---
    const gameCanvas = document.getElementById('game-canvas');
    const scoreDisplay = document.getElementById('score-display');
    const livesDisplay = document.getElementById('lives-display');
    const gameOverModal = document.getElementById('game-over-modal');
    const restartButton = document.getElementById('restart-button');
    const playerBasket = document.getElementById('player-basket');

    if (!gameCanvas || !scoreDisplay || !livesDisplay || !gameOverModal || !restartButton || !playerBasket) {
        console.error("One or more required DOM elements were not found.");
        return;
    }

    // --- Game State Management ---
    let gameState = {
        score: 0,
        lives: 3,
        isGameOver: false,
        fruits: [],
        bombs: [],
        fallSpeed: 2, // Initial fall speed
        basketX: 0,
        basketWidth: 100,
        basketHeight: 20,
        objectsSpawnTimer: 0,
        spawnInterval: 1000, // Base spawn interval (ms)
        lastSpawnTime: 0,
    };

    // --- Game Object Class/Factory ---

    class FallingObject {
        constructor(type, x, y, speed) {
            this.type = type; // 'fruit' or 'bomb'
            this.x = x;
            this.y = y;
            this.width = 30;
            this.height = 30;
            this.speed = speed;
            this.element = document.createElement('div');
            this.element.className = type;
            this.element.style.position = 'absolute';
            this.element.style.left = `${this.x}px`;
            this.element.style.top = `${this.y}px`;
            this.element.style.width = `${this.width}px`;
            this.element.style.height = `${this.height}px`;
            gameCanvas.appendChild(this.element);
        }

        update() {
            this.y += this.speed;
            this.element.style.top = `${this.y}px`;
        }

        isOffScreen() {
            return this.y > gameCanvas.height;
        }

        remove() {
            if (this.element && gameCanvas.contains(this.element)) {
                gameCanvas.removeChild(this.element);
            }
        }
    }

    // --- Core Game Functions ---

    /**
     * Sets initial global state and initializes the game.
     */
    function initializeGame() {
        gameState.score = 0;
        gameState.lives = 3;
        gameState.isGameOver = false;
        gameState.fruits = [];
        gameState.bombs = [];
        gameState.fallSpeed = 2;
        gameState.basketX = gameCanvas.clientWidth / 2 - gameState.basketWidth / 2; // Center the basket
        
        // Reset basket position visually
        playerBasket.style.left = `${gameState.basketX}px`;

        // Clear existing objects from canvas
        gameCanvas.innerHTML = '';
    }

    /**
     * Handles player input to move the basket.
     */
    function handlePlayerMovement(event) {
        if (gameState.isGameOver) return;

        const basketRect = playerBasket.getBoundingClientRect();
        const canvasRect = gameCanvas.getBoundingClientRect();
        
        // Calculate basket position relative to the canvas
        let currentBasketX = parseFloat(playerBasket.style.left);
        
        if (event.key === 'ArrowLeft') {
            gameState.basketX -= 20;
        } else if (event.key === 'ArrowRight') {
            gameState.basketX += 20;
        }

        // Clamp basket position within canvas boundaries
        const maxLeft = gameCanvas.clientWidth - gameState.basketWidth;
        const minLeft = 0;
        
        gameState.basketX = Math.max(minLeft, Math.min(maxLeft, gameState.basketX));