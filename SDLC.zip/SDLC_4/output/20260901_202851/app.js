```javascript
const Game = (() => {
    // --- DOM Element References ---
    const gameCanvas = document.getElementById('game-canvas');
    const scoreDisplay = document.getElementById('score-display');
    const livesDisplay = document.getElementById('lives-display');
    const gameOverModal = document.getElementById('game-over-modal');
    const restartButton = document.getElementById('restart-button');

    // --- Global State Initialization (Fixing Missing Logic) ---
    let score = 0;
    let lives = 3;
    let basketXPosition = gameCanvas.clientWidth / 2; // Initial center position
    let fruitsArray = [];
    let bombsArray = [];
    let gameLoopInterval;
    let isGameOver = false;

    // --- Game Object Definitions ---
    const FRUIT_SPEED = 2;
    const BOMB_SPEED = 3;
    const FRUIT_SIZE = 20;
    const BOMB_SIZE = 20;

    // --- Helper Functions ---

    /**
     * Updates the HUD display with current score and lives.
     */
    const updateHUD = () => {
        if (scoreDisplay) {
            scoreDisplay.textContent = `Score: ${score}`;
        }
        if (livesDisplay) {
            livesDisplay.textContent = `Lives: ${lives}`;
        }
    };

    /**
     * Spawns a random fruit or bomb object.
     */
    const spawnObject = () => {
        const randomType = Math.random() < 0.7 ? 'fruit' : 'bomb';
        const x = Math.random() * (gameCanvas.clientWidth - FRUIT_SIZE);
        const y = -FRUIT_SIZE; // Start above the canvas

        if (randomType === 'fruit') {
            fruitsArray.push({ x: x, y: y, type: 'fruit' });
        } else {
            bombsArray.push({ x: x, y: y, type: 'bomb' });
        }
    };

    /**
     * Handles movement based on keyboard input.
     * @param {string} direction - 'left' or 'right'
     */
    const handleInput = (direction) => {
        const step = 50;
        if (direction === 'left') {
            basketXPosition -= step;
        } else if (direction === 'right') {
            basketXPosition += step;
        }

        // Boundary checks
        const canvasWidth = gameCanvas.clientWidth;
        if (basketXPosition < 0) {
            basketXPosition = 0;
        } else if (basketXPosition > canvasWidth - 50) { // Assuming basket width is around 50
            basketXPosition = canvasWidth - 50;
        }

        // Update basket position visually
        gameCanvas.style.left = `${basketXPosition}px`;
    };

    /**
     * Checks for collisions between the basket and falling objects.
     */
    const checkCollision = () => {
        let newFruits = [];
        let newBombs = [];
        let scoreIncrease = 0;
        let livesLost = 0;

        const basketRect = {
            left: basketXPosition,
            right: basketXPosition + 50, // Assuming basket width 50
            top: 0,
            bottom: gameCanvas.clientHeight
        };

        // Check Fruits
        fruitsArray.forEach(fruit => {
            const fruitRect = {
                left: fruit.x,
                right: fruit.x + FRUIT_SIZE,
                top: fruit.y,
                bottom: fruit.y + FRUIT_SIZE
            };

            // Simple AABB collision check
            if (basketRect.right > fruitRect.left && basketRect.left < fruitRect.right && basketRect.top < fruitRect.bottom && basketRect.bottom > fruitRect.top) {
                scoreIncrease += 10;
            } else {
                newFruits.push(fruit);
            }
        });

        // Check Bombs
        bombsArray.forEach(bomb => {
            const bombRect = {
                left: bomb.x,
                right: bomb.x + BOMB_SIZE,
                top: bomb.y,
                bottom: bomb.y + BOMB_SIZE
            };

            if (basketRect.right > bombRect.left && basketRect.left < bombRect.right && basketRect.top < bombRect.bottom && basketRect.bottom > bombRect.top) {
                livesLost += 1;
            } else {
                newBombs.push(bomb);
            }
        });

        // Update state arrays
        fruitsArray = newFruits;
        bombsArray = newBombs;

        if (scoreIncrease > 0) {
            score += scoreIncrease;
        }

        if (livesLost > 0) {
            loseLife(livesLost);
        }
    };

    /**
     * Decrements lives and handles Game Over state.
     * @param {number} count - Number of lives lost.
     */
    const loseLife = (count) => {
        lives -= count;
        if (lives <= 0) {
            showGameOverModal();
        }
    };

    /**
     * Hides the game and shows the Game Over modal.
     */
    const showGameOverModal = () => {
        isGameOver = true;
        clearInterval(gameLoopInterval);
        gameCanvas.style.display = 'none';
        gameOverModal.style.display = 'flex';
    };

    /**
     * Resets all game state and restarts the game.
     */
    const restartGame = () => {
        // Reset State
        score = 0;
        lives = 3;
        basketXPosition = gameCanvas.clientWidth / 2;
        fruitsArray = [];
        bombsArray = [];
        isGameOver = false;

        // Reset DOM visibility
        gameOverModal.style.display = 'none';
        gameCanvas.style.display = 'block';

        // Restart Game Loop
        startGameLoop();
    };

    /**
     * Main game loop function.
     */
    const gameLoop = () => {
        if (isGameOver) return;

        // 1. Spawn new objects periodically
        if (Math.random() < 0.05) { // 5% chance per frame to spawn
            spawnObject();
        }

        // 2. Move objects
        fruitsArray.forEach(fruit => {
            fruit.y += FRUIT_SPEED;
        });
        bombsArray.forEach(bomb => {
            bomb.y += BOMB_SPEED;
        });

        // 3. Remove objects that fall off screen
        fruitsArray = fruitsArray.filter(fruit => fruit.y < gameCanvas.clientHeight);
        bombsArray = bombsArray.filter(bomb => bomb.y < gameCanvas.clientHeight);

        // 4. Check collisions
        checkCollision();

        // 5. Update HUD
        updateHUD();
    };

    /**
     * Initializes the game state and starts the main loop.
     */
    const initializeGame = () => {
        // Set initial basket position
        gameCanvas.style.left = `${basketXPosition}px`;

        // Start the game loop
        startGameLoop();
    };

    /**
     * Starts the continuous game loop.
     */
    const startGameLoop = () => {
        if (gameLoopInterval) {
            clearInterval(gameLoopInterval);
        }
        gameLoopInterval = setInterval(gameLoop, 1000 / 60); // 60 FPS
    };

    // --- Event Listeners ---

    /**
     * Handles keyboard input for basket movement.
     * @param {KeyboardEvent} event
     */
    const handleKeyDown = (event) => {
        if (isGameOver) return;