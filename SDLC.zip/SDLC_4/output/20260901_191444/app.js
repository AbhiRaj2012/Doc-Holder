```txt
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fruit Catcher Game</title>
    <style>
        :root {
            /* Color Palette */
            --color-primary: #4CAF50; /* Green for success/catch */
            --color-danger: #F44336; /* Red for danger/bombs */
            --color-background: #f0f0f0;
            --color-text: #333;
            --color-surface: #ffffff;
            --color-shadow: rgba(0, 0, 0, 0.1);

            /* Spacing & Typography */
            --spacing-unit: 1rem;
            --padding-base: calc(var(--spacing-unit) * 2);
            --basket-width: 100px;
            --basket-height: 20px;
            --game-area-height: 500px;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: var(--color-background);
            color: var(--color-text);
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            overflow: hidden;
        }

        #game-container {
            width: 100%;
            max-width: 600px;
            background-color: var(--color-surface);
            box-shadow: 0 4px 12px var(--color-shadow);
            border-radius: 8px;
            padding: var(--padding-base);
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        /* HUD Styling */
        #hud {
            display: flex;
            justify-content: space-between;
            width: 100%;
            margin-bottom: var(--spacing-unit);
            font-size: 1.2rem;
            font-weight: bold;
        }

        /* Game Area Styling */
        #game-area {
            width: 100%;
            height: var(--game-area-height);
            background-color: #e8f5e9; /* Light green background for the game area */
            position: relative;
            overflow: hidden;
            border: 2px solid var(--color-primary);
            margin-bottom: var(--spacing-unit);
        }

        /* Basket Styling */
        #basket {
            width: var(--basket-width);
            height: var(--basket-height);
            background-color: #333;
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            z-index: 10;
            transition: left 0.05s linear; /* Smooth movement feedback */
        }

        /* Object Styling (Fruits and Bombs) */
        .game-object {
            position: absolute;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            font-size: 1.5rem;
            text-align: center;
            line-height: 30px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        .fruit {
            background-color: #ffeb3b; /* Yellow */
            border: 2px solid #fbc02d;
        }

        .bomb {
            background-color: #ffcdd2; /* Light Red */
            border: 2px solid #e57373;
        }

        /* Game Over Modal Styling */
        #gameOverModal {
            display: none; /* Hidden by default */
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            justify-content: center;
            align-items: center;
            z-index: 100;
        }

        #modal-content {
            background-color: var(--color-surface);
            padding: var(--padding-base);
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.5);
        }

        #modal-content h2 {
            color: var(--color-danger);
            margin-top: 0;
        }

        #restartButton {
            background-color: var(--color-primary);
            color: var(--color-surface);
            border: none;
            padding: 10px 20px;
            margin-top: var(--spacing-unit);
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
        }

        #restartButton:hover {
            background-color: #388e3c;
        }
    </style>
</head>
<body>

    <div id="game-container">
        <!-- HUD -->
        <div id="hud">
            <div id="scoreDisplay">Score: 0</div>
            <div id="livesDisplay">Lives: 3</div>
        </div>

        <!-- Game Area -->
        <div id="game-area">
            <!-- Player Basket -->
            <div id="basket"></div>
            <!-- Game Over Modal -->
            <div id="gameOverModal">
                <div id="modal-content">
                    <h2>