```javascript
/**
 * Fruit Catcher Game Logic (main.js)
 * Implements all game mechanics, state management, and DOM interaction.
 */

class FruitCatcherGame {
    constructor(elementIds) {
        // --- State Initialization (Requirement 12, 13) ---
        this.state = {
            score: 0,
            lives: 3, // Start with 3 lives
            basketXPosition: 50,
            fruitsArray: [],
            bombsArray: [],
            gameRunning: false,
        };

        // --- DOM Element References ---
        this.elements = {
            canvas: document.getElementById(elementIds.gameCanvas),
            scoreDisplay: document.getElementById(elementIds.scoreDisplay),
            livesDisplay: document.getElementById(elementIds.livesDisplay),
            gameOverModal: document.getElementById(elementIds.gameOverModal),
            restartButton: document.getElementById(elementIds.restartButton),
            playerBasket: document.getElementById(elementIds.playerBasket),
        };

        if (!this.elements.canvas || !this.elements.scoreDisplay || !this.elements.livesDisplay || !this.elements.gameOverModal || !this.elements.restartButton || !this.elements.playerBasket) {
            console.error("One or more required DOM elements were not found.");
            return;
        }

        // --- Game Loop Control ---
        this.gameInterval = null;
        this.lastUpdateTime = 0;
        this.fallSpeedMultiplier = 1; // Controls progressive speed (Requirement 9)

        this.setupEventListeners();
        this.initializeGame();
    }

    /**
     * Sets up keyboard input handling.
     */
    setupEventListeners() {
        document.addEventListener('keydown', this.handlePlayerMovement.bind(this));
        this.elements.restartButton.addEventListener('click', this.resetGame.bind(this));
    }

    /**
     * Initializes the game state and starts the main loop. (Requirement 14)
     */
    initializeGame() {
        this.state.score = 0;
        this.state.lives = 3;
        this.state.basketXPosition = this.elements.canvas.width / 2;
        this.state.fruitsArray = [];
        this.state.bombsArray = [];
        this.state.gameRunning = true;
        this.fallSpeedMultiplier = 1;
        this.lastUpdateTime = performance.now();

        // Clear existing objects
        this.state.fruitsArray.forEach(obj => obj.element.remove());
        this.state.bombsArray.forEach(obj => obj.element.remove());
        this.state.fruitsArray = [];
        this.state.bombsArray = [];

        this.updateHUD();
        this.gameLoop();
    }

    /**
     * Main game loop, executed periodically.
     */
    gameLoop() {
        if (!this.state.gameRunning) {
            return;
        }

        const currentTime = performance.now();
        const deltaTime = (currentTime - this.lastUpdateTime) / 1000; // Delta time in seconds
        this.lastUpdateTime = currentTime;

        // 1. Update Object Positions (Requirement 9)
        this.updateObjectPositions(deltaTime);

        // 2. Check Collisions (Requirement 10, 11)
        this.checkCollisions();

        // 3. Update HUD (Requirement 12, 13)
        this.updateHUD();

        // 4. Check Game Over (Requirement 15)
        this.checkGameOver();

        // Request next frame
        requestAnimationFrame(this.gameLoop.bind(this));
    }

    /**
     * Handles player horizontal movement. (Requirement 5)
     * @param {KeyboardEvent} event
     */
    handlePlayerMovement(event) {
        if (!this.state.gameRunning) return;

        const basketWidth = this.elements.playerBasket.offsetWidth;
        const canvasWidth = this.elements.canvas.width;

        if (event.key === 'ArrowLeft') {
            this.state.basketXPosition -= basketWidth;
        } else if (event.key === 'ArrowRight') {
            this.state.basketXPosition += basketWidth;
        }

        // Clamp position within bounds
        this.state.basketXPosition = Math.max(0, Math.min(this.state.basketXPosition, canvasWidth - basketWidth));
    }

    /**
     * Spawns a random fruit or bomb. (Requirement 6, 7, 8)
     */
    spawnObject() {
        const canvasWidth = this.elements.canvas.width;
        const objectSize = 30; // Size of fruit/bomb

        // Randomly decide if it's a fruit (70%) or a bomb (30%)
        const isFruit = Math.random() < 0.7;

        const object = {
            id: Date.now() + Math.random(),
            type: isFruit ? 'fruit' : 'bomb',
            element: document.createElement('div'),
            x: Math.random() * (canvasWidth - objectSize),
            y: -objectSize, //