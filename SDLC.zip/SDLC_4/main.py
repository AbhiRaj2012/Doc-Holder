import json
from pathlib import Path
from datetime import datetime
from langgraph.graph import StateGraph, END
from agents.state import AgentState
from agents.requirements import requirement_node
from agents.planner import planner_node
from agents.coder import coder_node
from agents.reviewer import reviewer_node


def file_manager_node(state: AgentState):
    """Handles moving to the next file or finalizing."""
    pending = state["pending_files"]

    # Save the file to the timestamped disk directory
    if state["current_file"]:
        out_path = Path(state["run_dir"]) / state["current_file"]
        out_path.write_text(state["file_system"][state["current_file"]], encoding="utf-8")

    return {"pending_files": pending[1:]}


def finalize_node(state: AgentState):
    """Writes validation.json if there are errors."""
    errors = state["validation_errors"]
    if errors:
        validate_path = Path(state["run_dir"]) / "validation.json"
        validate_path.write_text(json.dumps(errors, indent=2), encoding="utf-8")

        print(f"\n📄 Saved validation.json. {len(errors)} file(s) need rework.")
    else:
        print("\n🎉 Project built perfectly with 0 validation errors!")
    return {}


def route_review(state: AgentState):
    if state["status"] in ["PASS", "FAIL_MAX"]:
        return "file_manager"
    return "coder"


def route_next(state: AgentState):
    if len(state["pending_files"]) > 0:
        return "coder"
    return "finalize"


# Graph Definition
workflow = StateGraph(AgentState)
workflow.add_node("requirements", requirement_node)
workflow.add_node("planner", planner_node)
workflow.add_node("coder", coder_node)
workflow.add_node("reviewer", reviewer_node)
workflow.add_node("file_manager", file_manager_node)
workflow.add_node("finalize", finalize_node)

workflow.set_entry_point("requirements")
workflow.add_edge("requirements", "planner")
workflow.add_edge("planner", "coder")
workflow.add_edge("coder", "reviewer")
workflow.add_conditional_edges("reviewer", route_review, {"coder": "coder", "file_manager": "file_manager"})
workflow.add_conditional_edges("file_manager", route_next, {"coder": "coder", "finalize": "finalize"})
workflow.add_edge("finalize", END)

app = workflow.compile()

if __name__ == "__main__":
    user_input = input("What application do you want to build?\n> ")
    run_dir = Path.cwd() / "output" / datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir.mkdir(parents=True, exist_ok=True)

    app.invoke({
        "user_input": user_input,
        "review_attempts": 0,
        "validation_errors": {},
        "run_dir": str(run_dir)
    })