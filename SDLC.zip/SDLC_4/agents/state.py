import json
import re
from typing import TypedDict
from pathlib import Path
from datetime import datetime
from langchain_ollama import ChatOllama

# Connect to your local model
llm = ChatOllama(model="gemma4:e2b", num_predict=4096, temperature=0.1)

class AgentState(TypedDict):
    user_input: str
    req_text: str          # Functional requirements only
    manifest: dict         # Strict JSON structural blueprint
    file_system: dict      # Holds the actual code
    pending_files: list    # ["index.html", "style.css", "main.js"]
    current_file: str      # The file currently being worked on
    review_attempts: int   # Counter for the 3-strike rule
    feedback: str          # Reviewer feedback
    validation_errors: dict # Stores mistakes if 3 strikes are hit
    status: str
    run_dir: str

def extract_json(text: str) -> dict:
    """Safe JSON extraction."""
    clean_text = re.sub(r"```(?:json)?", "", text, flags=re.IGNORECASE).replace("```", "")
    start = clean_text.find('{')
    end = clean_text.rfind('}')
    if start != -1 and end != -1:
        try:
            return json.loads(clean_text[start:end+1], strict=False)
        except:
            return {}
    return {}

def load_skill(skill_filename: str) -> str:
    skill_path = Path(__file__).parent.parent / "skills" / skill_filename
    try:
        return skill_path.read_text(encoding="utf-8")
    except FileNotFoundError:
        print(f" [!] Warning: Skill file {skill_filename} not found.")
        return ""

def write_log(run_dir: str, step: str, details: str):
    """Writes execution details to a timestamped log file."""
    if not run_dir:
        return
    log_file = Path(run_dir) / "execution_log.txt"
    timestamp = datetime.now().strftime("%H:%M:%S")
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"\n[{timestamp}] === {step.upper()} ===\n")
        f.write(str(details) + "\n")
        f.write("-" * 80 + "\n")