from pathlib import Path
from .state import AgentState, llm, write_log


def requirement_node(state: AgentState):
    print("\n📝 [Requirements] Extracting Functional Requirements...")
    prompt = f"""
    You are a Professional Technical Scoper. The user wants to build: '{state['user_input']}'

    Write a clear, concise `req.txt`. 
    - Describe the project simply.
    - List ONLY the Functional Requirements (what the app must DO, features, modules).
    - IGNORE all non-functional requirements (speed, load times, maintainability, etc.).
    - Keep it practical for a simple web app.
    """
    req_text = llm.invoke(prompt).content.strip()

    # Save to disk
    req_path = Path(state["run_dir"]) / "req.txt"
    req_path.parent.mkdir(exist_ok=True)
    req_path.write_text(req_text, encoding="utf-8")
    write_log(state["run_dir"], "Requirements - Output", req_text)

    return {"req_text": req_text}