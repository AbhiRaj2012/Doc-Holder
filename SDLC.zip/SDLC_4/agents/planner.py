import json
from pathlib import Path
from .state import AgentState, llm, extract_json, write_log


def planner_node(state: AgentState):
    print("\n📐 [Planner] Building unified manifest...")
    prompt = f"""
    You are a Professional Build Engineer, (who analyzes the project requirements and creates a build plan step by step),
    Read these requirements:
    {state['req_text']}

    Generate a strict JSON manifest for this web app.
    CRITICAL: The file names MUST ALWAYS be exactly: ["index.html", "style.css", "app.js"].

    Output ONLY valid JSON matching this exact structure:
    {{
      "project_files": ["index.html", "style.css", "main.js"],
      "layout": {{
        "main_container": "CSS Grid, 2 columns",
        "nav_bar": "Flexbox row"
      }},
      "element_ids": [
        {{ "id": "btn-add", "description": "Button to add item" }},
        {{ "id": "input-name", "description": "Text input for name" }}
      ],
      "global_state": [
        {{ "name": "itemsArray", "description": "Array holding added items" }}
      ],
      "functions": [
        {{ "name": "addItem", "triggered_by": "btn-add click", "description": "Reads input-name, updates itemsArray, calls renderList" }}
      ]
    }}
    """
    manifest = extract_json(llm.invoke(prompt).content)
    write_log(state["run_dir"], "Planner - Manifest", json.dumps(manifest, indent=2))

    # Fallback to ensure rigid naming
    files = manifest.get("project_files", ["index.html", "style.css", "main.js"])
    manifest_path = Path(state["run_dir"]) / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    return {
        "manifest": manifest,
        "pending_files": files,
        "file_system": {f: "" for f in files},
        "validation_errors": {}
    }