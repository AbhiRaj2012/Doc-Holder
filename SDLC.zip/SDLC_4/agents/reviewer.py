import re
from SDLC.agents.state import load_skill
from .state import AgentState, llm, write_log

def reviewer_node(state: AgentState):
    current_file = state["current_file"]
    code = state["file_system"][current_file]
    manifest = state["manifest"]
    attempts = state["review_attempts"] + 1

    reviewer_skill = load_skill("code_reviewer_skill.md")

    print(f"🔎 [Reviewer] Checking {current_file} against manifest constraints...")

    prompt = f"""
    {reviewer_skill}
    Review `{current_file}` against this manifest: {manifest}

    Code:
    ```
    {code}
    ```
    """

    feedback = llm.invoke(prompt).content.strip()

    write_log(state["run_dir"], f"Reviewer Feedback - {current_file}", feedback)

    # Bulletproof XML extraction
    verdict_match = re.search(r"<verdict>(.*?)</verdict>", feedback, re.IGNORECASE | re.DOTALL)
    verdict = verdict_match.group(1).strip().upper() if verdict_match else "FAIL"

    if verdict == "PASS":
        print(f"   ✅ {current_file} passed!")
        return {"status": "PASS", "review_attempts": 0, "feedback": ""}

    print(f"   ❌ Failed. Feedback: {feedback[:100]}...")

    # 3-Strike Logic
    validation_errors = state["validation_errors"].copy()
    if attempts >= 3:
        print(f"   ⚠️ Strike 3. Marking {current_file} as incomplete for later re_work.")
        validation_errors[current_file] = feedback
        return {"status": "FAIL_MAX", "review_attempts": 0, "validation_errors": validation_errors}

    return {"status": "FAIL", "review_attempts": attempts, "feedback": feedback}