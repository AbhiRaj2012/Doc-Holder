import re
from .state import AgentState, llm, load_skill, write_log


def coder_node(state: AgentState):
    current_file = state["pending_files"][0]
    manifest = state["manifest"]
    is_revision = state["review_attempts"] > 0
    coder_skill = load_skill("coder_skill.md")

    # Determine exact file type for the LLM warning
    file_type = current_file.split('.')[-1].upper()

    print(f"\n💻 [Coder] Writing {current_file} (Attempt {state['review_attempts'] + 1}/3)...")

    # Dynamic Focus Based on File Type
    focus_instructions = ""
    if file_type == "HTML":
        focus_instructions = f"Focus strictly on elements: {manifest.get('element_ids')}. MUST link style.css and app.js."
    elif file_type == "CSS":
        focus_instructions = f"Focus strictly on layout: {manifest.get('layout')}."
    elif file_type == "JS":
        focus_instructions = f"Focus strictly on element_ids: {manifest.get('element_ids')}, state: {manifest.get('global_state')}, and functions: {manifest.get('functions')}."

    # Hostile format enforcement banner
    format_warning = f"""
    ======================================================================
    WARNING: YOU ARE GENERATING A .{file_type} FILE.
    YOU MUST WRITE PURE {file_type} CODE ONLY. 
    IF YOU WRITE HTML TAGS INSIDE A JS OR CSS FILE, THE SYSTEM WILL CRASH.
    ======================================================================
    """

    if not is_revision:
        prompt = f"""
        {coder_skill}

        {format_warning}

        Write the complete code for `{current_file}`.
        REQUIREMENTS: {state['req_text']}

        {focus_instructions}

        Output ONLY the raw code inside ``` blocks.
        """
    else:
        prompt = f"""
        {coder_skill}

        {format_warning}

        Fix `{current_file}` based on Reviewer feedback.

        {focus_instructions}

        REVIEWER FEEDBACK: {state['feedback']}
        CURRENT CODE:\n{state['file_system'][current_file]}

        Output the ENTIRE fixed file inside ``` blocks. DO NOT use search/replace patches. Just rewrite the file correctly.
        """

    response = llm.invoke(prompt).content
    write_log(state["run_dir"], f"Coder Raw Response - {current_file} (Attempt {state['review_attempts'] + 1})",
              response)

    match = re.search(r"```[a-zA-Z]*\n(.*?)```", response, re.DOTALL)
    new_code = match.group(1).strip() if match else response.strip()

    updated_fs = state["file_system"].copy()
    updated_fs[current_file] = new_code
    return {"file_system": updated_fs, "current_file": current_file}