<SYSTEM_SKILL>
  <NAME>Modern CSS Layouts & Visual Hierarchy</NAME>
  <OBJECTIVE>
    Implement a clean, commercial-grade user interface using modern CSS principles[cite: 55].
  </OBJECTIVE>

  <IMPLEMENTATION_RULES>
    <RULE>Semantic Hierarchy: Use HTML5 semantic tags appropriately to structure the document layout[cite: 55].</RULE>
    <RULE>Flexbox & Grid Only: Use CSS Grid for main page scaffolding and Flexbox for component alignment[cite: 55].</RULE>
    <RULE>Theming & Variables: Define a `:root` scope with CSS custom properties for a cohesive color palette, spacing units (e.g., `0.5rem`, `1rem`), and border-radii[cite: 55].</RULE>
    <RULE>Interaction States: All clickable elements (buttons, cards, links) MUST have distinct `:hover` and `:active` transition states[cite: 55].</RULE>
    <RULE>Responsiveness: Use media queries to adapt CSS Grid templates for mobile and tablet viewport widths.</RULE>
  </IMPLEMENTATION_RULES>

  <ANTI_PATTERNS>
    <FORBIDDEN>Never use floats or manual positioning for layout structure[cite: 55].</FORBIDDEN>
    <FORBIDDEN>Never hardcode hex colors outside of the `:root` CSS custom properties block.</FORBIDDEN>
  </ANTI_PATTERNS>
</SYSTEM_SKILL>