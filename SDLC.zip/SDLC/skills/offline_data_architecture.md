<SYSTEM_SKILL>
  <NAME>Offline-First Local Data Architecture</NAME>
  <OBJECTIVE>
    Ensure the application functions completely offline without a backend server by utilizing advanced browser storage mechanisms[cite: 56].
  </OBJECTIVE>

  <IMPLEMENTATION_RULES>
    <RULE>The Ledger System: All state mutations MUST be recorded in a centralized JSON structure (a "Ledger") before updating the DOM[cite: 56].</RULE>
    <RULE>Persistent Storage: Use `localStorage` as the primary database[cite: 56]. Save the ledger immediately after every array mutation.</RULE>
    <RULE>Data Hydration: The application must trigger an `init()` or `hydrate()` function on DOMContentLoaded to parse the JSON from `localStorage` and rebuild the UI state instantly[cite: 56].</RULE>
    <RULE>Safe Parsing: ALWAYS wrap `JSON.parse()` in a `try/catch` block to prevent application crashes from corrupted `localStorage` data.</RULE>
    <RULE>Export Capability: If the app generates invoices, reports, or data tables, structure the HTML cleanly so it can easily be targeted for canvas-to-PDF export scripts later[cite: 56].</RULE>
  </IMPLEMENTATION_RULES>

  <ANTI_PATTERNS>
    <FORBIDDEN>Do not use external API calls for fonts, icons, or libraries[cite: 56]. Assume a strict offline environment[cite: 56].</FORBIDDEN>
    <FORBIDDEN>Do not update the DOM without first updating the central JavaScript state object.</FORBIDDEN>
  </ANTI_PATTERNS>
</SYSTEM_SKILL>