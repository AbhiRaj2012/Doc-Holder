import re
import json
from .state import AgentState, llm, write_log, MAX_REVISIONS, load_skill


def coder_node(state: AgentState):
    current_file = state["pending_files"][0]
    is_revision = state["review_attempts"] > 0
    base_code = state["file_system"].get(current_file, "")

    file_manifest = json.dumps(state["manifest"].get("files", {}).get(current_file, {}), indent=2)

    offline_skill = load_skill("offline_data_architecture.md")
    ui_skill = load_skill("modern_ui_ux.md")

    # Global memory context
    global_memory = "PREVIOUSLY BUILT FILES CONTEXT:\n"
    for filename, content in state["file_system"].items():
        if content and filename != current_file:
            global_memory += f"--- {filename} ---\n{content}\n"

    if not is_revision:
        print(f"\n💻 [Coder] Drafting initial structure for {current_file}...")
        prompt = f"""
        Write the code for `{current_file}` based strictly on this manifest:
        {file_manifest}

        {global_memory}

        APPLY THESE CORE SKILLS:
        {offline_skill}
        {ui_skill}

        CRITICAL CHUNKING RULE:
        If this file requires complex logic or multiple functions/sections, do NOT write the entire file at once. 
        Write the outer skeleton (e.g., HTML boilerplate, CSS structure, or JS variables) and use XML placeholder tags for the complex parts.

        Example:
        ```javascript
        let myData = [];
        <PLACEHOLDER id="renderDataFunction"/>
        <PLACEHOLDER id="saveDataFunction"/>
        ```
        Output ONLY the code inside ``` blocks.
        """
        response = llm.invoke(prompt).content
        match = re.search(r"```[a-zA-Z]*\n(.*?)```", response, re.DOTALL)
        new_code = match.group(1).strip() if match else response.strip()

        # --- CHUNKED GENERATION LOOP ---
        # Find all placeholders the LLM left behind
        placeholders = re.findall(r'<PLACEHOLDER\s+id=["\'](.*?)["\'].*?>', new_code, re.IGNORECASE)

        for ph_id in placeholders:
            print(f"   ↳ [Chunking] Generating isolated block: {ph_id}...")
            chunk_prompt = f"""
            You are generating an isolated code block for `{current_file}` to replace the placeholder: {ph_id}.

            MANIFEST CONTEXT:
            {file_manifest}

            Provide ONLY the raw code to replace the placeholder. Do not include markdown backticks. Do not re-write the whole file.
            """
            chunk_code = llm.invoke(chunk_prompt).content.strip()

            # Clean accidental backticks from the chunk
            chunk_code = chunk_code.replace("```javascript", "").replace("```html", "").replace("```css", "").replace(
                "```", "").strip()

            # Inject the generated chunk into the main code
            regex_placeholder = re.compile(f'<PLACEHOLDER\\s+id=["\']{ph_id}["\'].*?>', re.IGNORECASE)
            new_code = regex_placeholder.sub(chunk_code, new_code)

    else:
        print(f"\n🔄 [Coder] Surgically patching {current_file} (Attempt {state['review_attempts']}/{MAX_REVISIONS})...")
        prompt = f"""
        Fix `{current_file}` based on Reviewer feedback. Do NOT rewrite the whole file.

        MANIFEST REQUIREMENTS:
        {file_manifest}

        REVIEWER FEEDBACK:
        {state['feedback']}

        CURRENT CODE:
        ```
        {base_code}
        ```

        CRITICAL RULES:
        1. DO NOT TRUNCATE. You must complete the XML block entirely.
        2. Provide your fixes using EXACT XML blocks like this:

        <PATCH>
        <SEARCH>
        exact lines of old code to replace
        </SEARCH>
        <REPLACE>
        the new corrected code
        </REPLACE>
        </PATCH>
        """

        response = llm.invoke(prompt).content
        new_code = base_code

        # 1. Handle APPEND blocks (Bulletproof truncation recovery)
        append_blocks = re.findall(r"<APPEND>\s*(.*?)\s*</APPEND>", response, re.DOTALL)
        for append_text in append_blocks:
            clean_append = append_text.replace("```javascript", "").replace("```html", "").replace("```css",
                                                                                                   "").replace("```",
                                                                                                               "").strip()
            new_code += "\n" + clean_append
            print("   ↳ [Applied <APPEND> patch to bottom of file]")

        # 2. Handle SEARCH/REPLACE blocks
        blocks = re.findall(r"<SEARCH>\s*(.*?)\s*</SEARCH>\s*<REPLACE>\s*(.*?)\s*</REPLACE>", response, re.DOTALL)
        for old_text, new_text in blocks:
            clean_old = old_text.replace("```html", "").replace("```css", "").replace("```javascript", "").replace(
                "```js", "").replace("```", "").strip()
            clean_new = new_text.replace("```html", "").replace("```css", "").replace("```javascript", "").replace(
                "```js", "").replace("```", "").strip()

            if clean_old in new_code:
                new_code = new_code.replace(clean_old, clean_new)
                print("   ↳ [Applied <SEARCH>/<REPLACE> patch]")
            else:
                print("   ⚠️ [Failed to apply patch: <SEARCH> text not found perfectly]")

        if not blocks and not append_blocks:
            print("   ⚠️ [No valid <PATCH> blocks found. Using previous state.]")

    write_log(state["run_dir"], f"Coder - {current_file}", new_code)

    updated_fs = state["file_system"].copy()
    updated_fs[current_file] = new_code

    return {"file_system": updated_fs}