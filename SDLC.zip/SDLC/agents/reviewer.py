import json
from .state import AgentState, llm, write_log, load_skill

def reviewer_node(state: AgentState):
    current_file = state["pending_files"][0]
    file_code = state["file_system"][current_file]
    
    print(f"\n🔎 [Reviewer] Auditing {current_file}...")
    
    file_manifest = json.dumps(state["manifest"].get("files", {}).get(current_file, {}), indent=2)
    
    # --- LOAD SKILL ---
    grading_skill = load_skill("intent_based_grading.md")

    prompt = f"""
        Perform a strict audit on `{current_file}`.

        MANIFEST REQUIREMENTS: 
        {file_manifest}

        GRADING PROTOCOL:
        {grading_skill}

        CURRENT CODE:
        ```
        {file_code}
        ```

        If the code is 100% correct, reply with ONLY the word "PASS".
        If there are errors, explain exactly what needs to be changed.

        CRITICAL PATCHING RULES:
        1. TRUNCATION RECOVERY: If the code is truncated/cut-off at the end, DO NOT use <SEARCH> and <REPLACE>. You MUST use the <APPEND> tag to simply add the missing code to the bottom of the file.
        2. BUG FIXES: If you are fixing a specific bug in the middle of the file, use <SEARCH> and <REPLACE>.
        3. BATCH LIMIT: Do NOT output more than TWO (2) <PATCH> blocks per review. 

        CORRECT FORMAT FOR TRUNCATION:
        <PATCH>
        <APPEND>
        the rest of the missing code goes here
        </APPEND>
        </PATCH>

        CORRECT FORMAT FOR BUGS:
        <PATCH>
        <SEARCH>
        exact old code here
        </SEARCH>
        <REPLACE>
        new corrected code here
        </REPLACE>
        </PATCH>
        """
    review_output = llm.invoke(prompt).content.strip()
    write_log(state["run_dir"], f"Reviewer - {current_file}", review_output)
    
    if "PASS" in review_output.upper():
        print(f"   ✅ {current_file} passed review.")
        status = "PASS"
    else:
        print(f"   ❌ Issues found in {current_file}. Routing back to Coder.")
        status = "FAIL"
        
    return {
        "feedback": review_output,
        "status": status,
        "review_attempts": state["review_attempts"] + 1
    }