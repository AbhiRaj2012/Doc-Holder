from pathlib import Path
from .state import AgentState, llm, write_log

def requirement_node(state: AgentState):
    print("\n📝 [Requirements] Analyzing request and generating SRS/SDD...")
    
    prompt = f"""
    You are a Lead Systems Analyst. The user wants to build: '{state['user_input']}'
    
    Expand this into a comprehensive technical document combining an SRS (Software Requirements Specification) and SDD (Software Design Document).
    
    Include:
    1. Core Objectives & Scope
    2. Functional Requirements (Specific user interactions)
    3. Non-Functional Requirements (UI/UX, Performance)
    4. Technical Stack (Strictly HTML/CSS/Vanilla JS)
    
    Do not write code. Output the specifications clearly.
    """
    
    requirements = llm.invoke(prompt).content.strip()
    
    # Save the expanded requirements to the output directory
    req_path = Path(state["run_dir"]) / "SRS_SDD.txt"
    req_path.write_text(requirements, encoding="utf-8")
    write_log(state["run_dir"], "Requirements - Output", requirements)
    
    return {"requirements": requirements}