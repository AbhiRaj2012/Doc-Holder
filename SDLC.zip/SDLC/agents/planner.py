import json
from pathlib import Path
from .state import AgentState, llm, extract_json, write_log


def planner_node(state: AgentState):
    print("\n📐 [Planner] Architecting file structure...")

    # Step 1: Identify the files needed
    file_prompt = f"""
    Analyze these requirements:
    {state['requirements']}

    List the exact files needed to build this frontend application.
    Return ONLY a JSON array of strings.
    Example: ["index.html", "style.css", "script.js"]
    """
    files_to_build = extract_json(llm.invoke(file_prompt).content)

    if not isinstance(files_to_build, list) or len(files_to_build) == 0:
        print(" [!] File list generation failed. Using default stack.")
        files_to_build = ["index.html", "style.css", "script.js"]

    print(f"   ↳ Files mapped: {files_to_build}")

    # Step 2: Iteratively build the master manifest
    master_manifest = {"files": {}}

    for file in files_to_build:
        print(f"   ↳ Generating isolated blueprint for {file}...")
        manifest_prompt = f"""
        Generate a detailed JSON blueprint ONLY for `{file}`.

        REQUIREMENTS: 
        {state['requirements']}

        Ensure the JSON is perfectly formatted without trailing commas.
        Structure example for {file}:
        {{
          "description": "Purpose of the file",
          "dependencies": ["other files it relies on"],
          "elements_or_functions": {{
            "name_or_id": "description of what it does and its relationship to other elements"
          }}
        }}
        """
        file_response = llm.invoke(manifest_prompt).content
        file_manifest = extract_json(file_response)

        # Append to the master ledger
        master_manifest["files"][file] = file_manifest

    # Save the compiled master manifest
    manifest_path = Path(state["run_dir"]) / "manifest.json"
    manifest_path.write_text(json.dumps(master_manifest, indent=2), encoding="utf-8")
    write_log(state["run_dir"], "Planner - Master Manifest", json.dumps(master_manifest, indent=2))

    return {
        "manifest": master_manifest,
        "pending_files": files_to_build,
        "file_system": {f: "" for f in files_to_build},
        "review_attempts": 0,
        "feedback": "",
        "incomplete_files": {}
    }