```javascript
// Offline-First Local Data Architecture Implementation

const STORAGE_KEY = 'taskAgendaData';
let tasks = [];

/**
 * Persistent Storage: Load data from localStorage.
 * Safe Parsing: Wraps JSON.parse in try/catch.
 * @returns {Array of Task Objects} The loaded task array.
 */
function loadTasks() {
    try {
        const data = localStorage.getItem(STORAGE_KEY);
        if (data) {
            tasks = JSON.parse(data);
        } else {
            tasks = [];
        }
    } catch (error) {
        console.error("Error parsing localStorage data. Data might be corrupted.", error);
        tasks = []; // Reset to empty array on failure
    }
    return tasks;
}

/**
 * Persistent Storage: Save the current state to localStorage.
 * @param {Array of Task Objects} taskArray The array to save.
 */
function saveTasks(taskArray) {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(taskArray));
    } catch (error) {
        console.error("Error saving data to localStorage.", error);
    }
}

/**
 * Data Hydration: Rebuilds the UI state instantly.
 * Triggers the rendering process.
 */
function hydrate() {
    const loadedTasks = loadTasks();
    tasks = loadedTasks;
    renderTaskList();
    renderCalendar();
    highlightTaskDates();
}

/**
 * Core Logic: Renders the task list data to the DOM.
 * @param {Array of Task Objects} taskArray The array of tasks to render.
 */
function renderTaskList(taskArray) {
    const taskListContainer = document.getElementById('task-list-container');
    if (!taskListContainer) return;

    taskListContainer.innerHTML = '';

    if (taskArray.length === 0) {
        taskListContainer.innerHTML = '<p class="no-tasks-message">No tasks scheduled yet.</p>';
        return;
    }

    taskArray.forEach((task, index) => {
        const taskItem = document.createElement('div');
        taskItem.className = 'task-item';
        taskItem.dataset.taskId = task.id;
        taskItem.innerHTML = `
            <div class="task-details">
                <h3>${task.title}</h3>
                <p>Due Date: ${new Date(task.dueDate).toLocaleDateString()}</p>
            </div>
            <div class="task-actions">
                <button class="delete-btn" data-id="${task.id}">Delete</button>
            </div>
        `;
        taskListContainer.appendChild(taskItem);
    });
}

/**
 * Core Logic: Generates the HTML structure for the monthly calendar grid.
 * @param {Array of Task Objects} taskArray The array of tasks to check for dates.
 */
function renderCalendar(taskArray) {
    const calendarView = document.getElementById('calendar-view');
    if (!calendarView) return;

    // Clear previous calendar content
    calendarView.innerHTML = '';

    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth();

    // --- Calendar Header ---
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    const currentMonthName = monthNames[month];
    const currentYear = year;

    const headerHTML = `
        <div class="calendar-header">
            <button id="prev-month">&lt;</button>
            <h2>${currentMonthName} ${currentYear}</h2>
            <button id="next-month">&gt;</button>
        </div>
        <div class="calendar-grid" id="calendar-grid"></div>
    `;
    calendarView.innerHTML = headerHTML;
    const calendarGrid = document.getElementById('calendar-grid');

    // --- Calendar Grid Generation ---
    const firstDayOfMonth = new Date(currentYear, month, 1);
    const lastDayOfMonth = new Date(currentYear, month + 1, 0);
    const startDayOfWeek = firstDayOfMonth.getDay(); // 0 (Sunday) to 6 (Saturday)

    // Create 6 rows (for simplicity, we'll focus on the current month)
    for (let i = 0; i < 6; i++) {
        const row = document.createElement('div');
        row.className = 'calendar-row';
        row.style.display = 'grid';
        row.style.gridTemplateColumns = 'repeat(7, 1fr)';
        row.style.gap = 'var(--spacing-unit)';

        // Day Names (Header Row)
        const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
        dayNames.forEach(day => {
            const dayCell = document.createElement('div');
            dayCell.className = 'calendar-day-name';
            dayCell.textContent = day;
            row.appendChild(dayCell);
        });

        // Day Cells
        for (let j = 0; j < 7; j++) {
            const date = new Date(currentYear, month, j + 1);
            const cell = document.createElement('div');
            cell.className = 'calendar-day';
            cell.textContent = date.getDate();
            cell.dataset.date = `${currentYear}-${month + 1}-${date.getDate()}`;

            // Check for tasks and apply highlight
            if (highlightTaskDates(date, taskArray)) {
                cell.classList.add('highlighted-date');
            }

            row.appendChild(cell);
        }
        calendarGrid.appendChild(row);
    }

    // Attach navigation listeners (handled by setupEventListeners)
    document.getElementById('prev-month').addEventListener('click', () => changeMonth(-1));
    document.getElementById('next-month