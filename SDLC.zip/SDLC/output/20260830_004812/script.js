// --- Offline-First Local Data Architecture Implementation ---

const STORAGE_KEY = 'ledgerData';
let ledger = [];

/**
 * Persistent Storage: Load data from localStorage.
 * Rule: Safe Parsing (try/catch).
 */
function loadLedger() {
    try {
        const data = localStorage.getItem(STORAGE_KEY);
        if (data) {
            ledger = JSON.parse(data);
        } else {
            ledger = [];
        }
    } catch (error) {
        console.error("Error parsing localStorage data. Data might be corrupted.", error);
        ledger = []; // Fallback to empty array on error
    }
}

/**
 * Rule: Save the ledger immediately after every array mutation.
 */
function saveLedger() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(ledger));
    } catch (error) {
        console.error("Error saving data to localStorage.", error);
    }
}

/**
 * Rule: Data Hydration. Rebuilds the UI state instantly.
 */
function hydrate() {
    loadLedger();
    renderLedger();
}

/**
 * Rule: Render the UI based on the current state.
 */
function renderLedger() {
    const ledgerBody = document.getElementById('ledgerBody');
    if (!ledgerBody) return;

    ledgerBody.innerHTML = ''; // Clear existing rows

    if (ledger.length === 0) {
        ledgerBody.innerHTML = '<tr><td colspan="3" style="text-align: center;">No transactions recorded yet.</td></tr>';
        return;
    }

    ledger.forEach((item, index) => {
        const row = ledgerBody.insertRow();
        // Rule: Export Capability - Clean structure for potential export
        row.insertCell().textContent = index + 1;
        row.insertCell().textContent = item.description;
        row.insertCell().textContent = `$${item.amount.toFixed(2)}`;
    });
}

/**
 * Handles form submission and state mutation.
 */
document.getElementById('entryForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const descriptionInput = document.getElementById('description');
    const amountInput = document.getElementById('amount');

    const description = descriptionInput.value.trim();
    const amount = parseFloat(amountInput.value);

    if (!description || isNaN(amount) || amount <= 0) {
        alert("Please enter a valid description and a positive amount.");
        return;
    }

    // Rule: The Ledger System - Update state
    const newEntry = {
        id: Date.now(), // Simple unique ID
        description: description,
        amount: amount
    };

    ledger.push(newEntry);

    // Rule: Persistent Storage - Save immediately
    saveLedger();

    // Update UI
    renderLedger();

    // Clear form
    descriptionInput.value = '';
    amountInput.value = '';
});

// Initialize the application when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
    hydrate();
});