// =============================================================================
// 1. STATE MANAGEMENT & LOCAL STORAGE INTERFACE (The Ledger System)
// =============================================================================

/**
 * Mock implementation of the localStorage interface based on the manifest.
 * This handles the persistence layer.
 */
const localStorageInterface = {
    saveTasks() {
        localStorage.setItem('tasks', JSON.stringify(tasks));
    },
    loadTasks() {
        const data = localStorage.getItem('tasks');
        if (data) {
            tasks = JSON.parse(data);
        } else {
            tasks = [];
        }
    },
    saveTheme(theme) {
        currentTheme = theme;
        localStorage.setItem('theme', theme);
    },
    loadTheme() {
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme) {
            currentTheme = savedTheme;
        } else {
            // Default theme if nothing is saved
            currentTheme = 'light';
        }
    }
};

// =============================================================================
// 2. CORE UI FUNCTIONS
// =============================================================================

/**
 * Applies the theme class to the body element.
 * Manifest Call: applyTheme()
 */
function applyTheme() {
    document.body.classList.remove('dark-mode', 'light-mode');
    document.body.classList.add(currentTheme === 'dark' ? 'dark-mode' : 'light-mode');
}

/**
 * Dynamically generates and updates the DOM elements for the task list.
 * Manifest Call: renderTasks()
 */
function renderTasks() {
    const taskListElement = document.querySelector('.task-list');
    if (!taskListElement) return;

    taskListElement.innerHTML = ''; // Clear existing content

    tasks.forEach((task, index) => {
        const taskItem = document.createElement('li');
        taskItem.className = 'task-item';
        taskItem.innerHTML = `
            <div class="task-title">${task.title}</div>
            <div class="task-due">${task.dueDate}</div>
            <button class="delete-task" data-index="${index}">Delete</button>
        `;
        taskListElement.appendChild(taskItem);
    });

    // Attach event listeners for deletion
    document.querySelectorAll('.delete-task').forEach(button => {
        button.addEventListener('click', handleDeleteTask);
    });
}

/**
 * Calculates and renders the monthly calendar grid (Placeholder implementation).
 * Manifest Call: renderCalendar()
 */
function renderCalendar() {
    console.log("Rendering calendar based on tasks...");
    // In a full implementation, this would calculate dates and highlight tasks.
}

/**
 * Handles the creation of a new task, updates the array, and persists the data.
 * Manifest Call: addTask(title, dueDate)
 * @param {string} title - The title of the new task.
 * @param {string} dueDate - The due date of the task.
 */
function addTask(title, dueDate) {
    const newTask = {
        title: title,
        dueDate: dueDate
    };

    tasks.push(newTask);
    localStorageInterface.saveTasks();
    renderTasks();
}

/**
 * Event handler for the theme switch button.
 * Manifest Call: handleThemeToggle()
 */
function handleThemeToggle() {
    // Toggle theme state
    currentTheme = currentTheme === 'dark' ? 'light' : 'dark';

    // Save theme preference
    localStorageInterface.saveTheme(currentTheme);

    // Apply the new theme
    applyTheme();
}

/**
 * Handles the deletion of a task.
 * @param {Event} event - The click event.
 */
function handleDeleteTask(event) {
    const index = parseInt(event.target.dataset.index);
    if (index >= 0 && index < tasks.length) {
        // Remove the task
        tasks.splice(index, 1);
        
        // Save the updated state
        localStorageInterface.saveTasks();
        
        // Re-render the UI
        renderTasks();
    }
}

// =============================================================================
// 3. INITIALIZATION (Data Hydration)
// =============================================================================

/**
 * Initializes the application by loading data from localStorage and setting up initial state.
 * This acts as the hydrate function.
 */
function init() {
    // 1. Load Tasks
    localStorageInterface.loadTasks();

    // 2. Load Theme
    localStorageInterface.loadTheme();

    // 3. Apply Theme (Applies the loaded theme immediately)
    applyTheme();

    // 4. Render UI based on loaded data
    renderTasks();
    renderCalendar(); // Render calendar as well
}

// =============================================================================
// 4. EVENT LISTENERS & BOOTSTRAP
// =============================================================================

document.addEventListener('DOMContentLoaded', () => {
    // Attach Theme Toggle Listener
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', handleThemeToggle);
    }

    // Attach Add Task Listener (Example usage)
    const addTaskButton = document.getElementById('add-task-btn');
    if (addTaskButton) {
        addTaskButton.addEventListener('click', () => {
            const title = prompt("Enter task title:");
            if (title) {
                const dueDate = prompt("Enter due date (e.g., YYYY-MM-DD):");
                if (dueDate) {
                    addTask(title, dueDate);
                }
            }
        });
    }

    // Start the application flow
    init();
});