const appState = {
    tasks: [],
    theme: 'light'
};

/**
 * Persistence Layer Functions
 */

/**
 * Retrieves the task array from localStorage.
 * Implements Safe Parsing to handle corrupted data.
 */
function loadTasksFromStorage() {
    try {
        const data = localStorage.getItem('taskAgendaData');
        if (data) {
            const tasks = JSON.parse(data);
            appState.tasks = tasks;
        } else {
            appState.tasks = [];
        }
    } catch (error) {
        console.error("Error loading tasks from localStorage:", error);
        appState.tasks = []; // Fallback to empty array on error
    }
}

/**
 * Serializes the current task array and saves it back to localStorage.
 */
function saveTasksToStorage() {
    try {
        localStorage.setItem('taskAgendaData', JSON.stringify(appState.tasks));
    } catch (error) {
        console.error("Error saving tasks to localStorage:", error);
    }
}

/**
 * Task Management Functions
 */

/**
 * Handles the creation of a new task.
 * @param {string} title - The title of the task.
 * @param {string} dueDate - The due date of the task (YYYY-MM-DD format).
 */
function addTask(title, dueDate) {
    if (!title || !dueDate) {
        console.error("Task title and due date are required.");
        return;
    }

    const newTask = {
        id: Date.now(), // Simple unique ID generation
        title: title,
        dueDate: dueDate,
        isComplete: false
    };

    appState.tasks.push(newTask);
    saveTasksToStorage();
    renderTaskList();
    renderCalendar();
}

/**
 * Modifies an existing task's details.
 * @param {number} taskId - The ID of the task to update.
 * @param {string} newTitle - The new title.
 * @param {string} newDate - The new due date.
 * @param {boolean} isComplete - The new completion status.
 */
function updateTask(taskId, newTitle, newDate, isComplete) {
    const taskIndex = appState.tasks.findIndex(task => task.id === taskId);

    if (taskIndex !== -1) {
        appState.tasks[taskIndex].title = newTitle;
        appState.tasks[taskIndex].dueDate = newDate;
        appState.tasks[taskIndex].isComplete = isComplete;

        saveTasksToStorage();
        renderTaskList();
        renderCalendar();
    } else {
        console.error(`Task with ID ${taskId} not found.`);
    }
}

/**
 * Removes a task permanently from the task array.
 * @param {number} taskId - The ID of the task to delete.
 */
function deleteTask(taskId) {
    const initialLength = appState.tasks.length;
    appState.tasks = appState.tasks.filter(task => task.id !== taskId);

    if (appState.tasks.length < initialLength) {
        saveTasksToStorage();
        renderTaskList();
        renderCalendar();
    } else {
        console.warn(`Task with ID ${taskId} not found for deletion.`);
    }
}

/**
 * Rendering Functions
 */

/**
 * Generates the HTML structure for the monthly calendar grid.
 */
function renderCalendar() {
    const calendarView = document.getElementById('calendar-view');
    if (!calendarView) return;

    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth();

    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);

    const startDay = firstDayOfMonth.getDay(); // 0 (Sunday) to 6 (Saturday)
    const daysInMonth = lastDayOfMonth.getDate();

    let calendarHTML = `<h2>Calendar View</h2><div class="calendar-grid">`;

    // Day headers (Sun, Mon, Tue, etc.)
    const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    daysOfWeek.forEach(day => {
        calendarHTML += `<div class="calendar-date header">${day}</div>`;
    });

    // Calendar grid
    for (let i = 1; i <= daysInMonth; i++) {
        const currentDate = new Date(year, month, i);
        const dateString = currentDate.toISOString().split('T')[0];
        const dayClass = currentDate.toDateString() === today.toDateString() ? 'today' : '';
        
        let cellContent = `<div class="calendar-date ${dayClass}" data-date="${dateString}">${i}</div>`;

        // Check for tasks on this date
        const tasksOnDate = appState.tasks.filter(task => task.dueDate === dateString);
        if (tasksOnDate.length > 0) {
            cellContent += `<div class="task-indicator" title="${tasksOnDate.map(t => t.title).join(', ')}">📅</div>`;
        }

        calendarHTML += cellContent;
    }

    calendarHTML += `</div>`;
    calendarView.innerHTML = calendarHTML;
}

/**
 * Generates the HTML structure for the task list.
 */
function renderTaskList() {
    const taskListView = document.getElementById('task-list');
    if (!taskListView) return;

    // 1. Sort tasks by due date (ascending)
    const sortedTasks = [...appState.tasks].sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate));

    let taskHTML = `<h2>Task List</h2><div class="task-list">`;

    if (sortedTasks.length === 0) {
        taskHTML += `<p>No tasks found. Add a new task!</p>`;
    } else {
        sortedTasks.forEach(task => {
            const completedClass = task.isComplete ? 'completed' : '';
            taskHTML += `
                <div class="task-card ${completedClass}" data-task-id="${task.id}">
                    <h3>${task.title}</h3>
                    <p>Due Date: ${task.dueDate}</p>
                    <div class="task-actions">
                        <button class="update-btn" data-task-id="${task.id}">Update</button>
                        <button class="delete-btn" data-task-id="${task.id}">Delete</button>
                    </div>
                </div>
            `;
        });
    }

    taskHTML += `</div>`;
    taskListView.innerHTML = taskHTML;
}

/**
 * Theme Switching Functionality
 */

/**
 * Switches the application theme between Light Mode and Dark Mode.
 */
function toggleTheme() {
    const body = document.body;
    const currentTheme = appState.theme;
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';

    if (newTheme === 'dark') {
        body.classList.add('dark-mode');
        appState.theme = 'dark';
        localStorage.setItem('theme', 'dark');
    } else {
        body.classList.remove('dark-mode');
        appState.theme = 'light';
        localStorage.setItem('theme', 'light');
    }
}

/**
 * Event Listener Setup
 */

/**
 * Attaches all necessary event listeners to the DOM elements.
 */
function setupEventListeners() {
    // Theme Toggle Listener
    const themeButton = document.getElementById('theme_toggle_button');
    if (themeButton) {
        themeButton.addEventListener('click', toggleTheme);
    }

    // Task Form Submission Listener (Delegation)
    const taskForm = document.getElementById('task-form');
    if (taskForm) {
        taskForm.addEventListener('submit', handleAddTask);
    }

    // Task List Delegation (Update/Delete)
    const taskListContainer = document.querySelector('.task-list');
    if (taskListContainer) {
        taskListContainer.addEventListener('click', handleTaskActions);
    }

    // Calendar Navigation (Placeholder for future implementation)
    // Note: Actual calendar navigation logic is complex and omitted here as it requires more specific DOM structure, but the hook is established.
    // attachCalendarNavigationListener(); 
}

/**
 * Event Handlers (Delegation)
 */

/**
 * Handles the submission of the task form.
 */
function handleAddTask(event) {
    event.preventDefault();
    const titleInput = document.getElementById('task-title');
    const dateInput = document.getElementById('task_due_date');

    const title = titleInput.value.trim();
    const dueDate = dateInput.value.trim();

    if (title && dueDate) {
        addTask(title, dueDate);
        titleInput.value = '';
        dateInput.value = '';
    } else {
        alert("Please enter both a title and a due date.");
    }
}

/**
 * Handles clicks on task action buttons (Update/Delete).
 */
function handleTaskActions(event) {
    const target = event.target;
    const taskId = parseInt(target.dataset.taskId);

    if (target.classList.contains('delete-btn')) {
        if (confirm("Are you sure you want to delete this task?")) {
            deleteTask(taskId);
        }
    } else if (target.classList.contains('update-btn')) {
        // In a full implementation, this would open a modal. For this manifest, we simulate a simple update flow.
        const newTitle = prompt("Enter new title:", appState.tasks.find(t => t.id === taskId).title);
        if (newTitle !== null && newTitle.trim() !== "") {
            const newDate = prompt("Enter new due date (YYYY-MM-DD):", appState.tasks.find(t => t.id === taskId).dueDate);
            const isComplete = confirm("Mark this task as complete?");

            if (newDate && newTitle.trim() && isComplete === true) {
                updateTask(taskId, newTitle.trim(), newDate.trim(), true);
            } else if (newDate && newTitle.trim()) {
                 updateTask(taskId, newTitle.trim(), newDate.trim(), false);
            }
        }
    }
}

/**
 * Initialization Function
 */

/**
 * The main entry point function. Initializes the application.
 */
function initDashboard() {
    // 1. Load Data (Hydration)
    loadTasksFromStorage();

    // 2. Initial Rendering
    renderCalendar();
    renderTaskList();

    // 3. Setup Event Listeners
    setupEventListeners();
}

// Execute the initialization when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', initDashboard);