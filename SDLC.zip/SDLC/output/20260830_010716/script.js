// =============================================================================
// Offline-First Local Data Architecture & Application Logic (script.js)
// =============================================================================

// --- Central Data Store (The Ledger) ---
let invoices = [];
const STORAGE_KEY = 'invoices_ledger';

/**
 * Helper function to safely retrieve data from localStorage.
 * @param {string} key - The key to retrieve.
 * @returns {any} The parsed data or an empty array if error occurs.
 */
function loadLedger() {
    try {
        const data = localStorage.getItem(STORAGE_KEY);
        return data ? JSON.parse(data) : [];
    } catch (error) {
        console.error("Error parsing localStorage data. Data might be corrupted.", error);
        return [];
    }
}

/**
 * Helper function to save the entire ledger back to localStorage.
 * @param {Array} data - The array to save.
 */
function saveLedger(data) {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (error) {
        console.error("Error saving data to localStorage.", error);
    }
}

// =============================================================================
// Core Data Management Functions
// =============================================================================

/**
 * Generates a unique, system-defined identifier for a new invoice.
 * @returns {string} A unique ID.
 */
function generateInvoiceId() {
    return Date.now().toString(36) + Math.random().toString(36).substring(2);
}

/**
 * Saves the current state of an invoice object to localStorage.
 * @param {object} invoice - The invoice object to save.
 */
function saveInvoice(invoice) {
    invoices.push(invoice);
    saveLedger(invoices);
    console.log("Invoice saved successfully.");
}

/**
 * Updates the core data structure of a specific saved invoice.
 * @param {string} id - The ID of the invoice to update.
 * @param {object} newData - The new data to merge.
 */
function updateInvoiceData(id, newData) {
    const index = invoices.findIndex(inv => inv.id === id);
    if (index === -1) {
        console.error(`Invoice with ID ${id} not found for update.`);
        return false;
    }

    // Merge new data
    invoices[index] = { ...invoices[index], ...newData };

    // Recalculate totals after update
    calculateTotals(invoices[index]);

    saveLedger(invoices);
    console.log(`Invoice ${id} updated successfully.`);
    return true;
}

/**
 * Retrieves all saved invoice objects from localStorage and renders them to the UI.
 */
function loadInvoices() {
    const savedInvoices = loadLedger();
    invoices = savedInvoices; // Update the central ledger
    renderSavedInvoicesList(savedInvoices);
}

/**
 * Renders the list of saved invoices to the DOM.
 * @param {Array} invoicesToRender - The array of invoices to display.
 */
function renderSavedInvoicesList(invoicesToRender) {
    const listContainer = document.getElementById('saved-invoices-list');
    listContainer.innerHTML = '<h2>Saved Invoices</h2>'; // Clear previous list

    if (invoicesToRender.length === 0) {
        listContainer.innerHTML += '<p>No invoices found.</p>';
        return;
    }

    invoicesToRender.forEach(invoice => {
        const invoiceElement = document.createElement('div');
        invoiceElement.className = 'invoice-card';
        invoiceElement.innerHTML = `
            <h3>${invoice.invoiceNumber} (${invoice.clientName})</h3>
            <p>Date: ${invoice.invoiceDate}</p>
            <p>Total: $${invoice.grandTotal.toFixed(2)}</p>
            <button class="btn load-btn" data-id="${invoice.id}">Load Invoice</button>
        `;
        listContainer.appendChild(invoiceElement);
    });

    // Attach event listeners for loading
    document.querySelectorAll('.load-btn').forEach(button => {
        button.addEventListener('click', (e) => {
            const id = e.target.dataset.id;
            loadInvoice(id);
        });
    });
}

/**
 * Loads a specific invoice into the form for editing.
 * @param {string} id - The ID of the invoice to load.
 */
function loadInvoice(id) {
    const invoice = invoices.find(inv => inv.id === id);
    if (!invoice) {
        displayErrorMessage("Error: Invoice not found.");
        return;
    }

    // Populate form fields
    document.getElementById('invoice-number').value = invoice.invoiceNumber;
    document.getElementById('client-name').value = invoice.clientName;
    document.getElementById('invoice-date').value = invoice.invoiceDate;

    // Clear line items and recalculate
    document.getElementById('line-items-body').innerHTML = '';
    invoices = invoices.filter(inv => inv.id !== id); // Temporarily remove from active list
    
    // Re-render the form based on the loaded data
    renderInvoiceForm(invoice);
    
    // Re-render the saved list to reflect the change (optional, but good practice)
    loadInvoices();
}


// =============================================================================
// Invoice Calculation & Rendering Functions
// =============================================================================

/**
 * Performs all necessary financial calculations for the invoice.
 * @param {object} invoice - The invoice object to calculate.
 */
function calculateTotals(invoice) {
    let subtotal = 0;
    invoice.items.forEach(item => {
        subtotal += item.quantity * item.unitPrice;
    });

    const taxRate = 0.10; // Fixed tax rate based on manifest
    const taxAmount = subtotal * taxRate;
    const grandTotal = subtotal + taxAmount;

    invoice.subtotal = subtotal;
    invoice.taxAmount = taxAmount;
    invoice.grandTotal = grandTotal;
}

/**
 * Dynamically generates and updates the HTML form fields based on the current invoice data.
 * @param {object} invoice - The invoice data to render.
 */
function renderInvoiceForm(invoice) {
    document.getElementById('invoice-number').value = invoice.invoiceNumber || '';
    document.getElementById('client-name').value = invoice.clientName || '';
    document.getElementById('invoice-date').value = invoice.invoiceDate || '';

    // Render line items
    const tbody = document.getElementById('line-items-body');
    tbody.innerHTML = '';

    invoice.items.forEach((item, index) => {
        const row = tbody.insertRow();
        row.innerHTML = `
            <td><input type="text" name="item_desc" value="${item.description}" required></td>
            <td><input type="number" name="item_qty" value="${item.quantity}" required></td>
            <td><input type="number" step="0.01" name="item_price" value="${item.unitPrice.toFixed(2)}" required></td>
            <td><button type="button" class="remove-item-btn" data-index="${index}">Remove</button></td>
        `;
    });

    // Render totals
    document.getElementById('subtotal').textContent = invoice.subtotal.toFixed(2);
    document.getElementById('tax-amount').textContent = invoice.taxAmount.toFixed(2);
    document.getElementById('grand-total').textContent = invoice.grandTotal.toFixed(2);
}

/**
 * Generates the final, print-optimized HTML representation of the invoice.
 * @param {object} invoice - The invoice data to print.
 */
function renderInvoicePreview(invoice) {
    const previewDiv = document.getElementById('invoice-preview');
    let html = `
        <div class="invoice-details">
            <h1>Invoice #${invoice.invoiceNumber}</h1>
            <p><strong>Client:</strong> ${invoice.clientName}</p>
            <p><strong>Date:</strong> ${invoice.invoiceDate}</p>
            <hr>
            <table class="invoice-table">
                <thead>
                    <tr>
                        <th>Description</th>
                        <th>Quantity</th>
                        <th>Unit Price</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
    `;

    invoice.items.forEach(item => {
        const amount = (item.quantity * item.unitPrice).toFixed(2);
        html += `
            <tr>
                <td>${item.description}</td>
                <td>${item.quantity}</td>
                <td>$${item.unitPrice.toFixed(2)}</td>
                <td>$${amount}</td>
            </tr>
        `;
    });

    html += `
                </tbody>
            </table>
            <div class="totals-section">
                <p>Subtotal: $${invoice.subtotal.toFixed(2)}</p>
                <p>Tax (10%): $${invoice.taxAmount.toFixed(2)}</p>
                <h3>Grand Total: $${invoice.grandTotal.toFixed(2)}</h3>
            </div>
        </div>
    `;

    previewDiv.innerHTML = html;
    document.getElementById('invoice-preview').classList.remove('hidden');
}

/**
 * Handles the logic for adding a new line item to the currently active invoice.
 * @param {object} invoice - The current invoice object.
 */
function addItemToInvoice(invoice) {
    const descInput = document.querySelector('input[name="item_desc"]');
    const qtyInput = document.querySelector('input[name="item_qty"]');
    const priceInput = document.querySelector('input[name="item_price"]');

    const description = descInput.value.trim();
    const quantity = parseFloat(qtyInput.value);
    const unitPrice = parseFloat(priceInput.value);

    // Validation (NFR 3.2.3)
    if (!description || isNaN(quantity) || isNaN(unitPrice) || quantity <= 0 || unitPrice <= 0) {
        displayErrorMessage("Please enter valid description, quantity, and price for the item.");
        return false;
    }

    const newItem = {
        description: description,
        quantity: quantity,
        unitPrice: unitPrice,
    };

    invoice.items.push(newItem);

    // Recalculate and save
    calculateTotals(invoice);
    saveInvoice(invoice);
    renderInvoiceForm(invoice); // Re-render the form to show the new item
    return true;
}

/**
 * Processes the data submitted from the invoice creation form.
 * @param {Event} event - The form submission event.
 */
function handleFormSubmission(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);

    const invoiceId = formData.get('invoice_id') || generateInvoiceId(); // Use existing ID or generate new one
    const invoiceDate = formData.get('invoice_date');
    const clientName = formData.get('client_name');

    const items = [];
    let isValid = true;

    // Collect and validate line items
    for (let i = 0; i < formData.getAll('item_desc').length; i++) {
        const desc = formData.get(`item_desc${i}`);
        const qty = parseFloat(formData.get(`item_qty${i}`));
        const price = parseFloat(formData.get(`item_price${i}`));

        if (!desc || isNaN(qty) || isNaN(price) || qty <= 0 || price <= 0) {
            displayErrorMessage("Please correct the errors in the line items.");
            isValid = false;
            break;
        }

        items.push({ description: desc, quantity: qty, unitPrice: price });
    }

    if (!isValid) return;

    const newInvoice = {
        id: invoiceId,
        invoiceNumber: formData.get('invoice_number') || `INV-${Date.now()}`,
        clientName: clientName,
        invoiceDate: invoiceDate,
        items: items,
        subtotal: 0,
        taxAmount: 0,
        grandTotal: 0,
    };

    // Final calculation and save
    calculateTotals(newInvoice);
    saveInvoice(newInvoice);

    // Clear form and show success
    form.reset();
    displayErrorMessage(`Invoice ${newInvoice.invoiceNumber} successfully created and saved!`);
    
    // Refresh the list
    loadInvoices();
}

/**
 * Triggers the browser's native print dialog.
 */
function handlePrint() {
    const invoiceToPrint = invoices.find(inv => inv.id === document.getElementById('current-invoice-id')?.value);

    if (!invoiceToPrint) {
        displayErrorMessage("Please load an invoice before attempting to print.");
        return;
    }

    // 1. Render the print-optimized view
    renderInvoicePreview(invoiceToPrint);

    // 2. Trigger print dialog
    window.print();
}

/**
 * Displays user-friendly error feedback.
 * @param {string} message - The error message to display.
 */
function displayErrorMessage(message) {
    const errorElement = document.getElementById('error-message');
    errorElement.textContent = message;
    errorElement.style.color = 'red';
    setTimeout(() => {
        errorElement.textContent = '';
    }, 5000);
}


// =============================================================================
// Application Initialization
// =============================================================================

/**
 * Initializes the application. Loads saved invoices and sets up event listeners.
 */
function initApplication() {
    console.log("Application initializing...");

    // 1. Load data from storage
    loadInvoices();

    // 2. Set up event listeners
    setupEventListeners();
}

/**
 * Sets up all necessary DOM event listeners.
 */
function setupEventListeners() {
    // Event listener for form submission
    document.getElementById('invoice-form').addEventListener('submit', handleFormSubmission);

    // Event listener for generating print
    document.getElementById('generate_print_btn').addEventListener('click', handlePrint);

    // Event delegation for removing line items
    document.getElementById('line-items-body').addEventListener('click', (e) => {
        if (e.target.classList.contains('remove-item-btn')) {
            const index = parseInt(e.target.dataset.index);
            const currentInvoiceId = document.getElementById('current-invoice-id')?.value;
            
            if (!currentInvoiceId) {
                displayErrorMessage("Please load an invoice before removing items.");
                return;
            }

            const invoice = invoices.find(inv => inv.id === currentInvoiceId);
            if (invoice && index >= 0 && index < invoice.items.length) {
                invoice.items.splice(index, 1);
                calculateTotals(invoice);
                saveInvoice(invoice);
                renderInvoiceForm(invoice);
            }
        }
    });
}

// Execute initialization when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', initApplication);