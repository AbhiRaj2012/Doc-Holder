```javascript
const STORAGE_KEY = 'taskAgendaTasks';

// --- Utility Functions ---

/**
 * Retrieves the current task array from localStorage.
 * Implements safe parsing.
 * @returns {Array<TaskObject>} The loaded task array, or an empty array if loading fails.
 */
function loadTasks() {
    try {
        const data = localStorage.getItem(STORAGE_KEY);
        if (data) {
            return JSON.parse(data);
        }
        return [];
    } catch (error) {
        console.error("Error loading tasks from localStorage:", error);
        return [];
    }
}

/**
 * Saves the task array to localStorage.
 * Implements the persistence rule.
 * @param {Array<TaskObject>} tasksArray The array of tasks to save.
 * @returns {void}
 */
function saveTasks(tasksArray) {
    try {
        const data = JSON.stringify(tasksArray);
        localStorage.setItem(STORAGE_KEY, data);
    } catch (error) {
        console.error("Error saving tasks to localStorage:", error);
    }
}

/**
 * Helper function to format a date as YYYY-MM-DD string.
 * @param {Date} date The Date object.
 * @returns {string} Formatted date string.
 */
function formatDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// --- Data Layer ---

/**
 * Retrieves the task data from localStorage, parses the JSON string, and returns the task array.
 * @returns {Array<TaskObject>}
 */
const data_layer = {
    loadTasks: function() {
        return loadTasks();
    },

    /**
     * Serializes the provided task array into a JSON string and stores it in localStorage.
     * @param {Array<TaskObject>} tasksArray
     * @returns {void}
     */
    saveTasks: function(tasksArray) {
        saveTasks(tasksArray);
    },

    /**
     * Adds a new task object to the task array and immediately triggers a save operation.
     * @param {TaskObject} taskObject The new task to add.
     * @returns {void}
     */
    addTask: function(taskObject) {
        const tasks = loadTasks();
        tasks.push(taskObject);
        saveTasks(tasks);
    },

    /**
     * Removes a task from the array based on its unique ID and triggers a save operation.
     * @param {number} taskId The ID of the task to delete.
     * @returns {void}
     */
    deleteTask: function(taskId) {
        let tasks = loadTasks();
        tasks = tasks.filter(task => task.id !== taskId);
        saveTasks(tasks);
    }
};

// --- View Layer ---

/**
 * Dynamically generates and injects the HTML elements for the task list panel.
 * @param {Array<TaskObject>} tasksArray
 * @returns {void}
 */
const view_layer = {
    renderTaskList: function(tasksArray) {
        const container = document.getElementById('task_list_container');
        container.innerHTML = '';

        if (tasksArray.length === 0) {
            container.innerHTML = '<p style="text-align: center; color: var(--color-text-muted);">No tasks found. Add a new task!</p>';
            return;
        }

        tasksArray.forEach(task => {
            const taskElement = document.createElement('div');
            taskElement.className = 'task-item';
            taskElement.innerHTML = `
                <div class="task-title">${task.title}</div>
                <div class="task-date">${task.date}</div>
                <button class="delete-task-btn" data-task-id="${task.id}">Delete</button>
            `;
            container.appendChild(taskElement);
        });

        // Attach event listeners for deletion
        document.querySelectorAll('.delete-task-btn').forEach(button => {
            button.addEventListener('click', (e) => {
                const taskId = parseInt(e.target.dataset.taskId);
                data_layer.deleteTask(taskId);
                // Re-render the list after deletion
                loadTasks().then(tasks => view_layer.renderTaskList(tasks));
            });
        });
    },

    /**
     * Generates the HTML grid structure for the calendar view for a specified month.
     * @param {Array<TaskObject>} tasksArray
     * @param {number} currentMonth The zero-indexed month (0-11).
     * @returns {void}
     */
    renderCalendar: function(tasksArray, currentMonth) {
        const calendarGrid = document.getElementById('calendar_grid');
        calendarGrid.innerHTML = '';

        const year = new Date();
        const month = currentMonth;

        // 1. Calculate month boundaries
        const firstDayOfMonth = new Date(year, month, 1);
        const lastDayOfMonth = new Date(year, month + 1, 0);

        // 2. Determine starting day (0=Sun, 6=Sat)
        const startDayOfWeek = firstDayOfMonth.getDay();
        const daysInMonth = lastDayOfMonth.getDate();

        // 3. Add leading empty cells for alignment
        for (let i = 0; i < startDayOfWeek; i++) {
            const emptyCell = document.createElement('div');
            emptyCell.className = 'calendar-day empty';
            calendarGrid.appendChild(emptyCell);
        }

        // 4. Add actual days
        for (let day = 1; day <= daysInMonth; day++) {
            const date = new Date(year, month, day);
            const dateString = formatDate(date);
            const dayCell = document.createElement('div');
            dayCell.className = 'calendar-day';
            dayCell.dataset.date = dateString;
            dayCell.innerHTML = `<div class="day-number">${day}</div><div class="day-date">${dateString}</div>`;
            calendarGrid.appendChild(dayCell);
        }
    },

    /**
     * Iterates through all tasks and applies the appropriate CSS class to the corresponding date cells in the calendar.
     * @param {Array<TaskObject>} tasksArray
     * @returns {void}
     */
    highlightDates: function(tasksArray) {
        document.querySelectorAll('.calendar-day').forEach(cell => {
            const dateString = cell.dataset.date;
            if (!dateString) return;

            const taskDate = new Date(dateString);

            // Check if the task date falls within the current month being displayed
            if (taskDate.getMonth() === new Date().getMonth() && taskDate.getFullYear() === new Date().getFullYear()) {
                // Check if the date matches any task date
                const isTaskDate = tasksArray.some(task => task.date === dateString);

                if (isTaskDate) {
                    cell.classList.add('task-highlight');
                }
            }
        });
    },

    /**
     * Displays a modal or tooltip listing all tasks associated with a specific date clicked in the calendar.
     * @param {string} date The date string (YYYY-MM-DD) clicked.
     * @returns {void}
     */
    displayTaskModal: function(date) {
        const tasks = loadTasks();
        const modalDetails = document.getElementById('modal_details');
        modalDetails.innerHTML = '';

        const filteredTasks = tasks.filter(task => task.date === date);

        if (filteredTasks.length === 0) {
            modalDetails.innerHTML = `<p>No tasks found for ${date}.</p>`;
        } else {
            filteredTasks.forEach(task => {
                const detail = document.createElement('div');
                detail.className = 'task-detail-item';
                detail.innerHTML = `
                    <h4>${task.title}</h4>
                    <p>Due Date: ${task.date}</p>
                `;
                modalDetails.appendChild(detail);
            });
        }

        document.getElementById('task_detail_modal').classList.add('active');
    }
};

// --- Controller Layer ---

/**
 * Handles the event triggered when a user submits a form to add a new task.
 * @param {Event} event The form submission event.
 * @returns {void}
 */
const controller_layer = {
    handleTaskSubmission: function(event) {
        event.preventDefault();

        const titleInput = document.getElementById('input_title');
        const dateInput = document.getElementById('input_date');

        const title = titleInput.value.trim();
        const date = dateInput.value;

        if (!title || !date) {
            alert("Please enter both a task title and a due date.");
            return;
        }

        const newTask = {
            id: Date.now(), // Simple unique ID generation
            title: title,
            date: date
        };

        data_layer.addTask(newTask);

        // Re-initialize the dashboard to reflect changes
        controller_layer.initializeDashboard();
    },

    /**
     * Handles the click event on a date cell in the calendar, triggering the display of related tasks.
     * @param {string} date The clicked date (YYYY-MM-DD).
     * @returns {void}
     */
    handleCalendarClick: function(date) {
        view_layer.displayTaskModal(date);
    },

    /**
     * The main entry point. Loads data and triggers the initial rendering of both the task list and the calendar.
     * @returns {void}
     */
    initializeDashboard: function() {
        const tasks = data_layer.loadTasks();

        // 1. Render Task List
        view_layer.renderTaskList(tasks);

        // 2. Render Calendar
        const today = new Date();
        const currentMonth = today.getMonth();
        view_layer.renderCalendar(tasks, currentMonth);

        // 3. Highlight Dates
        view_layer.highlightDates(tasks);
    }
};

// --- Event Listeners and Initialization ---

document.addEventListener('DOMContentLoaded', () => {
    // Initialize the dashboard upon loading
    controller_layer.initializeDashboard();

    // Attach event listener for adding a task
    document.getElementById('task_input_form').addEventListener('submit', controller_layer.handleTaskSubmission);

    // Attach event listener for calendar clicks (delegation)
    document.getElementById('calendar_grid').addEventListener('click', (event) => {
        const target = event.target.closest('.calendar-day');
        if (target) {
            const date = target.dataset.date