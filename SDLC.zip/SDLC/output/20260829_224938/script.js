```javascript
const STORAGE_KEY = 'billingInvoices';

// --- Internal State Management (The Ledger) ---
let invoices = [];
let currentInvoiceState = null; // Holds the data for the invoice currently being edited
let invoiceListDOM = document.getElementById('line-items');
let invoicePreviewDOM = document.getElementById('invoice-preview');
let customerInputFields = {
    name: document.getElementById('customer-name'),
    address: document.getElementById('customer-address')
};
let lineItemInputs = document.getElementById('line-items');

/**
 * Helper function to save the current state to localStorage (The Ledger).
 * @param {Array} data - The array of invoices to save.
 */
function saveLedger(data) {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (error) {
        console.error("Error saving data to localStorage:", error);
    }
}

/**
 * Helper function to load the state from localStorage.
 * @returns {Array} The loaded array of invoices, or an empty array if loading fails.
 */
function loadLedger() {
    try {
        const data = localStorage.getItem(STORAGE_KEY);
        if (data) {
            invoices = JSON.parse(data);
        } else {
            invoices = [];
        }
        return invoices;
    } catch (error) {
        console.error("Error loading data from localStorage:", error);
        invoices = []; // Fallback to empty array on error
        return invoices;
    }
}

// --- data_persistence Functions ---

/**
 * Retrieves all saved invoices from localStorage and populates the invoice list view.
 * @returns {Array} Array of invoice objects.
 */
function loadInvoices() {
    const loadedInvoices = loadLedger();
    // Update the global state
    invoices = loadedInvoices;
    // Render the list
    renderInvoiceList(invoices);
    return invoices;
}

/**
 * Serializes the current invoice data and saves it to localStorage.
 * @param {Object} invoiceData - The invoice object to save.
 * @returns {void}
 */
function saveInvoice(invoiceData) {
    // Ensure the invoice has an ID for proper storage
    if (!invoiceData.id) {
        invoiceData.id = Date.now().toString();
    }
    
    // Update the global state
    const index = invoices.findIndex(inv => inv.id === invoiceData.id);
    if (index !== -1) {
        invoices[index] = invoiceData;
    } else {
        invoices.push(invoiceData);
    }

    // Save the updated ledger immediately
    saveLedger(invoices);
    console.log("Invoice saved successfully.");
}

/**
 * Retrieves a specific invoice by ID from localStorage and populates the editing form.
 * @param {string} invoiceId - The ID of the invoice to load.
 * @returns {Object|null} Invoice object or null if not found.
 */
function loadInvoice(invoiceId) {
    const invoice = invoices.find(inv => inv.id === invoiceId);
    if (invoice) {
        currentInvoiceState = { ...invoice }; // Deep copy for editing
        populateForm(currentInvoiceState);
        return currentInvoiceState;
    }
    return null;
}

/**
 * Removes a specific invoice from localStorage.
 * @param {string} invoiceId - The ID of the invoice to delete.
 * @returns {void}
 */
function deleteInvoice(invoiceId) {
    const initialLength = invoices.length;
    invoices = invoices.filter(inv => inv.id !== invoiceId);
    
    if (invoices.length < initialLength) {
        saveLedger(invoices);
        console.log(`Invoice ${invoiceId} deleted successfully.`);
    } else {
        console.warn(`Invoice with ID ${invoiceId} not found.`);
    }
}

// --- invoice_management Functions ---

/**
 * Resets the current invoice state to default values, preparing for a new invoice creation.
 * @returns {void}
 */
function initNewInvoice() {
    currentInvoiceState = {
        id: '',
        date: new Date().toISOString().split('T')[0],
        customerName: '',
        customerAddress: '',
        lineItemsArray: [],
        taxRate: 0.10, // Default tax rate
        subtotal: 0,
        tax: 0,
        grandTotal: 0
    };
    
    // Reset DOM inputs
    customerInputFields.name.value = '';
    customerInputFields.address.value = '';
    
    // Clear line items
    lineItemInputs.innerHTML = '';
    
    // Reset totals
    currentInvoiceState.subtotal = 0;
    currentInvoiceState.tax = 0;
    currentInvoiceState.grandTotal = 0;
}

/**
 * Adds a new line item to the current invoice, including input validation.
 * @param {string} description - The item description.
 * @param {number} quantity - The quantity of the item.
 * @param {number} unitPrice - The unit price.
 * @returns {void}
 */
function addItemToInvoice(description, quantity, unitPrice) {
    if (!currentInvoiceState) {
        console.error("Cannot add item: No current invoice state exists.");
        return;
    }

    const qty = parseFloat(quantity);
    const price = parseFloat(unitPrice);

    if (isNaN(qty) || isNaN(price) || qty <= 0 || price <= 0) {
        alert("Please enter valid positive numbers for quantity and price.");
        return;
    }

    const newItem = {
        description: description,
        quantity: qty,
        unitPrice: price,
        total: qty * price
    };

    currentInvoiceState.lineItemsArray.push(newItem);
    
    // Recalculate totals
    calculateTotals();
    
    // Update the DOM immediately
    renderLineItems(currentInvoiceState.lineItemsArray);
}

/**
 * Modifies the details of an existing line item.
 * @param {number} index - The index of the line item to update.
 * @param {string} field - The field to modify ('description', 'quantity', or 'unitPrice').
 * @param {string} value - The new value for the field.
 * @returns {void}
 */
function updateLineItem(index, field, value) {
    if (!currentInvoiceState || index < 0 || index >= currentInvoiceState.lineItemsArray.length) {
        console.error("Invalid line item index.");
        return;
    }

    const item = currentInvoiceState.lineItemsArray[index];
    
    if (field === 'quantity') {
        const qty = parseFloat(value);
        if (isNaN(qty) || qty <= 0) {
            alert("Quantity must be a positive number.");
            return;
        }
        item.quantity = qty;
        item.total = qty * item.unitPrice;
    } else if (field === 'unitPrice