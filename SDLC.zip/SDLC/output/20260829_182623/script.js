/**
 * script.js
 *
 * This script manages the application state, persistence (via localStorage),
 * and DOM manipulation for the task and calendar application.
 */

// --- Global State Initialization ---
let tasks = [];
let currentTheme = 'light'; // Default theme
let currentMonth = new Date().getMonth(); // Default to current month

// --- Utility Functions (Simulating external dependencies) ---

/**
 * Applies the theme class to the body element and updates the toggle state.
 * @param {string} theme - The theme to apply ('dark' or 'light').
 */
function applyTheme(theme) {
    document.body.classList.remove('theme-dark', 'theme-light');
    document.body.classList.add(`theme-${theme}`);
    updateThemeToggle(theme);
}

/**
 * Updates the theme toggle button state based on the current theme.
 * @param {string} theme - The current theme state.
 */
function updateThemeToggle(theme) {
    const toggleButton = document.getElementById('theme-toggle');
    if (toggleButton) {
        toggleButton.textContent = theme === 'dark' ? 'Switch to Light' : 'Switch to Dark';
    }
}

// --- Local Storage Handlers ---

/**
 * Retrieves and parses task data from localStorage.
 * @returns {Array<Object>} The loaded tasks array.
 */
function loadTasksFromStorage() {
    const storedTasks = localStorage.getItem(localStorage_tasks);
    if (storedTasks) {
        try {
            tasks = JSON.parse(storedTasks);
        } catch (e) {
            console.error("Error parsing tasks from localStorage:", e);
            tasks = [];
        }
    } else {
        tasks = [];
    }
    return tasks;
}

/**
 * Retrieves and sets the theme preference from localStorage and applies the theme.
 * @returns {void}
 */
function loadThemeFromStorage() {
    const storedTheme = localStorage.getItem(localStorage_theme);
    if (storedTheme) {
        currentTheme = storedTheme;
    } else {
        currentTheme = 'light'; // Default theme
    }
    applyTheme(currentTheme);
}

/**
 * Saves the current tasks array to localStorage.
 */
function saveTasksToStorage() {
    localStorage.setItem(localStorage_tasks, JSON.stringify(tasks));
}

/**
 * Saves the selected theme preference to localStorage and applies the theme.
 * @param {string} theme - The theme to save.
 * @returns {void}
 */
function saveTheme(theme) {
    localStorage.setItem(localStorage_theme, theme);
    applyTheme(theme);
}

// --- UI Rendering Functions ---

/**
 * Dynamically generates and populates the HTML for the task list panel.
 * @returns {void}
 */
function renderTaskList() {
    const taskListPanel = document.getElementById('task-list-panel');
    if (!taskListPanel) return;

    // Clear previous content
    taskListPanel.innerHTML = '';

    // Render tasks to the DOM
    renderTasksToDOM(tasks);
}

/**
 * Renders the task list items into the DOM.
 * @param {Array<Object>} taskArray - The array of tasks to display.
 * @returns {void}
 */
function renderTasksToDOM(taskArray) {
    const taskListPanel = document.getElementById('task-list-panel');
    if (!taskListPanel) return;

    taskArray.forEach(task => {
        const taskElement = document.createElement('li');
        taskElement.className = 'task-item';
        taskElement.innerHTML = `
            <span class="task-title">${task.title}</span>
            <button class="delete-task" data-id="${task.id}">Delete</button>
        `;
        taskListPanel.appendChild(taskElement);
    });

    // Attach event listeners for deletion
    document.querySelectorAll('.delete-task').forEach(button => {
        button.addEventListener('click', (e) => {
            const taskId = parseInt(e.target.dataset.id);
            deleteTask(taskId);
        });
    });
}

/**
 * Generates the calendar grid and marks tasks based on the current month.
 * @returns {void}
 */
function renderCalendar() {
    const calendarContainer = document.getElementById('calendar-view');
    if (!calendarContainer) return;

    // Clear previous content
    calendarContainer.innerHTML = '';

    // 1. Generate Calendar Grid (Simplified for manifest adherence)
    generateCalendarGrid(currentMonth);

    // 2. Render Tasks on Calendar
    renderTasksOnCalendar(tasks, currentMonth);
}

/**
 * Generates the basic calendar grid structure (placeholder implementation).
 * @param {number} month - The current month index (0-11).
 * @returns {void}
 */
function generateCalendarGrid(month) {
    // In a full implementation, this would generate the 7x6 grid structure.
    // For this manifest, we focus on the call structure.
    console.log(`Generating calendar grid for month: ${month}`);
}

/**
 * Renders task markers onto the calendar grid.
 * @param {Array<Object>} taskArray - The tasks.
 * @param {number} month - The current month being viewed.
 * @returns {void}
 */
function renderTasksOnCalendar(taskArray, month) {
    console.log(`Rendering ${taskArray.length} tasks onto the calendar for month ${month}.`);
    // Actual DOM manipulation logic would go here.
}


// --- Task Management Functions ---

/**
 * Adds a new task object to the global tasks array and saves the state.
 * @param {string} taskData - The title of the new task.
 * @returns {void}
 */
function addTaskToState(taskData) {
    const newTask = {
        id: Date.now(), // Simple unique ID
        title: taskData,
        completed: false
    };
    tasks.push(newTask);
    saveTasksToStorage();
    renderTaskList(); // Re-render the list
    renderCalendar(); // Re-render the calendar
}

/**
 * Deletes a task by its ID.
 * @param {number} taskId - The ID of the task to delete.
 * @returns {void}
 */
function deleteTask(taskId) {
    tasks = tasks.filter(task => task.id !== taskId);
    saveTasksToStorage();
    renderTaskList();
    renderCalendar();
}

// --- Initialization ---

/**
 * Loads all necessary data from localStorage and initializes the application state.
 * This function acts as the main hydration point.
 * @returns {void}
 */
function loadData() {
    console.log("Loading data from localStorage...");
    loadTasksFromStorage();
    loadThemeFromStorage();
    
    // Initial rendering after data is loaded
    renderTaskList();
    renderCalendar();
}

/**
 * Handles the form submission for adding a new task.
 * @param {Event} event - The form submit event.
 * @returns {void}
 */
function handleAddTask(event) {
    event.preventDefault();
    const input = document.getElementById('new-task-input');
    const taskData = input.value.trim();

    if (taskData) {
        addTaskToState(taskData);
        input.value = ''; // Clear input field
    } else {
        alert("Please enter a task title.");
    }
}

/**
 * Handles the theme toggle action.
 * @returns {void}
 */
function handleThemeToggle() {
    const newTheme = (currentTheme === 'dark' ? 'light' : 'dark');
    saveTheme(newTheme);
}


// --- Application Entry Point ---

document.addEventListener('DOMContentLoaded', () => {
    // 1. Load all persisted data
    loadData();

    // 2. Attach Event Listeners
    const addTaskForm = document.getElementById('add-task-form');
    if (addTaskForm) {
        addTaskForm.addEventListener('submit', handleAddTask);
    }

    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', handleThemeToggle);
    }

    // Ensure initial state is set correctly if data was loaded
    console.log("Application initialized successfully.");
});