```javascript
/**
 * Client-Side Billing Application - app.js
 * 
 * Implements the Offline-First Local Data Architecture and Modern CSS Layouts.
 */

// =============================================================================
// 1. Data Manager Module (Offline-First Local Data Architecture)
// =============================================================================
const dataManager = (function() {
    const STORAGE_KEY = 'billingInvoices';

    /**
     * Saves an invoice object to localStorage.
     * @param {object} invoiceData - The invoice object to save.
     */
    function saveInvoice(invoiceData) {
        try {
            const invoices = loadAllInvoices();
            invoices.push(invoiceData);
            localStorage.setItem(STORAGE_KEY, JSON.stringify(invoices));
            console.log('Invoice saved successfully.');
        } catch (error) {
            console.error('Error saving invoice to localStorage:', error);
            throw new Error('Failed to save data offline.');
        }
    }

    /**
     * Retrieves all invoice objects from localStorage.
     * @returns {Array<object>} An array of invoice objects.
     */
    function loadAllInvoices() {
        try {
            const data = localStorage.getItem(STORAGE_KEY);
            if (!data) {
                return [];
            }
            const invoices = JSON.parse(data);
            return invoices;
        } catch (error) {
            console.error('Error loading invoices from localStorage:', error);
            // Rule: Safe Parsing - return empty array on failure
            return [];
        }
    }

    /**
     * Retrieves a single invoice object based on its ID.
     * @param {string|number} id - The ID of the invoice to find.
     * @returns {object|undefined} The found invoice object.
     */
    function loadInvoiceById(id) {
        const invoices = loadAllInvoices();
        return invoices.find(invoice => invoice.id == id);
    }

    /**
     * Removes a specific invoice from localStorage.
     * @param {string|number} id - The ID of the invoice to delete.
     * @returns {boolean} True if the invoice was found and deleted, false otherwise.
     */
    function deleteInvoice(id) {
        try {
            let invoices = loadAllInvoices();
            const initialLength = invoices.length;
            invoices = invoices.filter(invoice => invoice.id != id);

            if (invoices.length < initialLength) {
                localStorage.setItem(STORAGE_KEY, JSON.stringify(invoices));
                console.log(`Invoice with ID ${id} deleted successfully.`);
                return true;
            } else {
                console.warn(`Invoice with ID ${id} not found for deletion.`);
                return false;
            }
        } catch (error) {
            console.error('Error deleting invoice from localStorage:', error);
            throw new Error('Failed to delete data offline.');
        }
    }

    return {
        saveInvoice,
        loadAllInvoices,
        loadInvoiceById,
        deleteInvoice
    };
})();

// =============================================================================
// 2. Calculation Engine Module (Business Logic)
// =============================================================================
const calculationEngine = (function() {

    /**
     * Calculates the subtotal for a single line item.
     * @param {object} item - The line item object (must contain quantity and price).
     * @returns {number} The calculated subtotal.
     */
    function calculateLineItemSubtotal(item) {
        const quantity = parseFloat(item.qty) || 0;
        const unitPrice = parseFloat(item.price) || 0;
        return quantity * unitPrice;
    }

    /**
     * Calculates all derived financial fields for an invoice.
     * @param {object} invoiceData - The full invoice object.
     * @returns {object} An object containing subtotal, tax, and total.
     */
    function calculateInvoiceTotals(invoiceData) {
        let subtotal = 0;
        let tax = 0;
        const TAX_RATE = 0.05; // 5% tax rate

        if (invoiceData.items && Array.isArray(invoiceData.items)) {
            invoiceData.items.forEach(item => {
                subtotal += calculateLineItemSubtotal(item);
            });
        }

        tax = subtotal * TAX_RATE;
        const total = subtotal + tax;

        return {
            subtotal: subtotal,
            tax: tax,
            total: total
        };
    }

    /**
     * Formats a numerical amount into a localized currency string.
     * @param {number} amount - The numerical amount to format.
     * @returns {string} The formatted currency string.
     */
    function formatCurrency(amount) {
        if (isNaN(amount)) return '$0.00';
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
        }).format(amount);
    }

    return {
        calculateLineItemSubtotal,
        calculateInvoiceTotals,
        formatCurrency
    };
})();

// =============================================================================
// 3. UI Renderer Module (DOM Manipulation)
// =============================================================================
const uiRenderer = (function() {
    const invoiceListContainer = document.getElementById('invoice-list-container');
    const invoicePreviewArea = document.getElementById('invoice-preview-area');
    const printButton = document.getElementById('print-invoice-btn');
    const errorMessageDisplay = document.getElementById('error-message-display');

    /**
     * Displays user-friendly feedback or errors.
     * @param {string} message - The message to display.
     * @param {string} type - The type of message (e.g., 'error', 'success').
     */
    function displayError(message, type = 'error') {
        errorMessageDisplay.textContent = message;
        errorMessageDisplay.className = `error-message ${type}-message`;
        errorMessageDisplay.style.display = 'block';
        setTimeout(() => {
            errorMessageDisplay.style.display = 'none';
        }, 5000);
    }

    /**
     * Dynamically generates the HTML list of all stored invoices.
     * @param {Array<object>} invoices - The array of invoice objects.
     */
    function renderInvoiceList(invoices) {
        invoiceListContainer.innerHTML = '';

        if (invoices.length === 0) {
            document.getElementById('no-invoices-message').style.display = 'block';
            return;
        }
        document.getElementById('no-invoices-message').style.display = 'none';

        invoices.forEach(invoice => {
            const card = document.createElement('div');
            card.className = 'invoice-card';
            card.setAttribute('data-invoice-id', invoice.id);
            card.innerHTML = `
                <h3>Invoice #${invoice.id}</h3>
                <p>Date: ${new Date(invoice.date).toLocaleDateString()}</p>
                <p>Total: ${calculationEngine.formatCurrency(invoice.totals.total)}</p>
            `;
            card.addEventListener('click', () => renderInvoicePreview(invoice));
            invoiceListContainer.appendChild(card);
        });
    }

    /**
     * Generates the HTML structure for the printable invoice document.
     * @param {object} invoiceData - The full invoice object.
     */
    function renderInvoicePreview(invoiceData) {
        let invoiceHtml = `
            <div class="invoice-document">
                <h1>Invoice #${invoiceData.id}</h1>
                <p>Date: ${new Date(invoiceData.date).toLocaleDateString()}</p>
                
                <h2>Line Items</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Description</th>
                            <th>Qty</th>
                            <th>Price</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        invoiceData.items.forEach(item => {
            const subtotal = calculationEngine.calculateLineItemSubtotal(item);
            invoiceHtml += `
                <tr>
                    <td>${item.desc}</td>
                    <td>${item.qty}</td>
                    <td>${calculationEngine.formatCurrency(item.price)}</td>
                    <td>${calculationEngine.formatCurrency(subtotal)}</td>
                </tr>
            `;
        });

        invoiceHtml += `
                    </tbody>
                </table>

                <h2>Totals</h2>
                <p>Subtotal: ${calculationEngine.formatCurrency(invoiceData.totals.subtotal)}</p>
                <p>Tax (5%): ${calculationEngine.formatCurrency(invoiceData.totals.tax)}</p>