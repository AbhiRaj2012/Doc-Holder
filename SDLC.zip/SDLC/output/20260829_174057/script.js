// --- 1. Data and Local Storage Management (Offline-First Architecture) ---

const LOCAL_STORAGE_KEY = "taskAgendaData";

/**
 * Retrieves data from localStorage.
 * @returns {Object|null} The stored data or null if not found.
 */
const localStorage = {
    getItem: (key) => {
        try {
            const data = localStorage.getItem(key);
            return data ? JSON.parse(data) : null;
        } catch (e) {
            console.error("Error reading from localStorage:", e);
            return null;
        }
    },
    setItem: (key, value) => {
        try {
            localStorage.setItem(key, JSON.stringify(value));
        } catch (e) {
            console.error("Error writing to localStorage:", e);
        }
    }
};

/**
 * Loads tasks from localStorage and populates the 'tasks' variable.
 * (FR 2.1.5)
 */
const loadTasks = () => {
    const data = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (data) {
        // Assuming the stored data is the array of tasks
        tasks = JSON.parse(data);
    } else {
        tasks = [];
    }
};

/**
 * Saves the current 'tasks' array back to localStorage.
 * (FR 2.1.5)
 */
const saveTasks = () => {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(tasks));
};

// --- 2. Theme Management ---

/**
 * Applies the correct theme class (light/dark) to the body element.
 * (FR 2.3.3)
 */
const applyTheme = () => {
    const theme = currentTheme || 'light';
    document.body.classList.remove('light', 'dark');
    document.body.classList.add(theme);
};

/**
 * Saves the user's preferred theme preference to localStorage.
 * (FR 2.3.3)
 */
const saveTheme = () => {
    const theme = document.body.classList.contains('dark') ? 'dark' : 'light';
    currentTheme = theme;
    localStorage.setItem('theme', theme);
};

/**
 * Handles the switching logic between Light and Dark modes.
 * (FR 2.3.3)
 */
const themeToggle = () => {
    const isDark = document.body.classList.contains('dark');
    const newTheme = isDark ? 'light' : 'dark';
    
    if (newTheme === 'dark') {
        document.body.classList.remove('light');
        document.body.classList.add('dark');
    } else {
        document.body.classList.remove('dark');
        document.body.classList.add('light');
    }
    
    saveTheme();
};

// --- 3. Rendering Functions ---

/**
 * Dynamically generates and inserts HTML elements for all tasks.
 * (FR 2.1.4)
 */
const renderTasks = (taskListContainer) => {
    taskListContainer.innerHTML = ''; // Clear existing content
    
    if (tasks.length === 0) {
        taskListContainer.innerHTML = '<p class="text-center text-gray-500 mt-4">No tasks found. Add a new one!</p>';
        return;
    }

    tasks.forEach((task, index) => {
        const taskElement = document.createElement('div');
        taskElement.className = `task-item p-4 mb-3 rounded-lg shadow-md transition duration-300 ${task.completed ? 'bg-green-100 border-l-4 border-green-500' : 'bg-white border-l-4 border-blue-500'}`;
        taskElement.innerHTML = `
            <div class="flex justify-between items-start">
                <span class="task-title font-semibold text-lg">${task.title}</span>
                <div class="flex space-x-2">
                    <button class="toggle-complete text-sm px-3 py-1 rounded transition ${task.completed ? 'bg-red-500 text-white' : 'bg-blue-500 text-white hover:bg-blue-600'}" data-index="${index}">
                        ${task.completed ? 'Undo' : 'Complete'}
                    </button>
                    <button class="delete-task text-sm text-red-500 hover:text-red-700" data-index="${index}">Delete</button>
                </div>
            </div>
            <p class="text-sm mt-2 text-gray-600">${task.date}</p>
        `;
        taskListContainer.appendChild(taskElement);
    });
};

/**
 * Generates the monthly calendar grid and highlights dates with tasks.
 * (FR 2.2.2)
 */
const renderCalendar = (calendarGrid) => {
    calendarGrid.innerHTML = '';
    
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth();

    // Create the calendar header
    const header = document.createElement('div');
    header.className = 'calendar-header text-center font-bold mb-4';
    header.innerHTML = `
        <button id="prev-month" class="text-xl mb-2 hover:text-blue-500">&lt;</button>
        <h2 id="current-month-year">${today.toLocaleString('default', { month: 'long', year: 'numeric' })}</h2>
        <button id="next-month" class="text-xl mt-2 hover:text-blue-500">&gt;</button>
    `;
    calendarGrid.appendChild(header);

    // Create the calendar grid
    const grid = document.createElement('div');
    grid.className = 'calendar-grid grid grid-cols-7 gap-1';

    // Calculate start day of the month
    const firstDayOfMonth = new Date(year, month, 1);
    // Calculate day of the week (0=Sun, 6=Sat)
    const startDayOfWeek = firstDayOfMonth.getDay();
    // Calculate total days in the month
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    // Add empty placeholders for preceding days
    for (let i = 0; i < startDayOfWeek; i++) {
        grid.appendChild(document.createElement('div'));
    }

    // Add actual days
    for (let day = 1; day <= daysInMonth; day++) {
        const date = new Date(year, month, day);
        const dateString = date.toISOString().split('T')[0]; // YYYY-MM-DD
        
        const dayCell = document.createElement('div');
        dayCell.className = `calendar-day p-2 text-center rounded-lg cursor-pointer transition duration-150 ${dateString === today.toISOString().split('T')[0] ? 'bg-blue-100 font-bold' : 'hover:bg-gray-100'}`;
        dayCell.textContent = day;
        dayCell.dataset.date = dateString;
        
        // Check for tasks on this date
        const hasTasks = tasks.some(task => task.date === dateString);
        if (hasTasks) {
            dayCell.classList.add('bg-blue-500', 'text-white');
        }

        grid.appendChild(dayCell);
    }
    
    calendarGrid.appendChild(grid);

    // Add event listeners for navigation and filtering
    document.getElementById('prev-month').addEventListener('click', () => changeMonth(-1));
    document.getElementById('next-month').addEventListener('click', () => changeMonth(1));
    document.querySelectorAll('.calendar-day').forEach(cell => {
        cell.addEventListener('click', () => handleCalendarClick(cell.dataset.date));
    });
};

/**
 * Handles the interaction when a date is clicked, filtering the task list.
 * (FR 2.2.3)
 * @param {string} dateString - The YYYY-MM-DD date clicked.
 */
const handleCalendarClick = (dateString) => {
    // Filter tasks based on the selected date
    const filteredTasks = tasks.filter(task => task.date === dateString);
    
    // Re-render the task list with the filtered results
    renderTasks(task-list-container);
    
    // Optional: Highlight the selected date
    document.querySelectorAll('.calendar-day').forEach(cell => cell.classList.remove('bg-blue-500', 'text-white'));
    document.querySelector(`.calendar-day[data-date="${dateString}"]`).classList.add('bg-blue-500', 'text-white');
};

/**
 * Helper function to change the displayed month.
 * @param {number} direction - -1 for previous, 1 for next.
 */
const changeMonth = (direction) => {
    const today = new Date();
    let date = new Date(today.getFullYear(), today.getMonth(), 1);
    date.setMonth(date.getMonth() + direction);
    
    // Re-render the calendar for the new month
    renderCalendar(calendar-grid);
};


// --- 4. Task Manipulation ---

/**
 * Removes a task from the array and triggers a save operation.
 * (FR 2.1.3, 2.1.5)
 * @param {number} index - The index of the task to delete.
 */
const deleteTask = (index) => {
    if (index >= 0 && index < tasks.length) {
        tasks.splice(index, 1);
        saveTasks();
        // Re-render the list
        renderTasks(task-list-container);
        // Re-render the calendar
        renderCalendar(calendar-grid);
    }
};

/**
 * Handles capturing input from the form and handles task creation/editing.
 * (FR 2.1.1, 2.1.2)
 * @param {Event} event - The submit event.
 */
const handleTaskInput = (event) => {
    event.preventDefault();

    const titleInput = document.getElementById('task-title');
    const dateInput = document.getElementById('task-date');

    const title = titleInput.value.trim();
    const date = dateInput.value;

    if (!title || !date) {
        alert("Please enter both a title and a date.");
        return;
    }

    // Add new task
    const newTask = {
        title: title,
        date: date,
        completed: false
    };

    tasks.push(newTask);
    saveTasks();

    // Re-render the UI
    renderTasks(task-list-container);
    renderCalendar(calendar-grid);

    // Clear the form
    titleInput.value = '';
    dateInput.value = '';
};


// --- 5. Initialization and Event Binding ---

/**
 * Initializes the application: loads data, sets up theme, and renders the UI.
 */
const init = () => {
    // 1. Load Data
    loadTasks();

    // 2. Apply Theme
    // Check if theme is explicitly set, otherwise default to light
    const storedTheme = localStorage.getItem('theme') || 'light';
    if (storedTheme === 'dark') {
        document.body.classList.add('dark');
    } else {
        document.body.classList.add('light');
    }
    currentTheme = storedTheme;

    // 3. Render UI
    renderTasks(task-list-container);
    renderCalendar(calendar-grid);

    // 4. Bind Event Listeners
    
    // Theme Toggle
    document.getElementById('theme-toggle').addEventListener('click', themeToggle);

    // Task Deletion (Delegation)
    task-list-container.addEventListener('click', (event) => {
        const target = event.target;
        
        // Delete Task
        if (target.classList.contains('delete-task')) {
            const index = parseInt(target.dataset.index);
            deleteTask(index);
        }
        
        // Toggle Completion
        if (target.classList.contains('toggle-complete')) {
            const index = parseInt(target.dataset.index);
            tasks[index].completed = !tasks[index].completed;
            saveTasks();
            renderTasks(task-list-container);
            renderCalendar(calendar-grid);
        }
    });

    // Task Submission
    document.getElementById('task-form').addEventListener('submit', handleTaskInput);
};

// Execute initialization when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', init);