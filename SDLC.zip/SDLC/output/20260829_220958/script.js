const appState = {
    data: [],
    filters: {
        by: 'all',
        value: '',
        label: ''
    },
    sort: {
        by: 'date',
        direction: 'asc'
    }
};

/**
 * Rule: Safe Parsing - Retrieves data from localStorage, handling potential errors.
 * Output: Populates the global appState object.
 */
function loadInitialState() {
    try {
        const storedState = localStorage.getItem('appStateLedger');
        if (storedState) {
            const loadedState = JSON.parse(storedState);
            // Merge loaded state, ensuring defaults are maintained if structure is missing
            appState.data = loadedState.data || [];
            appState.filters = loadedState.filters || appState.filters;
            appState.sort = loadedState.sort || appState.sort;
        } else {
            // Initialize default state if no data is found
            appState.data = [];
        }
    } catch (error) {
        console.error("Error loading state from localStorage:", error);
        // Fallback to default state if parsing fails
        appState.data = [];
    }
}

/**
 * Rule: Safe Parsing - Saves the current state to localStorage (The Ledger).
 * Rule: Persistent Storage - Save the ledger immediately after every array mutation.
 */
function saveState() {
    try {
        const stateToSave = {
            data: appState.data,
            filters: appState.filters,
            sort: appState.sort
        };
        localStorage.setItem('appStateLedger', JSON.stringify(stateToSave));
    } catch (error) {
        console.error("Error saving state to localStorage:", error);
    }
}

/**
 * Rule: Safe Parsing - Ensures all user-provided data is sanitized (XSS prevention).
 */
function sanitizeInput(input) {
    if (typeof input === 'string') {
        // Simple sanitization: strip HTML tags and escape potentially dangerous characters
        return input.replace(/<[^>]*>?/gm, '').trim();
    }
    return input;
}

/**
 * Rule: The Ledger System - Modifies the internal application state.
 * Output: Modifies the appState object.
 */
function updateAppState(newDataPoint) {
    // 1. Sanitize the input
    const sanitizedValue = sanitizeInput(newDataPoint.value);
    const sanitizedLabel = sanitizeInput(newDataPoint.label);

    // 2. Update the state
    appState.data.push({
        id: Date.now(), // Simple unique ID
        value: sanitizedValue,
        label: sanitizedLabel,
        date: new Date().toISOString() // Add date for sorting capability
    });

    // 3. Save the state immediately (The Ledger)
    saveState();

    // 4. Trigger the render cycle
    renderData();
}

/**
 * Rule: Processes the current appState data by applying active filters and sorting criteria.
 * Output: A filtered and sorted array of data ready for display.
 */
function applyFiltersAndSorting() {
    let data = [...appState.data];

    // 1. Filtering
    const filterBy = appState.filters.by;
    const filterValue = appState.filters.value.toLowerCase();
    const filterLabel = appState.filters.label.toLowerCase();

    if (filterBy === 'value' && filterValue) {
        data = data.filter(item => item.value.toLowerCase().includes(filterValue));
    } else if (filterBy === 'label' && filterLabel) {
        data = data.filter(item => item.label.toLowerCase().includes(filterLabel));
    } else if (filterBy === 'all') {
        // No filtering applied
    }

    // 2. Sorting
    const sortBy = appState.sort.by;
    const sortDirection = appState.sort.direction === 'asc' ? 1 : -1;

    data.sort((a, b) => {
        if (sortBy === 'value') {
            if (sortDirection === 1) return a.value.localeCompare(b.value);
            return b.value.localeCompare(a.value);
        }
        if (sortBy === 'label') {
            if (sortDirection === 1) return a.label.localeCompare(b.label);
            return b.label.localeCompare(a.label);
        }
        // Default sort by date (assuming date is always present)
        if (sortBy === 'date') {
            const dateA = new Date(a.date);
            const dateB = new Date(b.date);
            if (sortDirection === 1) return dateA - dateB;
            return dateB - dateA;
        }
        return 0;
    });

    return data;
}

/**
 * Rule: The core function responsible for dynamically updating the Document Object Model (DOM).
 * Output: Updates the UI based on the current filtered and sorted state.
 */
function renderData() {
    const filteredAndSortedData = applyFiltersAndSorting();
    const dataVisualizationElement = document.getElementById('data-visualization');
    const noDataMessage = document.getElementById('no-data-message');

    // Clear previous content
    dataVisualizationElement.innerHTML = '';

    if (filteredAndSortedData.length === 0) {
        noDataMessage.style.display = 'block';
        dataVisualizationElement.appendChild(noDataMessage);
        return;
    }

    noDataMessage.style.display = 'none';

    // Create and append data cards
    filteredAndSortedData.forEach(item => {
        const card = document.createElement('div');
        card.className = 'data-card';
        card.innerHTML = `
            <h3>${item.label}</h3>
            <p><strong>Value:</strong> ${item.value}</p>
            <p><strong>Date:</strong> ${new Date(item.date).toLocaleDateString()}</p>
        `;
        dataVisualizationElement.appendChild(card);
    });
}

/**
 * Rule: Attaches all necessary event listeners (e.g., input change, button clicks, filter changes) to the DOM elements.
 */
function attachEventListeners() {
    // 1. Data Submission Handler
    const dataForm = document.getElementById('data-form');
    if (dataForm) {
        dataForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const value = document.getElementById('data-value').value;
            const label = document.getElementById('data-label').value;

            if (value && label) {
                updateAppState({ value, label });
                dataForm.reset();
            } else {
                // Display error feedback
                const errorArea = document.getElementById('error_message_area');
                errorArea.textContent = 'Please fill in both value and label.';
                errorArea.className = 'feedback-area error-state';
            }
        });
    }

    // 2. Filter/Sort Control Handlers
    const applyFiltersButton = document.getElementById('apply-filters');
    if (applyFiltersButton) {
        applyFiltersButton.addEventListener('click', () => {
            // Update filter state based on select boxes
            appState.filters.by = document.getElementById('filter-by').value;
            appState.filters.value = document.getElementById('filter-by').value === 'value' ? document.getElementById('filter-value')?.value || '' : '';
            appState.filters.label = document.getElementById('filter-by').value === 'label' ? document.getElementById('filter-label')?.value || '' : '';

            // Re-apply filters and render
            renderData();
        });
    }

    // 3. Sort Control Handlers
    const sortBySelect = document.getElementById('sort-by');
    if (sortBySelect) {
        sortBySelect.addEventListener('change', (e) => {
            appState.sort.by = e.target.value;
            // Reset direction when sorting criteria changes
            appState.sort.direction = 'asc';
            renderData();
        });
    }
}

/**
 * Rule: Manages all click, change, and other user-triggered events on displayed data elements.
 * Output: Triggers calls to applyFiltersAndSorting or updateAppState.
 */
function handleInteractiveEvents(event) {
    const target = event.target;

    // Handle sorting clicks (if implemented on data cards)
    if (target.classList.contains('data-card')) {
        // Example: Clicking a card could trigger a sort action
        // For simplicity, we'll just log the interaction here, but in a full app, this would trigger a sort menu.
        console.log('Interactive event triggered on data card:', target.querySelector('h3').textContent);
    }
}

/**
 * Rule: The main entry point function. Sets up initial event listeners, loads initial state, and triggers the first rendering cycle.
 */
function initializeApplication() {
    // 1. Load initial state from storage
    loadInitialState();

    // 2. Attach all necessary event listeners
    attachEventListeners();

    // 3. Trigger the first rendering cycle based on loaded state
    renderData();
}

// Execute the main function when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', initializeApplication);