let appState = {
    tasks: [],
    theme: 'light'
};

const STORAGE_KEY = 'taskAgendaLedger';

// --- 1. Persistence Layer (The Ledger System) ---

/**
 * Loads the application state from localStorage.
 * Implements safe parsing using try/catch.
 * @returns {object} The loaded state or an empty default state.
 */
function loadState() {
    try {
        const data = localStorage.getItem(STORAGE_KEY);
        if (data) {
            const loadedState = JSON.parse(data);
            // Merge loaded state with default structure to ensure compatibility
            return { ...appState, ...loadedState };
        }
    } catch (error) {
        console.error("Error parsing localStorage data:", error);
        // If parsing fails, return default state
    }
    return appState;
}

/**
 * Saves the current application state to localStorage.
 * This function is called after every state mutation.
 */
function saveState() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(appState));
    } catch (error) {
        console.error("Error saving to localStorage:", error);
    }
}

// --- 2. Task Management Logic ---

/**
 * Adds a new task to the state and persists the change.
 * @param {Event} event - The form submission event.
 */
function addTask(event) {
    event.preventDefault();

    const title = document.getElementById('task_title').value.trim();
    const description = document.getElementById('task_description').value.trim();
    const dueDate = document.getElementById('task_due_date').value;

    if (!title || !dueDate) {
        alert("Please enter a Task Title and Due Date.");
        return;
    }

    const newTask = {
        id: Date.now(), // Simple unique ID
        title: title,
        description: description || 'No description provided.',
        dueDate: dueDate
    };

    // Update the central state (The Ledger)
    appState.tasks.push(newTask);

    // Persist the state immediately
    saveState();

    // Re-render the UI
    renderTaskList();

    // Clear the form
    document.getElementById('task_input_form').reset();
}

/**
 * Renders the list of tasks into the DOM.
 */
function renderTaskList() {
    const taskListDiv = document.getElementById('task_list');
    taskListDiv.innerHTML = ''; // Clear existing list

    if (appState.tasks.length === 0) {
        taskListDiv.innerHTML = '<p style="text-align: center; color: #888;">No tasks found. Add a new task above!</p>';
        return;
    }

    appState.tasks.forEach(task => {
        const taskItem = document.createElement('div');
        taskItem.className = 'task-item';
        taskItem.innerHTML = `
            <h3>${task.title}</h3>
            <p>${task.description}</p>
            <small>Due Date: ${task.dueDate}</small>
        `;
        taskListDiv.appendChild(taskItem);
    });
}

// --- 3. Calendar Management Logic ---

/**
 * Renders the monthly calendar grid.
 */
function renderCalendar() {
    const calendarGrid = document.getElementById('calendar_grid');
    calendarGrid.innerHTML = '';

    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth();

    // 1. Create Header (Days of the week)
    const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    daysOfWeek.forEach(day => {
        const header = document.createElement('div');
        header.className = 'calendar-header';
        header.textContent = day;
        calendarGrid.appendChild(header);
    });

    // 2. Create Calendar Grid Cells
    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);
    const startDayOfWeek = firstDayOfMonth.getDay(); // 0 (Sunday) to 6 (Saturday)

    // Add empty cells for padding before the 1st day
    for (let i = 0; i < startDayOfWeek; i++) {
        const emptyCell = document.createElement('div');
        emptyCell.className = 'calendar-day';
        calendarGrid.appendChild(emptyCell);
    }

    // Add actual days
    for (let day = 1; day <= lastDayOfMonth.getDate(); day++) {
        const date = new Date(year, month, day);
        const dayCell = document.createElement('div');
        dayCell.className = 'calendar-day';
        dayCell.textContent = day;

        // Check if this day has tasks
        const dayString = date.toISOString().split('T')[0];
        const hasEvent = appState.tasks.some(task => task.dueDate === dayString);

        if (hasEvent) {
            dayCell.classList.add('event-highlight');
        }

        // Highlight today
        if (date.toDateString() === today.toDateString()) {
            dayCell.classList.add('today');
        }

        calendarGrid.appendChild(dayCell);
    }
}

// --- 4. Theme Management Logic ---

/**
 * Toggles the application theme (light/dark mode).
 */
function toggleTheme() {
    const body = document.body;
    if (appState.theme === 'light') {
        appState.theme = 'dark';
    } else {
        appState.theme = 'light';
    }

    body.classList.toggle('dark-mode', appState.theme === 'dark');
    saveState();
}

/**
 * Applies the saved theme to the body element.
 */
function applyTheme() {
    document.body.classList.remove('dark-mode');
    if (appState.theme === 'dark') {
        document.body.classList.add('dark-mode');
    }
}

// --- 5. Initialization and Event Binding ---

/**
 * Initializes the application: loads data, sets up listeners, and renders the initial UI.
 */
function init() {
    // 1. Load State (Data Hydration)
    const loadedState = loadState();
    if (loadedState) {
        appState = loadedState;
    }

    // 2. Apply Theme
    applyTheme();

    // 3. Render UI based on loaded state
    renderTaskList();
    renderCalendar();

    // 4. Attach Event Listeners
    document.getElementById('task_input_form').addEventListener('submit', addTask);
    document.getElementById('theme_toggle_button').addEventListener('click', toggleTheme);
}

// Execute initialization when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', init);