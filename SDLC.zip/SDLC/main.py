import os
import json
from pathlib import Path
from datetime import datetime
from langgraph.graph import StateGraph, END

# Import the decoupled agents and state
from agents.state import AgentState, MAX_REVISIONS
from agents.planner import planner_node
from agents.coder import coder_node
from agents.reviewer import reviewer_node
from agents.requirements import requirement_node

import json  # Ensure json is imported at the top of main.py


def save_file_node(state: AgentState):
    """Saves verified file and logs incomplete files."""
    current_file = state["pending_files"][0]
    content = state["file_system"][current_file]
    incomplete = state.get("incomplete_files", {})

    # NEW LOGIC: Check if it hit max revisions and still failed
    if state["status"] == "FAIL":
        incomplete[current_file] = state["feedback"]
        print(f"   ⚠️ [Max Revisions Hit: {current_file} saved with known errors]")

    file_path = Path(state["run_dir"]) / current_file
    file_path.write_text(content, encoding="utf-8")
    print(f"\n💾 Saved file: {file_path}")

    return {
        "pending_files": state["pending_files"][1:],
        "review_attempts": 0,
        "feedback": "",
        "status": "",
        "incomplete_files": incomplete
    }


def finalize_workflow(state: AgentState):
    """Generates the validate.json ledger for any imperfect files."""
    incomplete = state.get("incomplete_files", {})
    if incomplete:
        validate_path = Path(state["run_dir"]) / "validate.json"
        validate_path.write_text(json.dumps(incomplete, indent=2), encoding="utf-8")
        print(f"\n📄 Validation Ledger created: {len(incomplete)} file(s) require manual review.")
    return {}


def route_review(state: AgentState):
    if state["status"] == "PASS" or state["review_attempts"] >= MAX_REVISIONS:
        return "save_file"
    return "coder"


def route_next_file(state: AgentState):
    if len(state["pending_files"]) > 0:
        return "coder"
    return "finalize_workflow"  # Route to finalizer instead of END


# Build the Graph
workflow = StateGraph(AgentState)
workflow.add_node("requirements", requirement_node)
workflow.add_node("planner", planner_node)
workflow.add_node("coder", coder_node)
workflow.add_node("reviewer", reviewer_node)
workflow.add_node("save_file", save_file_node)
workflow.add_node("finalize_workflow", finalize_workflow)  # Add the new node

workflow.set_entry_point("requirements")
workflow.add_edge("requirements", "planner")
workflow.add_edge("planner", "coder")
workflow.add_edge("coder", "reviewer")
workflow.add_conditional_edges("reviewer", route_review, {"coder": "coder", "save_file": "save_file"})
workflow.add_conditional_edges("save_file", route_next_file,
                               {"coder": "coder", "finalize_workflow": "finalize_workflow"})
workflow.add_edge("finalize_workflow", END)

app = workflow.compile()

if __name__ == "__main__":
    user_input = input("\nWhat application do you want to build?\n> ")
    
    base_dir = Path.cwd() / "output"
    run_dir = base_dir / datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"\n🚀 Starting build in: {run_dir}")
    app.invoke({"user_input": user_input, "run_dir": str(run_dir)})
    print(f"\n🎉 Build Complete! Check execution_log.txt in {run_dir}")