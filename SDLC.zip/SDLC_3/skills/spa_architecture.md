<SYSTEM_SKILL>
  <NAME>Modular SPA Architecture (Global Namespace)</NAME>
  <RULES>
    <RULE>Decouple logic: `storage.js` ONLY handles data and math. `app.js` ONLY handles the DOM.</RULE>
    <RULE>EVENT OWNERSHIP: `app.js` is strictly and solely responsible for writing `document.querySelectorAll` and `addEventListener` loops. Never delegate DOM binding to `storage.js`.</RULE>
    <RULE>FATAL ERROR AVOIDANCE: NEVER use ES6 `import` or `export` syntax. Share functions by attaching them to the global `window` object.</RULE>
  </RULES>
  <EXAMPLE>
    // In storage.js
    window.StorageApp = { saveData: function() { ... } };
    // In app.js
    document.getElementById('btn').addEventListener('click', () => window.StorageApp.saveData());
  </EXAMPLE>
</SYSTEM_SKILL>