<SYSTEM_SKILL>
  <NAME>Semantic Intent Grading</NAME>
  <RULES>
    <RULE>Manifest Verification: Cross-reference every DOM ID and JS function against the Manifest.</RULE>
    <RULE>Edge-Case Identification: What happens if local storage is empty? If the code does not handle null states gracefully, FAIL IT.</RULE>
  </RULES>
</SYSTEM_SKILL>