<SYSTEM_SKILL>
  <NAME>Event Delegation</NAME>
  <RULES>
    <RULE>Never attach individual event listeners to dozens of buttons.</RULE>
    <RULE>ALWAYS use Event Delegation. Attach a single `addEventListener('click')` to the parent container, and use `event.target` to determine which button was clicked.</RULE>
  </RULES>
  <EXAMPLE>
    document.getElementById('keypad-container').addEventListener('click', (e) => {
        if(e.target.tagName === 'BUTTON') {
            handleInput(e.target.dataset.value);
        }
    });
  </EXAMPLE>
</SYSTEM_SKILL>