<SYSTEM_SKILL>
  <NAME>UI Integrity & Data Entry</NAME>
  <RULES>
    <RULE>Context-Aware Inputs: If the app requires typing text (like a To-Do list), you MUST use `<input>` tags. If the app is a Calculator or uses a custom keypad, you MUST use `<button>` tags. Do not use inputs for calculator keys.</RULE>
    <RULE>Event Binding Ownership: `app.js` is strictly responsible for attaching `addEventListener` to DOM elements. `storage.js` only holds logic. Do not assume the other file will do it.</RULE>
    <RULE>Z-Index & Overlap: Ensure main containers have `overflow-x: hidden` and proper padding so elements do not bleed off the screen.</RULE>
  </RULES>
</SYSTEM_SKILL>