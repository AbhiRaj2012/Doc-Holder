<SYSTEM_SKILL>
  <NAME>Modern Clean CSS</NAME>
  <RULES>
    <RULE>Aesthetic: Design should look like modern Tailwind CSS or Material Design. Use soft shadows, rounded corners (8px), and clean padding.</RULE>
    <RULE>Layout: You ARE encouraged to use CSS Grid and Flexbox for structural layout (e.g., split-views, keypads, galleries).</RULE>
    <RULE>Color Scheme: Use a cohesive color palette (e.g., `#f4f4f9` for backgrounds, white for cards, and a primary accent color for active buttons).</RULE>
    <RULE>Visibility: ALWAYS include `.hidden { display: none !important; }` for JavaScript routing.</RULE>
  </RULES>
</SYSTEM_SKILL>