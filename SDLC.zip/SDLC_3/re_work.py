import os
import shutil
import re
import json
from pathlib import Path
from datetime import datetime
from agents.state import llm, load_skill, extract_json


def write_rework_log(run_dir: Path, step: str, details: str):
    """Writes to a dedicated execution_log_rework.txt file."""
    log_file = run_dir / "execution_log_rework.txt"
    timestamp = datetime.now().strftime("%H:%M:%S")
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"\n[{timestamp}] === {step.upper()} ===\n")
        f.write(str(details) + "\n")
        f.write("-" * 80 + "\n")


def run_rework():
    print("\n🛠️  [Re-Work Engine] Initializing targeted debugging...")

    # 1. Get User Input
    target_dir = input("Enter the exact folder path to fix (e.g., output/20260830_104437):\n> ").strip()
    base_path = Path(target_dir)

    if not base_path.exists() or not base_path.is_dir():
        print(f" [!] Error: Directory '{target_dir}' not found.")
        return

    issue_description = input("\nDescribe the issue or what you want to change:\n> ").strip()

    # 2. Create a safe copy of the project
    rework_path = Path(str(base_path) + "_rework")
    if rework_path.exists():
        shutil.rmtree(rework_path)
    shutil.copytree(base_path, rework_path)
    print(f"\n📂 Created safe working copy at: {rework_path}")

    write_rework_log(rework_path, "User Issue Report", issue_description)

    # 3. Read Project Context
    manifest_content = ""
    validate_content = ""
    file_system = {}

    for file_path in rework_path.iterdir():
        if file_path.is_file():
            content = file_path.read_text(encoding="utf-8")
            if file_path.name == "manifest.json":
                manifest_content = content
            elif file_path.name == "validate.json":
                validate_content = content
            elif file_path.name.endswith(('.html', '.css', '.js')):
                file_system[file_path.name] = content

    global_memory = "CURRENT PROJECT FILES:\n"
    for filename, code in file_system.items():
        global_memory += f"\n====== {filename} ======\n{code}\n======================\n"

    spa_skill = load_skill("spa_architecture.md")
    dom_skill = load_skill("dom_events.md")
    ui_skill = load_skill("universal_css.md")

    # =========================================================================
    # PHASE 1: THE DIAGNOSTICIAN (Generates the Work Manifest)
    # =========================================================================
    print("\n🧠 [Diagnostician] Analyzing project files to generate a Work Manifest...")

    diag_prompt = f"""
    You are an Expert Diagnostician and Software Architect.
    The user reported this issue: "{issue_description}"

    PROJECT MANIFEST: {manifest_content}
    VALIDATION LEDGER: {validate_content}

    {global_memory}

    YOUR TASK:
    Analyze the codebase and determine exactly which files need to be modified to fix the issue.
    Create a strict execution plan (Work Manifest) breaking down the fixes file by file.

    MANDATORY OUTPUT FORMAT:
    Return ONLY a JSON object containing a "tasks" array.
    Example:
    {{
        "tasks": [
            {{
                "file": "app.js",
                "analysis": "The form is submitting because e.preventDefault() is missing. There is also a syntax error on line 59 where 'class' was used as a variable.",
                "directive": "OVERWRITE the file. Add e.preventDefault() to handleFormSubmit. Fix the reserved keyword syntax error."
            }},
            {{
                "file": "index.html",
                "analysis": "Buttons are missing IDs required by the app.js event listeners.",
                "directive": "PATCH the file to add IDs 'btn-save' and 'btn-delete' to the respective buttons."
            }}
        ]
    }}
    """

    diag_response = llm.invoke(diag_prompt).content
    write_rework_log(rework_path, "Diagnostician Raw Output", diag_response)

    work_manifest_data = extract_json(diag_response)
    tasks = work_manifest_data.get("tasks", [])

    if not tasks:
        print("\n⚠️  [Diagnostician] Failed to generate a valid JSON Work Manifest. Aborting.")
        return

    print(f"\n📋 [Work Manifest] Identified {len(tasks)} file(s) requiring edits.")

    # Save the work manifest for debugging
    manifest_path = rework_path / "work_manifest.json"
    manifest_path.write_text(json.dumps(work_manifest_data, indent=2), encoding="utf-8")

    # =========================================================================
    # PHASE 2: THE SURGEON (Executes the Manifest in a Loop)
    # =========================================================================

    for task in tasks:
        target_file = task.get("file")
        analysis = task.get("analysis", "No analysis provided.")
        directive = task.get("directive", "Fix the file.")

        if target_file not in file_system:
            print(f"\n⏭️  Skipping '{target_file}': File does not exist in the project.")
            write_rework_log(rework_path, f"Skipped - {target_file}", "File not found in project.")
            continue

        print(f"\n⚙️  [Surgeon] Operating on: {target_file}")
        print(f"   ↳ Analysis: {analysis}")
        print(f"   ↳ Directive: {directive}")

        surg_prompt = f"""
        You are an Expert Surgeon Coder. 
        You are fixing ONE specific file: `{target_file}`.

        THE ISSUE: "{issue_description}"
        YOUR SPECIFIC DIRECTIVE FOR THIS FILE: "{directive}"

        CURRENT CODE FOR `{target_file}`:
        ```
        {file_system[target_file]}
        ```

        CROSS-FILE CONTEXT (Do not edit these, just use them for reference):
        {global_memory}

        SKILLS TO APPLY:
        {spa_skill}
        {dom_skill}
        {ui_skill}

        CRITICAL PATCHING RULES:
        1. If fixing a tiny bug (1-2 lines), use <SEARCH> and <REPLACE>. The <SEARCH> block MUST exactly match the existing code (maximum 2 lines).
        2. If the file is fundamentally broken, has massive syntax errors, or needs a large rewrite, use <OVERWRITE> to output the entire corrected file from top to bottom.

        MANDATORY OUTPUT FORMAT:
        <OVERWRITE file="{target_file}">
        entire new file code goes here
        </OVERWRITE>

        OR

        <PATCH file="{target_file}">
            <SEARCH>
            exact old code line
            </SEARCH>
            <REPLACE>
            new fixed code
            </REPLACE>
        </PATCH>
        """

        surg_response = llm.invoke(surg_prompt).content
        write_rework_log(rework_path, f"Surgeon Output - {target_file}", surg_response)

        new_code = file_system[target_file]
        changes_made = False

        # Parse Overwrites
        overwrite_blocks = re.findall(r'<OVERWRITE\s+file=["\'](.*?)["\']>(.*?)</OVERWRITE>', surg_response,
                                      re.DOTALL | re.IGNORECASE)
        for filename, new_content in overwrite_blocks:
            if filename == target_file:
                clean_content = new_content.replace("```javascript", "").replace("```html", "").replace("```css",
                                                                                                        "").replace(
                    "```", "").strip()
                new_code = clean_content
                print(f"   ↳ [OVERWRITE] Entire file replaced.")
                write_rework_log(rework_path, f"Applied OVERWRITE to {target_file}", "File completely rewritten.")
                changes_made = True

        # Parse Patches
        patch_blocks = re.findall(r'<PATCH\s+file=["\'](.*?)["\']>(.*?)</PATCH>', surg_response,
                                  re.DOTALL | re.IGNORECASE)
        for filename, patch_content in patch_blocks:
            if filename != target_file:
                continue

            # Handle APPEND
            append_blocks = re.findall(r"<APPEND>\s*(.*?)\s*</APPEND>", patch_content, re.DOTALL)
            for append_text in append_blocks:
                clean_append = append_text.replace("```javascript", "").replace("```html", "").replace("```css",
                                                                                                       "").replace(
                    "```", "").strip()
                new_code += "\n" + clean_append
                print(f"   ↳ [APPEND] patch applied.")
                write_rework_log(rework_path, f"Applied APPEND to {target_file}", clean_append)
                changes_made = True

            # Handle SEARCH/REPLACE
            blocks = re.findall(r"<SEARCH>\s*(.*?)\s*</SEARCH>\s*<REPLACE>\s*(.*?)\s*</REPLACE>", patch_content,
                                re.DOTALL)
            for old_text, new_text in blocks:
                clean_old = old_text.replace("```html", "").replace("```css", "").replace("```javascript", "").replace(
                    "```js", "").replace("```", "").strip()
                clean_new = new_text.replace("```html", "").replace("```css", "").replace("```javascript", "").replace(
                    "```js", "").replace("```", "").strip()

                if clean_old in new_code:
                    new_code = new_code.replace(clean_old, clean_new)
                    print(f"   ↳ [SEARCH/REPLACE] patch applied.")
                    write_rework_log(rework_path, f"Applied REPLACE to {target_file}",
                                     f"Replaced:\n{clean_old}\n\nWith:\n{clean_new}")
                    changes_made = True
                else:
                    print(f"   ⚠️ [FAIL] <SEARCH> text not found perfectly.")
                    write_rework_log(rework_path, f"Patch Failed - {target_file}",
                                     f"Could not find exact match for:\n{clean_old}")

        if not changes_made:
            print(f"   ⚠️ [Warning] Surgeon completed but no valid XML patches/overwrites were extracted.")

        # Save updated code back to memory and disk
        file_system[target_file] = new_code
        file_path = rework_path / target_file
        file_path.write_text(new_code, encoding="utf-8")

    print(f"\n✅ Re-work complete! Review your fixed application in: {rework_path}")
    print(f"📄 Full execution details saved to: {rework_path / 'execution_log_rework.txt'}")
    print(f"📋 Diagnostics plan saved to: {rework_path / 'work_manifest.json'}")


if __name__ == "__main__":
    run_rework()