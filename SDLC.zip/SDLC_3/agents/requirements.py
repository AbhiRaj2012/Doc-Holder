from pathlib import Path
from .state import AgentState, llm, write_log

def requirement_node(state: AgentState):
    print("\n📝 [Requirements] Analyzing request and generating SRS/SDD...")
    prompt = f"""
    You are a Lead Systems Analyst. The user wants to build: '{state['user_input']}'
    Expand this into a comprehensive SRS (Software Requirements Specification) and SDD (Software Design Document).
    Include: Core Objectives, Functional Requirements, Non-Functional Requirements, Technical Stack (Vanilla HTML/CSS/JS only).
    Output the specifications clearly without writing code.
    """
    requirements = llm.invoke(prompt).content.strip()
    req_path = Path(state["run_dir"]) / "SRS_SDD.txt"
    req_path.write_text(requirements, encoding="utf-8")
    write_log(state["run_dir"], "Requirements - Output", requirements)
    return {"requirements": requirements}