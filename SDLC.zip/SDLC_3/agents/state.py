import json
import re
from pathlib import Path
from datetime import datetime
from typing import TypedDict
from langchain_ollama import ChatOllama

# Initialize the 20B model
llm = ChatOllama(
    model="gemma4:e2b",  # Ensure this matches your local model name
    num_predict=4096,
    num_ctx=8192,
    temperature=0.3
)

# Optimized for speed: 2 attempts -> Reflect -> 2 attempts
MAX_REVISIONS = 4


class AgentState(TypedDict):
    user_input: str
    requirements: str
    run_dir: str
    manifest: dict
    file_system: dict
    pending_files: list
    feedback: str
    review_attempts: int
    status: str
    incomplete_files: dict
    reflection_summary: str


def write_log(run_dir: str, step: str, details: str):
    log_file = Path(run_dir) / "execution_log.txt"
    timestamp = datetime.now().strftime("%H:%M:%S")
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"\n[{timestamp}] === {step.upper()} ===\n")
        f.write(str(details) + "\n")
        f.write("-" * 80 + "\n")


def extract_json(text: str) -> dict:
    """Aggressively extracts and cleans JSON from LLM output, injecting missing commas."""
    clean_text = re.sub(r"```(?:json)?", "", text, flags=re.IGNORECASE).replace("```", "")

    start_idx = clean_text.find('{')
    list_start_idx = clean_text.find('[')

    if start_idx != -1 and (list_start_idx == -1 or start_idx < list_start_idx):
        end_idx = clean_text.rfind('}')
        json_str = clean_text[start_idx:end_idx + 1]
    elif list_start_idx != -1:
        end_idx = clean_text.rfind(']')
        json_str = clean_text[list_start_idx:end_idx + 1]
    else:
        return {}

    # Fix trailing commas
    json_str = re.sub(r',\s*([\]}])', r'\1', json_str)
    # Inject missing commas between key-value pairs
    json_str = re.sub(r'(["\]}])\s*("[a-zA-Z0-9_]+"\s*:)', r'\1,\n\2', json_str)

    try:
        return json.loads(json_str, strict=False)
    except Exception as e:
        print(f" [!] JSON Parsing Error: {e}")
        return {}


def load_skill(skill_filename: str) -> str:
    skill_path = Path(__file__).parent.parent / "skills" / skill_filename
    try:
        return skill_path.read_text(encoding="utf-8")
    except FileNotFoundError:
        print(f" [!] Warning: Skill file {skill_filename} not found.")
        return ""