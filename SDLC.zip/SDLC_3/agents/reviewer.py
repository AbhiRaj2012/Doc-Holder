import json
import re
from .state import AgentState, llm, write_log, load_skill


def reviewer_node(state: AgentState):
    current_file = state["pending_files"][0]
    file_code = state["file_system"][current_file]
    print(f"\n🔎 [Reviewer] Auditing {current_file} for logical integrity...")

    file_manifest = json.dumps(state["manifest"].get("files", {}).get(current_file, {}), indent=2)
    grading_skill = load_skill("intent_based_grading.md")

    global_memory = "FULL PROJECT CONTEXT:\n"
    for filename, content in state["file_system"].items():
        if content and filename != current_file:
            global_memory += f"--- {filename} ---\n{content}\n"

    prompt = f"""
    YOU ARE A STRICT QA REVIEWER. DO NOT WRITE THE FULL FILE FROM SCRATCH.

    ====== START OF CURRENT CODE TO REVIEW ({current_file}) ======
    {file_code}
    ====== END OF CURRENT CODE TO REVIEW ======

    BUSINESS REQUIREMENTS: {state.get('requirements', '')}
    MANIFEST REQUIREMENTS: {file_manifest}
    {global_memory}

    ANTI-SPECIFICATION GAMING RULES (CRITICAL):
        1. COMMON SENSE UI (FATAL): You must use human logic. If the app is a Calculator, it MUST have buttons for 0-9 and operators. If it is an Invoice app, it MUST have a way to add multiple line items. If the UI is missing obvious core features, FAIL IT, even if the manifest missed them.
        2. LOGIC OVER SYNTAX (FATAL): Trace the execution flow inside functions. If a function lacks math/logic, FAIL IT.
        3. HTML SCRIPT LINKAGE (FATAL): HTML files MUST verify every .js file is explicitly linked at the bottom of the body.
        4. DOM SYNCING (FATAL): Ensure `getElementById` exactly matches the classes/IDs present in the HTML.
        5. ES6 MODULE BAN (FATAL): Check for `import ` or `export `. If present, FAIL IT immediately.
        
    CRITICAL PATCHING RULES:
    1. TRUNCATION RECOVERY: Use <APPEND> to add missing code to the bottom.
    2. BUG FIXES: Use <SEARCH> and <REPLACE> for specific bugs. Maximum TWO (2) patches per review.

    MANDATORY OUTPUT FORMAT:
    End your review with a strict status tag: <STATUS>PASS</STATUS> or <STATUS>FAIL</STATUS>.
    """
    review_output = llm.invoke(prompt).content.strip()
    write_log(state["run_dir"], f"Reviewer - {current_file}", review_output)

    status_match = re.search(r"<STATUS>(.*?)</STATUS>", review_output, re.IGNORECASE)
    extracted_status = status_match.group(1).upper().strip() if status_match else ""

    if extracted_status == "PASS" or "NO PATCHES ARE NECESSARY" in review_output.upper():
        print(f"   ✅ {current_file} passed semantic review.")
        status = "PASS"
    else:
        print(f"   ❌ Logic/Syntax issues found in {current_file}. Routing back to Coder.")
        status = "FAIL"

    return {"feedback": review_output, "status": status, "review_attempts": state["review_attempts"] + 1}