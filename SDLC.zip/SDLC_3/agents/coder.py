import re
import json
from .state import AgentState, llm, write_log, MAX_REVISIONS, load_skill


def coder_node(state: AgentState):
    current_file = state["pending_files"][0]
    is_revision = state["review_attempts"] > 0
    base_code = state["file_system"].get(current_file, "")
    file_manifest = json.dumps(state["manifest"].get("files", {}).get(current_file, {}), indent=2)

    ui_skill = load_skill("universal_css.md")
    spa_skill = load_skill("spa_architecture.md")
    ui_integrity = load_skill("ui_integrity.md")

    all_files_list = ", ".join(state["file_system"].keys())
    global_memory = "PREVIOUSLY BUILT FILES:\n"
    for filename, content in state["file_system"].items():
        if content and filename != current_file:
            global_memory += f"--- {filename} ---\n{content}\n"

    if not is_revision:
        print(f"\n💻 [Coder] Drafting {current_file}...")
        prompt = f"""
        Write the code for `{current_file}` based strictly on this manifest:
        {file_manifest}
        {global_memory}

        APPLY THESE SKILLS:
        {ui_skill}
        {spa_skill}
        {ui_integrity}

        CRITICAL HTML LINKING RULE:
        If writing HTML, link these exact JS files at the bottom of the body: {all_files_list}. Do NOT link a generic 'script.js' unless it is in that list!

        SPEED OPTIMIZATION: Write the full file at once. ONLY use `<PLACEHOLDER id="funcName"/>` if the file will exceed 300 lines of code.
        Output ONLY the code inside ``` blocks.
        """
        response = llm.invoke(prompt).content
        match = re.search(r"```[a-zA-Z]*\n(.*?)```", response, re.DOTALL)
        new_code = match.group(1).strip() if match else response.strip()

        # Handle optional placeholders if it generated any
        placeholders = re.findall(r'<PLACEHOLDER\s+id=["\'](.*?)["\'].*?>', new_code, re.IGNORECASE)
        for ph_id in placeholders:
            print(f"   ↳ [Chunking] Generating isolated block: {ph_id}...")
            chunk_prompt = f"Generate raw code to replace the placeholder: {ph_id}.\nMANIFEST: {file_manifest}\nProvide ONLY raw code, no backticks."
            chunk_code = llm.invoke(chunk_prompt).content.strip()
            chunk_code = chunk_code.replace("```javascript", "").replace("```html", "").replace("```css", "").replace(
                "```", "").strip()
            new_code = re.sub(f'<PLACEHOLDER\\s+id=["\']{ph_id}["\'].*?>', chunk_code, new_code, flags=re.IGNORECASE)

    else:
        print(f"\n🔄 [Coder] Surgically patching {current_file} (Attempt {state['review_attempts']}/{MAX_REVISIONS})...")
        reflection_context = f"LESSONS FROM PREVIOUS FAILURES:\n{state.get('reflection_summary', '')}" if state.get(
            'reflection_summary') else ""

        prompt = f"""
        Fix `{current_file}` based on Reviewer feedback.
        {reflection_context}

        REVIEWER FEEDBACK:
        {state['feedback']}

        CURRENT CODE:
        ```
        {base_code}
        ```

        CRITICAL PATCHING RULES:
        1. For truncation, put missing code inside <APPEND> tags.
        2. For bugs, use <SEARCH> and <REPLACE>. Your <SEARCH> block MUST BE 1 TO 2 LINES MAXIMUM. Target the exact broken line so regex doesn't fail.

        <PATCH>
        <SEARCH>
        exact 1 line of old code
        </SEARCH>
        <REPLACE>
        the new corrected code
        </REPLACE>
        </PATCH>
        """
        response = llm.invoke(prompt).content
        new_code = base_code

        append_blocks = re.findall(r"<APPEND>\s*(.*?)\s*</APPEND>", response, re.DOTALL)
        for append_text in append_blocks:
            clean_append = append_text.replace("```javascript", "").replace("```html", "").replace("```css",
                                                                                                   "").replace("```",
                                                                                                               "").strip()
            new_code += "\n" + clean_append
            print("   ↳ [Applied <APPEND> patch]")

        blocks = re.findall(r"<SEARCH>\s*(.*?)\s*</SEARCH>\s*<REPLACE>\s*(.*?)\s*</REPLACE>", response, re.DOTALL)
        for old_text, new_text in blocks:
            clean_old = old_text.replace("```html", "").replace("```css", "").replace("```javascript", "").replace(
                "```js", "").replace("```", "").strip()
            clean_new = new_text.replace("```html", "").replace("```css", "").replace("```javascript", "").replace(
                "```js", "").replace("```", "").strip()

            if clean_old in new_code:
                new_code = new_code.replace(clean_old, clean_new)
                print("   ↳ [Applied <SEARCH>/<REPLACE> patch]")
            else:
                print("   ⚠️ [Failed to apply patch: <SEARCH> text not found perfectly]")

    write_log(state["run_dir"], f"Coder - {current_file}", new_code)
    updated_fs = state["file_system"].copy()
    updated_fs[current_file] = new_code

    return {"file_system": updated_fs}