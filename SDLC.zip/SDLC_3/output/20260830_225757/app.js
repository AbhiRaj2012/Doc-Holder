// app.js

// --- Module A: State & DOM References ---

// Internal state management (Mirroring the manifest's state structure)
let state = {
    currentInput: "",
    history: [],
    currentOperation: null
};

// DOM Element References
const displayElement = document.getElementById('display-output');
const historyLogElement = document.getElementById('history-log');

// --- Module D: Display Manager Functions ---

/**
 * Updates the Document Object Model (DOM) to show the calculated result or any relevant error messages.
 * @param {number} result - The calculated result.
 * @param {string | null} error - An error message, or null if successful.
 */
function displayResult(result, error = null) {
    if (error) {
        displayElement.value = "Error";
        // Optionally log error to history or console
        console.error("Calculation Error:", error);
    } else {
        // Limit display length for readability
        displayElement.value = parseFloat(result.toFixed(10)).toString();
    }
}

/**
 * Resets the visual display to zero or an initial state.
 */
function clearDisplay() {
    displayElement.value = "0";
}

/**
 * Clears the entire calculator state, clearing the display and operation history.
 */
function clearAll() {
    state.currentInput = "";
    state.history = [];
    state.currentOperation = null;
    clearDisplay();
    historyLogElement.innerHTML = ''; // Clear history log
}

// --- Module B: Input Handler Functions ---

/**
 * Processes raw numerical or operator input from the user and updates the internal state.
 * @param {string} value - The raw input string from the button press.
 */
function handleInput(value) {
    // Check if the input is a number or an operator
    if (/[0-9.+\-*/]/.test(value)) {
        // Append input to the current sequence
        state.currentInput += value;
        
        // Update display immediately
        displayResult(parseFloat(state.currentInput));
    } else if (value === 'C/AC') {
        // Clear all state
        clearAll();
    } else if (value === '=') {
        // Trigger calculation when equals is pressed
        performCalculation();
    }
}

// --- Module C: Calculation Engine Functions ---

/**
 * Executes the core mathematical logic based on the stored input sequence.
 * This function orchestrates the call to storage.js.
 */
function performCalculation() {
    if (state.currentInput === "") {
        return;
    }

    try {
        // 1. Parse the input string into tokens (operands and operators)
        // This uses the logic from storage.js
        const tokens = window.StorageApp.parseInput(state.currentInput);

        if (tokens.length === 0) {
            throw new Error("Empty input sequence.");
        }

        // 2. Execute the calculation using the engine
        const result = window.StorageApp.executeCalculation(tokens[0], tokens.slice(1));

        // 3. Update state and display
        state.history.push(result);
        displayResult(result);
        
        // Update history log (simple demonstration)
        historyLogElement.textContent = `Result: ${result}`;

    } catch (error) {
        // Centralized Error Propagation: Ensure system state is reset upon failure.
        // This guarantees that state corruption is prevented across module boundaries.
        displayResult(0, error.message);
        state.history = []; // Clear history on error
        historyLogElement.textContent = `Error: ${error.message}`;
    }
}

// --- Module A & C: Initialization ---

/**
 * Sets up initial event listeners for all calculator buttons and initializes the application state.
 */
function initializeCalculator() {
    // Bind all buttons to the handleInput function
    document.getElementById('button-clear').addEventListener('click', () => handleInput('C/AC'));
    document.getElementById('button-add').addEventListener('click', () => handleInput('+'));
    document.getElementById('button-subtract').addEventListener('click', () => handleInput('-'));
    document.getElementById('button-multiply').addEventListener('click', () => handleInput('*'));
    document.getElementById('button-divide').addEventListener('click', () => handleInput('/'));
    document.getElementById('button-equals').addEventListener('click', () => performCalculation());

    // Initialize display
    clearDisplay();
}

// --- Public Interface Exposure ---

// Expose the required functions to the global scope
window.initializeCalculator = initializeCalculator;
window.handleInput = handleInput;
window.performCalculation = performCalculation;
window.displayResult = displayResult;
window.clearAll = clearAll;

// Start the application when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', initializeCalculator);