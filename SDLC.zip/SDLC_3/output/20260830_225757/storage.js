window.StorageApp = (function() {
    // --- Internal State Management ---
    var history = [];
    var currentResult = 0;

    /**
     * State Manager Methods
     */

    /**
     * Stores the result of an intermediate calculation into the history.
     * @param {number} result - The calculated value.
     */
    function storeIntermediateResult(result) {
        history.push(result);
        currentResult = result;
    }

    /**
     * Clears the entire calculation history and resets the current result.
     */
    function clearHistory() {
        history = [];
        currentResult = 0;
    }

    /**
     * Resets the calculator to its initial state.
     */
    function resetCalculator() {
        clearHistory();
        // No specific action needed beyond clearing history and result
    }

    /**
     * Input Parser Methods
     */

    /**
     * Tokenizes the raw input string into an array of operands and operators.
     * @param {string} inputString - The raw string input (e.g., '5+3*2').
     * @returns {Array} An array containing numbers and operators.
     */
    function tokenizeInput(inputString) {
        // Simple tokenization: split by operator, keeping the operators.
        var tokens = [];
        var currentToken = '';
        
        // Standardize input (remove spaces)
        inputString = inputString.replace(/\s/g, '');

        for (var i = 0; i < inputString.length; i++) {
            var char = inputString[i];

            if (['+', '-', '*', '/'].includes(char)) {
                // If we have a pending number, push it first
                if (currentToken.length > 0) {
                    tokens.push(parseFloat(currentToken));
                    currentToken = '';
                }
                tokens.push(char);
            } else if (/[0-9.]/.test(char)) {
                // Accumulate digits/decimal points
                currentToken += char;
            }
        }

        // Push the final accumulated number
        if (currentToken.length > 0) {
            tokens.push(parseFloat(currentToken));
        }

        return tokens;
    }

    /**
     * Validates the parsed input for mathematical correctness.
     * @param {Array} tokens - The array of tokens from tokenizeInput.
     * @returns {boolean} True if the input is valid, false otherwise.
     */
    function validateInput(tokens) {
        if (tokens.length === 0) {
            return false;
        }

        // Check if the sequence alternates between numbers and operators
        var expectingNumber = true;
        for (var i = 0; i < tokens.length; i++) {
            var token = tokens[i];
            if (/[0-9.]/.test(token)) {
                if (!expectingNumber) {
                    // Found a number immediately after another number (e.g., 5 3)
                    return false;
                }
                expectingNumber = false;
            } else if (['+', '-', '*', '/'].includes(token)) {
                if (expectingNumber) {
                    // Found an operator immediately after another operator (e.g., 5 + * 3)
                    return false;
                }
                expectingNumber = true;
            }
        }
        return true;
    }

    /**
     * Calculation Engine Methods
     */

    /**
     * Performs the actual arithmetic operation.
     * @param {number} operand1
     * @param {number} operand2
     * @param {string} operator
     * @returns {number} The result of the operation.
     */
    function performOperation(operand1, operand2, operator) {
        switch (operator) {
            case '+':
                return operand1 + operand2;
            case '-':
                return operand1 - operand2;
            case '*':
                return operand1 * operand2;
            case '/':
                // Division by zero check is handled separately for error reporting
                return operand1 / operand2;
            default:
                throw new Error("Invalid operator");
        }
    }

    /**
     * Checks for division by zero errors before calculation.
     * @param {number} divisor
     * @returns {boolean} True if division by zero is imminent.
     */
    function checkDivisionByZero(divisor) {
        return divisor === 0;
    }

    /**
     * Calculates the sequence of operations based on the parsed input.
     * Implements left-to-right chained calculation.
     * @param {Array} operands - Array of numbers.
     * @param {Array} operators - Array of operators.
     * @returns {number} The final calculated result.
     */
    function calculateSequence(operands, operators) {
        if (operands.length === 0 || operators.length === 0) {
            return 0;
        }

        let result = operands[0];

        for (let i = 0; i < operators.length; i++) {
            const operator = operators[i];
            const operand2 = operands[i + 1];

            if (checkDivisionByZero(operand2) && operator === '/') {
                // Signal an error state if division by zero occurs
                throw new Error("Error: Division by zero");
            }

            result = performOperation(result, operand2, operator);
        }

        return result;
    }

    /**
     * Public Interface Methods
     */

    /**
     * Parses the raw string input into structured data.
     * @param {string} inputString - The input string.
     * @returns {Array} Tokenized operands and operators.
     */
    function parseInput(inputString) {
        const tokens = tokenizeInput(inputString);
        if (!validateInput(tokens)) {
            throw new Error("Invalid input format.");
        }
        return tokens;
    }

    /**
     * Executes the stored sequence of operations.
     * @param {Array} operands - Array of numbers.
     * @param {Array} operators - Array of operators.
     * @returns {number} The final result.
     */
    function executeCalculation(operands, operators) {
        if (operands.length !== operators.length + 1) {
            throw new Error("Mismatched operands and operators.");
        }
        
        // Use the core calculation engine
        return calculateSequence(operands, operators);
    }

    /**
     * Dispatches the operation based on the operator token.
     * @param {string} operation - The operator (+, -, *, /).
     * @returns {void}
     */
    function handleOperation(operation) {
        // This function is typically used by the UI to trigger the calculation flow.
        // In a full implementation, it would interact with the state manager
        // to retrieve the last operands and perform the calculation.
        // For this manifest, we assume the main execution happens via executeCalculation.
        console.log("Operation handled:", operation);
    }

    /**
     * Manages the visual output.
     * @param {number} result - The calculated result.
     * @param {string | null} error - An error message, or null if successful.
     */
    function displayResult(result, error = null) {
        const displayElement = document.getElementById('display-output');
        if (error) {
            displayElement.value = "Error";
            // In a real app, error handling would be more sophisticated
        } else {
            displayElement.value = result;
        }
    }

    /**
     * Resets the internal state.
     */
    function clearState() {
        resetCalculator();
        // Update display to initial state
        displayResult(0);
    }

    // --- Expose Public Interface ---
    window.StorageApp = {
        parseInput: parseInput,
        executeCalculation: executeCalculation,
        handleOperation: handleOperation,
        displayResult: displayResult,
        clearState: clearState,
        storeIntermediateResult: storeIntermediateResult,
        clearHistory: clearHistory,
        resetCalculator: resetCalculator,
        // Expose internal state for debugging if needed
        _history: history,
        _currentResult: currentResult
    };

})();