/**
 * app.js
 * Core application logic for the client-side billing tool.
 * Implements the functions defined in the manifest, managing data, calculation, and DOM manipulation.
 */

// =============================================================================
// Persistence Engine (Interacts with storage.js)
// =============================================================================

/**
 * Retrieves all saved invoices from LocalStorage.
 * @returns {Array} All saved invoice objects.
 */
function loadInvoices() {
    return window.StorageApp.loadInvoices();
}

/**
 * Persists a new or updated invoice object into LocalStorage.
 * @param {Object} invoice - The invoice object to save.
 */
function saveInvoice(invoiceObject) {
    window.StorageApp.saveInvoice(invoiceObject);
}

// =============================================================================
// Input Engine (Calculation and Validation)
// =============================================================================

/**
 * Performs rigorous client-side validation on all user inputs.
 * @param {Object} data - The data object containing line items, prices, and tax rate.
 * @returns {Object} An object containing validation status and error messages.
 */
function validateInputs(data) {
    const errors = {};

    // 1. Validate Tax Rate
    if (isNaN(data.taxRate) || data.taxRate < 0) {
        errors.taxRate = "Tax rate must be a non-negative number.";
    }

    // 2. Validate Line Items
    if (!data.lineItems || data.lineItems.length === 0) {
        errors.lineItems = "Please add at least one line item.";
    } else {
        data.lineItems.forEach((item, index) => {
            if (isNaN(item.quantity) || item.quantity <= 0) {
                errors[`item_${index}_quantity`] = `Line item ${index + 1} quantity must be a positive number.`;
            }
            if (isNaN(item.price) || item.price <= 0) {
                errors[`item_${index}_price`] = `Line item ${index + 1} price must be a positive number.`;
            }
        });
    }

    if (Object.keys(errors).length > 0) {
        return { isValid: false, errors: errors };
    }

    return { isValid: true, errors: {} };
}

/**
 * The core calculation engine.
 * @param {Array<Object>} lineItems - Array of line item objects ({description, quantity, price}).
 * @param {number} taxRate - The tax rate (as a decimal, e.g., 0.05).
 * @returns {Object} Calculated totals (subtotal, tax amount, total amount).
 */
function calculateInvoice(lineItems, taxRate) {
    let subtotal = 0;

    for (const item of lineItems) {
        // Ensure calculations use parsed numbers
        const quantity = parseFloat(item.quantity) || 0;
        const price = parseFloat(item.price) || 0;
        subtotal += quantity * price;
    }

    const taxAmount = subtotal * taxRate;
    const totalAmount = subtotal + taxAmount;

    return {
        subtotal: subtotal,
        taxAmount: taxAmount,
        totalAmount: totalAmount
    };
}

// =============================================================================
// Presentation Engine (DOM Manipulation)
// =============================================================================

/**
 * Dynamically generates the HTML structure for a single invoice.
 * @param {Object} invoiceObject - The complete invoice data.
 */
function renderInvoice(invoiceObject) {
    const outputArea = document.getElementById('invoice-output-area');
    if (!outputArea) return;

    // Construct the HTML for the invoice
    let html = document.createElement('div');
    html.id = 'invoice-container';
    html.innerHTML = `
        <div id="invoice-header">
            <h1>Invoice #${invoiceObject.id}</h1>
            <p>Customer: ${invoiceObject.customerName}</p>
            <p>Address: ${invoiceObject.customerAddress}</p>
        </div>
        <table id="line-items-table">
            <thead>
                <tr>
                    <th>Description</th>
                    <th>Quantity</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>
    `;

    // Add line items
    invoiceObject.lineItems.forEach(item => {
        html.innerHTML += `
            <tr>
                <td>${item.description}</td>
                <td>${item.quantity}</td>
                <td>$${item.price.toFixed(2)}</td>
            </tr>
        `;
    });

    html.innerHTML += `
            </tbody>
        </table>
        <div id="totals-section">
            <p>Subtotal: $${invoiceObject.subtotal.toFixed(2)}</p>
            <p>Tax (${(invoiceObject.taxRate * 100).toFixed(1)}%): $${invoiceObject.taxAmount.toFixed(2)}</p>
            <div class="grand_total">Total Amount: $${invoiceObject.totalAmount.toFixed(2)}</div>
        </div>
    `;

    // Clear previous content and append the new invoice
    outputArea.innerHTML = '';
    outputArea.appendChild(html);
}

/**
 * Triggers the browser's print dialog for the rendered invoice.
 * @param {Object} invoiceObject - The invoice data to be printed.
 */
function printInvoice(invoiceObject) {
    // Temporarily focus the print area and trigger the print dialog
    window.print();
}

// =============================================================================
// Application Initialization and Event Handling
// =============================================================================

/**
 * Main entry point. Sets up initial event listeners, loads saved data, and renders the initial dashboard.
 */
function initializeApp() {
    // 1. Load Data
    const invoices = loadInvoices();
    // Note: We don't explicitly use the 'invoiceTemplate' key from storage.js, 
    // but we assume the structure is consistent for rendering.

    // 2. Populate Invoice History List
    const historyList = document.getElementById('invoice-history-list');
    historyList.innerHTML = '';

    if (invoices.length === 0) {
        historyList.innerHTML = '<p class="placeholder">No invoices found.</p>';
    } else {
        invoices.forEach(invoice => {
            const historyItem = document.createElement('div');
            historyItem.className = 'invoice-history-item';
            historyItem.innerHTML = `
                <h3>Invoice #${invoice.id}</h3>
                <p>Customer: ${invoice.customerName}</p>
                <p>Date: ${new Date(invoice.date).toLocaleDateString()}</p>
                <p>Total: $${invoice.totalAmount.toFixed(2)}</p>
                <button class="view-details-btn" data-id="${invoice.id}">View Details</button>
            `;
            historyList.appendChild(historyItem);
        });
    }

    // 3. Set up Event Listeners
    setupEventListeners();
}

/**
 * Attaches all necessary event listeners to the DOM elements.
 */
function setupEventListeners() {
    const form = document.getElementById('invoice-form');
    const saveBtn = document.getElementById('save-btn');
    const printBtn = document.getElementById('print-btn');
    const addLineItemBtn = document.getElementById('add-line-item-btn');
    const generateBtn = document.getElementById('generate-btn');
    const saveBtnEl = document.getElementById('save-btn');
    const printBtnEl = document.getElementById('print-btn');

    // Handle Add Line Item dynamically
    addLineItemBtn.addEventListener('click', addLineItemRow);

    // Handle Form Submission (Calculation and Rendering)
    form.addEventListener('submit', handleFormSubmit);

    // Handle Saving
    saveBtnEl.addEventListener('click', handleSave);

    // Handle Printing
    printBtnEl.addEventListener('click', handlePrint);
}

/**
 * Handles the dynamic addition of a new line item row.
 */
function addLineItemRow() {
    const container = document.getElementById('line-items-container');
    const newItem = document.createElement('div');
    newItem.className = 'line-item-row';
    newItem.innerHTML = `
        <input type="text" name="item-description" placeholder="Description" required>
        <input type="number" name="item-quantity" placeholder="Quantity" required>
        <input type="number" name="item-price" placeholder="Price" step="0.01" required>
        <button type="button" class="remove-item-btn">Remove</button>
    `;
    container.appendChild(newItem);

    // Add event listener to the new remove button
    newItem.querySelector('.remove-item-btn').addEventListener('click', removeLineItemRow);
}

/**
 * Handles the removal of a line item row.
 */
function removeLineItemRow(event) {
    const row = event.target.closest('.line-item-row');
    if (row) {
        row.remove();
    }
}

/**
 * Gathers data from the form, validates it, calculates totals, and renders the invoice.
 * @param {Event} event - The form submission event.
 */
function handleFormSubmit(event) {
    event.preventDefault();

    const lineItems = [];
    const taxRate = parseFloat(document.getElementById('tax-rate').value) / 100; // Convert percentage to decimal

    // Gather line items
    document.querySelectorAll('.line-item-row').forEach(row => {
        const description = row.querySelector('input[name="item-description"]').value;
        const quantity = parseFloat(row.querySelector('input[name="item-quantity"]').value);
        const price = parseFloat(row.querySelector('input[name="item-price"]').value);

        if (description && !isNaN(quantity) && !isNaN(price)) {
            lineItems.push({
                description: description,
                quantity: quantity,
                price: price
            });
        }
    });

    if (lineItems.length === 0) {
        alert("Please add at least one line item before generating the invoice.");
        return;
    }

    const data = {
        customerName: document.getElementById('customer-name').value,
        customerAddress: document.getElementById('customer-address').value,
        lineItems: lineItems,
        taxRate: taxRate,
        subtotal: 0,
        taxAmount: 0,
        totalAmount: 0,
        date: new Date().toISOString()
    };

    // 1. Validation
    const validationResult = validateInputs(data);
    if (!validationResult.isValid) {
        alert("Input Error: " + Object.values(validationResult.errors).join('\n'));
        return;
    }

    // 2. Calculation
    const calculationResult = calculateInvoice(lineItems, taxRate);
    data.subtotal = calculationResult.subtotal;
    data.taxAmount = calculationResult.taxAmount;
    data.totalAmount = calculationResult.totalAmount;

    // 3. Presentation
    renderInvoice(data);
}

/**
 * Saves the generated invoice object to LocalStorage.
 */
function handleSave() {
    const invoiceId = Date.now().toString(); // Simple unique ID
    const newInvoice = {
        id: invoiceId,
        customerName: document.getElementById('customer-name').value,
        customerAddress: document.getElementById('customer-address').value,
        lineItems: [], // Note: We only save the header data for simplicity in this implementation, or the full calculated object.
        taxRate: parseFloat(document.getElementById('tax-rate').value) / 100,
        subtotal: 0,
        taxAmount: 0,
        totalAmount: 0,
        date: new Date().toISOString()
    };

    // Re-gather line items for saving the full structure
    const lineItems = [];
    document.querySelectorAll('.line-item-row').forEach(row => {
        const description = row.querySelector('input[name="item-description"]').value;
        const quantity = parseFloat(row.querySelector('input[name="item-quantity"]').value);
        const price = parseFloat(row.querySelector('input[name="item-price"]').value);
        if (description && !isNaN(quantity) && !isNaN(price)) {
            lineItems.push({ description, quantity, price });
        }
    });
    newInvoice.lineItems = lineItems;

    saveInvoice(newInvoice);
    alert(`Invoice ${invoiceId} saved successfully!`);
}

/**
 * Triggers the print function for the currently displayed invoice.
 */
function handlePrint() {
    const outputArea = document.getElementById('invoice-output-area');
    if (outputArea) {
        // Ensure the invoice is fully rendered before printing
        printInvoice({
            customerName: document.getElementById('customer-name').value,
            customerAddress: document.getElementById('customer-address').value,
            lineItems: [], // Line items are not strictly needed for printing the final formatted view
            taxRate: parseFloat(document.getElementById('tax-rate').value) / 100,
            subtotal: 0,
            taxAmount: 0,
            totalAmount: 0
        });
    }
}


// =============================================================================
// Application Entry Point
// =============================================================================

// Initialize the application when the DOM is fully loaded
window.onload = initializeApp;