window.StorageApp = {
    // Key for storing all invoices in localStorage
    STORAGE_KEY: 'invoices',

    /**
     * Loads all saved invoices from localStorage.
     * @returns {Array} An array of invoice objects, or an empty array if none are found.
     */
    loadInvoices: function() {
        const data = localStorage.getItem(this.STORAGE_KEY);
        if (data) {
            try {
                return JSON.parse(data);
            } catch (e) {
                console.error("Error parsing stored invoices:", e);
                return [];
            }
        }
        return [];
    },

    /**
     * Saves a new invoice object to localStorage.
     * @param {Object} invoice - The invoice object to save.
     */
    saveInvoice: function(invoice) {
        const invoices = this.loadInvoices();
        invoices.push(invoice);
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(invoices));
    },

    /**
     * Retrieves all saved invoices.
     * @returns {Array} All saved invoice objects.
     */
    getAllInvoices: function() {
        return this.loadInvoices();
    }
};