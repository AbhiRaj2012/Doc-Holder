/**
 * storage.js
 * Core JavaScript module for managing the state, handling input, and calculations
 * for the Calculator application.
 */

// Global state variables for the calculator
window.calculatorState = {
    currentOperand: '0',
    previousOperand: '0',
    operation: undefined,
    error: false
};

/**
 * Initializes the calculator state, sets up event listeners, and binds core functions to the UI elements.
 * @param {Array<HTMLElement>} elements - An array of DOM elements required for interaction.
 */
window.initializeCalculator = function(elements) {
    // Map DOM elements based on the manifest definitions
    const displayArea = elements.find(el => el.id === 'display_area');
    const operandInput = elements.find(el => el.id === 'operand_input');
    const operatorButtons = elements.find(el => el.id === 'operator_buttons');
    const controlButtons = elements.find(el => el.id === 'control_buttons');

    // Bind event listeners to the buttons (assuming they are dynamically added or referenced)
    // For this implementation, we assume the input functions will be called directly by app.js
    // based on the structure defined in the manifest.

    // Set initial display state
    updateDisplay(displayArea, window.calculatorState.currentOperand);

    // Attach listeners for demonstration (actual binding happens in app.js based on the provided structure)
    // We will rely on app.js to call these functions when buttons are clicked.
    console.log("Calculator initialized. State ready.");
};

/**
 * Processes numerical input from the keypad and updates the current operand state.
 * @param {string} value - The numerical value entered by the user.
 */
window.handleInput = function(value) {
    if (window.calculatorState.error) {
        window.clearState();
    }

    if (value === '.') {
        if (window.calculatorState.currentOperand.includes('.')) {
            return window.displayError('Error: Cannot add another decimal point.');
        }
    } else {
        // Handle initial input or replacement
        if (window.calculatorState.currentOperand === '0' && value !== '.') {
            window.calculatorState.currentOperand = value;
        } else {
            window.calculatorState.currentOperand = window.calculatorState.currentOperand + value;
        }
    }

    updateDisplay(document.getElementById('display_output'), window.calculatorState.currentOperand);
};

/**
 * Stores the selected arithmetic operation (+, -, *, /) for subsequent calculations.
 * @param {string} operator - The selected operator.
 */
window.selectOperator = function(operator) {
    const inputValue = parseFloat(window.calculatorState.currentOperand);

    if (window.calculatorState.previousOperand === '0') {
        window.calculatorState.previousOperand = inputValue;
    } else if (window.calculatorState.operation) {
        // If an operation is already pending, calculate the intermediate result first
        window.calculateResult();
        window.calculatorState.previousOperand = parseFloat(window.calculatorState.currentOperand);
    } else {
        window.calculatorState.previousOperand = parseFloat(window.calculatorState.currentOperand);
    }

    window.calculatorState.operation = operator;
    window.calculatorState.error = false;
};

/**
 * Executes the stored mathematical operation based on the current operands and updates the display.
 */
window.calculateResult = function() {
    let result;
    const prev = parseFloat(window.calculatorState.previousOperand);
    const current = parseFloat(window.calculatorState.currentOperand);

    if (isNaN(prev) || isNaN(current)) {
        window.displayError('Invalid input for calculation.');
        return;
    }

    switch (window.calculatorState.operation) {
        case '+':
            result = prev + current;
            break;
        case '-':
            result = prev - current;
            break;
        case '*':
            result = prev * current;
            break;
        case '/':
            if (current === 0) {
                window.displayError('Division by Zero.');
                window.clearState();
                return;
            }
            result = prev / current;
            break;
        default:
            return;
    }

    // Update state
    window.calculatorState.currentOperand = result.toString();
    window.calculatorState.previousOperand = ''; // Clear previous operand after calculation
    window.calculatorState.operation = undefined;
    window.calculatorState.error = false;

    // Update display
    updateDisplay(document.getElementById('display_output'), window.calculatorState.currentOperand);
};

/**
 * Resets all internal state variables (operands, operator) and clears the display to reset the calculator.
 */
window.clearState = function() {
    window.calculatorState = {
        currentOperand: '0',
        previousOperand: '0',
        operation: undefined,
        error: false
    };
    updateDisplay(document.getElementById('display_output'), '0');
    console.log("Calculator state cleared.");
};

/**
 * Handles error conditions by displaying a specific, user-friendly error message on the display.
 * @param {string} message - The error message to display.
 */
window.displayError = function(message) {
    window.calculatorState.error = true;
    window.displayErrorDisplay(message);
    console.error("Calculator Error:", message);
};

/**
 * Internal helper function to update the main display area.
 * @param {HTMLElement} displayElement - The DOM element to update.
 * @param {string} value - The value to display.
 */
function updateDisplay(displayElement, value) {
    if (window.calculatorState.error) {
        displayElement.textContent = "ERROR";
    } else {
        displayElement.textContent = value;
    }
}

/**
 * Internal helper function to update the dedicated error message area.
 * @param {HTMLElement} errorElement - The DOM element to update.
 * @param {string} message - The error message.
 */
function displayErrorDisplay(errorElement, message) {
    errorElement.textContent = message;
}