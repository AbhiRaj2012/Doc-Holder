/**
 * app.js
 * Core application logic. Initializes event listeners and connects the UI elements
 * to the mathematical operations defined in storage.js.
 */

// Ensure the window object is available for the functions defined in storage.js
// We rely on storage.js defining the functions, and app.js calling them correctly.

/**
 * Entry point for the Calculator application.
 * Initializes the calculator by setting up event listeners and binding UI elements.
 */
/**
 * app.js
 * Core application logic. Initializes event listeners and connects the UI elements
 * to the mathematical operations defined in storage.js.
 */

/**
 * Entry point for the Calculator application.
 * Initializes the calculator by setting up event listeners and binding UI elements.
 * Implements a strict, unidirectional data flow by delegating all state changes
 * and subsequent DOM updates to the storage layer.
 */
window.initializeCalculator = function() {
    // 1. Identify all necessary DOM elements based on the manifest
    const displayElement = document.getElementById('display_output');
    
    // 2. Identify all input elements (buttons) for event binding
    const inputElements = document.querySelectorAll('.number-btn, .operator-btn, .clear-btn, .decimal-btn, .equals-btn');

    // 3. Call the core initialization function from storage.js, passing the elements.
    // This function handles setting up the state and binding the event listeners,
    // ensuring that all subsequent DOM updates are driven by the state changes defined in storage.js.
    if (window.initializeCalculator) {
        window.initializeCalculator(Array.from(inputElements));
    } else {
        console.error("Error: storage.js functions not found. Initialization failed.");
    }
};

// Note: The functions handleInput, selectOperation, calculateResult, clearCalculator, and displayError
// are implemented in storage.js and are called implicitly when the DOM elements are clicked
// (which requires binding event listeners, typically done in app.js).