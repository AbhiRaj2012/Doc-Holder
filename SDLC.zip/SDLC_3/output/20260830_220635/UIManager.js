/**
 * UIManager.js
 * Manages the Presentation Layer (DOM manipulation) of the Calculator application.
 * Responsible for rendering results, handling visual feedback, and binding user input events
 * to the core logic provided by InputManager and CalculatorEngine.
 */

// --- Internal State (Optional, but good practice for a module) ---
window.UIManager = {
    // References to DOM elements
    displayElement: null,
    errorArea: null,
    inputKeypad: null,

    /**
     * Sets up initial event listeners and initializes display elements.
     */
    initializeUI: function() {
        this.displayElement = document.getElementById('display');
        this.errorArea = document.getElementById('error-message-area');
        this.inputKeypad = document.getElementById('keypad');

        if (!this.displayElement || !this.errorArea || !this.inputKeypad) {
            console.error("UIManager: Required DOM elements not found. UI initialization failed.");
            return;
        }

        // Bind the primary input handler to the keypad container
        this.bindKeypadEvents();
    },

    /**
     * Binds the primary event handler to the keypad to capture all button clicks.
     */
    bindKeypadEvents: function() {
        // Attach the primary event listener to the keypad container to capture all button clicks.
        this.inputKeypad.addEventListener('click', this.handleInputEvent.bind(this));
    },

    /**
     * Updates the main display element (DOM) with the provided numerical value and applies appropriate styling.
     * @param {string} value - The value to display.
     * @param {string} type - The type of display (e.g., 'input', 'result', 'error').
     */
    updateDisplay: function(value, type) {
        if (this.displayElement) {
            this.displayElement.textContent = value;
            this.displayElement.className = ''; // Clear previous states

            if (type === 'error') {
                this.displayElement.classList.add('error-state');
            } else if (type === 'result') {
                this.displayElement.classList.add('result-state');
            } else {
                // Default input state
                this.displayElement.classList.remove('error-state', 'result-state');
            }
        }
    },

    /**
     * Handles error states by updating the UI with a clear, user-friendly error message
     * and applying an error visual style.
     * @param {string} message - The error message to display.
     */
    displayError: function(message) {
        if (this.errorArea) {
            this.errorArea.textContent = message;
            this.errorArea.classList.add('error-state');
        }
    },

    /**
     * Receives the final calculated result and updates the display with the formatted output,
     * handling sign and decimal placement.
     * @param {number} result - The final numerical result.
     * @param {string} operation - The operation that led to this result.
     */
    renderResult: function(result, operation) {
        if (this.displayElement) {
            // Format the result to avoid excessive decimal places if it's an integer
            const formattedResult = parseFloat(result.toFixed(10));
            this.updateDisplay(formattedResult.toString(), 'result');
        }
    },

    /**
     * The primary event handler. Captures the clicked button's value and calls the InputManager
     * to update the calculation state.
     * @param {Event} event - The DOM event object.
     */
    handleInputEvent: function(event) {
        const target = event.target;
        const value = target.dataset.value || target.dataset.operator;

        if (!value) return;

        // Delegate the input processing to the InputManager
        window.InputManager.handleInput(value);
    }
};

// Initialize the UI when the script loads
window.UIManager.initializeUI();