/**
 * CalculatorEngine.js
 * The core mathematical logic module responsible for performing all arithmetic operations
 * and handling mathematical error checks (Model Layer).
 *
 * Dependencies: InputManager.js
 */

// --- Internal State ---
window.CalculatorEngine = {
    current_result: null,
    pending_operation: null,
    operand_a: null,
    operand_b: null
};

/**
 * Helper function to create a standardized error object.
 * @param {string} message - The error message.
 * @returns {object} An error object.
 */
window.CalculatorEngine.createError = function(message) {
    return {
        type: 'MathError',
        message: message
    };
};

/**
 * Calculates the sum of two numbers.
 * @param {number} operand1 - The first number.
 * @param {number} operand2 - The second number.
 * @returns {number} The sum.
 */
window.CalculatorEngine.add = function(operand1, operand2) {
    return operand1 + operand2;
};

/**
 * Calculates the difference between two numbers.
 * @param {number} operand1 - The first number.
 * @param {number} operand2 - The second number.
 * @returns {number} The difference (operand1 - operand2).
 */
window.CalculatorEngine.subtract = function(operand1, operand2) {
    return operand1 - operand2;
};

/**
 * Calculates the product of two numbers.
 * @param {number} operand1 - The first number.
 * @param {number} operand2 - The second number.
 * @returns {number} The product.
 */
window.CalculatorEngine.multiply = function(operand1, operand2) {
    return operand1 * operand2;
};

/**
 * Calculates the quotient of two numbers, with division by zero error handling.
 * @param {number} operand1 - The numerator.
 * @param {number} operand2 - The denominator.
 * @returns {number | object} The quotient (number) or an ErrorObject on division by zero.
 */
window.CalculatorEngine.divide = function(operand1, operand2) {
    if (operand2 === 0) {
        // Handle division by zero error (FR 3.1)
        return window.CalculatorEngine.createError("Error: Division by zero.");
    }
    return operand1 / operand2;
};

/**
 * Resets the internal state of the calculator to a neutral starting point.
 * (FR 2.4)
 * Note: This function resets the engine's internal state, which the InputManager will use
 * to clear the input history.
 * @returns {void}
 */
window.CalculatorEngine.clearAll = function() {
    window.CalculatorEngine.current_result = null;
    window.CalculatorEngine.pending_operation = null;
    window.CalculatorEngine.operand_a = null;
    window.CalculatorEngine.operand_b = null;
};