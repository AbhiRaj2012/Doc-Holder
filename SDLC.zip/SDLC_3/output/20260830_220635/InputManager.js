/**
 * InputManager.js
 * Manages all user input events, parses numerical input, and maintains the internal state
 * necessary for the calculation process.
 *
 * Dependencies: CalculatorEngine.js, UIManager.js
 */

// --- Internal State ---
window.InputManager = {
    currentOperand: null,
    previousOperand: null,
    operation: null,
    errorState: false,

    // References to external modules (assuming they are loaded globally)
    Calculator: null,
    UIManager: null,

    // DOM References
    displayElement: null,
    inputButtonsElement: null
};

/**
 * Initializes the event listeners for all numerical and operator buttons.
 * Binds the input processing logic to the DOM elements.
 */
window.InputManager.initializeInputListeners = function() {
    // 1. Get DOM references
    window.InputManager.displayElement = document.getElementById('display-output');
    window.InputManager.inputButtonsElement = document.getElementById('input-buttons');

    if (!window.InputManager.displayElement || !window.InputManager.inputButtonsElement) {
        console.error("InputManager: Required DOM elements not found.");
        return;
    }

    // 2. Attach listeners to all buttons within the input container
    const buttons = window.InputManager.inputButtonsElement.querySelectorAll('button');

    buttons.forEach(button => {
        button.addEventListener('click', function(event) {
            const value = event.target.dataset.value || event.target.dataset.operator;
            
            if (value) {
                // Determine if the input is a number, operator, or equals
                if (!isNaN(parseFloat(value)) || value === '.') {
                    window.InputManager.handleInput(value);
                } else if (['+', '-', '*', '/'].includes(value)) {
                    window.InputManager.handleOperation(value);
                } else if (value === '=') {
                    // Trigger calculation when equals is pressed
                    window.InputManager.calculate();
                }
            }
        });
    });
};

/**
 * Processes the raw string input received from a button click, updating the internal state.
 * @param {string} value - The numerical or decimal string input.
 */
window.InputManager.handleInput = function(value) {
    if (window.InputManager.errorState) {
        // If there is an error, clear the state before accepting new input
        window.InputManager.clearInput();
    }

    if (window.InputManager.currentOperand === null) {
        // Start a new operand
        window.InputManager.currentOperand = value;
    } else if (value === '.') {
        // Handle decimal point
        if (!window.InputManager.currentOperand.includes('.')) {
            window.InputManager.currentOperand += value;
        }
    } else {
        // Append new number
        window.InputManager.currentOperand += value;
    }

    window.InputManager.errorState = false;
};

/**
 * Stores the current operand and the pending operator, preparing the state for the next calculation.
 * @param {string} operator - The mathematical operator (+, -, *, /).
 */
window.InputManager.handleOperation = function(operator) {
    const inputValue = parseFloat(window.InputManager.currentOperand);

    if (window.InputManager.previousOperand === null) {
        // First operand setup
        window.InputManager.previousOperand = inputValue;
    } else if (window.InputManager.operation) {
        // If an operation is already pending, calculate the intermediate result
        window.InputManager.calculate();
        // Set the previous operand to the result of the previous operation
        window.InputManager.previousOperand = window.InputManager.currentOperand;
    }

    // Store the new operation and the current operand
    window.InputManager.operation = operator;
    window.InputManager.currentOperand = ''; // Clear current operand for the next number input
};

/**
 * Resets the internal state (current operand and pending operation) to a neutral starting state.
 */
window.InputManager.clearInput = function() {
    window.InputManager.currentOperand = null;
    window.InputManager.previousOperand = null;
    window.InputManager.operation = null;
    window.InputManager.errorState = false;
};

/**
 * Returns the current state of the calculation for consumption by the UIManager.
 * @returns {object} The current state object.
 */
window.InputManager.getCurrentState = function() {
    return {
        currentOperand: window.InputManager.currentOperand,
        previousOperand: window.InputManager.previousOperand,
        operation: window.InputManager.operation,
        errorState: window.InputManager.errorState
    };
};

/**
 * Internal method to trigger the calculation using the CalculatorEngine.
 * This function handles the delegation of the actual math execution.
 */
window.InputManager.calculate = function() {
    const prev = parseFloat(window.InputManager.previousOperand);
    const current = parseFloat(window.InputManager.currentOperand);
    let result;

    if (isNaN(prev) || isNaN(current)) {
        window.InputManager.errorState = true;
        window.InputManager.UIManager.displayError("Invalid input for calculation.");
        window.InputManager.clearInput();
        return;
    }

    switch (window.InputManager.operation) {
        case '+':
            result = prev + current;
            break;
        case '-':
            result = prev - current;
            break;
        case '*':
            result = prev * current;
            break;
        case '/':
            if (current === 0) {
                // Delegate division by zero error handling to the engine/manager
                window.InputManager.errorState = true;
                window.InputManager.UIManager.displayError("Error: Division by zero.");
                window.InputManager.clearInput();
                return;
            }
            result = prev / current;
            break;
        default:
            result = current;
    }

    // Update state
    window.InputManager.currentOperand = result.toString();
    window.InputManager.previousOperand = null;
    window.InputManager.operation = null;
    window.InputManager.errorState = false;
};

// Initialize the input listeners when the script loads
window.InputManager.initializeInputListeners();