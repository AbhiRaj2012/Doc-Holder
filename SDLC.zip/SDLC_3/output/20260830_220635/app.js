// app.js

// --- State Management ---
window.appState = {
    operands: [],
    current_operation: null,
    history: []
};

// --- Initialization Sequence ---
window.appState.initializeCalculator = function() {
    console.log("Application Initializing...");
    
    // 1. Initialize the core components (InputManager, CalculatorEngine, UIManager)
    // These modules are assumed to be globally available via window scope.

    // 2. Setup Event Handlers (as defined in module_structure)
    // Note: InputManager.initializeInputListeners is called internally in InputManager.js
    // We ensure the necessary setup is complete.

    // 3. Bind the primary flow logic
    // The InputManager handles raw input binding, but we define the orchestration here.
    
    console.log("Calculator initialized and event listeners bound.");
};

// --- Event Handlers ---

/**
 * Receives raw input from the UI, updates the internal state (operands/pending operation),
 * and triggers the calculation process.
 * @param {string} value - The numerical or decimal string input.
 * @param {string} operation - The pending mathematical operation.
 */
window.appState.handleInput = function(value, operation) {
    // This function acts as the bridge between the UI events (handled by InputManager)
    // and the state management.
    
    // Since InputManager.js already handles the complex state updates (currentOperand, previousOperand, operation),
    // this function primarily ensures the flow is correct, although in this specific architecture,
    // the InputManager's internal methods are the primary state modifiers.
    
    // We ensure the flow is managed by the InputManager's internal logic.
    // If we were to implement the full flow here, it would look like:
    // window.InputManager.handleInput(value);
    
    // For strict adherence to the manifest, we assume the InputManager handles the state update,
    // and this function is the entry point for the application logic flow.
    
    // We will rely on the InputManager's internal state updates for this implementation.
    console.log(`Input received: ${value}`);
};

/**
 * Calls the CalculatorEngine module to perform the actual mathematical operation,
 * handling potential errors and preparing the result for display.
 * @param {number} operand1 - The first number.
 * @param {number} operand2 - The second number.
 * @param {string} operator - The operator to use.
 */
window.appState.processCalculation = function(operand1, operand2, operator) {
    try {
        const engineResult = window.CalculatorEngine[operator](operand1, operand2);

        if (typeof engineResult === 'object' && engineResult.type === 'MathError') {
            // Handle division by zero or other engine errors
            window.appState.updateDisplay(null, engineResult.message);
            return;
        }

        // Update state and display the result
        window.appState.updateDisplay(engineResult, null);
        
        // Update history (optional, based on state_management definition)
        window.appState.history.push(`${operand1} ${operator} ${operand2} = ${engineResult}`);

    } catch (e) {
        // Catch unexpected errors
        window.appState.updateDisplay(null, "An unexpected calculation error occurred.");
    }
};

/**
 * Updates the Presentation Layer (DOM) with the calculated result or any relevant error messages,
 * ensuring immediate user feedback.
 * @param {number | null} result - The calculated result.
 * @param {string | null} error - Any error message.
 */
window.appState.updateDisplay = function(result, error = null) {
    if (result !== null) {
        // Use UIManager to handle the visual update
        window.UIManager.renderResult(result, window.appState.current_operation);
    } else if (error) {
        // Display error message
        window.UIManager.displayError(error);
    } else {
        // Clear display if no result or error
        window.UIManager.updateDisplay('0', 'input');
    }
};

/**
 * Resets the entire application state, clearing all stored operands, pending operations, and visual feedback.
 */
window.appState.clearAll = function() {
    // 1. Reset internal state
    window.appState.operands = [];
    window.appState.current_operation = null;
    window.appState.history = [];

    // 2. Reset the core logic engine state
    window.CalculatorEngine.clearAll();

    // 3. Update the display to a clean state
    window.UIManager.updateDisplay('0', 'input');
    console.log("Application state cleared successfully.");
};


// --- Execution ---
// Start the application by calling the initialization function
window.initializeCalculator();