/**
 * app.js
 * Manages the dynamic behavior, calculations, and DOM manipulation for the billing application.
 */

// --- DOM Element References ---
const customerAddressInput = document.getElementById('customerAddress');
const lineItemsContainer = document.getElementById('line-items-container');
const addItemBtn = document.getElementById('add-item-btn');
const generateButton = document.getElementById('generate-button');
const taxRateInput = document.getElementById('taxRate');
const subtotalDisplay = document.getElementById('subtotal-display');
const taxAmountDisplay = document.getElementById('tax-amount-display');
const totalAmountDisplay = document.getElementById('total-amount-display');
const invoiceListBody = document.getElementById('invoice-list-body');
const invoiceDetailsDisplay = document.getElementById('invoice-details-display');
const printButton = document.getElementById('print-button');

// --- State Management ---
let currentInvoiceItems = [];

/**
 * Calculates the subtotal, tax amount, and final total based on current line items and tax rate.
 * @returns {Object} An object containing subtotal, tax amount, and total amount.
 */
function calculateTotals() {
    let subtotal = 0;
    currentInvoiceItems.forEach(item => {
        // Ensure quantity and rate are treated as numbers for calculation
        const quantity = parseFloat(item.quantity) || 0;
        const rate = parseFloat(item.rate) || 0;
        subtotal += quantity * rate;
    });

    const taxRate = parseFloat(taxRateInput.value) / 100 || 0;
    const taxAmount = subtotal * taxRate;
    const totalAmount = subtotal + taxAmount;

    return {
        subtotal: subtotal,
        taxAmount: taxAmount,
        totalAmount: totalAmount
    };
}

/**
 * Updates the displayed total amounts on the form.
 */
function updateTotalsDisplay() {
    const totals = calculateTotals();
    subtotalDisplay.textContent = totals.subtotal.toFixed(2);
    taxAmountDisplay.textContent = totals.taxAmount.toFixed(2);
    totalAmountDisplay.textContent = totals.totalAmount.toFixed(2);
}

/**
 * Renders the dynamic line item rows based on the current state.
 */
function renderLineItems() {
    lineItemsContainer.innerHTML = '';

    if (currentInvoiceItems.length === 0) {
        // Re-add the default empty row if no items exist, or handle based on initial HTML structure
        const defaultRow = document.createElement('div');
        defaultRow.className = 'item-row';
        defaultRow.innerHTML = `
            <input type="text" name="itemDescription" placeholder="Description" required>
            <input type="number" name="quantity" placeholder="Quantity" required>
            <input type="number" name="rate" placeholder="Rate" step="0.01" required>
            <button type="button" class="remove-item-btn">Remove</button>
        `;
        lineItemsContainer.appendChild(defaultRow);
    } else {
        currentInvoiceItems.forEach((item, index) => {
            const itemRow = document.createElement('div');
            itemRow.className = 'item-row';
            itemRow.innerHTML = `
                <input type="text" name="itemDescription" value="${item.description}" placeholder="Description" required>
                <input type="number" name="quantity" value="${item.quantity}" placeholder="Quantity" required>
                <input type="number" name="rate" value="${item.rate}" step="0.01" placeholder="Rate" required>
                <button type="button" class="remove-item-btn">Remove</button>
            `;
            lineItemsContainer.appendChild(itemRow);
        });
    }

    // Re-attach event listeners for the newly created remove buttons
    attachRemoveItemListeners();
    updateTotalsDisplay();
}

/**
 * Adds a new line item to the state and re-renders the UI.
 * @param {string} description
 * @param {number} quantity
 * @param {number} rate
 */
function addItem(description, quantity, rate) {
    currentInvoiceItems.push({ description, quantity, rate });
    renderLineItems();
}

/**
 * Removes a line item from the state and re-renders the UI.
 * @param {number} index
 */
function removeItem(index) {
    currentInvoiceItems.splice(index, 1);
    renderLineItems();
}

/**
 * Handles the submission of the form to generate and save the invoice.
 * @param {Event} event
 */
function handleFormSubmit(event) {
    event.preventDefault();

    if (currentInvoiceItems.length === 0) {
        alert("Please add at least one item before generating the invoice.");
        return;
    }

    const totals = calculateTotals();
    const invoiceData = {
        id: Date.now(), // Simple unique ID
        customerAddress: customerAddressInput.value,
        items: currentInvoiceItems,
        taxRate: parseFloat(taxRateInput.value),
        subtotal: totals.subtotal,
        taxAmount: totals.taxAmount,
        totalAmount: totals.totalAmount,
        date: new Date().toISOString().split('T')[0]
    };

    // 1. Save to storage
    window.StorageApp.addInvoice(invoiceData);

    // 2. Display success and clear form (or reset state)
    alert(`Invoice ${invoiceData.id} generated successfully!`);
    
    // Reset form state for next entry
    resetForm();
}

/**
 * Resets the dynamic line items and totals back to their initial state.
 */
function resetForm() {
    currentInvoiceItems = [];
    // Re-render to show the initial empty state or default row
    renderLineItems();
    // Reset totals display to zero
    subtotalDisplay.textContent = '0.00';
    taxAmountDisplay.textContent = '0.00';
    totalAmountDisplay.textContent = '0.00';
}

/**
 * Renders all invoices from storage into the table.
 */
function renderInvoiceList() {
    const invoices = window.StorageApp.getAllInvoices();
    invoiceListBody.innerHTML = '';

    if (invoices.length === 0) {
        invoiceListBody.innerHTML = '<tr><td colspan="5" style="text-align: center;">No invoices found.</td></tr>';
        return;
    }

    invoices.forEach(invoice => {
        const row = invoiceListBody.insertRow();
        row.insertCell().textContent = invoice.id;
        row.insertCell().textContent = invoice.customerAddress;
        row.insertCell().textContent = invoice.date;
        row.insertCell().textContent = invoice.totalAmount.toFixed(2);
        
        const actionsCell = row.insertCell();
        actionsCell.innerHTML = `
            <button class="view-invoice-btn" data-id="${invoice.id}">View</button>
        `;
    });

    // Attach event listeners to the newly created 'View' buttons
    attachInvoiceActionListeners();
}

/**
 * Displays the details of a selected invoice in the viewer section.
 * @param {number} invoiceId
 */
function viewInvoiceDetails(invoiceId) {
    const invoices = window.StorageApp.getAllInvoices();
    const invoice = invoices.find(inv => inv.id === invoiceId);

    if (!invoice) {
        invoiceDetailsDisplay.innerHTML = '<p class="placeholder">Invoice not found.</p>';
        printButton.classList.add('hidden');
        return;
    }

    const itemRowsHtml = invoice.items.map(item => `
        <tr>
            <td>${item.description}</td>
            <td>${item.quantity}</td>
            <td>${item.rate.toFixed(2)}</td>
            <td>${(item.quantity * item.rate).toFixed(2)}</td>
        </tr>
    `).join('');

    invoiceDetailsDisplay.innerHTML = `
        <h3>Invoice ID: ${invoice.id}</h3>
        <p><strong>Customer Address:</strong> ${invoice.customerAddress}</p>
        <p><strong>Date:</strong> ${invoice.date}</p>
        <hr>
        <h4>Line Items:</h4>
        <table style="width:100%; border-collapse: collapse; margin-bottom: 15px;">
            <thead>
                <tr style="background-color: var(--primary-color); color: white;">
                    <th>Description</th>
                    <th>Qty</th>
                    <th>Rate</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody>
                ${itemRowsHtml}
            </tbody>
        </table>
        <hr>
        <p><strong>Subtotal:</strong> $${invoice.subtotal.toFixed(2)}</p>
        <p><strong>Tax Rate:</strong> ${(invoice.taxRate * 100).toFixed(2)}%</p>
        <p><strong>Tax Amount:</strong> $${invoice.taxAmount.toFixed(2)}</p>
        <h3 style="color: var(--primary-color);">Total Amount: $${invoice.totalAmount.toFixed(2)}</h3>
    `;

    printButton.classList.remove('hidden');
    
    // Set the print button action to the current invoice ID
    printButton.onclick = () => window.print();
}

/**
 * Attaches event listeners for removing line items.
 */
function attachRemoveItemListeners() {
    document.querySelectorAll('.remove-item-btn').forEach(button => {
        button.onclick = function() {
            // Find the parent item-row and remove it
            this.closest('.item-row').remove();
            // Re-render to update state and totals
            renderLineItems();
        };
    });
}

/**
 * Attaches event listeners for viewing invoices.
 */
function attachInvoiceActionListeners() {
    document.querySelectorAll('.view-invoice-btn').forEach(button => {
        button.addEventListener('click', function() {
            const invoiceId = parseInt(this.dataset.id);
            viewInvoiceDetails(invoiceId);
        });
    });
}

/**
 * Initialization function called on page load.
 */
function initialize() {
    // 1. Load initial data (though we don't use it for the form, it's good practice)
    // window.StorageApp.getAllInvoices(); // Not strictly needed for this flow

    // 2. Render the initial empty line item structure
    renderLineItems();

    // 3. Set up event listeners
    
    // Add Item Button Listener (Delegation on the form container)
    addItemBtn.addEventListener('click', () => {
        // Default values for a new item
        addItem('', 1, 0.01);
    });

    // Form Submission Listener
    generateButton.addEventListener('submit', handleFormSubmit);

    // Invoice View Listener (Delegation on the table body)
    invoiceListBody.addEventListener('click', (e) => {
        if (e.target.classList.contains('view-invoice-btn')) {
            const invoiceId = parseInt(e.target.dataset.id);
            viewInvoiceDetails(invoiceId);
        }
    });

    // Initial render of the invoice list (will be empty initially)
    renderInvoiceList();
}

// Start the application
window.onload = initialize;