window.appController = (function() {
    'use strict';

    // --- DOM Element References ---
    const navButtons = document.querySelectorAll('.nav-btn');
    const viewContents = document.querySelectorAll('.view-content');

    // --- Utility Functions ---

    /**
     * Switches the visible view based on the provided ID.
     * @param {string} viewId - The ID of the section to display.
     */
    function showView(viewId) {
        viewContents.forEach(view => {
            if (view.id === `view-${viewId}`) {
                view.classList.remove('hidden');
            } else {
                view.classList.add('hidden');
            }
        });
    }

    /**
     * Handles the navigation event by switching the view.
     * @param {Event} event - The click event.
     */
    function handleNavigation(event) {
        const targetView = event.target.dataset.view;
        if (targetView) {
            showView(targetView);
        }
    }

    // --- View-Specific Logic ---

    /**
     * Initializes the Home View content.
     */
    function initializeHomeView() {
        // 1. Load and display storage status
        const data = window.StorageApp.loadAllData();
        const storageStatusElement = document.getElementById('storage-status');
        if (storageStatusElement) {
            const count = data.invoices.length;
            storageStatusElement.textContent = `Total Invoices Stored: ${count}`;
        }

        // 2. Attach event listener for testing save
        const testSaveButton = document.getElementById('btn-test-storage');
        if (testSaveButton) {
            testSaveButton.addEventListener('click', handleTestStorageSave);
        }
    }

    /**
     * Handles the "Test Storage Save" action.
     */
    function handleTestStorageSave() {
        const newInvoice = {
            id: Date.now(),
            name: "Test Invoice",
            amount: 100.00,
            customer: {
                name: "Test Customer",
                address: "123 Test St"
            },
            items: [
                { name: "Service Fee", quantity: 1, price: 100.00 }
            ]
        };

        if (window.StorageApp.addInvoice(newInvoice)) {
            alert("Test Invoice successfully saved to LocalStorage!");
            // Refresh the storage view if it's visible
            if (document.getElementById('view-storage').classList.contains('hidden') === false) {
                loadStorageData();
            }
        } else {
            alert("Failed to save the test invoice.");
        }
    }

    /**
     * Populates the Storage View with invoice data.
     */
    function loadStorageData() {
        const invoices = window.StorageApp.getAllInvoices();
        const listElement = document.getElementById('storage-data-list');

        if (!listElement) return;

        // Clear existing list
        listElement.innerHTML = '';

        if (invoices.length === 0) {
            listElement.innerHTML = '<li style="background-color: var(--color-surface); border: 1px solid var(--color-border); padding: 1rem;">No data found.</li>';
            return;
        }

        invoices.forEach(invoice => {
            const li = document.createElement('li');
            li.style.cssText = 'background-color: var(--color-surface); border: 1px solid var(--color-border); padding: 1rem; margin-bottom: 0.5rem; border-radius: 4px;';
            li.innerHTML = `
                <strong>Invoice ID:</strong> ${invoice.id}<br>
                <strong>Name:</strong> ${invoice.name}<br>
                <strong>Amount:</strong> $${invoice.amount.toFixed(2)}
            `;
            listElement.appendChild(li);
        });
    }

    /**
     * Initializes the Invoice Generator View.
     */
    function initializeInvoiceView() {
        // 1. Load product data for dropdown
        const productData = window.dataManager.getProducts();
        window.invoiceGenerator.renderProductOptions(productData);

        // 2. Attach event listener for form submission
        const generateButton = document.getElementById('generate-invoice-btn');
        if (generateButton) {
            generateButton.addEventListener('click', handleGenerateInvoice);
        }
    }

    /**
     * Handles the invoice generation process.
     */
    function handleGenerateInvoice() {
        const invoiceName = document.getElementById('invoice-name').value.trim();
        const invoiceAmount = parseFloat(document.getElementById('invoice-amount').value);

        if (!invoiceName || isNaN(invoiceAmount) || invoiceAmount <= 0) {
            document.getElementById('invoice-output').innerHTML = '<p style="color: red;">Please enter a valid invoice name and amount.</p>';
            return;
        }

        // --- Mock Data Generation for Demonstration ---
        // Since the invoice form doesn't capture line items, we mock the data structure
        const mockItems = [
            { name: invoiceName, quantity: 1, price: invoiceAmount }
        ];
        const taxRate = 0.08; // 8% tax

        try {
            // Use the invoiceGenerator module
            const invoiceHTML = window.invoiceGenerator.generateInvoiceHTML({
                id: Date.now(),
                customer: {
                    name: invoiceName,
                    address: "Mock Address"
                },
                items: mockItems,
                totals: window.invoiceGenerator.calculateTotals(mockItems, taxRate)
            });

            document.getElementById('invoice-output').innerHTML = invoiceHTML;

        } catch (error) {
            console.error("Error generating invoice:", error);
            document.getElementById('invoice-output').innerHTML = `<p style="color: red;">An error occurred during calculation: ${error.message}</p>`;
        }
    }

    // --- Initialization and Setup ---

    /**
     * Sets up all initial event listeners and data loads when the controller starts.
     */
    function setup() {
        // 1. Setup Navigation Listeners
        navButtons.forEach(button => {
            button.addEventListener('click', handleNavigation);
        });

        // 2. Initialize View Logic
        initializeHomeView();
        initializeInvoiceView();

        // 3. Load initial data for the Storage view (in case it's the default view)
        loadStorageData();
    }

    // Execute setup when the script loads
    setup();

})();