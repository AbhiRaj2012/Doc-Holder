window.StorageApp = (function() {
    const STORAGE_KEYS = {
        INVOICES: "invoices",
        PRODUCTS: "products",
        SETTINGS: "settings"
    };

    /**
     * Helper function to safely retrieve data from LocalStorage.
     * @param {string} key - The key to retrieve.
     * @returns {any | null} The parsed data or null if not found or an error occurs.
     */
    function loadItem(key) {
        try {
            const data = localStorage.getItem(key);
            if (data === null) {
                return null;
            }
            return JSON.parse(data);
        } catch (error) {
            console.error(`Error loading data for key "${key}":`, error);
            return null;
        }
    }

    /**
     * Helper function to safely save data to LocalStorage.
     * @param {string} key - The key to save under.
     * @param {any} data - The data object to save.
     * @returns {boolean} True if save was successful, false otherwise.
     */
    function saveItem(key, data) {
        try {
            const jsonString = JSON.stringify(data);
            localStorage.setItem(key, jsonString);
            return true;
        } catch (error) {
            console.error(`Error saving data for key "${key}":`, error);
            return false;
        }
    }

    // --- Public Interface Functions ---

    /**
     * Retrieves all structured data (invoices, products, settings) from LocalStorage and returns a consolidated object.
     * Called upon application startup.
     * @returns {Object} Consolidated data object.
     */
    function loadAllData() {
        const invoices = loadItem(STORAGE_KEYS.INVOICES) || [];
        const products = loadItem(STORAGE_KEYS.PRODUCTS) || [];
        const settings = loadItem(STORAGE_KEYS.SETTINGS) || {};

        return {
            invoices: invoices,
            products: products,
            settings: settings
        };
    }

    /**
     * Serializes the provided data object and saves it to LocalStorage under the specified key.
     * @param {string} key - The LocalStorage key.
     * @param {any} data - The data object to save.
     * @returns {boolean} True if save was successful.
     */
    function saveData(key, data) {
        return saveItem(key, data);
    }

    /**
     * Retrieves the entire array of invoice objects stored in LocalStorage.
     * @returns {Array<Object>} The array of invoices.
     */
    function getAllInvoices() {
        return loadItem(STORAGE_KEYS.INVOICES) || [];
    }

    /**
     * Appends a new invoice object to the existing invoice array, updates the array, and saves the complete array back to LocalStorage.
     * @param {Object} invoiceObject - The new invoice to add.
     * @returns {boolean} True if the operation was successful.
     */
    function addInvoice(invoiceObject) {
        try {
            const invoices = loadItem(STORAGE_KEYS.INVOICES) || [];
            
            // Ensure the new item is valid before adding
            if (invoiceObject && typeof invoiceObject === 'object') {
                invoices.push(invoiceObject);
                saveItem(STORAGE_KEYS.INVOICES, invoices);
                return true;
            }
            return false;
        } catch (error) {
            console.error("Error adding invoice:", error);
            return false;
        }
    }

    /**
     * Retrieves the master list of products/services from LocalStorage.
     * @returns {Array<Object>} The array of products.
     */
    function getProducts() {
        return loadItem(STORAGE_KEYS.PRODUCTS) || [];
    }

    /**
     * Retrieves the user-defined application settings from LocalStorage.
     * @returns {Object} The settings object.
     */
    function getSettings() {
        return loadItem(STORAGE_KEYS.SETTINGS) || {};
    }

    // Expose the public interface
    return {
        loadAllData: loadAllData,
        saveData: saveData,
        getAllInvoices: getAllInvoices,
        addInvoice: addInvoice,
        getProducts: getProducts,
        getSettings: getSettings
    };
})();