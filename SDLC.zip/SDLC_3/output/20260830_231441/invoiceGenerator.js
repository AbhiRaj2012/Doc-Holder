/**
 * invoiceGenerator.js
 * Manages the core logic for invoice data entry, calculation, dynamic HTML generation, and printing.
 * Acts as the primary engine for invoice creation.
 */

// Ensure dependencies are available globally (assuming they are loaded before this script)
// window.StorageApp (from storage.js)
// window.appController (from appController.js)
// window.dataManager (from dataManager.js)

window.invoiceGenerator = (function() {

    /**
     * Retrieves necessary product and settings data from dataManager.js.
     * @returns {Object} Data required for invoice generation.
     */
    function loadInvoiceData() {
        try {
            // Assuming dataManager exposes a function to get necessary data
            const data = window.dataManager.loadAllData();
            return data;
        } catch (error) {
            console.error("Error loading invoice data:", error);
            return null;
        }
    }

    /**
     * Populates the dynamic input fields (e.g., line item inputs) with available products.
     * @param {Array<Object>} productData - The list of available products/services.
     */
    function renderProductOptions(productData) {
        const dropdown = document.getElementById('product-selection-dropdown');
        if (!dropdown) {
            console.error("DOM element 'product-selection-dropdown' not found.");
            return;
        }

        // Clear existing options
        dropdown.innerHTML = '<option value="">Select a Product</option>';

        if (productData && productData.length > 0) {
            productData.forEach(product => {
                const option = document.createElement('option');
                // Assuming product objects have an 'id' and 'name'
                option.value = product.id;
                option.textContent = `${product.name} ($${product.price.toFixed(2)})`;
                dropdown.appendChild(option);
            });
        }
    }

    /**
     * Iterates through line items, calculates subtotals, applies taxes, and determines the final grand total.
     * Ensures robust error handling for non-numeric inputs (NFR 2.2).
     * @param {Array<Object>} lineItems - Array of items with quantities and prices.
     * @param {number} taxRate - The tax rate to apply (e.g., 0.08 for 8%).
     * @returns {Object} Calculated totals including subtotals and grand total.
     */
    function calculateTotals(lineItems, taxRate) {
        let subtotal = 0;
        let totalTax = 0;

        if (!Array.isArray(lineItems)) {
            throw new Error("Input must be an array of line items.");
        }

        for (const item of lineItems) {
            const quantity = parseFloat(item.quantity);
            const price = parseFloat(item.price);

            // NFR 3.2: Input Validation for non-numeric inputs
            if (isNaN(quantity) || isNaN(price) || quantity <= 0 || price < 0) {
                throw new Error(`Invalid numeric input found in line item: ${JSON.stringify(item)}`);
            }

            subtotal += quantity * price;
        }

        const taxAmount = subtotal * taxRate;
        const grandTotal = subtotal + taxAmount;

        return {
            subtotal: subtotal,
            taxAmount: taxAmount,
            grandTotal: grandTotal,
            taxRate: taxRate // Added taxRate to the returned object
        };
    }

    /**
     * Dynamically constructs the complete, formatted HTML string for the invoice.
     * @param {Object} invoiceData - All necessary data (customer, items, totals).
     * @returns {string} The complete HTML string.
     */
    function generateInvoiceHTML(invoiceData) {
        if (!invoiceData) {
            return "<p style='color: red;'>Error: Invoice data is missing.</p>";
        }

        const { customer, items, totals } = invoiceData;

        let html = `
            <div class="invoice-document">
                <h1>INVOICE</h1>
                <h2>Invoice ID: ${invoiceData.id}</h2>
                
                <div class="invoice-header">
                    <h3>Billed To:</h3>
                    <p>${customer.name}</p>
                    <p>${customer.address}</p>
                </div>

                <table class="invoice-table">
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Line Total</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        // Generate line items
        items.forEach(item => {
            const lineTotal = item.quantity * item.price;
            html += `
                <tr>
                    <td>${item.name}</td>
                    <td>${item.quantity}</td>
                    <td>$${item.price.toFixed(2)}</td>
                    <td>$${lineTotal.toFixed(2)}</td>
                </tr>
            `;
        });

        html += `
                    </tbody>
                </table>

                <div class="invoice-totals">
                    <p>Subtotal: $${totals.subtotal.toFixed(2)}</p>
                    <p>Tax (${(totals.taxRate * 100).toFixed(1)}%): $${totals.taxAmount.toFixed(2)}</p>
                    <p class="grand-total">GRAND TOTAL: $${totals.grandTotal.toFixed(2)}</p>
                </div>
            </div>
        `;

        return html;
    }

    /**
     * Triggers the browser's native print dialog.
     * @param {string} invoiceHTML - The HTML content to be printed.
     */
    function printInvoice(invoiceHTML) {
        // Create a temporary window/iframe to display the HTML for printing
        const printWindow = window.open('', '_blank');
        printWindow.document.write('<html><head><title>Invoice Print</title>');
        printWindow.document.write('<style>@media print { .invoice-document { width: 100%; margin: 0; } } </style>');
        printWindow.document.write('</head><body>');
        printWindow.document.write(invoiceHTML);
        printWindow.document.write('</body></html>');
        printWindow.document.close();

        // Wait for content to load before printing (optional, but good practice)
        printWindow.focus();
        printWindow.print();
    }

    // Expose the public interface
    return {
        loadInvoiceData: loadInvoiceData,
        renderProductOptions: renderProductOptions,
        calculateTotals: calculateTotals,
        generateInvoiceHTML: generateInvoiceHTML,
        printInvoice: printInvoice
    };

})();