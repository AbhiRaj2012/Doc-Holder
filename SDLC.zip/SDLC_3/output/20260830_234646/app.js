// app.js

/**
 * Core application logic for binding DOM events to the mathematical functions.
 * This file is solely responsible for DOM manipulation and event handling.
 */

// Wait for the DOM content to be fully loaded before attempting to access elements
document.addEventListener('DOMContentLoaded', function() {
    // 1. Get references to the required DOM elements
    const displayElement = document.getElementById('display-output');
    const keypadContainer = document.getElementById('keypad-container');
    const errorMessageElement = document.getElementById('error-message');

    // Ensure elements exist before proceeding
    if (!displayElement || !keypadContainer || !errorMessageElement) {
        console.error("One or more required DOM elements were not found.");
        return;
    }

    // 2. Initialize the calculator logic by passing the DOM references
    // This calls the setup function defined in storage.js
    window.StorageApp.initializeCalculator({
        display: displayElement,
        keypadContainer: keypadContainer,
        errorMessage: errorMessageElement
    });
});