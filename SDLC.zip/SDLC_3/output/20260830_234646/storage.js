window.StorageApp = (function() {
    // --- Data Model Management ---
    let currentOperand = '0';
    let previousOperand = '';
    let operation = undefined;
    let result = '';

    // --- Internal Helper Functions ---

    /**
     * Updates the display element with the current state.
     * @param {HTMLElement} displayElement - The DOM element to update.
     * @param {string} value - The value to display.
     */
    function updateDisplay(displayElement, value) {
        displayElement.innerText = value;
    }

    /**
     * Updates the visual display based on the current result or operand.
     * @param {HTMLElement} displayElement - The DOM element to update.
     * @param {string} value - The value to display.
     */
    function updateDisplay(displayElement, value) {
        updateDisplay(displayElement, value);
    }

    /**
     * Clears all state variables to the initial default state.
     */
    function clearDisplay() {
        currentOperand = '0';
        previousOperand = '';
        operation = undefined;
        result = '';
    }

    /**
     * Processes user input (numbers, operators, decimal points).
     * @param {string} value - The input string from the button click.
     */
    /**
         * Processes user input (numbers, operators, decimal points).
         * Now handles building a full expression string.
         * @param {string} value - The input string from the button click.
         */
        function handleInput(value) {
            // Handle Clear (C)
            if (value === 'C') {
                clearDisplay();
                return;
            }

            // Input Validation: Check if the input is a valid number, decimal, or operator.
            const isOperator = ['+', '-', '*', '/'].includes(value);
            const isNumeric = !isNaN(parseFloat(value));

            if (!isOperator && !isNumeric && value !== '.') && value !== 'C') {
                displayError("Invalid Input");
                return;
            }

            // Handle Decimal Point
            if (value === '.') {
                if (currentOperand.includes('.')) {
                    // Prevent multiple decimal points
                    return;
                }
                // Allow decimal point only if we are building a number
                if (currentOperand === '0' && previousOperand === '') {
                    currentOperand = '0.';
                } else if (currentOperand !== '0' && previousOperand !== '') {
                    // If we are starting a new number after an operation, start with 0.
                    currentOperand = '0.';
                } else if (currentOperand === '0' && previousOperand !== '') {
                    // If we are continuing a previous result, just append the decimal.
                    currentOperand += '.';
                } else {
                    currentOperand += '.';
                }
                return;
            }

            // Handle Operators (+, -, *, /)
            if (isOperator) {
                // 1. Store the current operand as the previous operand if it exists.
                if (currentOperand !== '') {
                    previousOperand = currentOperand;
                }

                // 2. Handle chaining operations: If an operation is already pending, calculate the intermediate result.
                if (operation && previousOperand !== '') {
                    performCalculation();
                    previousOperand = result;
                }
                
                // 3. Set the new operation and reset current operand.
                operation = value;
                currentOperand = ''; // Reset current operand for the next number entry
                return;
            }

            // Handle Numbers
            // If the input is a valid number, append it.
            if (isNumeric) {
                // If currentOperand is '0' and we are entering a new number, replace '0' if the input is not '0' itself.
                if (currentOperand === '0' && value !== '0') {
                    currentOperand = value;
                } else {
                    currentOperand = currentOperand + value;
                }
            }
        }

    /**
     * Executes the stored mathematical operation.
     */
    /**
         * Evaluates the full expression using the Shunting-yard algorithm for correct precedence.
         * @param {string} expression - The full mathematical expression string.
         * @returns {string} The calculated result.
         */
        function performCalculation(expression) {
            // Step 1: Convert infix expression to postfix (Shunting-yard algorithm)
            const values = [];
            const operators = [];
            
            // Tokenize the expression (handle multi-digit numbers and operators)
            const tokens = expression.match(/(\d+\.?\d*|\+|\-|\*|\/|\(|\))/g) || [];

            for (const token of tokens) {
                if (!isNaN(parseFloat(token))) {
                    values.push(parseFloat(token));
                } else if (['+', '-', '*', '/', '(', ')'].includes(token)) {
                    operators.push(token);
                }
            }

            // Step 2: Process operators and values using stacks
            const output = [];
            const stack = [];

            for (const token of tokens) {
                if (!isNaN(parseFloat(token))) {
                    stack.push(token);
                } else if (token === '(') {
                    stack.push(token);
                } else if (token === ')') {
                    while (stack.length > 0 && stack[stack.length - 1] !== '(') {
                        output.push(stack.pop());
                    }
                    if (stack.length > 0 && stack[stack.length - 1] === '(') {
                        stack.pop(); // Pop the '('
                    }
                } else { // Operator
                    while (stack.length > 0 && operators[operators.length - 1] !== '(' && precedence(operators[operators.length - 1]) >= precedence(token)) {
                        output.push(stack.pop());
                    }
                    operators.push(token);
                }
            }

            // Pop remaining operators
            while (stack.length > 0) {
                output.push(stack.pop());
            }

            // Step 3: Evaluate the resulting postfix expression
            let resultStack = [];
            for (const token of output) {
                if (typeof token === 'number') {
                    resultStack.push(token);
                } else if (['+', '-', '*', '/'].includes(token)) {
                    const b = resultStack.pop();
                    const a = resultStack.pop();
                    let result;
                    switch (token) {
                        case '+': result = a + b; break;
                        case '-': result = a - b; break;
                        case '*': result = a * b; break;
                        case '/': 
                            if (b === 0) {
                                result = 'Error: Div by 0';
                                break;
                            }
                            result = a / b;
                            break;
                    }
                    resultStack.push(result);
                }
            }

            if (resultStack.length === 1) {
                return resultStack[0].toString();
            } else {
                return 'Error: Invalid Expression';
            }
        }

        /**
         * Helper function to determine operator precedence.
         * @param {string} op - The operator.
         * @returns {number} Precedence level.
         */
        function precedence(op) {
            if (op === '+' || op === '-') return 1;
            if (op === '*' || op === '/') return 2;
            return 0;
        }

    // --- Public Interface ---

    /**
     * Initializes the calculator by setting up event listeners.
     * @param {object} domElements - A map of DOM elements (e.g., { display: ..., keypad: ... }).
     */
    function initializeCalculator(domElements) {
        // Store references to the necessary DOM elements
        window.StorageApp.displayElement = domElements.display;
        window.StorageApp.keypadContainer = domElements.keypadContainer;
        window.StorageApp.errorMessageElement = domElements.errorMessage;

        // Attach event listeners to the keypad container
        const buttons = window.StorageApp.keypadContainer.querySelectorAll('.btn');

        buttons.forEach(button => {
            button.addEventListener('click', function() {
                const value = this.getAttribute('data-value');
                
                if (value === '=') {
                    performCalculation();
                } else if (value === 'C') {
                    clearDisplay();
                } else if (['+', '-', '*', '/'].includes(value)) {
                    handleInput(value);
                } else if (value === '.') {
                    handleInput(value);
                } else {
                    handleInput(value);
                }
                
                // Update display after every action
                updateDisplay(window.StorageApp.displayElement, currentOperand);
            });
        });
    }

    /**
     * Public method to update the display.
     * @param {string} result - The string to display.
     */
    function updateDisplay(result) {
        updateDisplay(window.StorageApp.displayElement, result);
    }

    /**
     * Public method to display error messages.
     * @param {string} message - The error message to display.
     */
    function displayError(message) {
        window.StorageApp.errorMessageElement.innerText = message;
    }

    // Expose the public interface
    return {
        initializeCalculator: initializeCalculator,
        handleInput: handleInput,
        performCalculation: performCalculation,
        clearDisplay: clearDisplay,
        updateDisplay: updateDisplay,
        displayError: displayError
    };
})();