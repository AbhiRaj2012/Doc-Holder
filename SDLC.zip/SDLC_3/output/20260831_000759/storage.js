/**
 * storage.js
 * Manages all client-side data persistence for the billing application using localStorage.
 */

// Define the key used to store the invoice data in localStorage
const STORAGE_KEY = 'billing_invoices';

/**
 * Retrieves the JSON string from localStorage and parses it into a usable array of invoice objects.
 * @returns {Array<Object>} The array of invoice objects, or an empty array if none are found or parsing fails.
 */
function loadInvoices() {
    try {
        const data = localStorage.getItem(STORAGE_KEY);
        if (!data) {
            return [];
        }
        const invoices = JSON.parse(data);
        // Ensure the loaded data is an array, even if corrupted
        if (Array.isArray(invoices)) {
            return invoices;
        }
        return [];
    } catch (error) {
        console.error("Error loading invoices from localStorage:", error);
        // Return an empty array on error to prevent application crash
        return [];
    }
}

/**
 * Serializes the array of invoice objects into a JSON string and stores it in localStorage.
 * @param {Array<Object>} invoicesArray - The array of invoice objects to be saved.
 * @returns {void}
 */
function saveInvoices(invoicesArray) {
    try {
        const data = JSON.stringify(invoicesArray);
        localStorage.setItem(STORAGE_KEY, data);
    } catch (error) {
        console.error("Error saving invoices to localStorage:", error);
    }
}

/**
 * Adds a new invoice object to the stored array and triggers a save operation.
 * @param {Object} invoiceObject - The new invoice object to be added.
 * @returns {void}
 */
function addInvoice(invoiceObject) {
    // 1. Load existing data
    const invoices = loadInvoices();

    // 2. Add the new invoice
    invoices.push(invoiceObject);

    // 3. Save the updated array
    saveInvoices(invoices);
}

/**
 * Retrieves and returns the complete list of all stored invoices from localStorage.
 * @returns {Array<Object>} The complete list of invoice objects.
 */
function getAllInvoices() {
    return loadInvoices();
}

// Expose the functions to the global scope (window) for use by app.js
window.StorageApp = {
    loadInvoices: loadInvoices,
    saveInvoices: saveInvoices,
    addInvoice: addInvoice,
    getAllInvoices: getAllInvoices
};