```javascript
/**
 * app.js
 * Main application controller for the Browser-Based Billing Application.
 * Manages all data persistence, calculations, DOM manipulation, and user interactions.
 */

// --- Global Application State and Constants ---
const DOM = {
    invoiceForm: document.getElementById('invoice-form'),
    invoiceListContainer: document.getElementById('invoice-list-body'),
    invoiceViewer: document.getElementById('invoice-details-display'),
    printButton: document.getElementById('print-button'),
    subtotalDisplay: document.getElementById('subtotal-display'),
    taxAmountDisplay: document.getElementById('tax-amount-display'),
    totalAmountDisplay: document.getElementById('total-amount-display')
};

// --- Core Application Logic (Interface Implementation) ---

/**
 * Retrieves all invoice data from localStorage and initializes the application state.
 * (Maps to loadInvoices())
 */
function loadInvoices() {
    const invoices = window.StorageApp.loadInvoices();
    return invoices;
}

/**
 * Serializes the array of invoice objects and stores it in localStorage.
 * (Maps to saveInvoices())
 * @param {Array<Object>} invoicesArray - The array of invoice objects to be saved.
 */
function saveInvoices(invoicesArray) {
    window.StorageApp.saveInvoices(invoicesArray);
}

/**
 * Dynamically generates and displays the list of saved invoices in the management view.
 * (Maps to renderInvoiceList())
 * @param {Array<Object>} invoices - The array of invoice objects to display.
 */
function renderInvoiceList(invoices) {
    DOM.invoiceListContainer.innerHTML = '';

    if (invoices.length === 0) {
        DOM.invoiceListContainer.innerHTML = '<tr><td colspan="5" style="text-align: center; padding: 15px;">No invoices found.</td></tr>';
        return;
    }

    invoices.forEach(invoice => {
        const row = DOM.invoiceListContainer.insertRow();
        row.insertCell().textContent = invoice.id;
        row.insertCell().textContent = invoice.customerName;
        row.insertCell().textContent = new Date(invoice.date).toLocaleDateString();
        row.insertCell().textContent = invoice.total;
        const actionsCell = row.insertCell();
        actionsCell.innerHTML = `<button class="view-btn" data-id="${invoice.id}">View</button>`;
    });

    // Attach event listeners to the newly created buttons
    document.querySelectorAll('.view-btn').forEach(button => {
        button.addEventListener('click', (e) => {
            const invoiceId = e.target.dataset.id;
            displayInvoice(invoiceId);
        });
    });
}

/**
 * Formats a single invoice object and renders its details into the dedicated invoice viewer area.
 * (Maps to displayInvoice())
 * @param {string} invoiceId - The ID of the invoice to display.
 */
function displayInvoice(invoiceId) {
    const invoices = loadInvoices();
    const invoice = invoices.find(inv => inv.id === invoiceId);

    if (!invoice) {
        DOM.invoiceViewer.innerHTML = '<p class="placeholder">Invoice not found.</p>';
        DOM.printButton.classList.add('hidden');
        return;
    }

    const formattedDate = new Date(invoice.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

    DOM.invoiceViewer.innerHTML = `
        <h2>Invoice #${invoice.id}</h2>
        <p><strong>Customer:</strong> ${invoice.customerName}</p>
        <p><strong>Address:</strong> ${invoice.customerAddress}</p>
        <p><strong>Date:</strong> ${formattedDate}</p>
        <h3>Line Items:</h3>
        <ul>
            ${invoice.items.map(item => `
                <li>${item.description}: ${item.quantity} x ${item.rate.toFixed(2)} = ${item.subtotal.toFixed(2)}</li>
            `).join('')}
        </ul>
        <div class="total-summary">
            <p>Subtotal: $${invoice.subtotal.toFixed(2)}</p>
            <p>Tax (${invoice.taxRate}%): $${invoice.taxAmount.toFixed(2)}</p>
            <p><strong>Total Amount: $${invoice.total.toFixed(2)}</strong></p>
        </div>
    `;

    DOM.printButton.classList.remove('hidden');
    DOM.printButton.onclick = () => handlePrint(invoiceId);
}

/**
 * Prepares the selected invoice data for printing and triggers the browser's native print dialog.
 * (Maps to handlePrint())
 * @param {string} invoiceId - The ID of the invoice to print.
 */
function handlePrint(invoiceId) {
    const invoices = loadInvoices();
    const invoice = invoices.find(inv => inv.id === invoiceId);

    if (!invoice) {
        alert("Error: Invoice not found for printing.");
        return;
    }

    // Create a printable view (simulating a print-friendly format)
    const printContent = `
        <div style="font-family: Arial, sans-serif; padding: 20px; border: 1px solid #000; max-width: 800px;">
            <h1>Invoice #${invoice.id}</h1>
            <p><strong>Customer:</strong> ${invoice.customerName}</p>
            <p><strong>Address:</strong> ${invoice.customerAddress}</p>
            <p><strong>Date:</strong> ${new Date(invoice.date).toDateString()}</p>
            <h3>Line Items:</h3>
            <ul>
                ${invoice.items.map(item => `
                    <li>${item.description}: ${item.quantity} @ ${item.rate.toFixed(2)} = ${item.subtotal.toFixed(2)}</li>
                `).join('')}
            </ul>
            <div class="total-summary" style="margin-top: 20px;">
                <p>Subtotal: $${invoice.subtotal.toFixed(2)}</p>
                <p>Tax (${invoice.taxRate}%): $${invoice.taxAmount.toFixed(2)}</p>
                <p style="font-size: 1.2em; font-weight: bold;">Total Amount: $${invoice.total.toFixed(2)}</p>
            </div>
        </div>
    `;

    // Use window.print() to trigger the print dialog
    const printWindow = window.open('', '_blank');
    printWindow.document.write('<html><head><title>Invoice Print</title></head><body>' + printContent + '</body></html>');
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
}

/**
 * Handles form submission, validates input, uses the calculator module to compute totals,
 * assigns a unique ID, and saves the new invoice object.
 * (Maps to generateAndSaveInvoice() and handleFormSubmission())
 * @param {Event} event - The form submission event.
 */
function handleFormSubmission(event) {
    event.preventDefault();

    const customerName = document.getElementById('customerName').value.trim();
    const customerAddress = document.getElementById('customerAddress').value.trim();
    const taxRate = parseFloat(document.getElementById('taxRate').value);

    if (!customerName || !customerAddress || isNaN(taxRate) || taxRate <= 0) {
        alert("Please ensure all fields are filled correctly and the tax rate is a positive number.");
        return;
    }

    const items = [];
    let subtotal = 0;

    // 1. Parse Line Items
    const itemRows = document.querySelectorAll('.item-row');
    itemRows.forEach(row => {
        const description = row.querySelector('input[name="itemDescription"]').value.trim();
        const quantity = parseFloat(row.querySelector('input[name="quantity"]').value);
        const rate = parseFloat(row.querySelector('input[name="rate"]').value);

        if (description && !isNaN(quantity) && !isNaN(rate) && rate > 0 && quantity > 0) {
            const itemSubtotal = quantity * rate;
            subtotal += itemSubtotal;
            items.push({
                description: description,
                quantity: quantity,
                rate: rate,
                subtotal: itemSubtotal
            });
        }
    });

    if (items.length === 0) {
        alert("Please add at least one valid item to the invoice.");
        return;
    }

    // 2. Use Calculator Module (Assumed dependency)
    // We assume calculator.js provides a function to handle the final calculation.
    // Since we don't have the actual calculator.js, we implement the logic here based on the manifest's intent.
    const taxAmount = subtotal * (taxRate / 100);
    const totalAmount = subtotal + taxAmount;

    // 3. Create Invoice Object
    const newInvoice = {
        id: Date.now().toString(), // Simple unique ID
        customerName: customerName,
        customerAddress: customerAddress,
        date: new Date().toISOString(),
        items: items,
        subtotal: subtotal,
        taxRate: taxRate,
        taxAmount: taxAmount,
        total: totalAmount
    };

    // 4. Save Data
    const currentInvoices = loadInvoices();
    currentInvoices.push(new