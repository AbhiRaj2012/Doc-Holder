"""
requirement_planner.py
=======================
Phase 2 add-on for loop_workflow_main.py / codebase_analyzer.py.

Where this sits in the pipeline:

    codebase_analyzer.py          ->  project_manifest.json (symbol index, no source)
    requirement_planner.py (HERE) ->  requirements.json + build_plan.json
    (future) editor / reviewer    ->  actually reads/writes source, guided by build_plan.json

Two jobs, two nodes:

  1. requirement_delta_node
     Takes the manifest (what the project already does, cheaply - just
     summaries/signatures, no raw code) + a natural-language change
     request, and produces a structured requirement list: each item is
     classified (new_feature / modify_feature / bugfix / remove_feature /
     non_functional), given a status (already_satisfied /
     partially_satisfied / not_satisfied), and grounded against real
     files/symbols in the manifest.

  2. planner_node
     Takes that requirement list and turns it into an ORDERED list of
     concrete Operations - one per unit of work - each naming an exact
     action, target file, target symbol (or None if it doesn't exist
     yet), plus constraints ("do not change this signature", "preserve
     DOM id X") and acceptance criteria a reviewer can later check
     against. This is the contract the editor/reviewer loop will consume;
     it never has to re-derive "what should I do and where" on its own.

Grounding, not trust:
  The LLM proposes file/symbol references; every reference is checked
  against the manifest afterward. Anything that doesn't exist in the
  manifest is stripped out and the drop is logged in the item's `notes`
  field rather than silently kept - same "manifest/disk is truth"
  principle codebase_analyzer.py uses for source retrieval.

Context stays bounded on large projects:
  A cheap keyword-overlap scorer (no embeddings, no extra LLM calls)
  ranks files by relevance to the change request. Only the top-N
  relevant files get their full symbol table in the prompt; every other
  file is still listed (by path) so the LLM knows it exists, but its
  symbol table isn't spent on tokens that probably won't matter.

Known limitations (documented rather than silently wrong):
  - Requirement/operation extraction is a single LLM call each (not
    chunked/mapped like the per-file summarization in codebase_analyzer).
    Fine for the common case; a very large change request touching most
    of a very large project may want batching - not implemented here.
  - depends_on / topological ordering is a best-effort DFS; a cycle in
    the LLM's own depends_on graph is broken silently (falls back to the
    LLM's suggested `order` field) rather than raising.
  - Relevance scoring is bag-of-words overlap, not semantic. It's cheap
    and good enough to bound context; swap in embeddings if you need
    better recall on large, loosely-named projects.

Drop this file next to loop_workflow_main.py and codebase_analyzer.py
(see section 7 at the bottom for wiring it into the existing StateGraph).
"""

import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional

from codebase_analyzer import _safe_json  # reuse the same tolerant JSON extractor

# ==========================================
# CONFIG
# ==========================================
MAX_RELEVANT_FILES = 12          # cap on files given full symbol tables in a prompt
MAX_CONTEXT_CHARS = 9000         # belt-and-suspenders alongside the file cap
_STOPWORDS = {
    "the", "a", "an", "and", "or", "to", "of", "in", "on", "for", "with",
    "is", "are", "this", "that", "it", "be", "as", "by", "at", "from",
    "we", "you", "i", "should", "want", "need", "please", "add", "make",
}

# ==========================================
# DATA MODEL
# ==========================================
@dataclass
class Requirement:
    id: str
    type: str                 # "new_feature" | "modify_feature" | "bugfix" | "remove_feature" | "non_functional"
    description: str
    status: str                # "already_satisfied" | "partially_satisfied" | "not_satisfied"
    related_files: list
    related_symbols: list       # [{"file": ..., "name": ...}]
    notes: str


@dataclass
class Operation:
    id: str
    requirement_ids: list
    action: str                 # "create_file" | "add_symbol" | "modify_symbol" | "delete_symbol" | "modify_file_generic"
    target_file: str
    target_symbol: Optional[str]
    symbol_kind: Optional[str]  # "function" | "class" | "method" | "block" | None
    is_new_file: bool
    is_new_symbol: bool
    description: str
    constraints: list
    acceptance_criteria: list
    depends_on: list
    order: int


# ==========================================
# 1. MANIFEST LOADING / STATE HELPERS
# ==========================================
def load_manifest(run_dir) -> dict:
    """Loads project_manifest.json as written by
    codebase_analyzer.build_project_manifest()."""
    path = Path(run_dir) / "project_manifest.json"
    if not path.exists():
        raise FileNotFoundError(
            f"No project_manifest.json in {run_dir} - run codebase_analyzer first."
        )
    return json.loads(path.read_text(encoding="utf-8"))


def _get_manifest_from_state(state: dict) -> dict:
    """analyze_existing_project_node stores the manifest as a JSON string
    on state['project_manifest']; a fresh CLI run may hand us a dict
    directly. Accept either."""
    pm = state.get("project_manifest")
    if pm is None:
        return load_manifest(state["run_dir"])
    return json.loads(pm) if isinstance(pm, str) else pm


def _write_log(run_dir: Path, step: str, details: str):
    """Same log format loop_workflow_main.py uses, so both scripts'
    entries interleave in one readable execution_log.txt."""
    from datetime import datetime
    log_file = Path(run_dir) / "execution_log.txt"
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"\n[{datetime.now().strftime('%H:%M:%S')}] === {step.upper()} ===\n")
        f.write(str(details) + "\n")
        f.write("-" * 80 + "\n")


# ==========================================
# 2. RELEVANCE FILTERING (keeps prompts bounded on big projects)
# ==========================================
def _tokenize(text: str) -> set:
    return {
        w for w in re.findall(r"[a-zA-Z_][a-zA-Z0-9_]*", (text or "").lower())
        if w not in _STOPWORDS and len(w) > 2
    }


def _file_text_blob(fm: dict) -> str:
    parts = [fm["path"], fm.get("file_summary", "")]
    for s in fm.get("symbols", []):
        parts.append(s.get("name", ""))
        parts.append(s.get("purpose", ""))
        parts.append(s.get("signature", ""))
    return " ".join(parts)


def _render_file_block(fm: dict) -> str:
    lines = [
        f"\n--- FILE: {fm['path']} ({fm['language']}, {fm['total_lines']} lines) ---",
        f"Summary: {fm.get('file_summary', '')}",
    ]
    for s in fm.get("symbols", []):
        owner = f"{s['parent']}." if s.get("parent") else ""
        sig = f" :: {s['signature']}" if s.get("signature") else ""
        lines.append(
            f"  [{s['kind']}] {owner}{s['name']}{sig} "
            f"(L{s['line_start']}-{s['line_end']}) - {s.get('purpose', '')}"
        )
    if not fm.get("symbols"):
        lines.append("  (no indexed symbols)")
    return "\n".join(lines)


def select_relevant_files(manifest: dict, query_text: str,
                           max_files: int = MAX_RELEVANT_FILES,
                           max_chars: int = MAX_CONTEXT_CHARS):
    """Ranks files by keyword overlap with the change request. Returns
    (selected_file_manifests, other_file_paths). When nothing scores
    (e.g. a vague request, or a small project), the original manifest
    order is preserved (Python's sort is stable), so small projects just
    get everything up to the caps - no filtering surprise."""
    query_tokens = _tokenize(query_text)
    scored = sorted(
        manifest["files"],
        key=lambda fm: len(_tokenize(_file_text_blob(fm)) & query_tokens),
        reverse=True,
    )
    selected, other, budget = [], [], max_chars
    for fm in scored:
        block = _render_file_block(fm)
        if len(selected) < max_files and budget - len(block) > 0:
            selected.append(fm)
            budget -= len(block)
        else:
            other.append(fm["path"])
    return selected, other


def render_manifest_context(manifest: dict, query_text: str) -> str:
    selected, other = select_relevant_files(manifest, query_text)
    lines = [
        f"PROJECT ROOT: {manifest['root']}",
        f"PROJECT TYPE: {manifest['project_type']} ({manifest['file_count']} file(s))",
    ]
    if manifest.get("entry_points"):
        lines.append(f"ENTRY POINTS: {', '.join(manifest['entry_points'])}")
    lines.append("\n=== RELEVANT FILES (full symbol tables) ===")
    for fm in selected:
        lines.append(_render_file_block(fm))
    if other:
        lines.append("\n=== OTHER FILES IN PROJECT (exist, not expanded here) ===")
        lines.extend(f"- {p}" for p in other)
    return "\n".join(lines)


# ==========================================
# 3. REQUIREMENT DELTA (map: manifest + change request -> requirement list)
# ==========================================
_REQUIREMENT_PROMPT = """You are a requirements analyst for an existing software project. \
You are given (a) a cheap index of what the project currently contains - file summaries and \
symbol names/signatures/purposes, NOT the actual source code - and (b) a change request from \
the project owner.

PROJECT INDEX:
{context}

CHANGE REQUEST:
{change_request}

Do two things:
1. In one or two sentences, summarize the CURRENT STATE of the project as it relates to this request.
2. Break the change request into a list of discrete requirements. For each one:
   - classify it as one of: new_feature, modify_feature, bugfix, remove_feature, non_functional
   - judge its status against the CURRENT project: already_satisfied, partially_satisfied, or not_satisfied
   - point to the specific files/symbols from the PROJECT INDEX above that are relevant \
(use exact paths and exact symbol names as shown - do not invent files or symbols that are not listed)
   - if a requirement needs something genuinely new (new file or new symbol), leave related_files/ \
related_symbols pointing at the CLOSEST existing file(s) it should live near, and say so in notes.

Return ONLY a JSON object, no markdown fences, no explanation, with exactly these keys:
{{
  "current_state_summary": "...",
  "assumptions": ["any assumption you had to make because the request was ambiguous - else []"],
  "requirements": [
    {{
      "id": "R1",
      "type": "new_feature",
      "description": "...",
      "status": "not_satisfied",
      "related_files": ["exact/path/from/index.ext"],
      "related_symbols": [{{"file": "exact/path/from/index.ext", "name": "exact_symbol_name"}}],
      "notes": "..."
    }}
  ]
}}
"""


def _validate_requirements(manifest: dict, data: dict) -> list:
    """Grounds every file/symbol reference the LLM proposed against the
    real manifest. Anything not found is dropped and recorded in notes -
    never silently kept, never silently discarded without a trace."""
    known_files = {fm["path"] for fm in manifest["files"]}
    known_symbols = {fm["path"]: {s["name"] for s in fm["symbols"]} for fm in manifest["files"]}

    requirements = []
    for i, r in enumerate(data.get("requirements") or [], 1):
        rid = r.get("id") or f"R{i}"

        raw_files = r.get("related_files") or []
        related_files = [f for f in raw_files if f in known_files]
        dropped_files = [f for f in raw_files if f not in known_files]

        raw_symbols = r.get("related_symbols") or []
        related_symbols, dropped_symbols = [], []
        for s in raw_symbols:
            f, n = s.get("file"), s.get("name")
            if f in known_symbols and n in known_symbols.get(f, set()):
                related_symbols.append({"file": f, "name": n})
            else:
                dropped_symbols.append(f"{f}:{n}")

        notes = (r.get("notes") or "").strip()
        if dropped_files:
            notes = (notes + f" [dropped unrecognized files: {dropped_files}]").strip()
        if dropped_symbols:
            notes = (notes + f" [dropped unrecognized symbols: {dropped_symbols}]").strip()

        requirements.append(Requirement(
            id=rid,
            type=r.get("type", "new_feature"),
            description=(r.get("description") or "").strip(),
            status=r.get("status", "not_satisfied"),
            related_files=related_files,
            related_symbols=related_symbols,
            notes=notes,
        ))
    return requirements


def build_requirement_delta(llm, manifest: dict, change_request: str, run_dir: Path) -> dict:
    context = render_manifest_context(manifest, change_request)
    prompt = _REQUIREMENT_PROMPT.format(context=context, change_request=change_request)
    _write_log(run_dir, "Requirement Delta - PROMPT", prompt)

    try:
        raw = llm.invoke(prompt).content.strip()
    except Exception as e:
        raw = ""
        print(f"   [!] requirement analysis failed: {e}")
    data = _safe_json(raw)
    _write_log(run_dir, "Requirement Delta - RAW OUTPUT", raw)

    requirements = _validate_requirements(manifest, data)
    delta = {
        "current_state_summary": data.get("current_state_summary", "(unavailable - review manually)"),
        "assumptions": data.get("assumptions") or [],
        "requirements": [asdict(r) for r in requirements],
    }

    Path(run_dir, "requirements.json").write_text(json.dumps(delta, indent=2), encoding="utf-8")
    Path(run_dir, "REQUIREMENTS.md").write_text(_render_requirements_md(delta), encoding="utf-8")
    return delta


def _render_requirements_md(delta: dict) -> str:
    lines = ["# Requirement Delta", "", "## Current State", delta["current_state_summary"], ""]
    if delta.get("assumptions"):
        lines.append("## Assumptions")
        lines.extend(f"- {a}" for a in delta["assumptions"])
        lines.append("")
    lines.append("## Requirements")
    status_icon = {"already_satisfied": "✅", "partially_satisfied": "🟡", "not_satisfied": "🔴"}
    for r in delta["requirements"]:
        icon = status_icon.get(r["status"], "•")
        lines.append(f"### {icon} {r['id']} [{r['type']}] - {r['status']}")
        lines.append(r["description"])
        if r["related_files"]:
            lines.append(f"- Files: {', '.join(r['related_files'])}")
        if r["related_symbols"]:
            syms = ", ".join(f"{s['file']}::{s['name']}" for s in r["related_symbols"])
            lines.append(f"- Symbols: {syms}")
        if r["notes"]:
            lines.append(f"- Notes: {r['notes']}")
        lines.append("")
    return "\n".join(lines)


# ==========================================
# 4. PLANNER (reduce: requirement list -> ordered operations)
# ==========================================
_PLANNER_PROMPT = """You are a technical planner for an existing software project. You are given \
a validated requirement list and the same project index used to produce it. Turn the requirements \
into a concrete, ORDERED list of operations another engineer (or another LLM, working file-by-file \
with no memory of this conversation) will execute one at a time.

PROJECT INDEX:
{context}

REQUIREMENTS (already validated against the project - file/symbol names here are real):
{requirements_json}

Rules for each operation:
- action is exactly one of: create_file, add_symbol, modify_symbol, delete_symbol, modify_file_generic
- target_file: the exact existing path from the index, OR a new path if action is create_file
- target_symbol: the exact existing symbol name if modifying/deleting, a suggested new name if \
adding, or null for modify_file_generic / create_file
- constraints: concrete guardrails the implementer MUST follow while touching this piece - e.g. \
"keep the signature calculate_total(items) unchanged", "preserve DOM id 'submit-btn' used by script.js", \
"do not alter unrelated functions in this file"
- acceptance_criteria: a short checklist a reviewer can mechanically check afterward
- depends_on: ids of other operations that must be completed first (e.g. a new helper function \
must exist before the operation that calls it) - else []
- order: your suggested execution order as an integer starting at 1 (ties broken by depends_on)
- requirement_ids: which requirement id(s) this operation fulfills

Also list any open_questions - things you could not resolve from the index alone and a human \
should confirm before building.

Return ONLY a JSON object, no markdown fences, no explanation, with exactly these keys:
{{
  "global_constraints": ["constraints that apply to every operation in this plan"],
  "operations": [
    {{
      "id": "OP1",
      "requirement_ids": ["R1"],
      "action": "modify_symbol",
      "target_file": "exact/path.ext",
      "target_symbol": "exact_or_suggested_name",
      "symbol_kind": "function",
      "description": "...",
      "constraints": ["..."],
      "acceptance_criteria": ["..."],
      "depends_on": [],
      "order": 1
    }}
  ],
  "open_questions": ["..."]
}}
"""


def _validate_operations(manifest: dict, data: dict) -> list:
    known_files = {fm["path"] for fm in manifest["files"]}
    known_symbols = {fm["path"]: {s["name"] for s in fm["symbols"]} for fm in manifest["files"]}
    valid_actions = {"create_file", "add_symbol", "modify_symbol", "delete_symbol", "modify_file_generic"}

    operations = []
    for i, op in enumerate(data.get("operations") or [], 1):
        oid = op.get("id") or f"OP{i}"
        action = op.get("action") if op.get("action") in valid_actions else "modify_file_generic"
        target_file = op.get("target_file") or ""
        target_symbol = op.get("target_symbol") or None

        is_new_file = target_file not in known_files
        # if the file doesn't exist yet, this can only sensibly be a file-creation op
        if is_new_file and action not in ("create_file",):
            action = "create_file"

        is_new_symbol = bool(target_symbol) and not (
            not is_new_file and target_symbol in known_symbols.get(target_file, set())
        )
        # can't modify/delete a symbol that doesn't exist - demote to an add instead
        if is_new_symbol and action in ("modify_symbol", "delete_symbol"):
            action = "add_symbol"

        operations.append(Operation(
            id=oid,
            requirement_ids=op.get("requirement_ids") or [],
            action=action,
            target_file=target_file,
            target_symbol=target_symbol,
            symbol_kind=op.get("symbol_kind"),
            is_new_file=is_new_file,
            is_new_symbol=is_new_symbol,
            description=(op.get("description") or "").strip(),
            constraints=op.get("constraints") or [],
            acceptance_criteria=op.get("acceptance_criteria") or [],
            depends_on=op.get("depends_on") or [],
            order=op.get("order") if isinstance(op.get("order"), int) else i,
        ))
    return operations


def _topological_order(operations: list) -> list:
    """Best-effort dependency-respecting order. Falls back to the LLM's
    own `order` hint for anything not reachable via depends_on, and
    silently breaks cycles (a cycle here means the plan itself is
    contradictory - not something to hang on, but worth surfacing via
    the PLAN.md so a human can catch it)."""
    by_id = {op.id: op for op in operations}
    ordered, visited, in_progress = [], set(), set()

    def visit(op):
        if op.id in visited or op.id in in_progress:
            return
        in_progress.add(op.id)
        for dep in op.depends_on:
            if dep in by_id:
                visit(by_id[dep])
        in_progress.discard(op.id)
        visited.add(op.id)
        ordered.append(op)

    for op in sorted(operations, key=lambda o: o.order):
        visit(op)
    return ordered


def build_plan(llm, manifest: dict, requirement_delta: dict, run_dir: Path) -> dict:
    all_reqs_text = json.dumps(requirement_delta["requirements"], indent=2)
    context = render_manifest_context(
        manifest,
        " ".join(r["description"] for r in requirement_delta["requirements"]),
    )
    prompt = _PLANNER_PROMPT.format(context=context, requirements_json=all_reqs_text)
    _write_log(run_dir, "Planner - PROMPT", prompt)

    try:
        raw = llm.invoke(prompt).content.strip()
    except Exception as e:
        raw = ""
        print(f"   [!] planning failed: {e}")
    data = _safe_json(raw)
    _write_log(run_dir, "Planner - RAW OUTPUT", raw)

    operations = _validate_operations(manifest, data)
    ordered = _topological_order(operations)

    plan = {
        "global_constraints": data.get("global_constraints") or [],
        "open_questions": data.get("open_questions") or [],
        "operations": [asdict(op) for op in ordered],
    }

    Path(run_dir, "build_plan.json").write_text(json.dumps(plan, indent=2), encoding="utf-8")
    Path(run_dir, "PLAN.md").write_text(_render_plan_md(plan), encoding="utf-8")
    return plan


def _render_plan_md(plan: dict) -> str:
    lines = ["# Build Plan", ""]
    if plan.get("global_constraints"):
        lines.append("## Global Constraints")
        lines.extend(f"- {c}" for c in plan["global_constraints"])
        lines.append("")
    lines.append("## Operations (execution order)")
    for op in plan["operations"]:
        tag = "NEW FILE" if op["is_new_file"] else ("NEW SYMBOL" if op["is_new_symbol"] else "EXISTING")
        sym = f"::{op['target_symbol']}" if op["target_symbol"] else ""
        lines.append(f"### {op['id']} - {op['action']} - {op['target_file']}{sym}  [{tag}]")
        lines.append(f"Fulfills: {', '.join(op['requirement_ids']) or '(none listed)'}")
        lines.append(op["description"])
        if op["constraints"]:
            lines.append("Constraints:")
            lines.extend(f"  - {c}" for c in op["constraints"])
        if op["acceptance_criteria"]:
            lines.append("Acceptance criteria:")
            lines.extend(f"  - [ ] {c}" for c in op["acceptance_criteria"])
        if op["depends_on"]:
            lines.append(f"Depends on: {', '.join(op['depends_on'])}")
        lines.append("")
    if plan.get("open_questions"):
        lines.append("## Open Questions")
        lines.extend(f"- {q}" for q in plan["open_questions"])
    return "\n".join(lines)


# ==========================================
# 5. LANGGRAPH INTEGRATION NODES
# ==========================================
def requirement_delta_node(state: dict) -> dict:
    """
    Expects on `state`:
        run_dir         : Path
        project_manifest: dict OR JSON string (as analyze_existing_project_node leaves it)
        change_request  : str  -> what the user wants done to the EXISTING project
                          (falls back to state['user_input'] if change_request isn't set,
                          so this can share the same entry field as the greenfield flow)

    Returns:
        requirement_delta : dict (see build_requirement_delta)
    """
    print("\n📋 [Requirement Delta] Comparing change request against current project...")
    manifest = _get_manifest_from_state(state)
    change_request = state.get("change_request") or state.get("user_input", "")

    delta = build_requirement_delta(llm, manifest, change_request, state["run_dir"])
    _write_log(state["run_dir"], "REQUIREMENT DELTA NODE",
               f"{len(delta['requirements'])} requirement(s) extracted.")
    return {"requirement_delta": delta}


def planner_node(state: dict) -> dict:
    """
    Expects on `state`:
        run_dir           : Path
        project_manifest   : dict OR JSON string
        requirement_delta  : dict (output of requirement_delta_node)

    Returns:
        build_plan          : dict (see build_plan)
        pending_operations  : list[str]  -> operation ids in execution order,
                               mirrors `pending_files` so the future editor
                               loop can pop from it the same way
        current_operation_index: int, starts at 0
    """
    print("\n🗺️  [Planner] Turning requirements into an operation sequence...")
    manifest = _get_manifest_from_state(state)
    plan = build_plan(llm, manifest, state["requirement_delta"], state["run_dir"])

    _write_log(state["run_dir"], "PLANNER NODE",
               f"{len(plan['operations'])} operation(s) planned, "
               f"{len(plan['open_questions'])} open question(s).")

    return {
        "build_plan": plan,
        "pending_operations": [op["id"] for op in plan["operations"]],
        "current_operation_index": 0,
    }


# ==========================================
# 6. STANDALONE LLM HANDLE
# ==========================================
llm = None
try:
    from langchain_ollama import ChatOllama
    llm = ChatOllama(model="gemma4:e2b", num_predict=1536, num_ctx=8192, temperature=0.1)
except Exception as e:
    print(f"[requirement_planner] no default LLM configured ({e}); "
          f"pass your own `llm` into build_requirement_delta(...)/build_plan(...) instead.")


# ==========================================
# 7. WIRING INTO loop_workflow_main.py's StateGraph
# ==========================================
"""
    from requirement_planner import requirement_delta_node, planner_node, llm as planner_llm

    # Extend AgentState with:
    #   change_request: str
    #   requirement_delta: dict
    #   build_plan: dict
    #   pending_operations: list[str]
    #   current_operation_index: int
    # (project_manifest is already on AgentState from codebase_analyzer's wiring)

    workflow.add_node("requirement_delta", requirement_delta_node)
    workflow.add_node("planner", planner_node)

    workflow.add_edge("analyze_existing", "requirement_delta")
    workflow.add_edge("requirement_delta", "planner")
    workflow.add_edge("planner", "editor")   # editor_node (phase 3) will need a small
                                              # change: instead of pulling file_system[...]
                                              # it pops pending_operations[0], looks the op
                                              # up in build_plan, and for existing symbols
                                              # calls codebase_analyzer.get_exact_source(...)
                                              # to fetch just the lines it needs to edit.
"""

# ==========================================
# 8. STANDALONE TEST
# ==========================================
if __name__ == "__main__":
    import sys

    if llm is None:
        print("No default LLM configured - edit section 6 or import build_requirement_delta/"
              "build_plan and pass your own `llm` object.")
        sys.exit(1)

    run_dir_input = input("Path to a run_dir that already has project_manifest.json: ").strip()
    run_dir = Path(run_dir_input)
    manifest = load_manifest(run_dir)
    print(f"Loaded manifest: {manifest['file_count']} file(s), {manifest['project_type']}.")

    change_request = input("\nWhat do you want done to this project?\n> ").strip()

    delta = build_requirement_delta(llm, manifest, change_request, run_dir)
    print(f"\n✅ {len(delta['requirements'])} requirement(s) written to "
          f"{run_dir/'requirements.json'} / REQUIREMENTS.md")

    plan = build_plan(llm, manifest, delta, run_dir)
    print(f"✅ {len(plan['operations'])} operation(s) written to "
          f"{run_dir/'build_plan.json'} / PLAN.md")
    if plan["open_questions"]:
        print("\n⚠️  Open questions for you to resolve before building:")
        for q in plan["open_questions"]:
            print(f"   - {q}")
