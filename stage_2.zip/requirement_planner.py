"""
requirement_planner.py
=======================
Phase 2: consumes project_manifest.json (from codebase_analyzer.py) + a user
change-request, and produces:
  1. requirement_analysis.json - what's already there vs what's missing/changed
  2. execution_plan.json       - ordered, surgical operations for the future
                                  editor/reviewer loop to execute

Context management:
  - Never sends full manifest to the LLM. Uses a 2-stage funnel:
      a) file_index (path + 2-3 line summary only) -> cheap relevance filter
         picks which files matter for this request (skipped if project is
         already small).
      b) symbol_digest (signatures/purpose/lines, NO source) built ONLY for
         the relevant files -> feeds requirement + planner prompts.
  - Source code is never pulled here. Operations reference target_file /
    target_symbol / context_refs; the editor resolves exact lines later via
    codebase_analyzer.get_exact_source().
"""

import json
import re
from pathlib import Path
from datetime import datetime
from typing import TypedDict, Optional

from langgraph.graph import StateGraph, END
from langchain_ollama import ChatOllama

llm = ChatOllama(model="gemma4:e2b", num_predict=2048, num_ctx=8192, temperature=0.1)

MAX_FILES_BEFORE_FILTER = 40
MAX_SYMBOLS_PER_FILE = 40
MAX_DIGEST_CHARS = 12000


def write_log(run_dir: Path, step: str, details):
    log_file = Path(run_dir) / "execution_log.txt"
    ts = datetime.now().strftime("%H:%M:%S")
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"\n[{ts}] === {step.upper()} ===\n{details}\n{'-' * 80}\n")


def _safe_json(raw: str, kind: str = "object"):
    raw = re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.MULTILINE).strip()
    pattern = r"\{.*\}" if kind == "object" else r"\[.*\]"
    m = re.search(pattern, raw, re.DOTALL)
    if not m:
        return None
    try:
        return json.loads(m.group(0))
    except json.JSONDecodeError:
        return None


class PlannerState(TypedDict):
    user_request: str
    run_dir: Path
    project_manifest: dict
    relevant_files: list
    requirement_analysis: dict
    execution_plan: dict


# ==========================================
# 1. LOAD MANIFEST
# ==========================================
def load_manifest_node(state: PlannerState):
    manifest_path = Path(state["run_dir"]) / "project_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    write_log(state["run_dir"], "Loaded Manifest",
              f"{manifest['file_count']} files, type={manifest['project_type']}")
    return {"project_manifest": manifest}


def build_file_index(manifest: dict) -> list:
    return [{"path": fm["path"], "language": fm["language"],
              "lines": fm["total_lines"], "summary": fm["file_summary"]}
            for fm in manifest["files"]]


def build_symbol_digest(manifest: dict, file_paths: set) -> list:
    out = []
    for fm in manifest["files"]:
        if fm["path"] not in file_paths:
            continue
        syms = fm["symbols"][:MAX_SYMBOLS_PER_FILE]
        out.append({
            "path": fm["path"], "language": fm["language"], "summary": fm["file_summary"],
            "symbols": [{"name": s["name"], "kind": s["kind"], "parent": s["parent"],
                          "signature": s["signature"], "purpose": s["purpose"],
                          "lines": [s["line_start"], s["line_end"]], "calls": s["calls"]}
                         for s in syms],
        })
    return out


# ==========================================
# 2. RELEVANCE FILTER (cheap - summaries only)
# ==========================================
_RELEVANCE_PROMPT = """User change request: {request}
Entry points: {entry_points}

Files (path, language, line count, summary):
{files}

Return ONLY a JSON array of the file paths (strings) most relevant to fulfilling the
request - files that will likely need reading or editing. Include entry points if
plausibly relevant. No explanation, no markdown fences, JSON array only.
"""


def select_relevant_files_node(state: PlannerState):
    manifest = state["project_manifest"]
    file_index = build_file_index(manifest)

    if len(file_index) <= MAX_FILES_BEFORE_FILTER:
        relevant = [f["path"] for f in file_index]
    else:
        prompt = _RELEVANCE_PROMPT.format(
            request=state["user_request"],
            entry_points=", ".join(manifest.get("entry_points", [])) or "none detected",
            files=json.dumps(file_index, indent=2)[:MAX_DIGEST_CHARS],
        )
        raw = llm.invoke(prompt).content.strip()
        relevant = _safe_json(raw, "array") or [f["path"] for f in file_index]

    write_log(state["run_dir"], "Relevance Filter", relevant)
    return {"relevant_files": relevant}


# ==========================================
# 3. REQUIREMENT ANALYZER
# ==========================================
_REQUIREMENT_PROMPT = """You are a requirement analyst comparing an EXISTING codebase against a
NEW change request. Use only the symbol digest below (no raw code) as your knowledge of
what already exists.

PROJECT TYPE: {project_type}
ENTRY POINTS: {entry_points}
USER REQUEST: {request}

SYMBOL DIGEST:
{digest}

Return ONLY a JSON object with exactly these keys:
{{
  "change_type": "new_feature | bug_fix | enhancement | refactor | ui_change",
  "existing_capabilities": [
    {{"file": "path", "symbol": "name or null", "note": "what already covers part of the request"}}
  ],
  "gap_requirements": [
    {{"id": "REQ-1", "description": "precise, testable requirement", "priority": "high|medium|low",
      "affects_files": ["path", ...]}}
  ],
  "risks": ["short risk or conflict notes, e.g. naming collisions, breaking existing calls"]
}}
No markdown fences, no explanation outside the JSON.
"""


def requirement_analyzer_node(state: PlannerState):
    manifest = state["project_manifest"]
    digest = build_symbol_digest(manifest, set(state["relevant_files"]))
    prompt = _REQUIREMENT_PROMPT.format(
        project_type=manifest.get("project_type"),
        entry_points=", ".join(manifest.get("entry_points", [])) or "none detected",
        request=state["user_request"],
        digest=json.dumps(digest, indent=2)[:MAX_DIGEST_CHARS],
    )
    write_log(state["run_dir"], "Requirement Analyzer - PROMPT", prompt)

    raw = llm.invoke(prompt).content.strip()
    data = _safe_json(raw, "object") or {
        "change_type": "unknown", "existing_capabilities": [],
        "gap_requirements": [], "risks": ["LLM output failed to parse"], "raw_output": raw,
    }
    write_log(state["run_dir"], "Requirement Analyzer - OUTPUT", json.dumps(data, indent=2))

    (Path(state["run_dir"]) / "requirement_analysis.json").write_text(
        json.dumps(data, indent=2), encoding="utf-8")
    return {"requirement_analysis": data}


# ==========================================
# 4. PLANNER
# ==========================================
_PLANNER_PROMPT = """You are a technical planner. Convert the gap requirements into an ORDERED
list of surgical operations for a downstream editor LLM that edits ONE symbol/file at a time
and never sees the whole project at once.

USER REQUEST: {request}

REQUIREMENT ANALYSIS:
{requirement_analysis}

SYMBOL DIGEST (existing project structure):
{digest}

Return ONLY a JSON object:
{{
  "operations": [
    {{
      "id": "OP-1",
      "requirement_id": "REQ-1",
      "operation_type": "create_file | add_function | add_class | modify_function | modify_class | modify_block | delete_symbol",
      "target_file": "path (existing or new)",
      "target_symbol": "existing symbol name, or null if creating new",
      "new_symbol_name": "name if operation_type creates a new symbol, else null",
      "new_symbol_signature": "intended signature/declaration if creating new, else null",
      "description": "exactly what to change and why, specific enough to act on without re-reading the whole file",
      "constraints": ["surgical guardrails: keep existing signature X unchanged, reuse ID Y, don't touch unrelated lines, ..."],
      "context_refs": ["path::symbol_name entries this operation needs to see the exact source of, else []"],
      "depends_on": ["OP-ids that must complete first, else []"]
    }}
  ]
}}
Order operations so dependencies come first. Keep each operation scoped to ONE symbol or ONE new file.
No markdown fences, no explanation outside the JSON.
"""


def _validate_plan(data: dict, manifest: dict) -> dict:
    valid_files = {fm["path"] for fm in manifest["files"]}
    valid_symbols = {(fm["path"], s["name"]) for fm in manifest["files"] for s in fm["symbols"]}
    for op in data.get("operations", []):
        tf, ts = op.get("target_file"), op.get("target_symbol")
        op["target_file_exists"] = tf in valid_files
        op["target_symbol_exists"] = bool(ts) and (tf, ts) in valid_symbols
    return data


def _render_plan_md(data: dict) -> str:
    lines = ["# Execution Plan", ""]
    for op in data.get("operations", []):
        target = f"{op.get('target_file')}::{op.get('target_symbol') or op.get('new_symbol_name') or '(new)'}"
        lines.append(f"## [{op.get('id')}] {op.get('operation_type')} — {target}")
        lines.append(op.get("description", ""))
        if op.get("constraints"):
            lines.append("**Constraints:**")
            lines += [f"- {c}" for c in op["constraints"]]
        if op.get("context_refs"):
            lines.append(f"**Context needed:** {', '.join(op['context_refs'])}")
        if op.get("depends_on"):
            lines.append(f"**Depends on:** {', '.join(op['depends_on'])}")
        lines.append("")
    return "\n".join(lines)


def planner_node(state: PlannerState):
    manifest = state["project_manifest"]
    digest = build_symbol_digest(manifest, set(state["relevant_files"]))
    prompt = _PLANNER_PROMPT.format(
        request=state["user_request"],
        requirement_analysis=json.dumps(state["requirement_analysis"], indent=2),
        digest=json.dumps(digest, indent=2)[:MAX_DIGEST_CHARS],
    )
    write_log(state["run_dir"], "Planner - PROMPT", prompt)

    raw = llm.invoke(prompt).content.strip()
    data = _safe_json(raw, "object") or {"operations": [], "raw_output": raw}
    data = _validate_plan(data, manifest)
    write_log(state["run_dir"], "Planner - OUTPUT", json.dumps(data, indent=2))

    (Path(state["run_dir"]) / "execution_plan.json").write_text(
        json.dumps(data, indent=2), encoding="utf-8")
    (Path(state["run_dir"]) / "EXECUTION_PLAN.md").write_text(
        _render_plan_md(data), encoding="utf-8")
    return {"execution_plan": data}


# ==========================================
# 5. GRAPH
# ==========================================
workflow = StateGraph(PlannerState)
workflow.add_node("load_manifest", load_manifest_node)
workflow.add_node("select_relevant", select_relevant_files_node)
workflow.add_node("requirements_analysis", requirement_analyzer_node)
workflow.add_node("planner", planner_node)

workflow.set_entry_point("load_manifest")
workflow.add_edge("load_manifest", "select_relevant")
workflow.add_edge("select_relevant", "requirements_analysis")
workflow.add_edge("requirements_analysis", "planner")
workflow.add_edge("planner", END)

app = workflow.compile()


# ==========================================
# 6. INTEGRATION NODE (for loop_workflow_main.py's StateGraph)
# ==========================================
def plan_change_node(state):
    """Drop-in node: expects run_dir (with project_manifest.json already
    written by codebase_analyzer) and user_request/user_input on state.
    Returns execution_plan for the future editor/reviewer nodes to consume
    instead of pending_files."""
    result = app.invoke({
        "user_request": state.get("user_request") or state.get("user_input"),
        "run_dir": state["run_dir"],
    })
    return {
        "project_manifest": result["project_manifest"],
        "requirement_analysis": result["requirement_analysis"],
        "execution_plan": result["execution_plan"],
    }


# ==========================================
# 7. STANDALONE TEST
# ==========================================
if __name__ == "__main__":
    run_dir_in = Path(input("run_dir containing project_manifest.json: ").strip())
    user_request_in = input("What do you want to do?\n> ").strip()

    write_log(run_dir_in, "SYSTEM", f"Planning change: '{user_request_in}'")
    result = app.invoke({"user_request": user_request_in, "run_dir": run_dir_in})

    n_req = len(result["requirement_analysis"].get("gap_requirements", []))
    n_ops = len(result["execution_plan"].get("operations", []))
    print(f"\n✅ {n_req} requirement(s), {n_ops} operation(s) planned.")
    print(f"See {run_dir_in/'requirement_analysis.json'} and {run_dir_in/'execution_plan.json'}")
