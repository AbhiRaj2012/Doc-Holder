from typing import TypedDict, List, Optional, Literal
from pydantic import BaseModel, Field

class TaskItem(BaseModel):
    task_id: str = Field(description="Unique ID, e.g., TASK-1")
    title: str = Field(description="Short title of the atomic task")
    target_files: List[str] = Field(description="Relative file paths to modify or create")
    instructions: str = Field(description="Detailed implementation instructions")
    verification_cmd: str = Field(description="Command to verify task, e.g., pytest tests/test_api.py")

class TaskPlan(BaseModel):
    tasks: List[TaskItem] = Field(description="Ordered list of tasks from first to last")

class ReviewResult(BaseModel):
    passed: bool = Field(description="True ONLY if all requirements are met and tests pass")
    feedback: str = Field(description="Specific root-cause feedback and fix instructions if failed")

class AgentState(TypedDict):
    project_path: str
    manifest_path: str
    issue_json_path: str
    user_input: str
    project_requirements: str
    force_reanalyze: bool

    manifest_data: dict

    task_stack: List[dict]
    current_task: Optional[dict]

    iteration_count: int
    max_iterations: int
    last_editor_diff: str
    reviewer_feedback: str
    task_completed: bool
    last_verification: str

    logs: List[str]

    human_decision: Optional[Literal["proceed", "work_on_it", "abort"]]

    run_id: str
    elapsed_sec: float
    task_attempts: int
    total_iterations: int
    planned_tasks: List[dict]
    task_results: List[dict]
    tool_trace: List[dict]
    eval_summary: dict
