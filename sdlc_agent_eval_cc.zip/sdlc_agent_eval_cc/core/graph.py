from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver
from core.state import AgentState
from core.evaluation import timed_node
from core.agents import (
    analyzer_node,
    planner_node,
    pop_next_task_node,
    editor_node,
    reviewer_node,
    complete_task_node,
    save_issue_node,
    evaluator_node,
)

def route_after_reviewer(state: AgentState) -> str:
    if state["task_completed"]:
        return "complete_task"
    if state["iteration_count"] < state["max_iterations"]:
        return "editor"
    return "save_issue"

def route_after_human(state: AgentState) -> str:
    decision = state.get("human_decision")
    if decision == "work_on_it":
        return "editor"
    elif decision == "proceed":
        return "complete_task"
    return "evaluator"

def route_stack_check(state: AgentState) -> str:
    return "evaluator" if len(state["task_stack"]) == 0 else "pop_next_task"

def human_decision_router_node(state: AgentState) -> dict:
    return {}

def build_sdlc_graph():
    workflow = StateGraph(AgentState)

    workflow.add_node("analyzer", timed_node(analyzer_node))
    workflow.add_node("planner", timed_node(planner_node))
    workflow.add_node("pop_next_task", timed_node(pop_next_task_node))
    workflow.add_node("editor", timed_node(editor_node))
    workflow.add_node("reviewer", timed_node(reviewer_node))
    workflow.add_node("complete_task", timed_node(complete_task_node))
    workflow.add_node("save_issue", timed_node(save_issue_node))
    workflow.add_node("human_gate", human_decision_router_node)
    workflow.add_node("evaluator", evaluator_node)

    workflow.add_edge(START, "analyzer")
    workflow.add_edge("analyzer", "planner")
    workflow.add_conditional_edges("planner", route_stack_check, {"pop_next_task": "pop_next_task", "evaluator": "evaluator"})

    workflow.add_edge("pop_next_task", "editor")
    workflow.add_edge("editor", "reviewer")
    workflow.add_conditional_edges("reviewer", route_after_reviewer, {
        "complete_task": "complete_task",
        "editor": "editor",
        "save_issue": "save_issue",
    })

    workflow.add_edge("save_issue", "human_gate")
    workflow.add_conditional_edges("human_gate", route_after_human, {
        "editor": "editor",
        "complete_task": "complete_task",
        "evaluator": "evaluator",
    })

    workflow.add_conditional_edges("complete_task", route_stack_check, {"pop_next_task": "pop_next_task", "evaluator": "evaluator"})
    workflow.add_edge("evaluator", END)

    memory = MemorySaver()
    return workflow.compile(checkpointer=memory, interrupt_before=["human_gate"])
