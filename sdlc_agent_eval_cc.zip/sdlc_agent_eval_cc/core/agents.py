import json
import subprocess
from pathlib import Path
from langchain_ollama import ChatOllama
from langchain_core.messages import SystemMessage, HumanMessage
from core.state import AgentState, TaskPlan, ReviewResult
from core.config_loader import load_config
from core.aider_bridge import build_aider_repomap_manifest, run_aider_editor
from core.safety import safe_target_files, parse_verification_cmd, truncate
from core.gitutil import ensure_git_repo, working_diff, stage_all, has_real_changes
from core.evaluation import build_trace_entry, build_task_result, evaluate_run, eval_cfg
from core.benchmark import persist

def get_dynamic_llm(cfg: dict) -> ChatOllama:
    return ChatOllama(
        model=cfg["ollama"]["model"],
        base_url=cfg["ollama"]["base_url"],
        num_ctx=int(cfg["ollama"]["num_ctx"]),
        temperature=float(cfg["ollama"]["temperature"]),
    )

def invoke_structured(llm, messages, retries: int = 2):
    for _ in range(retries + 1):
        try:
            out = llm.invoke(messages)
            if out is not None:
                return out
        except Exception:
            continue
    return None

def analyzer_node(state: AgentState) -> dict:
    cfg = load_config()
    ensure_git_repo(cfg["workflow"]["project_path"])
    manifest_file = Path(cfg["workflow"]["manifest_path"])
    if manifest_file.exists() and not state.get("force_reanalyze", False):
        manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
        msg = "Loaded existing manifest.json."
    else:
        manifest = build_aider_repomap_manifest(cfg)
        msg = "Generated new manifest.json using Aider RepoMap (Tree-sitter)."
    return {"manifest_data": manifest, "logs": state.get("logs", []) + [f"[Analyser] {msg}"]}

def planner_node(state: AgentState) -> dict:
    cfg = load_config()
    llm = get_dynamic_llm(cfg).with_structured_output(TaskPlan)
    reasoning = cfg["ollama"].get("reasoning_effort", "medium")

    manifest = dict(state["manifest_data"])
    manifest["file_list"] = manifest.get("file_list", [])[:300]

    sys_prompt = (
        f"Reasoning: {reasoning}\n"
        "You are the Requirements + Planning Agent. Review the Aider Repository Map and break the user request "
        "into an ordered list of atomic coding tasks. target_files must be relative paths inside the repository. "
        "verification_cmd must be a single command without pipes or shell operators (e.g. pytest tests/test_x.py)."
    )
    user_prompt = (
        f"Project Context:\n{state['project_requirements']}\n\n"
        f"Aider RepoMap & File Manifest:\n{truncate(json.dumps(manifest, indent=2), 40000)}\n\n"
        f"User Request:\n{state['user_input']}"
    )

    plan = invoke_structured(llm, [SystemMessage(content=sys_prompt), HumanMessage(content=user_prompt)])
    if plan is None or not plan.tasks:
        return {
            "task_stack": [],
            "planned_tasks": [],
            "logs": state.get("logs", []) + ["[Planner] Failed to produce a valid plan."],
        }

    root = cfg["workflow"]["project_path"]
    stack = []
    for t in plan.tasks:
        d = t.model_dump()
        d["target_files"] = safe_target_files(root, d["target_files"])
        if d["target_files"]:
            stack.append(d)
    return {
        "task_stack": stack,
        "planned_tasks": [dict(t) for t in stack],
        "task_results": [],
        "tool_trace": [],
        "total_iterations": 0,
        "logs": state.get("logs", []) + [f"[Planner] Created {len(stack)} tasks in Task Stack."],
    }

def pop_next_task_node(state: AgentState) -> dict:
    current = state["task_stack"][0]
    return {
        "current_task": current,
        "iteration_count": 0,
        "task_attempts": 0,
        "task_completed": False,
        "reviewer_feedback": "",
        "last_editor_diff": "",
        "last_verification": "none",
        "human_decision": None,
        "logs": state.get("logs", []) + [f"[Task Stack] Active: {current['task_id']} - {current['title']}"],
    }

def editor_node(state: AgentState) -> dict:
    cfg = load_config()
    task = state["current_task"]
    iteration = state["iteration_count"] + 1
    attempt = state.get("task_attempts", 0) + 1
    root = cfg["workflow"]["project_path"]

    log = f"[Editor (Aider)] Completed iteration {iteration} on {task['task_id']}."
    error = None
    try:
        run_aider_editor(
            cfg=cfg,
            target_files=task["target_files"],
            instructions=task["instructions"],
            reviewer_feedback=state.get("reviewer_feedback", ""),
        )
    except Exception as e:
        error = str(e)
        log = f"[Editor (Aider)] Iteration {iteration} on {task['task_id']} failed: {e}"

    diff = working_diff(root)
    entry = build_trace_entry(task, attempt, diff, error)
    return {
        "iteration_count": iteration,
        "task_attempts": attempt,
        "total_iterations": state.get("total_iterations", 0) + 1,
        "tool_trace": state.get("tool_trace", []) + [entry],
        "last_editor_diff": diff,
        "logs": state.get("logs", []) + [log],
    }

def reviewer_node(state: AgentState) -> dict:
    cfg = load_config()
    task = state["current_task"]
    root = cfg["workflow"]["project_path"]
    max_diff = int(cfg["workflow"].get("max_diff_chars", 24000))
    max_out = int(cfg["workflow"].get("max_output_chars", 8000))
    timeout = int(cfg["workflow"].get("verification_timeout", 120))
    diff = state["last_editor_diff"]

    if not has_real_changes(diff):
        fb = "Editor produced no file changes. Apply the required edits to the target files."
        return {
            "task_completed": False,
            "reviewer_feedback": fb,
            "last_verification": "no changes",
            "logs": state.get("logs", []) + [f"[Reviewer] Passed=False | {fb}"],
        }

    cmd_output = "No verification command specified."
    exit_code = None
    cmd = (task.get("verification_cmd") or "").strip()
    if cmd:
        parts = parse_verification_cmd(cmd)
        if parts is None:
            cmd_output = f"Verification command rejected by allowlist: {cmd}"
        else:
            try:
                proc = subprocess.run(
                    parts, cwd=root, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout
                )
                exit_code = proc.returncode
                cmd_output = f"Exit Code: {exit_code}\nSTDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}"
            except subprocess.TimeoutExpired:
                exit_code = -1
                cmd_output = f"Verification command timed out after {timeout}s."
            except FileNotFoundError as e:
                exit_code = -1
                cmd_output = f"Verification command not found: {e}"

    llm = get_dynamic_llm(cfg).with_structured_output(ReviewResult)
    sys_prompt = (
        f"Reasoning: {cfg['ollama'].get('reasoning_effort', 'medium')}\n"
        "You are the Reviewer Agent. Inspect the Git Diff produced by Aider and the test execution output. "
        "Mark passed=True ONLY if the task requirements are met and tests pass."
    )
    user_prompt = (
        f"Task: {task['instructions']}\n\n"
        f"Git Diff:\n{truncate(diff, max_diff)}\n\n"
        f"Verification Output:\n{truncate(cmd_output, max_out)}"
    )
    review = invoke_structured(llm, [SystemMessage(content=sys_prompt), HumanMessage(content=user_prompt)])

    if review is None:
        passed, feedback = False, "Reviewer produced no valid result."
    else:
        passed, feedback = review.passed, review.feedback
    if exit_code not in (None, 0):
        passed = False
        feedback = f"{feedback}\nVerification failed:\n{truncate(cmd_output, max_out)}"

    verification = "no command" if exit_code is None and not cmd else (
        "rejected" if exit_code is None else f"exit {exit_code}"
    )
    return {
        "task_completed": passed,
        "reviewer_feedback": feedback,
        "last_verification": verification,
        "logs": state.get("logs", []) + [f"[Reviewer] Passed={passed} | {feedback[:300]}"],
    }

def complete_task_node(state: AgentState) -> dict:
    cfg = load_config()
    stack = list(state["task_stack"])
    done = stack.pop(0)
    status = "passed" if state.get("task_completed") else "skipped"
    result = build_task_result(
        done,
        state.get("last_editor_diff", ""),
        status,
        state.get("task_attempts", 0),
        state.get("last_verification", "none"),
    )
    stage_all(cfg["workflow"]["project_path"])
    manifest = build_aider_repomap_manifest(cfg)
    return {
        "task_stack": stack,
        "current_task": None,
        "manifest_data": manifest,
        "task_results": state.get("task_results", []) + [result],
        "logs": state.get("logs", []) + [f"[Task Stack] Completed & popped {done['task_id']} ({status})."],
    }

def save_issue_node(state: AgentState) -> dict:
    cfg = load_config()
    issue_file = Path(cfg["workflow"]["issue_json_path"])
    issue_file.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "task": state["current_task"],
        "iterations": state["iteration_count"],
        "reviewer_feedback": state["reviewer_feedback"],
        "last_diff": state["last_editor_diff"],
    }
    issue_file.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return {"logs": state.get("logs", []) + ["[Escalation] Saved issue.json. Waiting for Human Decision..."]}

def evaluator_node(state: AgentState) -> dict:
    cfg = load_config()
    logs = state.get("logs", [])
    if not eval_cfg(cfg)["enabled"]:
        return {"logs": logs + ["[Evaluator] Disabled in config."]}
    if not state.get("planned_tasks"):
        return {"logs": logs + ["[Evaluator] No planned tasks; evaluation skipped."]}

    results = list(state.get("task_results", []))
    cur = state.get("current_task")
    if cur and all(r["id"] != cur["task_id"] for r in results):
        results.append(build_task_result(
            cur,
            state.get("last_editor_diff", ""),
            "failed",
            state.get("task_attempts", 0),
            state.get("last_verification", "none"),
        ))
    st = dict(state)
    st["task_results"] = results

    try:
        payload = evaluate_run(st, cfg)
        record, run_dir = persist(cfg, st, payload)
    except Exception as e:
        return {"task_results": results, "logs": logs + [f"[Evaluator] Failed: {e}"]}

    ov = payload["overall"]
    return {
        "task_results": results,
        "eval_summary": {
            "run_dir": run_dir,
            "overall": ov,
            "agentic_metrics": payload["agentic_metrics"],
        },
        "logs": logs + [
            f"[Evaluator] tasks={ov['tasks_passed']} | deepeval_avg={ov.get('deepeval_avg_score')} | "
            f"agentic_avg={ov['agentic_deepeval_avg']} | report={run_dir}"
        ],
    }
