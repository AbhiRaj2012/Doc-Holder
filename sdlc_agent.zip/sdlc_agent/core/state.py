from typing import TypedDict, List, Optional, Literal
from pydantic import BaseModel, Field

class TaskItem(BaseModel):
    task_id: str = Field(description="Unique ID, e.g., TASK-1")
    title: str = Field(description="Short title of the atomic task")
    target_files: List[str] = Field(description="Relative file paths to modify or create")
    instructions: str = Field(description="Detailed implementation instructions")
    verification_cmd: str = Field(description="Command to verify task, e.g., pytest tests/test_api.py")

class TaskPlan(BaseModel):
    tasks: List[TaskItem] = Field(description="Ordered list of tasks from first to last")

class ReviewResult(BaseModel):
    passed: bool = Field(description="True ONLY if all requirements are met and tests pass")
    feedback: str = Field(description="Specific root-cause feedback and fix instructions if failed")

class AgentState(TypedDict):
    project_path: str
    manifest_path: str
    issue_json_path: str
    user_input: str
    project_requirements: str
    
    # Generated / loaded manifest
    manifest_data: dict
    
    # LIFO Task Stack (index 0 is current active task)
    task_stack: List[dict]
    current_task: Optional[dict]
    
    # Iterative Loop Controls
    iteration_count: int
    max_iterations: int
    last_editor_diff: str
    reviewer_feedback: str
    task_completed: bool

    # For the Streamlit UI feed
    logs: List[str]
    
    # Human-in-the-loop Gate: "proceed", "work_on_it", "abort"
    human_decision: Optional[Literal["proceed", "work_on_it", "abort"]]