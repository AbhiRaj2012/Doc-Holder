(() => {
  const STORAGE_KEY = "kanban_tasks_v1";
  const THEME_KEY = "kanban_theme_v1";

  let tasks = loadTasks();
  let draggedTaskId = null;

  const taskForm = document.getElementById("task-form");
  const titleInput = document.getElementById("task-title");
  const priorityInput = document.getElementById("task-priority");
  const dueInput = document.getElementById("task-due");
  const searchInput = document.getElementById("search-input");
  const priorityFilter = document.getElementById("priority-filter");
  const themeToggle = document.getElementById("theme-toggle");
  const themeIcon = document.getElementById("theme-icon");
  const themeLabel = document.getElementById("theme-label");

  const lists = {
    todo: document.getElementById("list-todo"),
    "in-progress": document.getElementById("list-in-progress"),
    done: document.getElementById("list-done"),
  };

  const counts = {
    todo: document.getElementById("count-todo"),
    "in-progress": document.getElementById("count-in-progress"),
    done: document.getElementById("count-done"),
  };

  function escapeHTML(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  function loadTasks() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  function saveTasks() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem(THEME_KEY, theme);
    if (theme === "dark") {
      themeIcon.innerHTML = "&#9728;";
      themeLabel.textContent = "Light Mode";
    } else {
      themeIcon.innerHTML = "&#9790;";
      themeLabel.textContent = "Dark Mode";
    }
  }

  function initTheme() {
    const saved = localStorage.getItem(THEME_KEY) || "light";
    applyTheme(saved);
  }

  function createTaskElement(task) {
    const card = document.createElement("article");
    card.className = "task-card";
    card.draggable = true;
    card.dataset.id = task.id;

    const safeTitle = escapeHTML(task.title);
    const safePriority = escapeHTML(task.priority);
    const dueText = task.due ? `Due: ${escapeHTML(task.due)}` : "No due date";

    card.innerHTML = `
      <div class="task-top">
        <span class="task-title">${safeTitle}</span>
        <div class="task-actions">
          <button type="button" class="icon-btn edit-btn" title="Edit task" aria-label="Edit task">&#9998;</button>
          <button type="button" class="icon-btn delete-btn" title="Delete task" aria-label="Delete task">&#10005;</button>
        </div>
      </div>
      <div class="task-meta">
        <span class="priority-badge priority-${safePriority}">${safePriority}</span>
        <span>${dueText}</span>
      </div>
    `;

    card.addEventListener("dragstart", () => {
      draggedTaskId = task.id;
      card.classList.add("dragging");
    });

    card.addEventListener("dragend", () => {
      draggedTaskId = null;
      card.classList.remove("dragging");
    });

    card.querySelector(".edit-btn").addEventListener("click", () => {
      const updated = prompt("Edit task title:", task.title);
      if (updated !== null && updated.trim() !== "") {
        task.title = updated.trim();
        saveTasks();
        render();
      }
    });

    card.querySelector(".delete-btn").addEventListener("click", () => {
      tasks = tasks.filter((t) => t.id !== task.id);
      saveTasks();
      render();
    });

    return card;
  }

  function render() {
    const query = searchInput.value.trim().toLowerCase();
    const filterPriority = priorityFilter.value;

    Object.values(lists).forEach((listEl) => {
      listEl.innerHTML = "";
    });

    const visibleCounts = { todo: 0, "in-progress": 0, done: 0 };

    tasks.forEach((task) => {
      const matchesQuery = task.title.toLowerCase().includes(query);
      const matchesPriority =
        filterPriority === "all" || task.priority === filterPriority;

      if (!matchesQuery || !matchesPriority) return;

      const targetList = lists[task.status] || lists.todo;
      targetList.appendChild(createTaskElement(task));
      visibleCounts[task.status] = (visibleCounts[task.status] || 0) + 1;
    });

    Object.keys(counts).forEach((status) => {
      counts[status].textContent = visibleCounts[status];
    });
  }

  taskForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const title = titleInput.value.trim();
    if (!title) return;

    tasks.unshift({
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      title,
      priority: priorityInput.value,
      due: dueInput.value,
      status: "todo",
    });

    saveTasks();
    taskForm.reset();
    priorityInput.value = "medium";
    render();
  });

  Object.values(lists).forEach((listEl) => {
    listEl.addEventListener("dragover", (e) => {
      e.preventDefault();
      listEl.classList.add("drag-over");
    });

    listEl.addEventListener("dragleave", () => {
      listEl.classList.remove("drag-over");
    });

    listEl.addEventListener("drop", (e) => {
      e.preventDefault();
      listEl.classList.remove("drag-over");
      if (!draggedTaskId) return;

      const task = tasks.find((t) => t.id === draggedTaskId);
      if (task) {
        task.status = listEl.dataset.status;
        saveTasks();
        render();
      }
    });
  });

  searchInput.addEventListener("input", render);
  priorityFilter.addEventListener("change", render);
  themeToggle.addEventListener("click", () => {
    const current = document.documentElement.getAttribute("data-theme");
    applyTheme(current === "dark" ? "light" : "dark");
  });

  initTheme();
  render();
})();