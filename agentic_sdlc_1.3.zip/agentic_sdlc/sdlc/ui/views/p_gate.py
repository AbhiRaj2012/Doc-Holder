from __future__ import annotations

import json

import streamlit as st

from ...graph.human_gate import read_issue
from .. import common, jobs


def panel(run: dict) -> None:
    s = common.settings()
    project = common.project_of(s, run["project"])
    info = jobs.pending_interrupt(s, project, run["run_id"])
    if info is None:
        st.info("This run is not paused.")
        return
    c = common.cfg()
    if info.get("type") == "approve_commands":
        st.subheader("Commands outside the allowlist")
        for e in info.get("events", []):
            st.write(f"`{e.get('task_id')}`: `{e.get('command')}` ({e.get('reason')})")
        proposals = info.get("proposals", [])
        chosen = st.multiselect("Approve executables for this project", proposals, default=[])
        if st.button("Continue", type="primary"):
            jobs.start_resume(s, project, run["run_id"], approve=chosen, no_eval=not c["run_eval"])
            st.success("Resumed.")
            st.rerun()
        return
    issue = read_issue(run["dir"])
    st.subheader(f"Decision needed: task {info.get('task_id')}: {info.get('title')}")
    st.write(f"Reason: **{info.get('reason')}** | iteration {info.get('iteration')}")
    exp = info.get("explanation") or issue.get("explanation") or {}
    if exp:
        st.info(f"**What happened:** {exp.get('what_happened', '')}\n\n**Likely cause:** {exp.get('why', '')}\n\n**Suggested:** {exp.get('recommendation', 'work')}")
    if info.get("repeats"):
        st.warning(f"This same problem has reached you {info['repeats'] + 1} times. An empty hint will use the suggested one automatically.")
    st.caption("Details")
    for h in issue.get("history", []):
        st.write(f"- {h}")
    if issue.get("diff"):
        st.code(issue["diff"], language="diff")
    with st.expander("Full issue.json"):
        st.code(json.dumps(issue, indent=2, default=str)[:20000], language="json")
    opts = ["work", "restart", "replan", "replan_all", "accept", "proceed", "abort"]
    rec = exp.get("recommendation", "work")
    action = st.radio("Decision", opts, index=opts.index(rec) if rec in opts else 0, format_func={"work": "Work on it again (with a hint)", "restart": "Discard this task's changes and start it fresh", "replan": "Re-plan the remaining work (keeps completed tasks)", "replan_all": "Roll back the whole run and re-plan from scratch", "accept": "Accept the current change as done", "proceed": "Skip this task (discards its change)", "abort": "Abort the run"}.get, horizontal=True)
    hint = st.text_area("Hint for the editor / note for the planner", value=exp.get("suggested_hint", ""), key=f"hint_{info.get('task_id')}_{info.get('iteration')}_{info.get('repeats', 0)}", disabled=action not in ("work", "restart", "replan", "replan_all"))
    if st.button("Submit", type="primary"):
        jobs.start_resume(s, project, run["run_id"], action=action, hint=hint, no_eval=not c["run_eval"])
        st.success("Resumed.")
        st.rerun()
