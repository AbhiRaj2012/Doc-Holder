from __future__ import annotations

import streamlit as st

from ...core import hardware
from .. import common


def render() -> None:
    c = common.cfg()
    st.header("Models and hardware")
    c["base_url"] = st.text_input("Ollama URL", c["base_url"])
    models = common.installed_models(c["base_url"])
    if models:
        for label, key in (("Main model", "main_model"), ("Judge model", "judge_model")):
            opts = models if c[key] in models else [c[key], *models]
            c[key] = st.selectbox(label, opts, index=opts.index(c[key]), key=f"sel_{key}")
    else:
        st.warning("No models reported by Ollama; type the names manually.")
        c["main_model"] = st.text_input("Main model", c["main_model"])
        c["judge_model"] = st.text_input("Judge model", c["judge_model"])
    with st.expander("Per-role models (optional)", expanded=any(c[f"{r}_model"] for r in ("planner", "editor", "reviewer"))):
        st.caption("Leave a role on 'same as main' to use the main model. A stronger coding model as editor usually helps most; the context is sized for the most demanding model.")
        for role, label in (("planner", "Planner / architect"), ("editor", "Editor / writer"), ("reviewer", "Reviewer / explainer")):
            key = f"{role}_model"
            opts = ["", *models] if models else [""]
            if c[key] and c[key] not in opts:
                opts.append(c[key])
            c[key] = st.selectbox(label, opts, index=opts.index(c[key]), format_func=lambda m: m or "same as main", key=f"sel_{key}") if models else st.text_input(label, c[key], key=f"txt_{key}")

    presets = hardware.load_presets()
    names = ["Custom"] + [p["label"] for p in presets]
    pick = st.selectbox("Hardware preset", names)
    if pick != "Custom":
        p = presets[names.index(pick) - 1]
        c["gpu"], c["kv"] = float(p["gpu_vram_gb"]), p["kv_cache_type"]
    c["gpu"] = st.slider("GPU VRAM (GB)", 2.0, 80.0, float(c["gpu"]), 0.5)
    c["kv"] = st.selectbox("KV cache type", ["f16", "q8_0", "q4_0"], index=["f16", "q8_0", "q4_0"].index(c["kv"]))
    c["ctx"] = st.slider("Context size override (0 = derive from hardware)", 0, 131072, int(c["ctx"]), 1024)
    c["model_gb"] = st.slider("Model GPU footprint in GB (0 = use Ollama's file size)", 0.0, 80.0, float(c["model_gb"]), 0.1,
                              help="Set this when only part of the model sits in VRAM, e.g. effective-parameter models whose embeddings stay in RAM. Check `ollama ps` after loading.")
    c["toolchain"] = st.text_input("C/C++ toolchain folders (optional, ';' separated)", c["toolchain"],
                                   help="Use the same compiler/qmake folders as your IDE kit, e.g. C:\\msys64\\ucrt64\\bin. Empty = use PATH, else auto-detect one consistent kit.")
    c["auto_context"] = st.checkbox("Derive context and budgets from the hardware before the run", c["auto_context"])
    s = common.settings()
    ctx, notes = common.derived_context(s)
    if ctx:
        st.info(f"Derived context for this hardware: {ctx} tokens")
    for n in notes:
        st.caption(n)

    st.subheader("Pipeline")
    c["plan_critic"] = st.checkbox("Plan critic (extra LLM call)", c["plan_critic"])
    c["regression_gate"] = st.checkbox("Regression gate (re-run earlier verify commands)", c["regression_gate"])
    c["llm_drift"] = st.checkbox("LLM drift check in evaluation", c["llm_drift"])
    c["use_aider"] = st.checkbox("Use Aider CLI as editor (native fallback after failures)", c["use_aider"])
    c["max_iter"] = st.slider("Max iterations per task", 1, 10, int(c["max_iter"]))
    c["run_eval"] = st.checkbox("Evaluate automatically after the run", c["run_eval"])
