from __future__ import annotations

import time
from typing import Any

PIPELINE = ["prepare", "analyse", "plan", "approve_commands", "pick", "split", "edit", "suspend", "review", "regression", "commit", "integrate", "gate", "finish"]
MAIN_FLOW = ["prepare", "analyse", "plan", "pick", "edit", "review", "regression", "commit", "integrate", "finish"]
NODE_LABEL = {
    "prepare": "Prepare workspace", "analyse": "Analyse repo", "plan": "Plan tasks", "approve_commands": "Approve commands", "pick": "Pick task",
    "split": "Split task", "edit": "Edit code", "suspend": "Suspend task", "review": "Review", "regression": "Regression check",
    "commit": "Commit", "integrate": "Wiring check", "gate": "Human gate", "finish": "Finish",
}
CREATE_FLOW = ["requirements", "architect", "pick", "write", "review", "save", "verify", "finish"]
NODE_LABEL.update({"requirements": "Requirements", "architect": "Architect manifest", "write": "Write file", "save": "Save file",
                   "verify": "Project check", "pick_fix": "Fix file"})
HIDDEN = {"llm_call", "llm_start", "node_start", "node"}
STATUS_ICON = {"completed": "✅", "in_progress": "▶️", "pending": "⏳", "split": "🔀", "suspended": "⏸️", "skipped": "⏭️", "blocked": "⛔"}


def active_node(events: list[dict[str, Any]]) -> dict[str, Any] | None:
    open_nodes: dict[str, dict[str, Any]] = {}
    for e in events:
        if e["type"] == "node_start":
            open_nodes[e["node"]] = e
        elif e["type"] == "node":
            open_nodes.pop(e["node"], None)
        elif e["type"] in ("run_end",):
            open_nodes.clear()
    return max(open_nodes.values(), key=lambda e: e["seq"]) if open_nodes else None


def pending_llm(events: list[dict[str, Any]]) -> dict[str, Any] | None:
    last_start = next((e for e in reversed(events) if e["type"] == "llm_start"), None)
    if not last_start:
        return None
    done = any(e["type"] == "llm_call" and e["seq"] > last_start["seq"] for e in events)
    return None if done else last_start


def snapshot(events: list[dict[str, Any]], now: float | None = None) -> dict[str, Any]:
    now = now or time.time()
    node = active_node(events)
    waiting = pending_llm(events)
    calls = [e for e in events if e["type"] == "llm_call"]
    last_task = next((e for e in reversed(events) if e["type"] == "task_start"), None)
    last_event = next((e for e in reversed(events) if e["type"] not in HIDDEN), None)
    last_any = events[-1] if events else None
    return {
        "node": node["node"] if node else "",
        "node_since": round(now - node["ts"], 1) if node else 0.0,
        "task_id": (node or {}).get("task_id") or (last_task or {}).get("task_id", ""),
        "task_title": (last_task or {}).get("title", ""),
        "iteration": (node or {}).get("iteration", 0),
        "waiting_model": ({"node": waiting["node"], "model": waiting["model"], "since": round(now - waiting["ts"], 1),
                           "prompt_tokens_est": waiting.get("prompt_tokens_est", 0), "effort": waiting.get("effort", "")} if waiting else None),
        "llm_calls": len(calls),
        "tokens": sum(c.get("prompt_tokens", 0) + c.get("completion_tokens", 0) for c in calls),
        "last_event": last_event["type"] if last_event else "",
        "idle_s": round(now - last_any["ts"], 1) if last_any else 0.0,
        "finished": any(e["type"] == "run_end" for e in events),
    }


def short_id(task_id: str, keep: int = 3) -> str:
    parts = task_id.split(".")
    if len(parts) <= keep + 1:
        return task_id
    return f"{parts[0]}.{parts[1]}…+{len(parts) - 3}…{parts[-1]}"


def depth(task_id: str) -> int:
    return task_id.count(".")


def task_rows(tasks: list[dict[str, Any]], collapse: bool = True) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    hidden_done = 0
    for t in tasks:
        if collapse and t["status"] in ("completed", "skipped") and not t.get("parent_id"):
            hidden_done += 1
            continue
        d = depth(t["id"])
        rows.append({
            "task": ("&nbsp;&nbsp;" * min(d, 6)) + ("↳ " if d else "") + short_id(t["id"]),
            "status": f"{STATUS_ICON.get(t['status'], '')} {t['status']}",
            "title": t["title"],
            "shrink": t.get("shrink_level", 0),
            "verify": t.get("verify_command") or "-",
        })
    if hidden_done:
        rows.insert(0, {"task": f"({hidden_done} finished top-level tasks hidden)", "status": "", "title": "", "shrink": "", "verify": ""})
    return rows


def _fmt_time(ts: float) -> str:
    return time.strftime("%H:%M:%S", time.localtime(ts))


def describe(e: dict[str, Any]) -> str:
    t = e["type"]
    tid = short_id(e.get("task_id", "")) if e.get("task_id") else ""
    if t == "task_start":
        if e.get("source") is None:
            return f"▶ start {tid} “{e.get('title', '')}”"
        return f"▶ start {tid} “{e.get('title', '')}” ({e.get('source')}, action {e.get('action')}, shrink {e.get('shrink_level')})"
    if t == "verify":
        probs = "; ".join(f"{k}: {v[0]}" for k, v in (e.get("problems") or {}).items())[:300]
        return f"🧪 project check round {e.get('round')}: {'passed' if e.get('ok') else 'FAILED ⟶ ' + probs}"
    if t == "task_end":
        if e.get("status") == "replaced":
            return f"♻ {tid} replaced by the new plan"
        return f"{'✅' if e.get('status') == 'completed' else '⏭'} {tid} {e.get('status')} after {e.get('iterations')} iteration(s), files: {', '.join(e.get('files', [])) or 'none'}"
    if t == "task_suspended":
        return f"⏸ {tid} suspended: {e.get('reason')} → shrink level {e.get('shrink_level')}"
    if t in ("split", "task_split"):
        kids = e.get("children")
        return f"🔀 {tid} split into {len(kids) if isinstance(kids, list) else kids}"
    if t == "split_refused":
        return f"⛔ {tid} split refused: {e.get('why')}"
    if t == "tool_call":
        ok = "ok" if e.get("ok") else "FAILED"
        extra = f", {e.get('blocks_applied', 0)} applied/{e.get('blocks_failed', 0)} failed blocks, {e.get('edit_format')}" if e.get("tool") == "apply_edit" else ""
        err = (e.get("error") or "").strip().splitlines()
        more = f"  ⟶ {err[0][:160]}" if err and not e.get("ok") else ""
        took = f" {e['duration_s']}s" if e.get("duration_s") else ""
        return f"🔧 {e.get('tool')} {tid} it{e.get('iteration')} → {ok}{extra}{took}{more}"
    if t == "editor_backend_disabled":
        return f"⚠ {e.get('backend')} disabled: {e.get('reason')}"
    if t == "suspend_refused":
        return f"⛔ {tid} not suspended again ({e.get('reason')}): {e.get('why', 'limit reached')}"
    if t == "analogue":
        return f"🧭 {e.get('new')} follows the pattern of {e.get('existing')} (used in {len(e.get('files', []))} files)"
    if t == "integration_tasks":
        return f"🔗 wiring tasks added: {', '.join(e.get('tasks', []))} ({'; '.join(e.get('missing', []))[:200]})"
    if t == "integration_ok":
        return "🔗 wiring check passed"
    if t == "plan_ready":
        return f"📋 plan ready: {e.get('tasks')} tasks" + (f", warnings: {e.get('warnings')}" if e.get("warnings") else "")
    if t == "review":
        fb = (e.get("feedback") or "").strip().replace("\n", " ")[:200]
        return f"🔍 review {tid}: {'approved' if e.get('approved') else 'rejected'}" + (f" ⟶ {fb}" if fb and not e.get("approved") else "")
    if t == "baseline_build":
        return "🏗 baseline build: " + ("passed" if e.get("ok") else f"FAILED before any change ⟶ {str(e.get('error'))[:200]}")
    if t == "gpu_offload":
        return f"🐢 {e.get('model')}: only {round(float(e.get('gpu_share', 0)) * 100)}% on GPU — {e.get('why')}"
    if t == "no_change_loop":
        return f"⛔ {tid} repeated no-op edits: {e.get('why')}"
    detail = {k: v for k, v in e.items() if k not in {"ts", "seq", "run_id", "project_id", "type"}}
    return f"{t} {str(detail)[:140]}"


def timeline(events: list[dict[str, Any]], n: int = 60) -> list[str]:
    return [f"{_fmt_time(e['ts'])}  {describe(e)}" for e in events if e["type"] not in HIDDEN][-n:]


def node_outputs(events: list[dict[str, Any]], n: int = 12) -> list[dict[str, Any]]:
    return [e for e in events if e["type"] == "node" and e.get("output")][-n:]


def llm_calls(events: list[dict[str, Any]], n: int = 12) -> list[dict[str, Any]]:
    return [e for e in events if e["type"] == "llm_call"][-n:][::-1]


def flow_for(events: list[dict[str, Any]]) -> list[str]:
    return CREATE_FLOW if any(e.get("type") == "run_start" and e.get("mode") == "create" for e in events) else MAIN_FLOW


def strip_html(active: str, done: set[str], flow: list[str] | None = None) -> str:
    chips = []
    flow = flow or MAIN_FLOW
    for name in flow:
        style = "background:#ff4b4b;color:#fff;font-weight:700" if name == active else "background:#1f6f43;color:#fff" if name in done else "background:#2b2f3a;color:#9aa0ab"
        chips.append(f'<span style="padding:4px 10px;border-radius:12px;margin-right:4px;font-size:13px;{style}">{NODE_LABEL[name]}</span>')
    extra = ""
    if active and active not in flow:
        extra = f'<span style="padding:4px 10px;border-radius:12px;font-size:13px;background:#ff4b4b;color:#fff;font-weight:700">{NODE_LABEL.get(active, active)}</span>'
    return "".join(chips) + extra


def done_nodes(events: list[dict[str, Any]]) -> set[str]:
    return {e["node"] for e in events if e["type"] == "node"}


def task_progress(tasks: list[dict[str, Any]], events: list[dict[str, Any]]) -> tuple[int, int]:
    top = [t for t in tasks if not t.get("parent_id")]
    plan = next((e for e in reversed(events) if e.get("type") == "plan_ready"), None)
    if not top:
        return 0, int(plan.get("tasks", 0)) if plan else 0
    done = sum(t.get("status") in ("completed", "skipped", "blocked") for t in top)
    return done, len(top)


def task_label(task_id: str, tasks: list[dict[str, Any]], events: list[dict[str, Any]]) -> str:
    done, total = task_progress(tasks, events)
    tid = short_id(task_id) or "-"
    if not total:
        return tid
    running = any(t.get("id") == task_id and t.get("status") not in ("completed", "skipped", "blocked") for t in tasks) or (task_id and not tasks)
    return f"{tid} ({min(done + (1 if running else 0), total)} of {total})"


def progress_caption(tasks: list[dict[str, Any]], events: list[dict[str, Any]]) -> str:
    done, total = task_progress(tasks, events)
    replans = sum(e.get("type") == "replan" for e in events)
    return f"{done} of {total} tasks done" + (f" · plan revised {replans}×, task ids continue after the replaced ones" if replans else "") if total else ""
