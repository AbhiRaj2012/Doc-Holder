from __future__ import annotations

from typing import Any

import streamlit as st

from ..core.config import Settings, load_settings
from ..core.project_store import Project, ProjectStore
from ..core import hardware

DEFAULTS: dict[str, Any] = {
    "base_url": "http://localhost:11434", "main_model": "gpt-oss:20b", "judge_model": "gpt-oss:20b",
    "gpu": 16.0, "model_gb": 0.0, "kv": "q8_0", "ctx": 0, "auto_context": True, "plan_critic": True, "regression_gate": True,
    "llm_drift": True, "use_aider": True, "max_iter": 5, "run_eval": True,
    "planner_model": "", "editor_model": "", "reviewer_model": "", "toolchain": "",
}


def cfg() -> dict[str, Any]:
    for k, v in DEFAULTS.items():
        st.session_state.setdefault(k, v)
    return st.session_state


def settings() -> Settings:
    c = cfg()
    o: dict[str, Any] = {
        "ollama": {"base_url": c["base_url"], "main_model": c["main_model"], "judge_model": c["judge_model"],
                   "role_models": {r: c[f"{r}_model"] for r in ("planner", "editor", "reviewer") if c[f"{r}_model"]}},
        "hardware": {"gpu_vram_gb": float(c["gpu"]), "kv_cache_type": c["kv"], "context_override": int(c["ctx"]) or None, "model_gpu_gb": float(c["model_gb"]) or None},
        "features": {"plan_critic": c["plan_critic"], "regression_gate": c["regression_gate"], "llm_drift": c["llm_drift"]},
        "limits": {"max_iterations_per_task": int(c["max_iter"])},
        "paths": {"toolchain": [d.strip() for d in c["toolchain"].split(";") if d.strip()]},
    }
    if int(c["ctx"]):
        o["ollama"]["num_ctx"] = int(c["ctx"])
    return load_settings(overrides=o)


@st.cache_data(ttl=10, show_spinner=False)
def installed_models(base_url: str) -> list[str]:
    from ..adapters.ollama_client import OllamaClient

    try:
        return OllamaClient(load_settings(overrides={"ollama": {"base_url": base_url}})).list_models()
    except Exception:
        return []


def project_of(s: Settings, project_id: str) -> Project:
    return ProjectStore(s).get(project_id)


def derived_context(s: Settings) -> tuple[int | None, list[str]]:
    from ..adapters.ollama_client import OllamaClient

    try:
        client = OllamaClient(s)
        arch, sizing = hardware.sizing_arch(client, s)
        ctx, notes = hardware.derive_context(s.hardware.gpu_vram_gb, arch, s.hardware.kv_cache_type, s.hardware.overhead_gb, s.hardware.context_override)
        return ctx, (sizing if len(sizing) > 1 else []) + notes
    except Exception as exc:
        return None, [f"model info unavailable: {exc}"]


def table(rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    cols = list(rows[0])
    esc = lambda v: str(v if v is not None else "").replace("|", "\\|").replace("\n", " ")[:160]
    lines = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    lines += ["| " + " | ".join(esc(r.get(c)) for c in cols) + " |" for r in rows]
    st.markdown("\n".join(lines))


def run_picker(s: Settings, key: str, states: tuple[str, ...] | None = None):
    from .jobs import list_runs

    show_hidden = st.checkbox("Show hidden runs", False, key=f"{key}_hidden")
    runs = [r for r in list_runs(s, include_hidden=show_hidden) if states is None or r["state"] in states]
    if not runs:
        return None
    labels = [f"{r['project']} / {r['run_id']}  ({r['state']})" + ("  [hidden]" if r["hidden"] else "") for r in runs]
    last = st.session_state.get("last_run")
    default = next((n for n, r in enumerate(runs) if last and (r["project"], r["run_id"]) == tuple(last)), 0)
    i = st.selectbox("Run", range(len(runs)), index=default, format_func=lambda x: labels[x], key=key)
    return runs[i]
