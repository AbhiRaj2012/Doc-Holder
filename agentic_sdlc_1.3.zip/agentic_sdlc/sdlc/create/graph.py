from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, TypedDict

from langgraph.graph import END, START, StateGraph

from ..adapters.git_ops import GitRepo
from ..adapters.ollama_client import LLMError, OllamaClient
from ..agents.context import AgentContext
from ..agents.explainer import Explainer
from ..core.budget import BudgetExceeded, RunGuard
from ..core.config import Settings
from ..core.ledger import IssueLedger
from ..core.project_store import Project
from ..telemetry.jsonl_logger import EventLogger, log_llm
from ..core import guards
from . import agents, checks, templates
from .schemas import Blueprint, Requirements

MAX_VERIFY_ROUNDS = 2


class CreateState(TypedDict, total=False):
    request: str
    language_hint: str
    requirements: dict
    blueprint: dict
    tasks: list
    queue: list
    current: str
    feedback: str
    attempts: int
    approved: bool
    verify_round: int
    verify_ok: bool
    task_stats: dict
    status: str
    error: str
    started_at: float
    active_s: float
    iterations_total: int
    edit_attempts: int
    edit_failed_attempts: int
    last_problem: str
    same_problem: int
    last_verify: str


@dataclass
class CreateRuntime:
    settings: Settings
    project: Project
    run_id: str
    client: Any
    logger: EventLogger
    guard: RunGuard
    git: GitRepo

    @property
    def repo(self) -> Path:
        return self.project.code

    @property
    def run_dir(self) -> Path:
        return self.project.run_dir(self.run_id)


def make_runtime(settings: Settings, project: Project, run_id: str, client: Any = None) -> CreateRuntime:
    run_dir = project.run_dir(run_id)
    logger = EventLogger(run_dir / "events.jsonl", run_id, project.id)
    guard = RunGuard(settings.limits.max_wall_seconds, settings.limits.max_total_tokens)
    if client is None:
        client = OllamaClient(settings, guard, on_call=lambda e: log_llm(logger, e), on_start=lambda e: logger({"type": "llm_start", **e}))
    git = GitRepo(project.code, settings.git.author_name, settings.git.author_email)
    git.ensure_repo()
    return CreateRuntime(settings, project, run_id, client, logger, guard, git)


def _task(state: CreateState, tid: str) -> dict:
    return next(t for t in state["tasks"] if t["id"] == tid)


def _set_task(state: CreateState, tid: str, **kw: Any) -> list:
    return [dict(t, **kw) if t["id"] == tid else t for t in state["tasks"]]


def _bump(state: CreateState, tid: str, key: str, n: int = 1) -> dict:
    stats = {k: dict(v) for k, v in (state.get("task_stats") or {}).items()}
    stats.setdefault(tid, {})[key] = stats.get(tid, {}).get(key, 0) + n
    return stats


def _save_stack(rt: CreateRuntime, tasks: list) -> None:
    (rt.run_dir / "stack.json").write_text(json.dumps({"tasks": tasks, "suspended": []}, indent=2), encoding="utf-8")


def make_nodes(rt: CreateRuntime) -> dict[str, Callable[[CreateState], dict[str, Any]]]:
    s = rt.settings
    timeout = s.limits.subprocess_timeout_s

    def bp_of(state: CreateState) -> Blueprint:
        return Blueprint.model_validate(state["blueprint"])

    def requirements(state: CreateState) -> dict[str, Any]:
        rt.logger({"type": "run_start", "mode": "create", "project_name": rt.project.meta.get("name", rt.project.id), "objective": state["request"][:2000],
                   "model_main": s.ollama.main_model, "model_judge": s.ollama.judge_model, "role_models": dict(s.ollama.role_models), "num_ctx": s.ollama.num_ctx})
        req = agents.requirements(rt.client, s, state["request"])
        (rt.run_dir / "requirements.md").write_text(req.as_text(), encoding="utf-8")
        return {"requirements": req.model_dump()}

    def architect(state: CreateState) -> dict[str, Any]:
        req = Requirements.model_validate(state["requirements"])
        bp, notes = agents.architect(rt.client, s, rt.repo, req, state["request"], state.get("language_hint", ""))
        (rt.run_dir / "blueprint.json").write_text(bp.model_dump_json(indent=2), encoding="utf-8")
        (rt.run_dir / "design_brief.md").write_text(f"{req.as_text()}\n\n## Manifest\n{bp.as_text()}", encoding="utf-8")
        tasks = []
        for n, f in enumerate(bp.files, 1):
            build = Path(f.path).name in checks.BUILD_FILES
            tasks.append({
                "id": f"T{n}", "title": f"Create {f.path}", "description": f.purpose, "language": checks.file_language(f.path, bp.language) or bp.language,
                "kind": "scaffold" if build else "feature", "target_files": [f.path], "symbol_targets": f.provides, "acceptance_criteria": f.acceptance,
                "verify_command": bp.test_command or None, "verify_source": "planner" if bp.test_command else "default", "depends_on": [],
                "priority": 3, "reference_files": f.depends_on, "status": "pending", "parent_id": None, "shrink_level": 0,
            })
        tpl = templates.load(bp.language)
        fixed: set[str] = set()
        if tpl:
            written = templates.write(rt.repo, bp, tpl, rt.project.meta.get("name", rt.project.id))
            fixed = {p for p in written if p in tpl.fixed}
            if written:
                rt.git.commit_all("sdlc(create): starter template")
                rt.logger({"type": "template_applied", "language": bp.language, "files": written, "fixed": sorted(fixed)})
        stats: dict[str, dict[str, int]] = {}
        for t in tasks:
            if t["target_files"][0] in fixed:
                t["status"] = "completed"
                stats[t["id"]] = {"iterations": 1}
                rt.logger({"type": "task_start", "task_id": t["id"], "title": t["title"], "action": "template", "shrink_level": 0})
                rt.logger({"type": "task_end", "task_id": t["id"], "status": "completed", "iterations": 0, "files": t["target_files"], "reason": "provided by the starter template"})
        _save_stack(rt, tasks)
        rt.logger({"type": "plan", "tasks": len(tasks), "warnings": notes, "policy_events": 0})
        rt.logger({"type": "plan_ready", "tasks": len(tasks), "files": [t["target_files"][0] for t in tasks], "warnings": notes, "language": bp.language, "entry": bp.entry})
        return {"blueprint": bp.model_dump(), "tasks": tasks, "queue": [t["id"] for t in tasks if t["status"] == "pending"], "verify_round": 0, "task_stats": stats}

    def pick(state: CreateState) -> dict[str, Any]:
        tid, rest = state["queue"][0], state["queue"][1:]
        t = _task(state, tid)
        rt.logger({"type": "task_start", "task_id": tid, "title": t["title"], "action": "start", "shrink_level": 0})
        tasks = _set_task(state, tid, status="in_progress")
        _save_stack(rt, tasks)
        return {"current": tid, "queue": rest, "tasks": tasks, "attempts": 0, "approved": False, "last_problem": "", "same_problem": 0}

    def write(state: CreateState) -> dict[str, Any]:
        rt.guard.check()
        tid = state["current"]
        path = _task(state, tid)["target_files"][0]
        bp = bp_of(state)
        req = Requirements.model_validate(state["requirements"])
        target = rt.repo / path
        current = target.read_text(encoding="utf-8", errors="replace") if target.exists() else ""
        t0 = time.monotonic()
        error = ""
        fb = state.get("feedback", "")
        local = re.search(rf"SYNTAX\s+{re.escape(path)}:(\d+)\s*-\s*(.+)", fb.replace("\\", "/"))
        if local and current.count("\n") > 80:
            try:
                repaired = agents.repair_excerpt(rt.client, path, current, int(local.group(1)), local.group(2).strip())
            except LLMError:
                repaired = None
            if repaired:
                target.write_text(repaired, encoding="utf-8")
                rt.logger({"type": "local_repair", "task_id": tid, "file": path, "line": int(local.group(1)), "why": "fixed the reported lines instead of rewriting a long file"})
                attempts = state.get("attempts", 0) + 1
                rt.logger({"type": "tool_call", "node": "editor", "tool": "apply_edit", "task_id": tid, "iteration": attempts, "args": {"file": path, "mode": "repair"},
                           "ok": True, "files_changed": [path], "blocks_applied": 1, "blocks_failed": 0, "edit_format": "create-repair", "duration_s": round(time.monotonic() - t0, 2)})
                return {"attempts": attempts, "feedback": "", "approved": False, "iterations_total": state.get("iterations_total", 0) + 1,
                        "edit_attempts": state.get("edit_attempts", 0) + 1, "edit_failed_attempts": state.get("edit_failed_attempts", 0),
                        "task_stats": _bump(state, tid, "iterations")}
        try:
            text, resp = agents.write_file(rt.client, s, rt.repo, bp, req, path, current, fb)
            if getattr(resp, "truncated", False):
                error = "output truncated: the file was too long; write a shorter, simpler version"
            elif len(text.strip()) < 5:
                error = "the model returned no file content"
        except LLMError as exc:
            text, error = "", f"model call failed: {exc}"
        ok = not error
        if ok:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(text, encoding="utf-8")
        attempts = state.get("attempts", 0) + 1
        rt.logger({"type": "tool_call", "node": "editor", "tool": "apply_edit", "task_id": tid, "iteration": attempts, "args": {"file": path, "mode": "create"},
                   "ok": ok, "files_changed": [path] if ok else [], "blocks_applied": 1 if ok else 0, "blocks_failed": 0 if ok else 1,
                   "edit_format": "create-whole", "duration_s": round(time.monotonic() - t0, 2), **({"error": error} if error else {})})
        return {"attempts": attempts, "feedback": error, "approved": False, "iterations_total": state.get("iterations_total", 0) + 1,
                "edit_attempts": state.get("edit_attempts", 0) + 1, "edit_failed_attempts": state.get("edit_failed_attempts", 0) + (0 if ok else 1),
                "task_stats": _bump(state, tid, "iterations")}

    def review(state: CreateState) -> dict[str, Any]:
        out = _review(state)
        fb = "" if out.get("approved") else out.get("feedback", state.get("feedback", ""))
        same = state.get("same_problem", 0) + 1 if fb and fb == state.get("last_problem") else 0
        if same:
            rt.logger({"type": "repeat_problem", "task_id": state["current"], "why": "the same problem came back; another attempt would not change it"})
        return {**out, "last_problem": fb, "same_problem": same}

    def _review(state: CreateState) -> dict[str, Any]:
        tid = state["current"]
        path = _task(state, tid)["target_files"][0]
        if state.get("feedback"):
            return {"approved": False}
        bp = bp_of(state)
        result = checks.syntax(rt.repo, path, bp.language, timeout)
        rt.logger({"type": "tool_call", "node": "reviewer", "tool": "syntax_check", "task_id": tid, "iteration": state.get("attempts", 0),
                   "args": {"files": [path]}, "ok": result.ok, "skipped": result.skipped, **({"error": result.output_tail[-500:]} if not result.ok else {})})
        if not result.ok:
            fb = "SYNTAX ERRORS:\n" + "\n".join(f.short() for f in result.failures[:8]) if result.failures else result.output_tail[-800:]
            rt.logger({"type": "review", "task_id": tid, "approved": False, "feedback": fb[:600]})
            return {"approved": False, "feedback": fb}
        text = (rt.repo / path).read_text(encoding="utf-8", errors="replace")
        dups = guards.duplicate_definitions(path, "", text)
        if dups:
            fb = "DUPLICATE DEFINITIONS (the later one silently replaces the earlier one): " + ", ".join(dups) + ". Keep exactly one definition of each."
            rt.logger({"type": "review", "task_id": tid, "approved": False, "feedback": fb})
            return {"approved": False, "feedback": fb}
        try:
            verdict = agents.review_file(rt.client, s, rt.repo, bp, path, text)
        except LLMError as exc:
            rt.logger({"type": "review", "task_id": tid, "approved": True, "feedback": f"reviewer unavailable ({exc}); syntax passed"})
            return {"approved": True, "feedback": ""}
        if verdict.passed or not verdict.issues:
            rt.logger({"type": "review", "task_id": tid, "approved": True, "feedback": ""})
            return {"approved": True, "feedback": ""}
        patched, left = agents.apply_patches(text, verdict)
        if patched != text:
            (rt.repo / path).write_text(patched, encoding="utf-8")
            again = checks.syntax(rt.repo, path, bp.language, timeout)
            if not again.ok:
                (rt.repo / path).write_text(text, encoding="utf-8")
                left = [i.problem for i in verdict.issues]
        approved = not left
        fb = "REVIEW:\n" + "\n".join(f"- {x}" for x in left) if left else ""
        rt.logger({"type": "review", "task_id": tid, "approved": approved, "feedback": fb[:600], "patched": patched != text})
        return {"approved": approved, "feedback": fb}

    def save(state: CreateState) -> dict[str, Any]:
        tid = state["current"]
        path = _task(state, tid)["target_files"][0]
        status = "completed" if state.get("approved") else "skipped"
        rt.git.commit_all(f"sdlc(create {tid}): {path}")
        tasks = _set_task(state, tid, status=status)
        _save_stack(rt, tasks)
        rt.logger({"type": "task_end", "task_id": tid, "status": status, "iterations": state.get("attempts", 0), "files": [path],
                   **({"reason": "review limit reached; the file was kept as written", "last_problem": state.get("feedback", "")[:400]} if status != "completed" else {})})
        return {"tasks": tasks, "current": "", "feedback": ""}

    def verify(state: CreateState) -> dict[str, Any]:
        bp = bp_of(state)
        files = [t["target_files"][0] for t in state["tasks"]]
        results, per_file, general = checks.full_check(rt.repo, files, bp.language, bp.test_command, timeout)
        deps = checks.dependencies(rt.repo, files)
        if deps:
            rt.logger({"type": "dependency_needed", "task_id": "", "packages": sorted({p for v in deps.values() for p in v}), "files": sorted(deps)})
        for f, msgs in checks.integration(rt.repo, files, bp.entry, bp.language).items():
            per_file.setdefault(f, []).extend(msgs)
        by_kind = {r.name: r for r in results}
        for t in state["tasks"]:
            for kind in ("build", "test"):
                r = by_kind.get(kind)
                if r is not None:
                    rt.logger({"type": "tool_call", "node": "verify", "tool": f"run_{kind}", "task_id": t["id"], "iteration": state.get("verify_round", 0) + 1,
                               "args": {"command": r.command, "files": files}, "ok": r.ok, "skipped": r.skipped, "duration_s": r.duration_s})
        if general:
            target = next((f for f in files if Path(f).name in checks.BUILD_FILES), bp.entry)
            per_file.setdefault(target, []).extend(general)
        ok = not per_file
        signature = json.dumps({k: sorted(v) for k, v in sorted(per_file.items())})
        rnd = state.get("verify_round", 0) + 1
        warnings = [f"{r.name}: {r.failures[0].short(200) if r.failures else r.output_tail[-200:]}" for r in results if not r.ok and not r.skipped and r.name not in checks.BLOCKING]
        rt.logger({"type": "verify", "round": rnd, "ok": ok, "problems": {k: v[:5] for k, v in per_file.items()}, "warnings": warnings})
        if not ok and signature == state.get("last_verify"):
            rt.logger({"type": "repeat_problem", "task_id": "", "why": "the project check found the same problems as the previous round; stopping"})
        if ok or rnd > MAX_VERIFY_ROUNDS or signature == state.get("last_verify"):
            return {"verify_round": rnd, "verify_ok": ok, "queue": [], "last_verify": signature}
        ids = {t["target_files"][0]: t["id"] for t in state["tasks"]}
        queue = [ids[f] for f in files if f in per_file]
        tasks = [dict(t, status="pending") if t["id"] in queue else t for t in state["tasks"]]
        fb = {ids[f]: "PROJECT CHECK FAILED:\n" + "\n".join(f"- {m}" for m in per_file[f][:10]) for f in per_file if f in ids}
        (rt.run_dir / "verify_feedback.json").write_text(json.dumps(fb, indent=2), encoding="utf-8")
        _save_stack(rt, tasks)
        return {"verify_round": rnd, "verify_ok": False, "queue": queue, "tasks": tasks, "last_verify": signature}

    def pick_fix(state: CreateState) -> dict[str, Any]:
        out = pick(state)
        fb = json.loads((rt.run_dir / "verify_feedback.json").read_text(encoding="utf-8")) if (rt.run_dir / "verify_feedback.json").exists() else {}
        out["feedback"] = fb.get(out["current"], "")
        return out

    def finish(state: CreateState) -> dict[str, Any]:
        tasks = state.get("tasks", [])
        done = bool(tasks) and all(t["status"] == "completed" for t in tasks) and state.get("verify_ok", False)
        status = state.get("status") if state.get("status") in ("failed", "budget_exceeded") else ("completed" if done else "partial")
        if status != "completed":
            facts = "\n".join([f"New project run ended with status {status}", f"Error: {state.get('error') or 'none'}",
                               *[f"File not approved: {t['target_files'][0]}" for t in tasks if t["status"] != "completed"]])
            vf = rt.run_dir / "verify_feedback.json"
            if vf.exists():
                facts += "\nLast project check problems:\n" + vf.read_text(encoding="utf-8")[:1500]
            ctx = AgentContext(s, rt.client, rt.repo, rt.run_dir, rt.git, IssueLedger(rt.run_dir), rt.project.id, rt.project.id, rt.logger)
            exp = Explainer(ctx).explain(facts)
            (rt.run_dir / "run_explanation.json").write_text(json.dumps(exp.model_dump(), indent=2), encoding="utf-8")
        summary = run_summary(rt, state, status)
        (rt.run_dir / "run_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        rt.logger({"type": "run_end", **{k: v for k, v in summary.items() if k not in ("tasks", "task_stats", "objective")}})
        return {"status": status}

    return {"requirements": requirements, "architect": architect, "pick": pick, "write": write, "review": review, "save": save,
            "verify": verify, "pick_fix": pick_fix, "finish": finish}


def run_summary(rt: CreateRuntime, state: CreateState, status: str) -> dict[str, Any]:
    s = rt.settings
    tasks = state.get("tasks", [])
    count = lambda st: sum(1 for t in tasks if t["status"] == st)  # noqa: E731
    attempts = state.get("edit_attempts", 0)
    return {
        "run_id": rt.run_id, "project_id": rt.project.id, "project_name": rt.project.meta.get("name", rt.project.id), "mode": "create",
        "objective": state.get("request", ""), "final_status": status, "num_tasks": len(tasks), "tasks_completed": count("completed"),
        "tasks_skipped": count("skipped"), "tasks_blocked": count("blocked"), "total_time_s": round(state.get("active_s", 0.0), 2),
        "wall_time_s": round(time.time() - state.get("started_at", time.time()), 2), "model_main": s.ollama.main_model, "model_judge": s.ollama.judge_model, "role_models": dict(s.ollama.role_models),
        "context_size": s.ollama.num_ctx, "gpu_size_gb": s.hardware.gpu_vram_gb, "kv_cache_type": s.hardware.kv_cache_type,
        "iterations_total": state.get("iterations_total", 0), "tokens_total": rt.guard.tokens_used, "escalations": 0, "edit_attempts": attempts,
        "edit_failure_rate": round(state.get("edit_failed_attempts", 0) / attempts, 3) if attempts else 0.0, "policy_violations": 0,
        "verify_ok": state.get("verify_ok", False), "verify_rounds": state.get("verify_round", 0), "task_stats": state.get("task_stats", {}),
        "tasks": [{k: t.get(k) for k in ("id", "title", "status", "language", "kind", "target_files", "acceptance_criteria", "verify_command", "verify_source", "depends_on", "parent_id")} for t in tasks],
        "finished_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }


def _traced(rt: CreateRuntime, name: str, fn: Callable[[CreateState], dict[str, Any]]) -> Callable[[CreateState], dict[str, Any]]:
    def wrapper(state: CreateState) -> dict[str, Any]:
        t0 = time.monotonic()
        rt.logger({"type": "node_start", "node": name, "task_id": state.get("current", ""), "iteration": state.get("attempts", 0)})
        try:
            update = dict(fn(state) or {})
        except BudgetExceeded as exc:
            rt.logger({"type": "budget_exceeded", "node": name, "reason": exc.reason})
            update = {"status": "budget_exceeded", "error": exc.reason, "queue": []}
        except LLMError as exc:
            rt.logger({"type": "error", "node": name, "error": str(exc)[:500]})
            update = {"status": "failed", "error": f"{name}: {exc}", "queue": []}
        dur = time.monotonic() - t0
        brief = {k: (v if isinstance(v, (int, float, bool)) or (isinstance(v, str) and len(v) < 200) else f"{len(v)} items" if isinstance(v, list) else "…")
                 for k, v in update.items() if k in ("current", "attempts", "approved", "feedback", "verify_ok", "verify_round", "status", "error", "queue")}
        rt.logger({"type": "node", "node": name, "task_id": state.get("current", "") or update.get("current", ""), "iteration": update.get("attempts", state.get("attempts", 0)),
                   "duration_s": round(dur, 3), "output": brief})
        update["active_s"] = round(state.get("active_s", 0.0) + dur, 3)
        return update

    return wrapper


def after_architect(state: CreateState) -> str:
    return "finish" if state.get("status") in ("failed", "budget_exceeded") or not state.get("queue") else "pick"


def after_write(state: CreateState) -> str:
    return "finish" if state.get("status") in ("failed", "budget_exceeded") else "review"


def after_review(state: CreateState, max_attempts: int) -> str:
    if state.get("status") in ("failed", "budget_exceeded"):
        return "finish"
    return "save" if state.get("approved") or state.get("same_problem", 0) >= 1 or state.get("attempts", 0) >= max_attempts else "write"


def after_save(state: CreateState) -> str:
    if state.get("status") in ("failed", "budget_exceeded"):
        return "finish"
    if state.get("queue"):
        return "pick_fix" if state.get("verify_round", 0) else "pick"
    return "verify"


def after_verify(state: CreateState) -> str:
    return "pick_fix" if state.get("queue") else "finish"


def build(rt: CreateRuntime):
    nodes = make_nodes(rt)
    g = StateGraph(CreateState)
    for name, fn in nodes.items():
        g.add_node(name, _traced(rt, name, fn))
    max_attempts = rt.settings.limits.max_iterations_per_task
    g.add_edge(START, "requirements")
    g.add_conditional_edges("requirements", lambda st: "finish" if st.get("status") in ("failed", "budget_exceeded") else "architect", {"architect": "architect", "finish": "finish"})
    g.add_conditional_edges("architect", after_architect, {"pick": "pick", "finish": "finish"})
    g.add_edge("pick", "write")
    g.add_edge("pick_fix", "write")
    g.add_conditional_edges("write", after_write, {"review": "review", "finish": "finish"})
    g.add_conditional_edges("review", lambda st: after_review(st, max_attempts), {"save": "save", "write": "write", "finish": "finish"})
    g.add_conditional_edges("save", after_save, {"pick": "pick", "pick_fix": "pick_fix", "verify": "verify", "finish": "finish"})
    g.add_conditional_edges("verify", after_verify, {"pick_fix": "pick_fix", "finish": "finish"})
    g.add_edge("finish", END)
    return g.compile()


def run_create(rt: CreateRuntime, request: str, language_hint: str = "") -> dict[str, Any]:
    app = build(rt)
    limit = 60 + rt.settings.limits.max_tasks * (rt.settings.limits.max_iterations_per_task * 2 + 4) * (MAX_VERIFY_ROUNDS + 1)
    state = app.invoke({"request": request, "language_hint": language_hint, "started_at": time.time(), "tasks": [], "queue": []}, {"recursion_limit": limit})
    return json.loads((rt.run_dir / "run_summary.json").read_text(encoding="utf-8")) if (rt.run_dir / "run_summary.json").exists() else dict(state)
