from __future__ import annotations

import json
import os
import shutil
import time
from typing import Any, Callable

from langgraph.types import interrupt

from ...adapters.ollama_client import LLMError
from ...agents.planner import write_brief
from ...core.command_policy import CommandPolicy, save_approved
from ...core.schemas import Manifest
from ...runners.base import build_jobs
from ...runners.registry import get_runner
from ...core.state import PipelineState
from ..runtime import Runtime

Node = Callable[[PipelineState], dict[str, Any]]


def make_prepare(rt: Runtime) -> Node:
    def prepare(state: PipelineState) -> dict[str, Any]:
        s = rt.settings
        rt.git.ensure_repo()
        branch, base = rt.git.create_run_branch(s.git.branch_prefix, rt.run_id)
        rt.logger({
            "type": "run_start", "project_name": rt.project.meta.get("name", rt.project.id), "objective": state.get("requirements", "")[:2000],
            "model_main": s.ollama.main_model, "model_judge": s.ollama.judge_model, "context_size": s.ollama.num_ctx,
            "gpu_size_gb": s.hardware.gpu_vram_gb, "kv_cache_type": s.hardware.kv_cache_type, "branch": branch,
        })
        return {
            "branch": branch, "base_commit": base, "last_good_commit": base, "status": "running", "tokens_used": 0, "iteration": 0,
            "suspended": [], "tasks": [], "started_at": state.get("started_at") or time.time(), "iterations_total": 0,
            "escalations": 0, "edit_attempts": 0, "edit_failed_attempts": 0, "active_s": 0.0, "task_stats": {}, "policy_events": [],
        }

    return prepare


def make_analyse(rt: Runtime) -> Node:
    def analyse(state: PipelineState) -> dict[str, Any]:
        manifest = rt.analyser.run(rt.store.load_manifest(rt.project))
        rt.store.save_manifest(rt.project, manifest)
        rt.logger({"type": "manifest", "files": len(manifest.files), "languages": manifest.languages, "has_tests": manifest.has_tests, "empty": manifest.is_empty, "parser": manifest.parser})
        if rt.settings.features.baseline_build and not manifest.is_empty and not (rt.run_dir / "baseline.json").exists():
            runner = get_runner(manifest.primary_language, rt.ctx.repo, rt.settings.limits.subprocess_timeout_s)
            if runner.commands().get("build") and runner.enabled("build"):
                check = runner.run_kind("build", [])
                serial = False
                if not check.ok and not check.skipped and "{jobs}" in runner.commands().get("build", "") and build_jobs() != "1":
                    os.environ["SDLC_BUILD_JOBS"] = "1"
                    retry = runner.run_kind("build", [])
                    if retry.ok:
                        check, serial = retry, True
                        rt.logger({"type": "build_jobs", "jobs": 1, "why": "the parallel build failed but a serial build passed (likely compiler crash or memory pressure with many jobs)"})
                    else:
                        os.environ.pop("SDLC_BUILD_JOBS", None)
                first = (check.failures[0].short(300) if check.failures else check.output_tail.strip().splitlines()[-1:] and check.output_tail.strip().splitlines()[-1][:300]) or ""
                info = {"ok": check.ok, "skipped": check.skipped, "command": check.command, "duration_s": check.duration_s, "error": "" if check.ok else str(first), "tail": check.output_tail[-1500:], **({"jobs": 1} if serial else {}),
                        "tools": {exe: shutil.which(exe, path=runner.env["PATH"]) for exe in ("g++", "gcc", "qmake", "cmake", "mingw32-make", "make") if shutil.which(exe, path=runner.env["PATH"])}}
                (rt.run_dir / "baseline.json").write_text(json.dumps(info, indent=2), encoding="utf-8")
                rt.logger({"type": "baseline_build", **{k: info[k] for k in ("ok", "skipped", "command", "duration_s", "error", "tools")}, "tail": info["tail"][-600:] if not check.ok else ""})
        return {"manifest": manifest.model_dump(mode="json")}

    return analyse


def make_plan(rt: Runtime) -> Node:
    def plan(state: PipelineState) -> dict[str, Any]:
        manifest = Manifest.model_validate(state["manifest"])
        req, user_input = state.get("requirements", ""), state.get("user_input", "")
        try:
            result = rt.planner.plan(manifest, req, user_input)
            if rt.settings.features.plan_critic:
                try:
                    verdict = rt.critic.review(req, result.plan)
                    if not verdict.ok and (verdict.issues or verdict.missing_requirements):
                        result = rt.planner.revise(manifest, req, user_input, result, verdict.as_text())
                except LLMError as exc:
                    rt.logger({"type": "plan_critic_unavailable", "error": str(exc)[:200]})
        except (LLMError, ValueError) as exc:
            rt.logger({"type": "plan_failed", "error": str(exc)[:500]})
            return {"status": "failed", "error": f"planning failed: {exc}"[:500]}
        write_brief(rt.run_dir, req, result)
        for event in result.policy_events:
            rt.logger(event)
        proposals = [{"executable": p} for p in result.proposals]
        rt.logger({"type": "plan_ready", "tasks": len(result.plan.tasks), "warnings": result.warnings, "proposals": result.proposals})
        return {"tasks": [t.model_dump(mode="json") for t in result.plan.tasks], "allow_proposals": proposals, "policy_events": result.policy_events, "analogues": result.analogues}

    return plan


def make_approve_commands(rt: Runtime) -> Node:
    def approve(state: PipelineState) -> dict[str, Any]:
        events = state.get("policy_events", [])
        decision = interrupt({
            "type": "approve_commands", "run_id": rt.run_id,
            "proposals": [p["executable"] for p in state.get("allow_proposals", [])],
            "events": [{k: e.get(k) for k in ("task_id", "command", "reason", "executable")} for e in events],
        })
        approved = {str(x) for x in (decision or {}).get("approved", [])}
        tasks = [dict(t) for t in state.get("tasks", [])]
        remaining = list(events)
        if approved:
            rt.approved |= approved
            save_approved(rt.project.approved_commands_path, rt.approved)
            by_id = {t["id"]: t for t in tasks}
            remaining = []
            for e in events:
                task = by_id.get(e["task_id"])
                if task and e.get("executable") in approved:
                    res = CommandPolicy(rt.ctx.repo, task["language"], approved=rt.approved).resolve_verify(e["command"], None)
                    if res.source == "planner":
                        task["verify_command"], task["verify_source"] = res.command, "planner"
                        continue
                remaining.append(e)
        rt.logger({"type": "commands_approved", "approved": sorted(approved), "rejected": [p["executable"] for p in state.get("allow_proposals", []) if p["executable"] not in approved]})
        return {"tasks": tasks, "allow_proposals": [], "policy_events": remaining}

    return approve
