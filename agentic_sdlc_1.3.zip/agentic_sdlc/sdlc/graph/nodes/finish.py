from __future__ import annotations

import json
import time
from typing import Any, Callable

from ...core.state import PipelineState
from ..runtime import Runtime

Node = Callable[[PipelineState], dict[str, Any]]
KEPT = ("aborted", "budget_exceeded", "failed")


def run_summary(rt: Runtime, state: PipelineState, status: str) -> dict[str, Any]:
    s = rt.settings
    tasks = state.get("tasks", [])
    count = lambda st: sum(1 for t in tasks if t["status"] == st)  # noqa: E731
    attempts = state.get("edit_attempts", 0)
    return {
        "run_id": rt.run_id, "project_id": rt.project.id, "project_name": rt.project.meta.get("name", rt.project.id),
        "objective": state.get("requirements", ""), "final_status": status, "num_tasks": len(tasks),
        "tasks_completed": count("completed"), "tasks_skipped": count("skipped"), "tasks_blocked": count("blocked"),
        "total_time_s": round(state.get("active_s", 0.0), 2), "wall_time_s": round(time.time() - state.get("started_at", time.time()), 2),
        "model_main": s.ollama.main_model, "model_judge": s.ollama.judge_model, "role_models": dict(s.ollama.role_models), "context_size": s.ollama.num_ctx,
        "gpu_size_gb": s.hardware.gpu_vram_gb, "kv_cache_type": s.hardware.kv_cache_type,
        "iterations_total": state.get("iterations_total", 0), "tokens_total": state.get("tokens_used", 0),
        "escalations": state.get("escalations", 0), "edit_attempts": attempts,
        "edit_failure_rate": round(state.get("edit_failed_attempts", 0) / attempts, 3) if attempts else 0.0,
        "policy_violations": len(state.get("policy_events", [])), "branch": state.get("branch", ""),
        "task_stats": state.get("task_stats", {}),
        "tasks": [{k: t.get(k) for k in ("id", "title", "status", "language", "kind", "target_files", "acceptance_criteria", "verify_command", "verify_source", "depends_on", "parent_id")} for t in tasks],
        "finished_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }


def make_finish(rt: Runtime) -> Node:
    def finish(state: PipelineState) -> dict[str, Any]:
        current = state.get("status", "")
        tasks = state.get("tasks", [])
        if current in KEPT:
            status = current
        elif tasks and all(t["status"] == "completed" or (t.get("optional") and t["status"] == "skipped") for t in tasks):
            status = "completed"
        else:
            status = "partial"
        if status != "completed":
            open_tasks = [f"{x['id']} {x['title']} [{x['status']}]" for x in tasks if x["status"] != "completed"]
            facts = "\n".join([f"The run ended with status: {status}", f"Error: {state.get('error') or 'none'}", *[f"Task not completed: {x}" for x in open_tasks[:8]], *[f"- {i.message[:160]}" for i in list(rt.ledger.issues.values())[-6:]]])
            exp = rt.explainer.explain(facts, "")
            (rt.run_dir / "run_explanation.json").write_text(json.dumps(exp.model_dump(), indent=2), encoding="utf-8")
        summary = run_summary(rt, state, status)
        (rt.run_dir / "run_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        rt.logger({"type": "run_end", **{k: v for k, v in summary.items() if k not in ("tasks", "task_stats", "objective")}})
        return {"status": status, "exit_reason": state.get("exit_reason") or status}

    return finish
