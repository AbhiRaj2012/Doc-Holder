from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ..core.schemas import HumanDecision


def read_issue(run_dir: Path) -> dict[str, Any]:
    p = run_dir / "issue.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}


def decision(action: str, hint: str = "") -> dict[str, Any]:
    return HumanDecision(action=action, hint=hint).model_dump()  # type: ignore[arg-type]


def approval(approved: list[str]) -> dict[str, Any]:
    return {"approved": approved}
