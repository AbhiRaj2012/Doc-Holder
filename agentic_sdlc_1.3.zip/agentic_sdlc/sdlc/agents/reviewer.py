from __future__ import annotations

import re

from pydantic import BaseModel, Field

from ..core.budget import Section, estimate_tokens, fit_sections
from ..core.ledger import findings_from_review
from ..core.schemas import CheckResult, Failure, LLMVerdict, ReviewResult, Task, fingerprint
from .analyser import looks_like_test
from ..core import guards
from ..core import symbols as sym
from ..runners.registry import get_runner
from . import context_select, prompts
from .context import AgentContext

REAL_CHECKS = ("build", "test")


class ReviewDraft(BaseModel):
    approved: bool
    unmet: list[int] = Field(default_factory=list)
    deferred: list[int] = Field(default_factory=list)
    feedback: str = ""


def evidence(checks: list[CheckResult]) -> str:
    lines = []
    for c in checks:
        state = "skipped (" + (c.output_tail.strip().splitlines()[0] if c.output_tail.strip() else "not configured") + ")" if c.skipped else "passed" if c.ok else "FAILED"
        lines.append(f"- {c.name}: {state}" + (f" [{c.command}]" if c.command and not c.skipped else ""))
    return "\n".join(lines)


class ReviewerAgent:
    def __init__(self, ctx: AgentContext):
        self.ctx = ctx

    def _existing_code(self, task: Task, diff: str, max_symbols: int = 3, max_lines: int = 40) -> str:
        text = " ".join([task.title, *task.acceptance_criteria])
        words = set(re.findall(r"[A-Za-z_][\w]*(?:::[A-Za-z_]\w*)?", text))
        index = context_select.project_index(self.ctx.repo)
        added = {ln[1:].strip() for ln in diff.splitlines() if ln.startswith("+") and not ln.startswith("+++") and ln[1:].strip()}
        out: list[str] = []
        for w in sorted(words, key=len, reverse=True):
            leaf = w.split("::")[-1]
            if len(leaf) < 3 or leaf not in index or len(out) >= max_symbols:
                continue
            owner = w.split("::")[0] if "::" in w else ""
            for rel, full, line, _sig in index[leaf]:
                if owner and owner not in full:
                    continue
                lines = (self.ctx.repo / rel).read_text(encoding="utf-8", errors="replace").splitlines()
                s = sym.find(sym.extract(sym.lang_for(rel), "\n".join(lines)), full)
                end = min(s.end if s else line + 10, line - 1 + max_lines)
                body = "\n".join(lines[line - 1:end])
                body_lines = [b.strip() for b in body.splitlines() if b.strip()]
                new = sum(b in added for b in body_lines)
                if body_lines and new * 2 < len(body_lines) and body.strip() not in diff:
                    out.append(f"--- {rel}:{line} ({full}, unchanged) ---\n{body}")
                break
        return "\n".join(out)

    def _llm_verdict(self, task: Task, checks: list[CheckResult], diff: str, upcoming: list[str] | None = None) -> LLMVerdict | None:
        system = prompts.load("reviewer")
        criteria = "\n".join(f"{n}. {c}" for n, c in enumerate(task.acceptance_criteria, 1))
        head = f"TASK {task.id}: {task.title}\n{task.description}\n\nACCEPTANCE CRITERIA:\n{criteria}\n\nAUTOMATED CHECKS:\n{evidence(checks)}\n" + (f"\nUPCOMING TASKS (done later, not by this change):\n" + "\n".join(f"- {u}" for u in upcoming) + "\n" if upcoming else "")
        budget = self.ctx.settings.prompt_tokens_for("reviewer") - estimate_tokens(system) - 100
        existing = self._existing_code(task, diff)
        parts = fit_sections([Section("head", head, 9, 300, "head"), Section("diff", diff, 5, 300, "middle"), Section("existing", existing, 4, 0, "head")], budget)
        user = f"{parts['head']}\nDIFF (all changes for this task):\n{parts['diff']}"
        if parts["existing"].strip():
            user += f"\n\nEXISTING CODE the criteria refer to (unchanged, already part of the program):\n{parts['existing']}"
        msgs = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        try:
            draft, _ = self.ctx.client.structured("reviewer", msgs, ReviewDraft, max_tokens=1600, retries=1)
        except Exception as exc:
            self.ctx.log({"type": "review_llm_unavailable", "task_id": task.id, "error": str(exc)[:200]})
            return None
        deferred = {i for i in draft.deferred if 1 <= i <= len(task.acceptance_criteria)} if upcoming else set()
        unmet = [task.acceptance_criteria[i - 1] for i in draft.unmet if 1 <= i <= len(task.acceptance_criteria) and i not in deferred]
        approved = (draft.approved or bool(deferred)) and not unmet
        if deferred:
            self.ctx.log({"type": "criteria_deferred", "task_id": task.id, "criteria": [task.acceptance_criteria[i - 1] for i in sorted(deferred)]})
        if not approved and not unmet and not deferred:
            unmet = list(task.acceptance_criteria)
        return LLMVerdict(approved=approved, unmet_criteria=unmet, feedback=draft.feedback.strip()[:500])

    def _current_content(self, task: Task) -> str:
        parts = []
        for f in task.target_files:
            p = self.ctx.repo / f
            if p.is_file():
                parts.append(f"--- {f} (current content, unchanged) ---\n{p.read_text(encoding='utf-8', errors='replace')}")
        return ("NO CHANGES WERE MADE. Decide whether the CURRENT CONTENT below already satisfies the criteria.\n" + "\n".join(parts)) if parts else ""

    def review(self, task: Task, iteration: int, baseline: str, upcoming: list[str] | None = None) -> tuple[ReviewResult, dict[str, int]]:
        ctx = self.ctx
        changed = ctx.git.changed_since(baseline)
        files = sorted(set(changed) | {f for f in task.target_files if (ctx.repo / f).exists()})
        runner = get_runner(task.language, ctx.repo, ctx.settings.limits.subprocess_timeout_s)
        base = ctx.baseline
        ignore = (base.get("error") or "command failed") if base and base.get("ok") is False and not base.get("skipped") else ""
        checks = runner.run_all(files, task.verify_command, ignore_build_failure=ignore)
        if task.mirror and task.mirror.get("read"):
            from .analogues import field_readers
            name = task.mirror["read"]
            if not set(field_readers(ctx.repo, name, looks_like_test)) & set(task.target_files):
                checks.append(CheckResult(name="lint", ok=False, command="effect check", failures=[Failure(kind="lint", message=f"{name} is still never read in {', '.join(task.target_files)}; use it in the calculation so changing it changes the result")]))
        elif task.mirror:
            gaps = [(f, g) for f in task.target_files if (ctx.repo / f).is_file()
                    for g in guards.mirror_gaps((ctx.repo / f).read_text(encoding="utf-8", errors="replace"), task.mirror["old"], task.mirror["new"])]
            if gaps:
                checks.append(CheckResult(name="lint", ok=False, command="mirror check", failures=[Failure(kind="lint", file=f, message=f"{task.mirror['old']} is handled here but {task.mirror['new']} has no matching line: {g}; add the same handling for {task.mirror['new']}") for f, g in gaps]))
        runnable = bool(task.verify_command or runner.commands().get("test"))
        if task.kind == "test" and runnable and any(looks_like_test(f) for f in changed):
            for i, c in enumerate(checks):
                if c.name == "test" and c.skipped and not re.search(r"tool not found|package not installed", c.output_tail or ""):
                    checks[i] = CheckResult(name="test", ok=False, command=c.command, output_tail=c.output_tail, failures=[Failure(kind="test", message=(
                        "the new test was never run (" + (c.output_tail.strip().splitlines()[0] if c.output_tail.strip() else "no test command") + "). "
                        "Register it so the project's own test command runs it: CMake needs enable_testing() and add_test(NAME <name> COMMAND <target>), "
                        "Make needs a test target, Python/JS test files must be named like test_*.py / *.test.js."))])
        for c in checks:
            ctx.log({"type": "tool_call", "node": "reviewer", "tool": f"run_{c.name}", "task_id": task.id, "iteration": iteration,
                     "args": {"command": c.command, "files": files}, "ok": c.ok, "skipped": c.skipped, "duration_s": c.duration_s,
                     "failures": len(c.failures),
                     "tool_missing": bool(c.failures and c.failures[0].message.startswith("tool not found")),
                     **({"error": (c.failures[0].short(400) if c.failures else c.output_tail.strip()[-300:]), "tail": c.output_tail[-700:]} if not c.ok and not c.skipped else {})})
        diff = ctx.git.diff_since(baseline, max_chars=200_000)
        review = ReviewResult(checks=checks)
        if not diff.strip():
            current = self._current_content(task)
            verdict = self._llm_verdict(task, checks, current, upcoming) if current and review.deterministic_ok else None
            if verdict is not None and verdict.approved:
                verdict.feedback = ("The existing code already satisfies this task; no change was needed. " + verdict.feedback).strip()
                review.llm = verdict
            else:
                review.llm = LLMVerdict(approved=False, unmet_criteria=list(task.acceptance_criteria),
                                        feedback=(verdict.feedback if verdict else "") or "No changes were made for this task.")
        elif review.deterministic_ok:
            review.llm = self._llm_verdict(task, checks, diff, upcoming)
        has_real = any(c.ok and not c.skipped and c.name in REAL_CHECKS for c in checks)
        if review.llm is None and review.deterministic_ok and not has_real:
            review.llm = LLMVerdict(
                approved=False, unmet_criteria=list(task.acceptance_criteria),
                feedback="No build or test check could run and the LLM review was unavailable, so the change cannot be verified.",
            )
        if review.llm is not None:
            review.approved = review.deterministic_ok and review.llm.approved
        else:
            review.approved = review.deterministic_ok and has_real
        test = next((c for c in checks if c.name == "test" and not c.ok and not c.skipped), None)
        if test and changed and all(looks_like_test(f) for f in changed) and re.search(r"AssertionError|assert |Expected|expected .* (?:to|but)", test.output_tail or ""):
            test.failures.insert(1, Failure(kind="test", message="Only test files changed in this task, so the failing assertion comes from the test itself or from code written earlier. Read the real implementation: if it is right, assert what it actually returns (or check type, length, range, sign) instead of guessed numbers."))
        review.fingerprint = fingerprint(diff, review.feedback_text(ctx.settings.limits.max_failures_fed_back))
        stats = ctx.ledger.ingest(task.id, iteration, findings_from_review(review))
        ctx.log({"type": "review", "task_id": task.id, "iteration": iteration, "approved": review.approved,
                 "deterministic_ok": review.deterministic_ok, "llm": review.llm.approved if review.llm else None,
                 "feedback": review.feedback_text(ctx.settings.limits.max_failures_fed_back)[:500], **stats})
        return review, stats
