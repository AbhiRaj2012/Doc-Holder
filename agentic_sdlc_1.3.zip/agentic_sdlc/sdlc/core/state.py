from __future__ import annotations

from typing import Any, TypedDict


class PipelineState(TypedDict, total=False):
    analogues: list
    no_change_streak: int
    repeat_count: int
    accepted_by_human: bool
    last_problem: str
    gate_sig: str
    gate_repeats: int
    integration_round: int
    replans: int
    integration_added: bool
    run_id: str
    project_id: str
    repo_path: str
    workspace: str
    branch: str
    base_commit: str
    last_good_commit: str
    requirements: str
    user_input: str
    manifest: dict[str, Any]
    tasks: list[dict[str, Any]]
    suspended: list[dict[str, Any]]
    allow_proposals: list[dict[str, Any]]
    current_task_id: str
    iteration: int
    edit_failures: int
    edit_format: str
    last_edit: dict[str, Any]
    last_review: dict[str, Any]
    feedback: str
    fingerprints: list[str]
    human_hint: str
    issue: dict[str, Any]
    decision: dict[str, Any]
    exit_reason: str
    status: str
    error: str
    tokens_used: int
    started_at: float
    policy_events: list[dict[str, Any]]
    edit_ok: bool
    approved: bool
    regression_ok: bool
    suspend_reason: str
    gate_reason: str
    shrink_level: int
    scope_symbols: list[str]
    resume_action: str
    task_base: str
    edit_error: str
    iterations_total: int
    escalations: int
    edit_attempts: int
    edit_failed_attempts: int
    active_s: float
    task_stats: dict[str, dict[str, int]]


TERMINAL_STATUSES = ("completed", "aborted", "failed")


def current_task(state: PipelineState) -> dict[str, Any] | None:
    tid = state.get("current_task_id")
    for t in state.get("tasks", []):
        if t["id"] == tid:
            return t
    return None


def next_pending_task(state: PipelineState) -> dict[str, Any] | None:
    done = {t["id"] for t in state.get("tasks", []) if t["status"] == "completed"}
    for t in state.get("tasks", []):
        if t["status"] == "pending" and all(d in done for d in t.get("depends_on", [])):
            return t
    return None


def mark_blocked_dependents(tasks: list[dict[str, Any]]) -> list[dict[str, Any]]:
    bad = {t["id"] for t in tasks if t["status"] in ("skipped", "blocked")}
    changed = True
    while changed:
        changed = False
        for t in tasks:
            if t["status"] == "pending" and any(d in bad for d in t.get("depends_on", [])):
                t["status"] = "blocked"
                bad.add(t["id"])
                changed = True
    return tasks
