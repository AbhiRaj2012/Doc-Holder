from __future__ import annotations

import re
import shlex
import shutil
import subprocess
import time
from pathlib import Path

import yaml

from ..core.config import Settings
from ..core.schemas import EditResult
from ..runners.sandbox import run_command
from .edit_engine import parse_blocks
from .edit_types import EditRequest
from .git_ops import GitRepo

REQUIRED_FLAGS = (
    "--model", "--edit-format", "--no-auto-commits", "--no-dirty-commits", "--no-auto-lint", "--yes-always",
    "--no-stream", "--no-pretty", "--no-fancy-input", "--no-suggest-shell-commands", "--no-detect-urls",
    "--no-check-update", "--analytics-disable", "--no-show-model-warnings", "--no-show-release-notes",
    "--map-tokens", "--model-settings-file", "--chat-history-file", "--input-history-file",
    "--llm-history-file", "--message-file", "--read", "--timeout", "--weak-model", "--reasoning-effort",
)
_SECTION = re.compile(r"^(TO LLM|LLM RESPONSE)\s+\d{4}-\d{2}-\d{2}", re.M)
_APPLIED = re.compile(r"Applied edit to (\S+)")
_TOKENS = re.compile(r"Tokens:\s*([\d.,]+k?)\s+sent,\s*([\d.,]+k?)\s+received", re.I)
_FAIL_SIGNALS = ("did not match", "did not conform", "SearchReplaceNoExactMatch", "reflections allowed")


def _num(s: str) -> int:
    s = s.replace(",", "")
    return int(float(s[:-1]) * 1000) if s.endswith("k") else int(float(s))


def parse_tokens(stdout: str) -> tuple[int, int]:
    sent = recv = 0
    for a, b in _TOKENS.findall(stdout):
        sent, recv = sent + _num(a), recv + _num(b)
    return sent, recv


def response_text(history: str) -> str:
    marks = list(_SECTION.finditer(history))
    out = []
    for i, m in enumerate(marks):
        if m.group(1) == "LLM RESPONSE":
            end = marks[i + 1].start() if i + 1 < len(marks) else len(history)
            out.append(history[m.end():end])
    return "\n".join(out)


class AiderCliBackend:
    name = "aider"

    def __init__(self, settings: Settings, git: GitRepo):
        self.settings, self.git = settings, git

    def available(self) -> bool:
        b = self.settings.aider.binary
        return bool(shutil.which(b)) or Path(b).exists()

    def check_flags(self) -> list[str]:
        try:
            r = subprocess.run([self.settings.aider.binary, "--help"], capture_output=True, text=True, timeout=120)
        except (OSError, subprocess.SubprocessError) as exc:
            return [f"cannot run aider: {exc}"]
        return [f for f in REQUIRED_FLAGS if f not in r.stdout]

    def model_settings(self, fmt: str) -> str:
        o = self.settings
        entry = {
            "name": f"ollama_chat/{o.model_for('editor')}",
            "edit_format": fmt,
            "use_repo_map": True,
            "extra_params": {
                "num_ctx": o.ollama.num_ctx,
                "temperature": o.ollama.temperature,
                "num_predict": o.budget.max_output_tokens.get("editor", 4000),
            },
        }
        return yaml.safe_dump([entry], sort_keys=False)

    def build_command(self, req: EditRequest, work: Path) -> list[str]:
        a, o = self.settings.aider, self.settings
        model = f"ollama_chat/{o.model_for('editor')}"
        cmd = [
            a.binary, "--model", model, "--weak-model", model, "--edit-format", req.edit_format or a.edit_format,
            *(["--reasoning-effort", o.effort_for("editor")] if o.effort_for("editor") != "off" else []),
            "--no-auto-commits", "--no-dirty-commits", "--no-auto-lint", "--yes-always", "--no-stream", "--no-pretty",
            "--no-fancy-input", "--no-suggest-shell-commands", "--no-detect-urls", "--no-check-update",
            "--analytics-disable", "--no-show-model-warnings", "--no-show-release-notes",
            "--map-tokens", str(a.map_tokens), "--timeout", str(o.ollama.request_timeout_s),
            "--model-settings-file", str(work / "model.settings.yml"),
            "--chat-history-file", str(work / "chat.md"),
            "--input-history-file", str(work / "input.history"),
            "--llm-history-file", str(work / "llm.history"),
            "--message-file", str(work / "message.txt"),
            *a.extra_args,
        ]
        for f in req.read_files:
            cmd += ["--read", f]
        return cmd + list(req.files)

    def edit(self, req: EditRequest) -> EditResult:
        fmt = req.edit_format or self.settings.aider.edit_format
        work = req.run_dir / "aider" / req.tag
        work.mkdir(parents=True, exist_ok=True)
        (work / "message.txt").write_text(req.message, encoding="utf-8")
        (work / "model.settings.yml").write_text(self.model_settings(fmt), encoding="utf-8")
        req.edit_format = fmt
        cmd = self.build_command(req, work)
        before = self.git.snapshot()
        res = run_command(
            shlex.join(cmd), req.repo, self.settings.aider.timeout_s,
            env_extra={"OLLAMA_API_BASE": self.settings.ollama.base_url}, no_network=False,
        )
        after = self.git.snapshot()
        history = (work / "llm.history").read_text(encoding="utf-8", errors="replace") if (work / "llm.history").exists() else ""
        blocks = parse_blocks(response_text(history))
        files = self.git.changed_between(before, after)
        sent, recv = parse_tokens(res.output)
        failed = [s for s in _FAIL_SIGNALS if s.lower() in res.output.lower()]
        error = ""
        if res.timed_out:
            error = f"aider timed out after {self.settings.aider.timeout_s}s"
        elif res.exit_code != 0 and not files:
            error = f"aider exited with code {res.exit_code}"
        elif not files:
            error = "aider made no changes"
        if failed and files:
            error = "some edits failed to apply: " + ", ".join(failed)
        if error:
            error += "\n" + "\n".join(res.output.strip().splitlines()[-12:])
        return EditResult(
            ok=bool(files) and not res.timed_out, files_changed=files, diff=self.git.diff_trees(before, after),
            stdout_tail=res.output[-1500:], error=error, edit_format=f"aider-{fmt}", duration_s=res.duration_s,
            tokens_in=sent, tokens_out=recv, blocks_applied=len(_APPLIED.findall(res.output)),
            blocks_failed=len(failed), blocks=[{"path": b.path, "search_lines": len(b.search.splitlines()), "replace_lines": len(b.replace.splitlines())} for b in blocks],
            invocation={"backend": "aider", "format": fmt, "files": req.files, "read_files": req.read_files, "argv": cmd[:3]},
        )
