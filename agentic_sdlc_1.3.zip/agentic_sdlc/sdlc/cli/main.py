from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from pathlib import Path
from typing import Any, Callable

from ..core import offline_env
from ..core.config import Settings, load_settings
from ..core.project_store import Project, ProjectError, ProjectStore, new_run_id
from ..graph.builder import RunStatus, build_graph, current_status, open_checkpointer, resume_pipeline, run_pipeline
from ..graph.human_gate import approval, decision, read_issue
from ..graph.runtime import Runtime, build_runtime

Out = Callable[[str], None]


def overrides_from(args: argparse.Namespace) -> dict[str, Any]:
    o: dict[str, Any] = {}

    def put(path: tuple[str, ...], value: Any) -> None:
        if value is None:
            return
        d = o
        for k in path[:-1]:
            d = d.setdefault(k, {})
        d[path[-1]] = value

    put(("ollama", "main_model"), getattr(args, "model", None))
    put(("ollama", "judge_model"), getattr(args, "judge", None))
    for role in ("planner", "editor", "reviewer"):
        put(("ollama", "role_models", role), getattr(args, f"{role}_model", None))
    put(("ollama", "base_url"), getattr(args, "ollama_url", None))
    put(("ollama", "num_ctx"), getattr(args, "ctx", None))
    put(("hardware", "gpu_vram_gb"), getattr(args, "gpu", None))
    put(("hardware", "kv_cache_type"), getattr(args, "kv", None))
    put(("hardware", "model_gpu_gb"), getattr(args, "model_gb", None))
    put(("hardware", "context_override"), getattr(args, "ctx", None))
    put(("limits", "max_iterations_per_task"), getattr(args, "max_iter", None))
    if getattr(args, "no_critic", False):
        put(("features", "plan_critic"), False)
    if getattr(args, "no_regression", False):
        put(("features", "regression_gate"), False)
    return o


def settings_from(args: argparse.Namespace) -> Settings:
    s = load_settings(getattr(args, "config", None), overrides_from(args))
    offline_env.apply(s.tiktoken_dir(), s.ollama.base_url)
    if s.paths.toolchain:
        os.environ["SDLC_TOOLCHAIN"] = os.pathsep.join(s.paths.toolchain)
    return s


def make_runtime(settings: Settings, project: Project, store: ProjectStore, run_id: str, use_aider: bool = True) -> Runtime:
    return build_runtime(settings, project, store, run_id, use_aider=use_aider)


def apply_hardware(settings: Settings, out: Out) -> Settings:
    from ..adapters.ollama_client import OllamaClient
    from ..core import hardware

    client = OllamaClient(settings)
    arch, sizing = hardware.sizing_arch(client, settings)
    tuned, warnings = hardware.apply_profile(settings, arch)
    for w in [*sizing, *warnings]:
        out(f"hardware: {w}")
    out(f"hardware: num_ctx={tuned.ollama.num_ctx} for {settings.hardware.gpu_vram_gb:g} GB, {settings.hardware.kv_cache_type} KV cache")
    tuned, notes = hardware.calibrate(client, tuned, model=arch.name)
    for n in notes:
        out(f"hardware: {n}")
    return tuned


def find_project(store: ProjectStore, run_id: str, project_id: str | None) -> Project:
    ids = [project_id] if project_id else store.list_projects()
    for pid in ids:
        project = store.get(pid)
        if (project.workspace / "runs" / run_id).is_dir():
            return project
    raise ProjectError(f"run {run_id} not found" + (f" in project {project_id}" if project_id else ""))


def run_settings(project: Project, run_id: str, fallback: Settings) -> Settings:
    p = project.workspace / "runs" / run_id / "settings.json"
    return Settings.model_validate_json(p.read_text(encoding="utf-8")) if p.exists() else fallback


def describe_interrupt(info: dict[str, Any], project: Project, run_id: str, out: Out) -> None:
    if info.get("type") == "approve_commands":
        out("\nThe plan uses commands that are not on the allowlist:")
        for e in info.get("events", []):
            out(f"  {e.get('task_id')}: `{e.get('command')}` ({e.get('reason')})")
        out(f"Proposed executables: {', '.join(info.get('proposals', [])) or 'none'}")
        return
    issue = read_issue(project.workspace / "runs" / run_id)
    out(f"\nHuman gate: task {info.get('task_id')} - {info.get('title')} (reason: {info.get('reason')}, iteration {info.get('iteration')})")
    exp = info.get("explanation") or issue.get("explanation") or {}
    if exp:
        out(f"  What happened: {exp.get('what_happened', '')}\n  Likely cause: {exp.get('why', '')}\n  Suggested: {exp.get('recommendation', '')} - {exp.get('suggested_hint', '')}")
    for h in (issue.get("history") or [])[-8:]:
        out(f"  {h}")
    out(f"Details: {info.get('issue_path')}")


def ask_decision(info: dict[str, Any], ask: Callable[[str], str]) -> Any:
    if info.get("type") == "approve_commands":
        raw = ask("Approve which executables? (comma separated, 'all', or empty for none): ").strip()
        props = info.get("proposals", [])
        return approval(props if raw.lower() == "all" else [x.strip() for x in raw.split(",") if x.strip()])
    while True:
        raw = ask("Decision: [w]ork on it / [r]estart task fresh (discard its changes) / re-[n]plan remaining work / [f]resh plan (roll back whole run) / [c]ommit (accept current change) / [p]roceed (skip task) / [a]bort: ").strip().lower()
        if raw[:1] in ("w", "r", "n", "f", "c", "p", "a"):
            break
    action = {"w": "work", "r": "restart", "n": "replan", "f": "replan_all", "c": "accept", "p": "proceed", "a": "abort"}[raw[0]]
    hint = ask("Hint for the editor (optional): ").strip() if action in ("work", "restart", "replan", "replan_all") else ""
    return decision(action, hint)


def drive(app: Any, project: Project, run_id: str, status: RunStatus, interactive: bool, ask: Callable[[str], str], out: Out) -> RunStatus:
    while not status.done and status.interrupt:
        describe_interrupt(status.interrupt, project, run_id, out)
        if not interactive:
            out(f"\nPaused. Resume with: python -m sdlc resume {run_id} --project {project.id} --action work|restart|replan|replan_all|accept|proceed|abort [--hint TEXT] [--approve exe1,exe2]")
            return status
        status = resume_pipeline(app, run_id, ask_decision(status.interrupt, ask))
    return status


def finish(settings: Settings, project: Project, run_id: str, status: RunStatus, evaluate: bool, out: Out) -> int:
    s = status.state
    out(f"\nRun {run_id}: {s.get('status')}  ({sum(1 for t in s.get('tasks', []) if t['status'] == 'completed')}/{len(s.get('tasks', []))} tasks completed)")
    if s.get("error"):
        out(f"error: {s['error']}")
    if evaluate and evaluate_and_report(settings, project, run_id, out):
        return 2
    return 0 if s.get("status") == "completed" else 1


def evaluate_and_report(settings: Settings, project: Project, run_id: str, out: Out) -> int:
    from ..evals.run_evals import evaluate_run_dir

    try:
        results, _ = evaluate_run_dir(settings, project.workspace / "runs" / run_id, log=out)
        for r in results:
            out(f"  {r.name:<22} {r.score:.2f}  {r.band:<10} {'pass' if r.passed else 'FAIL'}  [{r.source}]")
        return 0
    except Exception as exc:
        out(f"evaluation failed: {exc}")
        return 2


def make_create_runtime(settings: Settings, project: Project, run_id: str) -> Any:
    from ..create.graph import make_runtime as create_runtime

    return create_runtime(settings, project, run_id)


def cmd_create(args: argparse.Namespace, out: Out, ask: Callable[[str], str]) -> int:
    from ..create.graph import run_create
    from ..create.project import new_project

    settings = settings_from(args)
    if args.auto_context:
        settings = apply_hardware(settings, out)
    request = Path(args.request_file).read_text(encoding="utf-8") if args.request_file else args.request
    if not (request or "").strip():
        out("error: describe the application with --request or --request-file")
        return 2
    run_id = args.run_id or new_run_id()
    project = ProjectStore(settings).get(args.project) if args.project else new_project(settings, args.name or "new-app", run_id)
    run_dir = project.run_dir(run_id)
    args._run_dir = run_dir
    (run_dir / "settings.json").write_text(settings.model_dump_json(indent=2), encoding="utf-8")
    out(f"create mode  project {project.id}  run {run_id}  code {project.code}")
    rt = make_create_runtime(settings, project, run_id)
    summary = run_create(rt, request, args.language or "")
    out(f"\nRun {run_id}: {summary.get('final_status')}  ({summary.get('tasks_completed')}/{summary.get('num_tasks')} files approved, project check {'passed' if summary.get('verify_ok') else 'failed'})")
    exp = run_dir / "run_explanation.json"
    if exp.exists():
        e = json.loads(exp.read_text(encoding="utf-8"))
        out(f"What happened: {e.get('what_happened')}\nLikely cause: {e.get('why')}")
    out(f"Project files: {project.code}")
    if not args.no_eval and evaluate_and_report(settings, project, run_id, out):
        return 2
    return 0 if summary.get("final_status") == "completed" else 1


def cmd_run(args: argparse.Namespace, out: Out, ask: Callable[[str], str]) -> int:
    settings = settings_from(args)
    if args.auto_context:
        settings = apply_hardware(settings, out)
    store = ProjectStore(settings)
    project = store.open(args.source, args.name, fresh=args.fresh)
    run_id = args.run_id or new_run_id()
    requirements = Path(args.requirements_file).read_text(encoding="utf-8") if args.requirements_file else args.requirements
    if not (requirements or "").strip():
        out("error: give requirements with --requirements or --requirements-file")
        return 2
    run_dir = project.run_dir(run_id)
    args._run_dir = run_dir
    (run_dir / "settings.json").write_text(settings.model_dump_json(indent=2), encoding="utf-8")
    out(f"project {project.id}  run {run_id}  code {project.code}")
    rt = make_runtime(settings, project, store, run_id, use_aider=not args.no_aider)
    app = build_graph(rt, open_checkpointer(run_dir / "checkpoint.sqlite"))
    status = run_pipeline(app, rt, requirements, args.user_input or "")
    status = drive(app, project, run_id, status, not args.non_interactive, ask, out)
    if not status.done:
        return 3
    return finish(settings, project, run_id, status, not args.no_eval, out)


def cmd_resume(args: argparse.Namespace, out: Out, ask: Callable[[str], str]) -> int:
    base = settings_from(args)
    store = ProjectStore(base)
    project = find_project(store, args.run_id, args.project)
    settings = run_settings(project, args.run_id, base)
    args._run_dir = project.workspace / "runs" / args.run_id
    offline_env.apply(settings.tiktoken_dir(), settings.ollama.base_url)
    rt = make_runtime(settings, project, store, args.run_id, use_aider=not args.no_aider)
    app = build_graph(rt, open_checkpointer(project.workspace / "runs" / args.run_id / "checkpoint.sqlite"))
    status = current_status(app, args.run_id)
    if status.done:
        out("run already finished")
        return finish(settings, project, args.run_id, status, not args.no_eval, out)
    if args.action or args.approve is not None:
        info = status.interrupt or {}
        value = approval([x for x in (args.approve or "").split(",") if x]) if info.get("type") == "approve_commands" else decision(args.action or "work", args.hint or "")
        status = resume_pipeline(app, args.run_id, value)
    else:
        status = resume_pipeline(app, args.run_id) if not status.interrupt else status
    status = drive(app, project, args.run_id, status, not args.non_interactive, ask, out)
    if not status.done:
        return 3
    return finish(settings, project, args.run_id, status, not args.no_eval, out)


def pending(settings: Settings, project: Project, run_id: str) -> RunStatus:
    store = ProjectStore(settings)
    rt = make_runtime(settings, project, store, run_id, use_aider=False)
    app = build_graph(rt, open_checkpointer(project.workspace / "runs" / run_id / "checkpoint.sqlite"))
    return current_status(app, run_id)


def cmd_status(args: argparse.Namespace, out: Out, ask: Callable[[str], str]) -> int:
    base = settings_from(args)
    project = find_project(ProjectStore(base), args.run_id, args.project)
    st = pending(run_settings(project, args.run_id, base), project, args.run_id)
    out(json.dumps({"project": project.id, "done": st.done, "interrupt": st.interrupt, "status": st.state.get("status")}, default=str))
    return 0


def cmd_eval(args: argparse.Namespace, out: Out, ask: Callable[[str], str]) -> int:
    from ..evals.run_evals import evaluate_run_dir

    settings = settings_from(args)
    store = ProjectStore(settings)
    project = find_project(store, args.run_id, args.project)
    results, _ = evaluate_run_dir(settings, project.workspace / "runs" / args.run_id, log=out)
    for r in results:
        out(f"{r.name:<22} {r.score:.2f}  {r.band:<10} {'pass' if r.passed else 'FAIL'}  [{r.source}]  {r.reason[:80]}")
    return 0


def cmd_dashboard(args: argparse.Namespace, out: Out, ask: Callable[[str], str]) -> int:
    from ..dashboard.build_dashboard import rebuild

    out(str(rebuild(settings_from(args))))
    return 0


def cmd_projects(args: argparse.Namespace, out: Out, ask: Callable[[str], str]) -> int:
    store = ProjectStore(settings_from(args))
    for pid in store.list_projects():
        p = store.get(pid)
        runs = sorted(d.name for d in (p.workspace / "runs").iterdir()) if (p.workspace / "runs").exists() else []
        out(f"{pid}  source={p.source}  runs={len(runs)}" + (f"  last={runs[-1]}" if runs else ""))
    return 0


def cmd_sync(args: argparse.Namespace, out: Out, ask: Callable[[str], str]) -> int:
    store = ProjectStore(settings_from(args))
    project = store.get(args.project)
    if not store.source_changed(project) and not args.force:
        out("source unchanged")
        return 0
    store.sync(project, force=args.force)
    out(f"re-imported {project.source} into {project.code}")
    return 0


def cmd_export(args: argparse.Namespace, out: Out, ask: Callable[[str], str]) -> int:
    store = ProjectStore(settings_from(args))
    out(str(store.export(store.get(args.project), args.to)))
    return 0


def cmd_preflight(args: argparse.Namespace, out: Out, ask: Callable[[str], str]) -> int:
    settings = settings_from(args)
    bad = 0

    def line(ok: bool | None, text: str) -> None:
        nonlocal bad
        out(("[ok]   " if ok else "[warn] " if ok is None else "[FAIL] ") + text)
        bad += ok is False

    line(shutil.which("git") is not None, "git installed")
    from ..core import symbols as sym

    missing_ts = [lang for lang in ("c", "cpp", "java", "js", "css", "html") if sym.backend(lang) != "tree-sitter"]
    line(None if missing_ts else True, "tree-sitter parsers loaded" if not missing_ts else f"tree-sitter unavailable for {', '.join(missing_ts)}: regex symbol extraction is used")
    line(True if offline_env.netns_available() else None, "network-less sandbox (unshare -rn) available" if offline_env.netns_available() else "unshare -rn unavailable: test commands run without a network namespace")
    try:
        from ..adapters.ollama_client import OllamaClient

        client = OllamaClient(settings)
        models = client.list_models()
        line(True, f"Ollama reachable ({len(models)} models)")
        for label, name in (("main", settings.ollama.main_model), ("judge", settings.ollama.judge_model), *settings.ollama.role_models.items()):
            line(name in models, f"{label} model '{name}' pulled")
    except Exception as exc:
        line(False, f"Ollama not reachable at {settings.ollama.base_url}: {exc}")
    from ..adapters.aider_cli import AiderCliBackend
    from ..adapters.git_ops import GitRepo

    aider = AiderCliBackend(settings, GitRepo(Path.cwd()))
    if aider.available():
        missing = aider.check_flags()
        line(not missing, "aider supports all required flags" if not missing else f"aider is missing flags: {', '.join(missing)}")
    else:
        line(None, f"aider binary '{settings.aider.binary}' not found: the native editor will be used")
    try:
        import deepeval  # noqa: F401

        line(True, "deepeval importable")
    except Exception as exc:
        line(False, f"deepeval import failed: {exc}")
    if args.repo:
        from ..runners.registry import detect_languages, preflight

        langs = list(detect_languages(args.repo))
        out(f"repo languages: {', '.join(langs) or 'none detected'}")
        for problem in preflight(args.repo, langs):
            line(None, problem)
    return 1 if bad else 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="sdlc", description="Air-gapped agentic SDLC pipeline")
    p.add_argument("--config", help="path to settings.yaml")
    sub = p.add_subparsers(dest="cmd", required=True)

    def common(sp: argparse.ArgumentParser) -> None:
        sp.add_argument("--model", help="main model")
        sp.add_argument("--judge", help="judge model")
        sp.add_argument("--planner-model", dest="planner_model", help="model for planning (default: --model)")
        sp.add_argument("--editor-model", dest="editor_model", help="model that writes code (default: --model)")
        sp.add_argument("--reviewer-model", dest="reviewer_model", help="model for review and explanations (default: --model)")
        sp.add_argument("--ollama-url")

    r = sub.add_parser("run", help="run the pipeline on a project")
    common(r)
    r.add_argument("source", help="project directory")
    r.add_argument("--name")
    r.add_argument("--requirements", default="")
    r.add_argument("--requirements-file")
    r.add_argument("--user-input")
    r.add_argument("--run-id")
    r.add_argument("--fresh", action="store_true", help="re-import the project copy")
    r.add_argument("--gpu", type=float, help="GPU VRAM in GB")
    r.add_argument("--model-gb", dest="model_gb", type=float, help="model GPU footprint in GB when smaller than the file size")
    r.add_argument("--kv", choices=["f16", "q8_0", "q4_0"])
    r.add_argument("--ctx", type=int, help="context size override")
    r.add_argument("--auto-context", action="store_true", help="derive context and budgets from the GPU and model")
    r.add_argument("--max-iter", type=int)
    r.add_argument("--no-aider", action="store_true")
    r.add_argument("--no-critic", action="store_true")
    r.add_argument("--no-regression", action="store_true")
    r.add_argument("--no-eval", action="store_true")
    r.add_argument("--non-interactive", action="store_true", help="stop at human prompts instead of asking")
    r.set_defaults(fn=cmd_run)

    c = sub.add_parser("create", help="build a new project from a description")
    common(c)
    c.add_argument("--name", help="project name")
    c.add_argument("--project", help="existing empty project id (used by the UI)")
    c.add_argument("--request", default="")
    c.add_argument("--request-file")
    c.add_argument("--language", choices=["python", "c", "cpp", "java", "js", "web"])
    c.add_argument("--run-id")
    c.add_argument("--gpu", type=float)
    c.add_argument("--model-gb", dest="model_gb", type=float)
    c.add_argument("--kv", choices=["f16", "q8_0", "q4_0"])
    c.add_argument("--ctx", type=int)
    c.add_argument("--auto-context", action="store_true")
    c.add_argument("--max-iter", type=int)
    c.add_argument("--no-eval", action="store_true")
    c.set_defaults(fn=cmd_create)

    s = sub.add_parser("resume", help="resume a paused or interrupted run")
    common(s)
    s.add_argument("run_id")
    s.add_argument("--project")
    s.add_argument("--action", choices=["work", "restart", "replan", "replan_all", "accept", "proceed", "abort"])
    s.add_argument("--hint")
    s.add_argument("--approve", help="comma separated executables to approve")
    s.add_argument("--no-aider", action="store_true")
    s.add_argument("--no-eval", action="store_true")
    s.add_argument("--non-interactive", action="store_true")
    s.set_defaults(fn=cmd_resume)

    t = sub.add_parser("status", help="print the state of a run as JSON")
    t.add_argument("run_id")
    t.add_argument("--project")
    t.set_defaults(fn=cmd_status)

    e = sub.add_parser("eval", help="(re)evaluate a finished run")
    common(e)
    e.add_argument("run_id")
    e.add_argument("--project")
    e.set_defaults(fn=cmd_eval)

    rp = sub.add_parser("report", help="write timeline.txt, plan.md and failures.md for a run")
    rp.add_argument("run_id")
    rp.add_argument("--project")
    rp.set_defaults(fn=cmd_report)

    d = sub.add_parser("dashboard", help="rebuild the global dashboard")
    d.set_defaults(fn=cmd_dashboard)
    sub.add_parser("projects", help="list imported projects").set_defaults(fn=cmd_projects)

    y = sub.add_parser("sync", help="re-import a project from its source")
    y.add_argument("project")
    y.add_argument("--force", action="store_true")
    y.set_defaults(fn=cmd_sync)

    x = sub.add_parser("export", help="export a project's changes as a patch or into a folder")
    x.add_argument("project")
    x.add_argument("--to")
    x.set_defaults(fn=cmd_export)

    f = sub.add_parser("preflight", help="check the environment")
    common(f)
    f.add_argument("--repo")
    f.set_defaults(fn=cmd_preflight)
    return p


def main(argv: list[str] | None = None, out: Out = print, ask: Callable[[str], str] = input) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.fn(args, out, ask)
    except (ProjectError, FileNotFoundError, ValueError) as exc:
        out(f"error: {exc}")
        return 2
    except KeyboardInterrupt:
        out("\ninterrupted; the run can be resumed with 'resume'")
        return 130
    finally:
        run_dir = getattr(args, "_run_dir", None)
        if run_dir is not None:
            write_reports(run_dir, out)


def write_reports(run_dir: Path, out: Out) -> None:
    from ..telemetry.report import write_debug_files

    try:
        paths = write_debug_files(run_dir)
        if paths:
            out("debug files: " + ", ".join(str(p) for p in paths))
    except Exception as exc:
        out(f"debug files could not be written: {exc}")


def cmd_report(args: argparse.Namespace, out: Out, ask: Callable[[str], str]) -> int:
    project = find_project(ProjectStore(settings_from(args)), args.run_id, args.project)
    write_reports(project.workspace / "runs" / args.run_id, out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
