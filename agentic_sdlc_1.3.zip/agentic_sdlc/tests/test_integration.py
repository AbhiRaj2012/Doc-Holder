from __future__ import annotations

from pathlib import Path

from sdlc.agents import analogues as ana
from sdlc.agents.analyser import Analyser
from sdlc.agents.editor import EditorAgent
from sdlc.core.config import load_settings
from sdlc.core.paths import posix, posix_list
from sdlc.core.schemas import Task
from sdlc.graph.builder import summarize

from .test_graph import Env, client, task_draft, write

WAVES_H = "class SineWave {\npublic:\n    double at(double t);\n};\n\nclass SquareWave {\npublic:\n    double at(double t);\n};\n"
UI_CPP = 'void MainWindow::init() {\n    combo->addItem("Sine", new SineWave());\n    combo->addItem("Square", new SquareWave());\n}\n'
CMAKE = "add_executable(app src/main.cpp src/signals/Waveforms.h)\n"
FILES = {"src/signals/Waveforms.h": WAVES_H, "src/ui/MainWindow.cpp": UI_CPP, "CMakeLists.txt": CMAKE, "src/main.cpp": "int main() { return 0; }\n"}


def make_repo(tmp: Path) -> Path:
    for rel, text in FILES.items():
        p = tmp / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text)
    return tmp


def test_posix_helpers():
    assert posix("test\\waveform_tests.cpp") == "test/waveform_tests.cpp" and posix("./a/b") == "a/b"
    assert posix_list(["a\\b.cpp", "a/b.cpp"]) == ["a/b.cpp"]
    t = Task(id="T1", title="t", description="d", language="cpp", target_files=["test\\w.cpp"], acceptance_criteria=["x"])
    assert t.target_files == ["test/w.cpp"]


def test_manifest_has_posix_paths_and_config_files(tmp_path):
    repo = make_repo(tmp_path)
    m = Analyser(load_settings(), repo).run()
    paths = {f.path for f in m.files}
    assert "src/signals/Waveforms.h" in paths and "CMakeLists.txt" in paths and all("\\" not in p for p in paths)


def test_analogue_finds_sibling_and_touchpoints(tmp_path):
    repo = make_repo(tmp_path)
    m = Analyser(load_settings(), repo).run()
    found = ana.find_analogues(m, repo, "Add a CosineWave class to the signal generators")
    assert found and found[0].new_name == "CosineWave" and found[0].existing in ("SineWave", "SquareWave")
    files = {t.file for t in found[0].touchpoints}
    assert "src/ui/MainWindow.cpp" in files
    block = ana.prompt_block(found)
    assert "EXISTING PATTERN" in block and "MainWindow.cpp" in block
    assert ana.reference_files(found) == ["src/signals/Waveforms.h"]


def test_edit_to_existing_file_with_backslash_scope_is_kept(tmp_path):
    env = Env(tmp_path, client([task_draft()]), lambda r: [write("calc.py", "x")])
    task = Task(id="T1", title="t", description="d", language="python", target_files=["calc.py"], acceptance_criteria=["a"])
    task.target_files = ["calc.py"]
    agent = EditorAgent(env.rt.ctx, env.backend)
    before = env.rt.ctx.git.snapshot()
    env.code.joinpath("calc.py").write_text("def add(a, b):\n    return a + b\n")
    from sdlc.core.schemas import EditResult

    res = EditResult(ok=True, files_changed=["calc.py"])
    task.target_files = ["calc.py"]
    assert agent._enforce_scope(task, before, res) == []


def test_wiring_tasks_added_when_new_class_is_isolated(tmp_path):
    from sdlc.graph.builder import build_graph, open_checkpointer, run_pipeline
    from sdlc.graph.nodes.integrate import make_integrate
    from sdlc.graph.runtime import build_runtime
    from sdlc.core.project_store import ProjectStore

    s = load_settings(overrides={"paths": {"projects_root": str(tmp_path / "projects"), "benchmark_dir": str(tmp_path / "bench")}})
    src = make_repo(tmp_path / "src")
    store = ProjectStore(s)
    project = store.open(src, "demo")
    (project.code / "src/signals/Waveforms.h").write_text(WAVES_H + "\nclass CosineWave {\npublic:\n    double at(double t);\n};\n")
    rt = build_runtime(s, project, store, "r1", client=object(), editor_backend=object())
    manifest = Analyser(s, project.code, project.id).run()
    analogues = [a.to_dict() for a in ana.find_analogues(Analyser(s, src).run(), src, "Add a CosineWave class")]
    state = {"analogues": analogues, "manifest": manifest.model_dump(mode="json"), "tasks": []}
    out = make_integrate(rt)(state)
    assert out["integration_added"] and out["status"] == "running"
    targets = {t["target_files"][0] for t in out["tasks"]}
    assert "src/ui/MainWindow.cpp" in targets and out["tasks"][0]["id"] == "W1"
    again = make_integrate(rt)({**state, "integration_round": 1})
    assert not again["integration_added"]
    (project.code / "src/ui/MainWindow.cpp").write_text(UI_CPP + '    combo->addItem("Cosine", new CosineWave());\n')
    manifest = Analyser(s, project.code, project.id).run()
    done = make_integrate(rt)({**state, "manifest": manifest.model_dump(mode="json")})
    assert not done["integration_added"]


def test_summarize_edit_output():
    out = summarize("edit", {"edit_ok": True, "edit_error": "", "last_edit": {"edit_format": "native-diff", "files_changed": ["a.h"], "blocks_applied": 1, "blocks_failed": 0, "diff_head": "+x"}})
    assert out["files"] == ["a.h"] and out["blocks"] == "1 applied / 0 failed"
