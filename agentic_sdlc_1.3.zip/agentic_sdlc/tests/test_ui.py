from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

from sdlc.core.config import load_settings
from sdlc.core.project_store import ProjectStore
from sdlc.ui import jobs

from .helpers import PY_FILES

APP = str(Path(__file__).resolve().parents[1] / "sdlc" / "ui" / "streamlit_app.py")


def env(tmp_path: Path):
    s = load_settings(overrides={"paths": {"projects_root": str(tmp_path / "projects"), "benchmark_dir": str(tmp_path / "bench")}})
    src = tmp_path / "src"
    src.mkdir()
    for n, t in PY_FILES.items():
        (src / n).write_text(t)
    store = ProjectStore(s)
    return s, store, store.open(src, "demo")


def test_job_state_and_listing(tmp_path):
    s, store, project = env(tmp_path)
    d = project.run_dir("r1")
    assert jobs.job_state(d) == "idle"
    (d / "exit.code").write_text("3\n")
    assert jobs.job_state(d) == "waiting for human"
    (d / "exit.code").write_text("0\n")
    assert jobs.job_state(d) == "completed"
    assert [(r["project"], r["run_id"]) for r in jobs.list_runs(s)] == [("demo", "r1")]


def test_launch_writes_exit_code_and_log(tmp_path):
    s, store, project = env(tmp_path)
    d = project.run_dir("r2")
    cfg = jobs.write_config(s, d)
    jobs.launch(["projects"], d, cfg)
    import time

    for _ in range(100):
        if (d / "exit.code").exists():
            break
        time.sleep(0.2)
    assert (d / "exit.code").read_text().strip() == "0"
    assert "demo" in (d / "cli.log").read_text()
    assert jobs.job_state(d) == "completed"


def test_run_info_and_tail(tmp_path):
    s, store, project = env(tmp_path)
    d = project.run_dir("r3")
    (d / "events.jsonl").write_text("\n".join(json.dumps(e) for e in [{"ts": 1, "seq": 1, "type": "llm_call"}, {"ts": 2, "seq": 2, "type": "task_start", "task_id": "T1"}]))
    info = jobs.run_info(d)
    assert info["stack"]["tasks"] == [] and jobs.tail_events(info["events"]) == ['task_start  {"task_id": "T1"}']


@pytest.mark.parametrize("page", ["run", "live", "evals", "dashboard", "setup"])
def test_pages_render(tmp_path, monkeypatch, page):
    from streamlit.testing.v1 import AppTest

    s, store, project = env(tmp_path)
    project.run_dir("r1")
    monkeypatch.setenv("SDLC_TEST_ROOT", str(tmp_path))

    def app(page: str) -> None:
        import importlib
        import os
        from pathlib import Path

        from sdlc.core.config import load_settings
        from sdlc.ui import common

        root = Path(os.environ["SDLC_TEST_ROOT"])
        fixed = load_settings(overrides={"paths": {"projects_root": str(root / "projects"), "benchmark_dir": str(root / "bench")}})
        common.settings = lambda: fixed
        importlib.import_module(f"sdlc.ui.views.p_{page}").render()

    at = AppTest.from_function(app, args=(page,), default_timeout=60)
    at.run()
    assert not at.exception, at.exception
    if page == "run":
        at.text_area[0].set_value("x")
        at.button[0].click().run()
        assert at.error and "does not exist" in at.error[0].value
    if page == "dashboard":
        assert (tmp_path / "bench" / "dashboard.html").exists()


def test_live_page_with_events(tmp_path, monkeypatch):
    from streamlit.testing.v1 import AppTest

    s, store, project = env(tmp_path)
    d = project.run_dir("r9")
    rows = [
        {"ts": 1.0, "seq": 1, "type": "node_start", "node": "edit", "task_id": "T1.1.1", "iteration": 1},
        {"ts": 2.0, "seq": 2, "type": "llm_start", "node": "editor", "model": "m", "prompt_tokens_est": 500, "effort": "low"},
        {"ts": 3.0, "seq": 3, "type": "llm_call", "node": "editor", "model": "m", "prompt_tokens": 500, "completion_tokens": 40, "duration_s": 1.0, "output": "SEARCH/REPLACE", "thinking": "t", "thinking_chars": 1, "done_reason": "length", "max_tokens": 900, "effort": "low", "retry": True},
        {"ts": 4.0, "seq": 4, "type": "node", "node": "edit", "task_id": "T1.1.1", "iteration": 1, "duration_s": 3.0, "output": {"ok": False, "diff": "-a\n+b", "files": ["a.h"]}},
    ]
    (d / "events.jsonl").write_text("\n".join(json.dumps(r) for r in rows))
    (d / "stack.json").write_text(json.dumps({"tasks": [{"id": "T1.1.1", "status": "in_progress", "title": "x|y", "parent_id": "T1.1", "shrink_level": 1}], "suspended": []}))
    monkeypatch.setenv("SDLC_TEST_ROOT", str(tmp_path))

    def app() -> None:
        import os
        from pathlib import Path

        from sdlc.core.config import load_settings
        from sdlc.ui import common
        from sdlc.ui.views import p_live

        root = Path(os.environ["SDLC_TEST_ROOT"])
        fixed = load_settings(overrides={"paths": {"projects_root": str(root / "projects"), "benchmark_dir": str(root / "bench")}})
        common.settings = lambda: fixed
        p_live.render()

    at = AppTest.from_function(app, default_timeout=60)
    at.run()
    assert not at.exception, at.exception
    assert any("Active node" in m.label for m in at.metric)


def test_stop_and_hide_runs(tmp_path):
    import subprocess
    import sys
    import time

    s, store, project = env(tmp_path)
    d = project.run_dir("20261118-000001-aaaa")
    d2 = project.run_dir("20261118-000002-bbbb")
    proc = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(60)"], start_new_session=(sys.platform != "win32"))
    (d / "job.pid").write_text(str(proc.pid))
    assert jobs.job_state(d) == "running"
    assert [r["run_id"] for r in jobs.list_runs(s)] == ["20261118-000002-bbbb", "20261118-000001-aaaa"]
    assert [r["run_id"] for r in jobs.running_runs(s)] == ["20261118-000001-aaaa"]
    assert jobs.stop_run(d) == "stopped"
    proc.wait(timeout=10)
    assert jobs.job_state(d) == "stopped by user"
    jobs.hide_run(d2)
    assert [r["run_id"] for r in jobs.list_runs(s)] == ["20261118-000001-aaaa"]
    assert len(jobs.list_runs(s, include_hidden=True)) == 2
