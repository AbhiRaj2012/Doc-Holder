from __future__ import annotations

import json
from pathlib import Path

from sdlc.cli import main as cli
from sdlc.core.config import load_settings
from sdlc.graph.runtime import build_runtime

from .helpers import PY_FILES
from .test_graph import Scripted, calc, client, write


class Harness:
    def __init__(self, tmp_path: Path, actions):
        s = load_settings(overrides={"paths": {"projects_root": str(tmp_path / "projects"), "benchmark_dir": str(tmp_path / "bench")}, "limits": {"max_iterations_per_task": 2}})
        self.cfg = tmp_path / "settings.json"
        self.cfg.write_text(s.model_dump_json())
        self.src = tmp_path / "src"
        self.src.mkdir()
        for n, t in PY_FILES.items():
            (self.src / n).write_text(t)
        self.actions, self.fake, self.lines = actions, client(), []

    def patch(self, monkeypatch):
        def make(settings, project, store, run_id, use_aider=True):
            return build_runtime(settings, project, store, run_id, client=self.fake, editor_backend=Scripted(project.code, self.actions()))
        monkeypatch.setattr(cli, "make_runtime", make)

    def call(self, *argv, answers=()):
        it = iter(answers)
        return cli.main(["--config", str(self.cfg), *argv], out=self.lines.append, ask=lambda p: next(it))

    @property
    def text(self) -> str:
        return "\n".join(self.lines)


def test_run_completes_and_lists(tmp_path, monkeypatch):
    h = Harness(tmp_path, lambda: [write("calc.py", calc())])
    h.patch(monkeypatch)
    assert h.call("run", str(h.src), "--name", "demo", "--requirements", "fix add", "--no-eval", "--run-id", "r1") == 0
    assert "completed" in h.text and "1/1 tasks" in h.text
    h.lines.clear()
    assert h.call("projects") == 0 and "demo" in h.text and "runs=1" in h.text
    assert h.call("run", str(h.src), "--requirements", "") == 2


def test_gate_non_interactive_then_resume(tmp_path, monkeypatch):
    bad = write("calc.py", calc(add="a * b"))
    h = Harness(tmp_path, lambda: [bad])
    h.patch(monkeypatch)
    assert h.call("run", str(h.src), "--name", "demo", "--requirements", "fix add", "--no-eval", "--run-id", "r1", "--non-interactive") == 3
    assert "Human gate" in h.text and "resume r1" in h.text
    h.actions = lambda: [write("calc.py", calc())]
    assert h.call("resume", "r1", "--action", "work", "--hint", "use +", "--no-eval", "--non-interactive") == 0
    assert "completed" in h.text


def test_gate_interactive_abort(tmp_path, monkeypatch):
    h = Harness(tmp_path, lambda: [write("calc.py", calc(add="a * b"))])
    h.patch(monkeypatch)
    code = h.call("run", str(h.src), "--name", "demo", "--requirements", "x", "--no-eval", "--run-id", "r1", answers=["x", "a"])
    assert code == 1 and "aborted" in h.text


def test_overrides_and_unknown_run(tmp_path):
    h = Harness(tmp_path, lambda: [])
    args = cli.build_parser().parse_args(["run", "s", "--model", "m", "--gpu", "8", "--ctx", "16384", "--no-critic"])
    o = cli.overrides_from(args)
    assert o["ollama"]["main_model"] == "m" and o["hardware"]["gpu_vram_gb"] == 8 and o["features"]["plan_critic"] is False
    assert h.call("resume", "nope") == 2 and "error" in h.text


def test_dashboard_and_preflight(tmp_path):
    h = Harness(tmp_path, lambda: [])
    assert h.call("dashboard") == 0 and Path(h.lines[-1]).exists()
    h.call("preflight", "--ollama-url", "http://127.0.0.1:9")
    assert "Ollama not reachable" in h.text


def test_auto_eval_after_run(tmp_path, monkeypatch):
    h = Harness(tmp_path, lambda: [write("calc.py", calc())])
    h.patch(monkeypatch)
    assert h.call("run", str(h.src), "--name", "demo", "--requirements", "fix add", "--run-id", "r1", "--non-interactive") == 0
    d = tmp_path / "projects"
    status = next(d.rglob("eval_status.json"))
    assert json.loads(status.read_text())["state"] == "done"
    assert next(d.rglob("eval_results.json")).exists() and (tmp_path / "bench" / "benchmark.jsonl").exists()


def test_auto_eval_after_pause_and_resume(tmp_path, monkeypatch):
    h = Harness(tmp_path, lambda: [write("calc.py", calc(add="a * b"))])
    h.patch(monkeypatch)
    assert h.call("run", str(h.src), "--name", "demo", "--requirements", "fix add", "--run-id", "r1", "--non-interactive") == 3
    assert not list((tmp_path / "projects").rglob("eval_status.json"))
    h.actions = lambda: [write("calc.py", calc())]
    assert h.call("resume", "r1", "--action", "work", "--non-interactive") == 0
    assert json.loads(next((tmp_path / "projects").rglob("eval_status.json")).read_text())["state"] == "done"


def test_debug_files_written_after_run_and_pause(tmp_path, monkeypatch):
    h = Harness(tmp_path, lambda: [write("calc.py", calc(add="a * b"))])
    h.patch(monkeypatch)
    assert h.call("run", str(h.src), "--name", "demo", "--requirements", "fix add", "--no-eval", "--run-id", "r1", "--non-interactive") == 3
    d = next((tmp_path / "projects").rglob("runs/r1"))
    assert (d / "timeline.txt").exists() and "start T1" in (d / "timeline.txt").read_text()
    plan = (d / "plan.md").read_text()
    assert "| T1 |" in plan and "Acceptance criteria" in plan
    assert "review rejected" in (d / "failures.md").read_text() or "tool" in (d / "failures.md").read_text()
    (d / "plan.md").unlink()
    assert h.call("report", "r1") == 0 and (d / "plan.md").exists()
