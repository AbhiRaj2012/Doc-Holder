import os
import time
import subprocess
import requests

def ensure_ollama_ready(cfg: dict) -> tuple[bool, str]:
    ollama_cfg = cfg["ollama"]
    base_url = ollama_cfg["base_url"].rstrip("/")
    model_name = ollama_cfg["model"]

    # 1. Inject Ollama server environment variables into current process & child processes
    for key, val in ollama_cfg.get("server_env", {}).items():
        os.environ[str(key)] = str(val)

    # Also set OLLAMA_API_BASE so Aider knows where to connect
    os.environ["OLLAMA_API_BASE"] = base_url

    # 2. Check if Ollama is listening on localhost:11434; if not, spawn it with env vars
    try:
        resp = requests.get(f"{base_url}/api/tags", timeout=2)
        server_up = resp.status_code == 200
    except requests.RequestException:
        server_up = False

    if not server_up:
        try:
            subprocess.Popen(
                ["ollama", "serve"],
                env=os.environ.copy(),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            for _ in range(10):
                time.sleep(1)
                try:
                    if requests.get(f"{base_url}/api/tags", timeout=2).status_code == 200:
                        server_up = True
                        break
                except requests.RequestException:
                    continue
        except FileNotFoundError:
            return False, "Ollama binary not found in PATH."

    if not server_up:
        return False, f"Could not reach Ollama at {base_url}."

    # 3. Verify model exists locally; auto-pull if enabled and online
    tags_resp = requests.get(f"{base_url}/api/tags", timeout=5).json()
    installed_models = [m["name"] for m in tags_resp.get("models", [])]

    if model_name not in installed_models and f"{model_name}:latest" not in installed_models:
        if ollama_cfg.get("auto_pull", True):
            pull_resp = requests.post(
                f"{base_url}/api/pull",
                json={"name": model_name, "stream": False},
                timeout=1800,
            )
            if pull_resp.status_code != 200:
                return False, f"Failed to pull {model_name}: {pull_resp.text}"
        else:
            return False, f"Model '{model_name}' not found locally on {base_url} (auto_pull=False)."

    return True, f"Connected to {base_url} | Model: {model_name} | Ctx: {ollama_cfg['num_ctx']}"

def list_local_models(base_url: str = "http://localhost:11434") -> list[str]:
    try:
        resp = requests.get(f"{base_url.rstrip('/')}/api/tags", timeout=2).json()
        return [m["name"] for m in resp.get("models", [])]
    except Exception:
        return ["gpt-oss:20b"]