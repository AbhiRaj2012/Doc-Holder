import subprocess
from pathlib import Path

EXCLUDE = ":(exclude).aider*"

def git(cwd, *args):
    return subprocess.run(["git", *args], cwd=str(cwd), capture_output=True, text=True)

def ensure_git_repo(project_path: str) -> None:
    root = Path(project_path).resolve()
    root.mkdir(parents=True, exist_ok=True)
    top = git(root, "rev-parse", "--show-toplevel")
    if top.returncode != 0 or Path(top.stdout.strip()).resolve() != root:
        git(root, "init")
        git(root, "add", "-A", "--", ".", EXCLUDE)
        git(root, "-c", "user.name=sdlc", "-c", "user.email=sdlc@local",
            "commit", "-m", "baseline", "--allow-empty")

def working_diff(project_path: str) -> str:
    git(project_path, "add", "-N", "--", ".", EXCLUDE)
    return git(project_path, "diff", "--", ".", EXCLUDE).stdout

def stage_all(project_path: str) -> None:
    git(project_path, "add", "-A", "--", ".", EXCLUDE)