import os
import re
import json
import html as htmllib
from datetime import datetime
from pathlib import Path
from typing import Optional

os.environ.setdefault("DEEPEVAL_TELEMETRY_OPT_OUT", "YES")
try:
    from deepeval.models.base_model import DeepEvalBaseLLM
    from deepeval.metrics import GEval
    from deepeval.test_case import LLMTestCase, LLMTestCaseParams
    DEEPEVAL_AVAILABLE = True
except Exception:
    DEEPEVAL_AVAILABLE = False

VALID_TOOLS = ("aider_edit", "aider_create")

AGENTIC_METRIC_SPECS = {
    "Plan Quality": {
        "key": "plan_quality", "bad_max": 0.59, "good_min": 0.80, "threshold": 0.70,
        "bad_label": "0 - 0.59", "good_label": "0.80 - 1.0",
        "criteria": (
            "Evaluate the quality, granularity, logical ordering, and completeness of the execution plan "
            "in ACTUAL_OUTPUT against the user request and repository manifest in INPUT. "
            "Check if tasks are properly scoped (one file/logical unit per step), ordered so dependencies "
            "are created before use, and cover the full user requirement without redundant steps."
        ),
    },
    "Plan Adherence": {
        "key": "plan_adherence", "bad_max": 0.59, "good_min": 0.80, "threshold": 0.70,
        "bad_label": "0 - 0.59", "good_label": "0.80 - 1.0",
        "criteria": (
            "Evaluate how strictly the executed steps, file modifications, and diffs in ACTUAL_OUTPUT "
            "adhered to the planned steps and descriptions specified in INPUT. Penalize skipped tasks, "
            "unauthorized out-of-scope file modifications, or deviations from planned target files."
        ),
    },
    "Tool Correctness": {
        "key": "tool_correctness", "bad_max": 0.69, "good_min": 0.90, "threshold": 0.70,
        "bad_label": "0 - 0.69", "good_label": "0.90 - 1.0",
        "criteria": (
            "Evaluate whether the correct editing action/tool (aider_edit for existing files vs aider_create "
            "for new files) and static verification were selected and applied in ACTUAL_OUTPUT "
            "given the file existence state and task requirements in INPUT."
        ),
    },
    "Argument Correctness": {
        "key": "argument_correctness", "bad_max": 0.69, "good_min": 0.90, "threshold": 0.70,
        "bad_label": "0 - 0.69", "good_label": "0.90 - 1.0",
        "criteria": (
            "Evaluate the accuracy of tool arguments in ACTUAL_OUTPUT against INPUT: valid relative file paths "
            "inside the repository, correct target files for each task, and syntactically valid resulting code."
        ),
    },
    "Step Efficiency": {
        "key": "step_efficiency", "bad_max": 0.69, "good_min": 0.85, "threshold": 0.70,
        "bad_label": "0 - 0.69", "good_label": "0.85 - 1.0",
        "criteria": (
            "Evaluate the execution efficiency in ACTUAL_OUTPUT based on total iterations, retry attempts, "
            "and failed edits relative to total tasks in INPUT. First-try passes with minimal diff overhead "
            "and zero redundant retries should score highest (0.85 - 1.0)."
        ),
    },
    "Task Completion": {
        "key": "task_completion", "bad_max": 0.69, "good_min": 0.90, "threshold": 0.70,
        "bad_label": "0 - 0.69", "good_label": "0.90 - 1.0",
        "criteria": (
            "Evaluate whether the final code changes and task outcomes in ACTUAL_OUTPUT completely, "
            "accurately, and functionally fulfill the original user request in INPUT, with all tasks passing "
            "review and no remaining syntax errors, TODOs, or broken references."
        ),
    },
}

if DEEPEVAL_AVAILABLE:
    class OllamaEvalModel(DeepEvalBaseLLM):
        def __init__(self, chat_model, name):
            self._chat = chat_model
            self._name = name

        def load_model(self):
            return self._chat

        def generate(self, prompt: str) -> str:
            text = self._chat.invoke(prompt).content
            return re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL).strip()

        async def a_generate(self, prompt: str) -> str:
            return self.generate(prompt)

        def get_model_name(self) -> str:
            return self._name


def static_check(root: str, files: list) -> str:
    for f in files:
        p = Path(root) / f
        if p.suffix == ".py" and p.exists():
            try:
                compile(p.read_text(encoding="utf-8"), str(p), "exec")
            except (SyntaxError, ValueError, UnicodeDecodeError) as e:
                return f"{f}: {e}"
    return "ok"


def task_result(task: dict, trace: list, status: str, diff: str, root: str) -> dict:
    steps = [t for t in trace if t.get("task_id") == task["task_id"]]
    last = steps[-1] if steps else {}
    return {
        "id": task["task_id"],
        "title": task.get("title", ""),
        "file": task["target_files"][0],
        "files": task["target_files"],
        "action": last.get("action", "edit"),
        "tool": last.get("tool"),
        "arguments": last.get("arguments"),
        "status": status,
        "attempts": len(steps),
        "static_check": static_check(root, task["target_files"]),
        "diff": diff,
    }


def classify_metric_score(metric_name: str, score: Optional[float]) -> dict:
    spec = AGENTIC_METRIC_SPECS[metric_name]
    base = {"threshold": spec["threshold"], "bad_range": spec["bad_label"], "good_range": spec["good_label"]}
    if score is None:
        return {"score": None, "passed": False, "band": "N/A", **base}
    s = round(float(score), 2)
    band = "Bad" if s <= spec["bad_max"] else "Good" if s >= spec["good_min"] else "Moderate"
    return {"score": s, "passed": s >= spec["threshold"], "band": band, **base}


def compute_fallbacks(planned: list, results: list, trace: list, iterations: int) -> dict:
    total = max(len(planned), 1)
    valid = sum(
        1 for t in planned
        if t.get("file") and t.get("action") in ("edit", "create") and len(t.get("description", "")) >= 10
    )
    pq = round(min(1.0, valid / total), 2)

    pmap = {t["id"]: t for t in planned}
    adhered = sum(
        1 for r in results
        if r["id"] in pmap and r["file"] == pmap[r["id"]]["file"] and r["status"] == "passed"
    )
    pa = round(adhered / total, 2)

    et = [t for t in trace if str(t.get("step", "")).startswith("editor_")]
    if et:
        tc = round(sum(1 for t in et if t.get("tool") in VALID_TOOLS and t.get("status") == "applied") / len(et), 2)
        ac = round(sum(
            1 for t in et
            if t.get("status") == "applied" and isinstance(t.get("arguments"), dict) and t["arguments"].get("file")
        ) / len(et), 2)
    else:
        tc = ac = 0.0

    attempts = sum(max(r.get("attempts", 1), 1) for r in results) or max(iterations, 1)
    se = round(max(0.0, min(1.0, total / max(attempts, total))), 2)
    passed = sum(1 for r in results if r.get("status") == "passed")
    tcomp = round(passed / total, 2)
    return {
        "Plan Quality": (pq, "Deterministic fallback: ratio of well-formed, scoped tasks in plan."),
        "Plan Adherence": (pa, "Deterministic fallback: ratio of planned tasks executed on target files and passed."),
        "Tool Correctness": (tc, "Deterministic fallback: ratio of editor calls using a valid tool and applying changes."),
        "Argument Correctness": (ac, "Deterministic fallback: ratio of applied tool calls with valid file arguments."),
        "Step Efficiency": (se, f"Deterministic fallback: {total} planned task(s) in {attempts} attempt(s)."),
        "Task Completion": (tcomp, f"Deterministic fallback: {passed}/{total} tasks passed review."),
    }


def _file_metrics(llm) -> list:
    judge = OllamaEvalModel(llm, llm.model)
    return [
        GEval(
            name="Correctness",
            criteria=(
                "The ACTUAL_OUTPUT is a source file after an automated edit. Using the user request, manifest and plan "
                "given in INPUT as ground truth: do all referenced identifiers, imports and function calls exist "
                "and match the project conventions? Does each changed function's logic plausibly fulfil the "
                "request? Flag any obvious runtime or syntax bug."
            ),
            evaluation_params=[LLMTestCaseParams.INPUT, LLMTestCaseParams.ACTUAL_OUTPUT],
            model=judge, threshold=0.70,
        ),
        GEval(
            name="Completeness",
            criteria=(
                "Using the user request and plan given in INPUT as the spec, does ACTUAL_OUTPUT implement "
                "every requested change for this file with real logic, not a TODO or empty stub?"
            ),
            evaluation_params=[LLMTestCaseParams.INPUT, LLMTestCaseParams.ACTUAL_OUTPUT],
            model=judge, threshold=0.70,
        ),
    ]


def _agentic_metrics(llm) -> dict:
    judge = OllamaEvalModel(llm, llm.model)
    return {
        name: GEval(
            name=name, criteria=spec["criteria"],
            evaluation_params=[LLMTestCaseParams.INPUT, LLMTestCaseParams.ACTUAL_OUTPUT],
            model=judge, threshold=spec["threshold"],
        )
        for name, spec in AGENTIC_METRIC_SPECS.items()
    }


def evaluate_agentic(llm, state: dict, planned: list, results: list, trace: list) -> dict:
    iterations = sum(1 for t in trace if str(t.get("step", "")).startswith("editor_"))
    fallbacks = compute_fallbacks(planned, results, trace, iterations)
    files = (state.get("manifest_data") or {}).get("file_list", [])
    input_payload = json.dumps({
        "user_request": state.get("user_input", ""),
        "project_requirements": state.get("project_requirements", ""),
        "manifest_summary": {"file_count": len(files), "files": files[:60]},
        "planned_tasks": planned,
    }, indent=2)[:5000]
    actual_payload = json.dumps({
        "total_iterations": iterations,
        "task_results": [
            {
                "id": r["id"], "file": r["file"], "action": r["action"], "tool": r.get("tool"),
                "arguments": r.get("arguments"), "status": r["status"], "attempts": r["attempts"],
                "static_check": r.get("static_check"), "diff_excerpt": r.get("diff", "")[:600],
            }
            for r in results
        ],
        "tool_trace": trace[:25],
    }, indent=2)[:6000]

    out = {}
    metrics = _agentic_metrics(llm) if DEEPEVAL_AVAILABLE else {}
    case = LLMTestCase(input=input_payload, actual_output=actual_payload) if DEEPEVAL_AVAILABLE else None
    for name in AGENTIC_METRIC_SPECS:
        score, reason = fallbacks[name]
        if name in metrics:
            try:
                metrics[name].measure(case)
                if metrics[name].score is not None:
                    score = round(metrics[name].score, 2)
                    reason = metrics[name].reason or reason
            except Exception as e:
                reason = f"{reason} (DeepEval fallback due to: {e})"
        meta = classify_metric_score(name, score)
        meta["reason"] = reason
        out[name] = meta
    return out


def deepeval_score_file(code: str, context: str, metrics: list):
    if not DEEPEVAL_AVAILABLE or not code.strip():
        return None
    case = LLMTestCase(input=context, actual_output=code)
    res = {}
    for m in metrics:
        try:
            m.measure(case)
            res[m.name] = {"score": round(m.score, 2) if m.score is not None else None, "reason": m.reason}
        except Exception as e:
            res[m.name] = {"score": None, "reason": f"DeepEval metric failed: {e}"}
    return res


def compute_custom_score(attempts: int) -> float:
    return round(max(0.25, 1.0 - 0.25 * (max(attempts, 1) - 1)), 2)


def load_history(path: Path) -> list:
    if not path.exists():
        return []
    out = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return out


def append_history(path: Path, record: dict) -> list:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")
    return load_history(path)


def render_markdown(overall: dict, agentic: dict, report: dict) -> str:
    L = ["# Evaluation Report", "", f"**Custom score avg:** {overall['custom_score_avg']} / 1.0"]
    if overall.get("deepeval_avg_score") is not None:
        L.append(f"**DeepEval score avg:** {overall['deepeval_avg_score']} / 1.0")
    if overall.get("agentic_deepeval_avg") is not None:
        L.append(f"**Agentic DeepEval avg:** {overall['agentic_deepeval_avg']} / 1.0")
    L += [
        f"**Tasks passed:** {overall['tasks_passed']}",
        f"**Active time:** {overall['total_time_sec']} s",
        f"**Total tasks:** {overall['total_tasks']}",
        f"**Time per task:** {overall['time_per_task_sec']} s/task",
        "", "## Agentic Workflow Evaluation Matrix (DeepEval)", "",
        "| Metric | Score | Threshold | Bad Range | Good Range | Status | Band | Reason |",
        "| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :--- |",
    ]
    for name, d in agentic.items():
        sc = d["score"] if d["score"] is not None else "n/a"
        reason = str(d.get("reason", "")).replace("\n", " ").replace("|", "/")[:160]
        L.append(
            f"| **{name}** | {sc} | {d['threshold']:.2f} | {d['bad_range']} | {d['good_range']} | "
            f"{'PASS' if d['passed'] else 'FAIL'} | {d['band']} | {reason} |"
        )
    L.append("")
    for fn, d in report.items():
        L.append(f"## {fn}")
        L.append(f"- Tasks: {d['tasks']} | Attempts: {d['attempts']} | Custom score: {d['custom_score']}")
        for name, res in (d.get("deepeval") or {}).items():
            L.append(f"  - **{name}**: {res['score'] if res['score'] is not None else 'n/a'} — {res['reason']}")
        L.append("")
    return "\n".join(L)


def render_svg(records: list) -> str:
    W, H, PAD = 920, 300, 48
    n = len(records)
    if n == 0:
        return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="120">'
                f'<text x="20" y="60" font-family="sans-serif" font-size="13">No runs tracked yet.</text></svg>')

    def xf(i):
        return PAD + (i / max(n - 1, 1)) * (W - 2 * PAD)

    def yf(s):
        return H - PAD - s * (H - 2 * PAD)

    series = [
        ("deepeval_avg_score", "DeepEval Avg", "#2563eb"),
        ("custom_score_avg", "Custom Avg", "#16a34a"),
        ("plan_quality", "Plan Quality", "#9333ea"),
        ("plan_adherence", "Plan Adherence", "#db2777"),
        ("tool_correctness", "Tool Correctness", "#ea580c"),
        ("argument_correctness", "Arg Correctness", "#0891b2"),
        ("step_efficiency", "Step Efficiency", "#4f46e5"),
        ("task_completion", "Task Completion", "#059669"),
    ]
    lines, legend = [], []
    for idx, (key, label, color) in enumerate(series):
        pts = [(i, r.get(key)) for i, r in enumerate(records) if r.get(key) is not None]
        avg = ""
        if pts:
            poly = " ".join(f"{xf(i):.1f},{yf(s):.1f}" for i, s in pts)
            dots = "".join(
                f'<circle cx="{xf(i):.1f}" cy="{yf(s):.1f}" r="3" fill="{color}"><title>Run {i + 1} {label}: {s:.2f}</title></circle>'
                for i, s in pts
            )
            lines.append(f'<polyline points="{poly}" fill="none" stroke="{color}" stroke-width="2"/>{dots}')
            avg = f" ({sum(s for _, s in pts) / len(pts):.2f})"
        lx, ly = PAD + (idx % 4) * 210, 14 + (idx // 4) * 16
        legend.append(
            f'<circle cx="{lx}" cy="{ly}" r="4" fill="{color}"/>'
            f'<text x="{lx + 8}" y="{ly + 4}" font-size="10.5" fill="#374151">{label}{avg}</text>'
        )
    grid = "".join(
        f'<line x1="{PAD}" y1="{yf(g):.1f}" x2="{W - PAD}" y2="{yf(g):.1f}" stroke="#e5e7eb"/>'
        f'<text x="6" y="{yf(g) + 4:.1f}" font-size="10" fill="#6b7280">{g:.2f}</text>'
        for g in (0.0, 0.25, 0.5, 0.70, 0.85, 1.0)
    )
    ty = yf(0.70)
    thr = (f'<line x1="{PAD}" y1="{ty:.1f}" x2="{W - PAD}" y2="{ty:.1f}" stroke="#dc2626" stroke-dasharray="4,4"/>'
           f'<text x="{W - PAD - 85}" y="{ty - 4:.1f}" font-size="10" fill="#dc2626">Threshold 0.70</text>')
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" font-family="sans-serif">'
            f'<rect width="{W}" height="{H}" fill="white"/>{grid}{thr}{"".join(lines)}{"".join(legend)}'
            f'<text x="{PAD}" y="{H - 10}" font-size="11" fill="#374151">Run 1</text>'
            f'<text x="{W - PAD - 40}" y="{H - 10}" font-size="11" fill="#374151">Run {n}</text></svg>')


def _cell(name: str, val) -> str:
    if val is None:
        return "<td>n/a</td>"
    info = classify_metric_score(name, val)
    if info["band"] == "Good":
        bg, fg = "#dcfce7", "#166534"
    elif info["passed"]:
        bg, fg = "#fef9c3", "#854d0e"
    else:
        bg, fg = "#fee2e2", "#991b1b"
    return (f'<td style="background:{bg};color:{fg};font-weight:600;" '
            f'title="{name}: {info["band"]} (Threshold {info["threshold"]:.2f}, Good {info["good_range"]}, Bad {info["bad_range"]})">'
            f'{val:.2f} <span style="font-size:10px;font-weight:400;">({info["band"]})</span></td>')


def render_html(records: list) -> str:
    esc = htmllib.escape

    def avg(key):
        v = [r[key] for r in records if r.get(key) is not None]
        return round(sum(v) / len(v), 2) if v else "n/a"

    spec_rows = "".join(
        f"<tr><td><b>{n}</b></td><td style='color:#991b1b;background:#fef2f2;'>{s['bad_label']}</td>"
        f"<td style='color:#166534;background:#f0fdf4;'>{s['good_label']}</td>"
        f"<td><b>{s['threshold']:.2f}</b></td><td><b>{avg(s['key'])}</b></td></tr>"
        for n, s in AGENTIC_METRIC_SPECS.items()
    )
    rows = []
    for i, r in enumerate(records):
        c = r.get("llm_config", {})
        rows.append(
            f"<tr><td>{i + 1}</td><td>{esc(str(r.get('timestamp', '')))}</td>"
            f"<td>{esc(str(c.get('model', '')))}</td><td>{c.get('num_ctx', '')}</td>"
            f"<td>{esc(str(r.get('request', ''))[:55])}</td>"
            f"<td>{r.get('tasks_passed', '')}</td><td>{r.get('total_tasks', 'n/a')}</td>"
            f"<td>{r.get('total_time_sec', 'n/a')}</td><td>{r.get('time_per_task_sec', 'n/a')}</td>"
            f"<td>{r.get('custom_score_avg', 'n/a')}</td><td>{r.get('deepeval_avg_score', 'n/a')}</td>"
            + "".join(_cell(n, r.get(s["key"])) for n, s in AGENTIC_METRIC_SPECS.items())
            + "</tr>"
        )
    last_tasks = ""
    if records and records[-1].get("task_summary"):
        tr = "".join(
            f"<tr><td>{esc(str(t['id']))}</td><td>{esc(str(t['file']))}</td><td>{esc(str(t['status']))}</td>"
            f"<td>{t['attempts']}</td><td>{esc(str(t.get('static_check', '')))[:80]}</td></tr>"
            for t in records[-1]["task_summary"]
        )
        last_tasks = (f"<h3>Latest Run — Task Breakdown</h3><table class='matrix-table'>"
                      f"<tr><th>Task</th><th>File</th><th>Status</th><th>Attempts</th><th>Static check</th></tr>{tr}</table>")
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>SDLC Pipeline — Benchmark History</title>
<style>
body {{ font-family: system-ui, sans-serif; margin: 2rem; color: #111827; max-width: 1450px; }}
table {{ border-collapse: collapse; margin-top: 1rem; width: 100%; }}
th, td {{ border: 1px solid #e5e7eb; padding: 6px 8px; text-align: left; font-size: 12.5px; }}
th {{ background: #f9fafb; }}
.matrix-table {{ width: auto; min-width: 640px; margin-bottom: 1.5rem; }}
.summary-bar {{ background: #f8fafc; border: 1px solid #e2e8f0; padding: 10px 14px; border-radius: 6px; font-size: 13px; line-height: 1.6; }}
</style></head>
<body>
<h1>Benchmark History &amp; DeepEval Agentic Matrix</h1>
<div class="summary-bar">
<b>{len(records)}</b> run(s) tracked — All-time avg custom: <b>{avg('custom_score_avg')}</b> &nbsp;|&nbsp;
DeepEval: <b>{avg('deepeval_avg_score')}</b> &nbsp;|&nbsp; Time/task: <b>{avg('time_per_task_sec')} s</b><br>
Plan Quality: <b>{avg('plan_quality')}</b> &nbsp;|&nbsp; Plan Adherence: <b>{avg('plan_adherence')}</b> &nbsp;|&nbsp;
Tool Correctness: <b>{avg('tool_correctness')}</b> &nbsp;|&nbsp; Argument Correctness: <b>{avg('argument_correctness')}</b> &nbsp;|&nbsp;
Step Efficiency: <b>{avg('step_efficiency')}</b> &nbsp;|&nbsp; Task Completion: <b>{avg('task_completion')}</b>
</div>
<h3>DeepEval Agentic Evaluation Reference Matrix</h3>
<table class="matrix-table">
<tr><th>Metric</th><th>Bad Range</th><th>Good Range</th><th>Threshold</th><th>All-Time Avg</th></tr>
{spec_rows}
</table>
{render_svg(records)}
{last_tasks}
<table>
<tr><th>#</th><th>Timestamp</th><th>Model</th><th>num_ctx</th><th>Request</th>
<th>Tasks passed</th><th>Total tasks</th><th>Active time (s)</th><th>Time/task (s)</th>
<th>Custom avg</th><th>DeepEval avg</th>
<th>Plan Quality</th><th>Plan Adherence</th><th>Tool Correctness</th>
<th>Argument Correctness</th><th>Step Efficiency</th><th>Task Completion</th></tr>
{"".join(rows)}
</table>
</body></html>"""


def run_evaluation(cfg: dict, llm, state: dict) -> dict:
    ev = cfg.get("evaluation", {})
    planned = state.get("planned_tasks", [])
    results = state.get("task_results", [])
    trace = state.get("tool_trace", [])
    root = Path(cfg["workflow"]["project_path"]).resolve()
    max_chars = int(ev.get("file_max_chars", 6000))
    total_tasks = len(planned)
    passed_n = sum(1 for r in results if r["status"] == "passed")
    total_time = round(float(state.get("active_sec", 0.0)), 2)

    context = (
        f"USER REQUEST:\n{state.get('user_input', '')}\n\n"
        f"PROJECT REQUIREMENTS:\n{state.get('project_requirements', '')}\n\n"
        f"PLAN:\n{json.dumps(planned, indent=2)[:3000]}"
    )
    file_metrics = _file_metrics(llm) if DEEPEVAL_AVAILABLE else []

    by_file: dict = {}
    for r in results:
        if r["status"] == "passed":
            by_file.setdefault(r["file"], []).append(r)

    report = {}
    for fn, rs in by_file.items():
        try:
            code = (root / fn).read_text(encoding="utf-8")[:max_chars]
        except (OSError, UnicodeDecodeError):
            code = ""
        scores = [compute_custom_score(r["attempts"]) for r in rs]
        report[fn] = {
            "tasks": len(rs),
            "attempts": sum(r["attempts"] for r in rs),
            "custom_score": round(sum(scores) / len(scores), 2),
            "deepeval": deepeval_score_file(code, context, file_metrics),
        }

    agentic = evaluate_agentic(llm, state, planned, results, trace)
    a_vals = [m["score"] for m in agentic.values() if m.get("score") is not None]
    a_avg = round(sum(a_vals) / len(a_vals), 2) if a_vals else None
    custom = [f["custom_score"] for f in report.values()]

    overall = {
        "tasks_passed": f"{passed_n}/{total_tasks}",
        "deepeval_available": DEEPEVAL_AVAILABLE,
        "custom_score_avg": round(sum(custom) / len(custom), 2) if custom else 0.0,
        "total_tasks": total_tasks,
        "total_time_sec": total_time,
        "time_per_task_sec": round(total_time / total_tasks, 2) if total_tasks else 0.0,
        "agentic_deepeval_avg": a_avg,
    }
    for name, spec in AGENTIC_METRIC_SPECS.items():
        overall[spec["key"]] = agentic[name]["score"]
    f_vals = [
        m["score"] for f in report.values() if f.get("deepeval")
        for m in f["deepeval"].values() if m and m.get("score") is not None
    ]
    combined = f_vals + a_vals
    overall["deepeval_avg_score"] = round(sum(combined) / len(combined), 2) if combined else None

    stamp = datetime.now()
    run_dir = Path(ev.get("runs_dir", "./workspace_state/runs")) / stamp.strftime("%Y%m%d_%H%M%S")
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "evaluation.json").write_text(json.dumps({
        "overall": overall, "agentic_metrics": agentic, "files": report,
        "tasks": results, "tool_trace": trace,
    }, indent=2), encoding="utf-8")
    (run_dir / "evaluation.md").write_text(render_markdown(overall, agentic, report), encoding="utf-8")

    record = {
        "timestamp": stamp.isoformat(timespec="seconds"),
        "run_dir": str(run_dir),
        "request": state.get("user_input", "")[:200],
        "llm_config": {
            "model": cfg["ollama"]["model"],
            "num_ctx": cfg["ollama"]["num_ctx"],
            "temperature": cfg["ollama"]["temperature"],
            "reasoning_effort": cfg["ollama"].get("reasoning_effort"),
        },
        "tasks_passed": overall["tasks_passed"],
        "total_tasks": total_tasks,
        "total_time_sec": total_time,
        "time_per_task_sec": overall["time_per_task_sec"],
        "custom_score_avg": overall["custom_score_avg"],
        "deepeval_available": DEEPEVAL_AVAILABLE,
        "deepeval_avg_score": overall["deepeval_avg_score"],
        "agentic_deepeval_avg": a_avg,
        **{spec["key"]: overall[spec["key"]] for spec in AGENTIC_METRIC_SPECS.values()},
        "agentic_metrics": agentic,
        "task_summary": [
            {"id": r["id"], "file": r["file"], "status": r["status"],
             "attempts": r["attempts"], "static_check": r.get("static_check")}
            for r in results
        ],
        "per_file": {fn: {"tasks": d["tasks"], "attempts": d["attempts"]} for fn, d in report.items()},
    }
    history = append_history(Path(ev.get("history_path", "./workspace_state/benchmark_history.jsonl")), record)
    page = render_html(history)
    html_path = Path(ev.get("html_path", "./workspace_state/benchmark_history.html"))
    html_path.parent.mkdir(parents=True, exist_ok=True)
    html_path.write_text(page, encoding="utf-8")
    (run_dir / "evaluation.html").write_text(page, encoding="utf-8")

    return {
        "overall": overall,
        "agentic_metrics": agentic,
        "run_dir": str(run_dir),
        "runs_tracked": len(history),
    }