import yaml
from pathlib import Path

CONFIG_PATH = Path("config.yaml")

def load_config() -> dict:
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    sync_aider_model_settings(cfg)
    return cfg

def save_config(cfg: dict) -> None:
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        yaml.safe_dump(cfg, f, sort_keys=False)
    sync_aider_model_settings(cfg)

def sync_aider_model_settings(cfg: dict) -> str:
    """Writes Aider's model settings file so Aider passes num_ctx to localhost:11434."""
    settings_path = Path(cfg["workflow"]["aider_settings_path"])
    settings_path.parent.mkdir(parents=True, exist_ok=True)
    
    model_id = f"ollama_chat/{cfg['ollama']['model']}"
    aider_settings = [
        {
            "name": model_id,
            "edit_format": cfg["aider"].get("edit_format", "diff"),
            "use_repo_map": True,
            "extra_params": {
                "num_ctx": int(cfg["ollama"]["num_ctx"]),
                "temperature": float(cfg["ollama"]["temperature"]),
            },
        }
    ]
    with open(settings_path, "w", encoding="utf-8") as f:
        yaml.safe_dump(aider_settings, f, sort_keys=False)
    return str(settings_path.resolve())