@echo off 
echo Installing deepeval from local files... 
pip install --no-index --find-links=. deepeval 
echo. 
echo Installation complete! You can now run agentic_sdlc_deepEval_2_2.py 
pause 
