// DOM References
const btnAdd = document.getElementById('btn-add');
const inputValue = document.getElementById('input-value');
const displayTotal = document.getElementById('display-total');

// Functions
function updateColor(elementId, hexValue) {
    const element = document.getElementById(elementId);

    if (element) {
        element.style.backgroundColor = hexValue;
    } else {
        console.error(`Error: Element with ID "${elementId}" not found.`);
    }
}
function generateRandomHex() {
    /**
     * Generates a random hexadecimal color code (#RRGGBB).
     * @returns {string} The generated hex color code.
     */
    
    // Helper function to generate a random hex component (00 to FF)
    const randomHexComponent = () => {
        // Generate a random integer between 0 and 255
        const randomInt = Math.floor(Math.random() * 256);
        // Convert to hexadecimal string and pad with a leading zero if necessary
        return randomInt.toString(16).padStart(2, '0');
    };

    const r = randomHexComponent();
    const g = randomHexComponent();
    const b = randomHexComponent();

    return `#${r}${g}${b}`;
}