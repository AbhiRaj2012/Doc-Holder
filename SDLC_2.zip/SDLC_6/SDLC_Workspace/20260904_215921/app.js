```javascript
/**
 * Stores a new invoice object into the local storage for persistence.
 * @param {object} invoiceData - The invoice object to be saved.
 */
function saveInvoice(invoiceData) {
    const invoices = loadInvoices();
    invoices.push(invoiceData);
    localStorage.setItem('invoices', JSON.stringify(invoices));
}

/**
 * Retrieves all stored invoice objects from local storage and returns them as an array.
 * @returns {Array<object>} An array of all stored invoice objects.
 */
function loadInvoices() {
    const data = localStorage.getItem('invoices');
    return data ? JSON.parse(data) : [];
}

/**
 * Initializes a new invoice structure with client details and line items.
 * @param {string} clientName - The name of the client.
 * @param {string} invoiceNumber - The unique invoice number.
 * @param {string} date - The date of the invoice.
 * @param {Array<object>} lineItems - The initial array of line items.
 */
function createInvoice(clientName, invoiceNumber, date, lineItems) {
    const newInvoice = {
        id: Date.now().toString(), // Simple unique ID generation
        invoiceNumber: invoiceNumber,
        clientName: clientName,
        date: date,
        lineItems: lineItems,
        totals: { subtotal: 0, tax: 0, total: 0 }
    };

    saveInvoice(newInvoice);
}

/**
 * Adds a new line item to a specific invoice.
 * @param {string} invoiceId - The ID of the invoice to update.
 * @param {string} description - The description of the line item.
 * @param {number} quantity - The quantity of the item.
 * @param {number} unitPrice - The unit price of the item.
 */
function addLineItem(invoiceId, description, quantity, unitPrice) {
    const invoices = loadInvoices();
    const invoiceIndex = invoices.findIndex(inv => inv.id === invoiceId);

    if (invoiceIndex === -1) {
        console.error("Invoice not found.");
        return;
    }

    const lineItem = {
        description: description,
        quantity: parseFloat(quantity),
        unitPrice: parseFloat(unitPrice),
        subtotal: parseFloat(quantity) * parseFloat(unitPrice)
    };

    invoices[invoiceIndex].lineItems.push(lineItem);
    saveInvoice(invoices[invoiceIndex]);
}

/**
 * Modifies the details of an existing line item within an invoice.
 * @param {string} invoiceId - The ID of the invoice.
 * @param {number} lineIndex - The index of the line item to modify.
 * @param {string} description - The new description.
 * @param {number} quantity - The new quantity.
 * @param {number} unitPrice - The new unit price.
 */
function updateLineItem(invoiceId, lineIndex, description, quantity, unitPrice) {
    const invoices = loadInvoices();
    const invoiceIndex = invoices.findIndex(inv => inv.id === invoiceId);

    if (invoiceIndex === -1) {
        console.error("Invoice not found.");
        return;
    }

    if (lineIndex >= 0 && lineIndex < invoices[invoiceIndex].lineItems.length) {
        const updatedItem = {
            description: description,
            quantity: parseFloat(quantity),
            unitPrice: parseFloat(unitPrice),
            subtotal: parseFloat(quantity) * parseFloat(unitPrice)
        };
        invoices[invoiceIndex].lineItems[lineIndex] = updatedItem;
        saveInvoice(invoices[invoiceIndex]);
    } else {
        console.error("Invalid line item index.");
    }
}

/**
 * Removes a specific line item from an invoice.
 * @param {string} invoiceId - The ID of the invoice.
 * @param {number} lineIndex - The index of the line item to remove.
 */
function removeLineItem(invoiceId, lineIndex) {
    const invoices = loadInvoices();
    const invoiceIndex = invoices.findIndex(inv => inv.id === invoiceId);

    if (invoiceIndex === -1) {
        console.error("Invoice not found.");
        return;
    }

    if (lineIndex >= 0 && lineIndex < invoices[invoiceIndex].lineItems.length) {
        invoices[invoiceIndex].lineItems.splice(lineIndex, 1);
        saveInvoice(invoices[invoiceIndex]);
    } else {
        console.error("Invalid line item index for removal.");
    }
}

/**
 * Calculates the subtotal, tax, and final total amount for a given invoice based on its line items.
 * @param {string} invoiceId - The ID of the invoice to calculate totals for.
 * @returns {object} An object containing the calculated totals.
 */
function calculateTotals(invoiceId) {
    const invoices = loadInvoices();
    const invoice = invoices.find(inv => inv.id === invoiceId);

    if (!invoice) {
        return { subtotal: 0, tax: 0, total: 0 };
    }

    let subtotal = 0;
    invoice.lineItems.forEach(item => {
        subtotal += item.subtotal;
    });

    // Use a configuration or passed argument for tax rate in a real app.
    // Keeping the 10% rate for demonstration as per original context.
    const TAX_RATE = 0.10;
    const tax = subtotal * TAX_RATE;
    const total = subtotal + tax;

    return { subtotal: subtotal, tax: tax, total: total };
}

/**
 * Retrieves a single invoice by its ID.
 * @param {string} invoiceId - The ID of the invoice to