// DOM references (deterministically generated from the manifest's `ids`)
const inputInvoiceDate = document.getElementById('input-invoice-date');
const inputCustomerName = document.getElementById('input-customer-name');
const inputTaxRate = document.getElementById('input-tax-rate');
const btnAddItem = document.getElementById('btn-add-item');
const invoiceItemsContainer = document.getElementById('invoice-items-container');
const btnFinalizeInvoice = document.getElementById('btn-finalize-invoice');
const btnPrintInvoice = document.getElementById('btn-print-invoice');

// Function implementations (filled in below)
function addItem(itemName, quantity, rate) {
    // 1. Calculate the line total
    const lineTotal = calculateLineTotal(quantity, rate);

    // 2. Create the new item object
    const newItem = {
        name: itemName,
        quantity: quantity,
        rate: rate,
        total: lineTotal
    };

    // 3. Add the item to the invoice data structure (assuming invoiceData is the array)
    if (typeof invoiceData === 'undefined') {
        // Initialize data structure if it doesn't exist
        invoiceData = [];
    }
    invoiceData.push(newItem);

    // 4. Re-render the invoice items to update the DOM
    renderInvoiceItems();
}
function removeItem(index) {
    // Ensure the data structure exists
    if (typeof invoiceData === 'undefined' || !Array.isArray(invoiceData)) {
        console.error("Invoice data structure is not initialized.");
        return;
    }

    // 1. Validate the index
    if (index >= 0 && index < invoiceData.length) {
        // 2. Remove the item from the data structure
        invoiceData.splice(index, 1);

        // 3. Re-render the invoice items to update the DOM
        renderInvoiceItems();
    } else {
        console.error(`Invalid index provided: ${index}`);
    }
}
function calculateLineTotal(quantity, rate) {
    // Calculate the subtotal: Quantity multiplied by Rate
    if (typeof quantity !== 'number' || typeof rate !== 'number') {
        console.error("Quantity and Rate must be numbers.");
        return 0;
    }
    return quantity * rate;
}
function calculateGrandTotal(lineItems) {
    let grandTotal = 0;

    if (Array.isArray(lineItems)) {
        for (const item of lineItems) {
            // Assuming each line item object has a 'subtotal' property
            if (typeof item.subtotal === 'number') {
                grandTotal += item.subtotal;
            }
        }
    }

    return grandTotal;
}
function calculateTax(grandTotal, taxRate) {
    if (typeof grandTotal !== 'number' || typeof taxRate !== 'number') {
        return 0;
    }
    // Calculate tax amount: Grand Total * Tax Rate
    return grandTotal * taxRate;
}
function calculateFinalTotal(grandTotal, taxAmount) {
    if (typeof grandTotal !== 'number' || typeof taxAmount !== 'number') {
        return 0;
    }
    // Calculate final total: Grand Total + Tax Amount
    return grandTotal + taxAmount;
}
function generateInvoicePreview(invoiceData) {
    // Clear previous content
    const container = invoiceItemsContainer;
    if (!container) {
        console.error("invoiceItemsContainer not found.");
        return;
    }
    container.innerHTML = '';

    // --- Helper function to format currency ---
    const formatCurrency = (amount) => `$${amount.toFixed(2)}`;

    // --- Build the Invoice HTML ---
    let html = `
        <div class="invoice-preview">
            <h1>Invoice</h1>
            <div class="invoice-header">
                <p><strong>Invoice Date:</strong> ${invoiceData.date}</p>
                <p><strong>Customer:</strong> ${invoiceData.customerName}</p>
            </div>
            <table class="invoice-items">
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
    `;

    let subtotal = 0;

    invoiceData.items.forEach(item => {
        const itemTotal = item.quantity * item.price;
        subtotal += itemTotal;

        html += `
            <tr>
                <td>${item.description}</td>
                <td>${item.quantity}</td>
                <td>${formatCurrency(item.price)}</td>
                <td>${formatCurrency(itemTotal)}</td>
            </tr>
        `;
    });

    const taxAmount = subtotal * (invoiceData.taxRate / 100);
    const grandTotal = subtotal + taxAmount;

    html += `
                </tbody>
            </table>
            <div class="invoice-summary">
                <p><strong>Subtotal:</strong> ${formatCurrency(subtotal)}</p>
                <p><strong>Tax (${(invoiceData.taxRate)}%):</strong> ${formatCurrency(taxAmount)}</p>
                <h3>Grand Total: ${formatCurrency(grandTotal)}</h3>
            </div>
        </div>
    `;

    // Inject the generated HTML
    container.innerHTML = html;
}
function finalizeInvoice(invoiceData) {
    // In a real application, this is where complex final calculations,
    // validation, and data serialization would occur.

    if (!invoiceData || !invoiceData.items || invoiceData.items.length === 0) {
        console.error("Cannot finalize: Invoice data is incomplete.");
        return false;
    }

    // Simulate final calculation check (assuming generateInvoicePreview calculated totals)
    let subtotal = 0;
    invoiceData.items.forEach(item => {
        subtotal += item.quantity * item.price;
    });

    const taxAmount = subtotal * (invoiceData.taxRate / 100);
    const grandTotal = subtotal + taxAmount;

    const finalInvoiceData = {
        ...invoiceData,
        calculatedTotals: {
            subtotal: subtotal,
            tax: taxAmount,
            total: grandTotal
        },
        timestamp: new Date().toISOString()
    };

    // Simulate saving the data (e.g., to localStorage or an API call)
    try {
        localStorage.setItem('finalInvoice', JSON.stringify(finalInvoiceData));
        console.log("Invoice successfully finalized and saved to local storage.");
        return true;
    } catch (error) {
        console.error("Error saving invoice data:", error);
        return false;
    }
}
function printInvoice(invoiceData) {
    if (!invoiceData) {
        console.error("No invoice data provided to print.");
        return;
    }

    // 1. Ensure the invoice is visible and ready for printing.
    // In a real scenario, you might hide navigation elements or apply specific print CSS.
    
    // 2. Trigger the browser print dialog.
    window.print();

    // Optional: Add a small delay or focus action if needed for complex print setups.
    // Note: The actual content printed depends entirely on the CSS applied to the generated HTML.
    console.log("Print dialog triggered for the invoice.");
}
