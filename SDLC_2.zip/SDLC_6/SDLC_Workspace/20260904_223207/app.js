/**
 * Invoice Management Module Skeleton
 * Optimized for Vanilla JS implementation.
 */

// --- Global State and DOM References ---
const STORAGE_KEY = 'invoices';
let invoices = []; // Array to hold all loaded invoice objects
let currentInvoiceId = null; // Tracks the ID of the currently selected invoice

// DOM References (Assuming standard IDs exist in the HTML)
const invoiceListContainer = document.getElementById('invoice-list');
const invoiceDetailContainer = document.getElementById('invoice-details');


/**
 * Retrieves all saved invoices from Local Storage and populates the invoice listing UI.
 * @param {function} callback - Function to execute upon successful loading.
 */
function loadInvoices(callback) {
    function loadInvoices(callback) {
    try {
        const invoices = JSON.parse(localStorage.getItem('invoices')) || [];
        
        // Clear existing list
        const invoiceListElement = document.getElementById('invoice-list');
        if (invoiceListElement) {
            invoiceListElement.innerHTML = '';
        }

        if (invoices.length === 0) {
            callback([]);
            return;
        }

        // Render the list
        invoices.forEach(invoice => {
            const invoiceElement = document.createElement('div');
            invoiceElement.className = 'invoice-item';
            invoiceElement.innerHTML = `
                <h3>Invoice #${invoice.id} - ${invoice.date}</h3>
                <p>Total: $${invoice.grandTotal.toFixed(2)}</p>
                <button onclick="viewInvoiceDetails(${invoice.id})">View Details</button>
            `;
            invoiceListElement.appendChild(invoiceElement);
        });

        callback(invoices);

    } catch (error) {
        console.error("Error loading invoices from Local Storage:", error);
        callback([]);
    }
}
    try {
        const storedData = localStorage.getItem(STORAGE_KEY);
        if (storedData) {
            invoices = JSON.parse(storedData);
            // Logic to render the list of invoices to the DOM
            callback(invoices);
        } else {
            invoices = [];
            callback([]);
        }
    } catch (error) {
        console.error("Error loading invoices from Local Storage:", error);
        callback([]);
    }
}

/**
 * Saves the current invoice data (including line items and totals) into Local Storage.
 * @param {object} invoiceData - The complete invoice object to be saved.
 */
function saveInvoice(invoiceData) {
    function saveInvoice(invoiceData) {
    try {
        const invoices = JSON.parse(localStorage.getItem('invoices')) || [];
        
        // Ensure the invoice has a unique ID if it doesn't already
        if (!invoiceData.id) {
            invoiceData.id = Date.now(); // Simple unique ID generation
        }

        // Add the new invoice to the array
        invoices.push(invoiceData);

        // Save the updated array back to Local Storage
        localStorage.setItem('invoices', JSON.stringify(invoices));
        
        console.log("Invoice saved successfully.");

    } catch (error) {
        console.error("Error saving invoice to Local Storage:", error);
        throw new Error("Failed to save invoice data.");
    }
}
    try {
        // Ensure data is stored as a string
        localStorage.setItem(STORAGE_KEY, JSON.stringify(invoiceData));
    } catch (error) {
        console.error("Error saving invoice to Local Storage:", error);
    }
}

/**
 * Calculates all financial totals (line item subtotals, tax, and grand total) based on the input line items and tax rate.
 * @param {array} items - Array of line item objects.
 * @param {number} taxRate - The tax rate (e.g., 0.08 for 8%).
 * @returns {{subtotals: array, taxAmount: number, grandTotal: number}} - Calculated financial results.
 */
function generateInvoiceData(items, taxRate) {
    function generateInvoiceData(items, taxRate) {
    let subtotals = [];
    let total = 0;

    if (!Array.isArray(items) || items.length === 0) {
        return {
            subtotals: [],
            taxAmount: 0,
            grandTotal: 0
        };
    }

    // 1. Calculate subtotals
    items.forEach(item => {
        // Ensure price is treated as a number
        const price = parseFloat(item.price) || 0;
        const subtotal = price; // Assuming price is the subtotal for simplicity
        subtotals.push(subtotal);
        total += subtotal;
    });

    // 2. Calculate tax amount
    const taxAmount = total * taxRate;

    // 3. Calculate grand total
    const grandTotal = total + taxAmount;

    return {
        subtotals: subtotals,
        taxAmount: taxAmount,
        grandTotal: grandTotal
    };
}
    // Implementation will iterate through items, calculate subtotals, apply tax, and determine the grand total.
    return {
        subtotals: [],
        taxAmount: 0,
        grandTotal: 0
    };
}

/**
 * Adds a new line item or updates an existing one within the current invoice data structure.
 * @param {number} index - The index of the line item to modify.
 * @param {string} description - The description of the item.
 * @param {number} quantity - The quantity of the item.
 * @param {number} unitPrice - The unit price of the item.
 */
function addOrUpdateLineItem(index, description, quantity, unitPrice) {
    /**
     * Adds a new line item or updates an existing one in the invoice data.
     * @param {number} index - The index of the line item to modify.
     * @param {string} description - The description of the item.
     * @param {number} quantity - The quantity of the item.
     * @param {number} unitPrice - The price per unit.
     * @param {Array<Object>} invoiceData - The current array of line items.
     * @returns {Array<Object>} The updated invoice data.
     */
    function addOrUpdateLineItem(index, description, quantity, unitPrice, invoiceData) {
        if (index < 0 || index >= invoiceData.length) {
            throw new Error("Invalid index provided.");
        }

        // Update the specific line item
        invoiceData[index] = {
            description: description,
            quantity: Number(quantity),
            unitPrice: Number(unitPrice)
        };

        // In a real application, this function would likely trigger a state update
        // and potentially call calculateTotals() immediately.
        return invoiceData;
    }
    // Logic to safely modify the 'invoices' array item, update line item details, and trigger recalculation.
}

/**
 * Performs the full calculation sequence: calculates all line item subtotals, the overall subtotal, tax, and the final grand total.
 * @param {object} invoiceData - The complete invoice object.
 * @returns {{subtotal: number, tax: number, grandTotal: number}} - The calculated financial summary.
 */
function calculateTotals(invoiceData) {
    /**
     * Performs the full calculation sequence for the invoice.
     * @param {object} invoiceData - The invoice data containing the line items.
     * @returns {{subtotal: number, tax: number, grandTotal: number}} The calculated totals.
     */
    function calculateTotals(invoiceData) {
        let subtotal = 0;

        // 1. Calculate Subtotal
        for (const item of invoiceData) {
            // Ensure quantity and unitPrice are valid numbers before multiplication
            const itemSubtotal = (item.quantity || 0) * (item.unitPrice || 0);
            subtotal += itemSubtotal;
        }

        // 2. Calculate Tax (Assuming a fixed tax rate for demonstration, e.g., 10%)
        const TAX_RATE = 0.10;
        const tax = subtotal * TAX_RATE;

        // 3. Calculate Grand Total
        const grandTotal = subtotal + tax;

        return {
            subtotal: parseFloat(subtotal.toFixed(2)),
            tax: parseFloat(tax.toFixed(2)),
            grandTotal: parseFloat(grandTotal.toFixed(2))
        };
    }
    // Implementation to run generateInvoiceData and extract the results from the invoiceData structure.
    return {
        subtotal: 0,
        tax: 0,
        grandTotal: 0
    };
}

/**
 * Renders the selected invoice data into the designated HTML container, applying necessary CSS classes for professional formatting.
 * @param {object} invoice - The invoice object to render.
 */
function renderInvoice(invoice) {
    // <PLACEHOLDER id="renderInvoice"/>
    // DOM manipulation logic to populate invoiceDetailContainer with formatted HTML.
}

/**
 * Retrieves and displays the full details of a selected invoice for editing or viewing.
 * @param {string} invoiceId - The unique identifier of the invoice.
 * @returns {object} - The full invoice data.
 */
function displayInvoiceDetails(invoiceId) {
    /**
     * Retrieves and displays the full details of a selected invoice.
     * @param {string} invoiceId - The unique identifier of the invoice to display.
     * @returns {object} The invoice data, or null if not found.
     */
    function displayInvoiceDetails(invoiceId) {
        try {
            const invoicesJson = localStorage.getItem('invoices');
            if (!invoicesJson) {
                console.error("No invoice data found in Local Storage.");
                return null;
            }

            const invoices = JSON.parse(invoicesJson);
            const invoice = invoices.find(inv => inv.id === invoiceId);

            if (invoice) {
                // --- DOM Manipulation ---
                const detailsContainer = document.getElementById('invoice-details');
                if (detailsContainer) {
                    detailsContainer.innerHTML = `
                        <h2>Invoice Details (ID: ${invoice.id})</h2>
                        <div class="invoice-details">
                            <p><strong>Invoice ID:</strong> ${invoice.id}</p>
                            <p><strong>Date:</strong> ${invoice.date}</p>
                            <p><strong>Amount:</strong> $${invoice.amount.toFixed(2)}</p>
                            <p><strong>Customer:</strong> ${invoice.customerName}</p>
                            <p><strong>Items:</strong></p>
                            <ul>
                                ${invoice.items.map(item => `<li>${item.description}: $${item.price.toFixed(2)}</li>`).join('')}
                            </ul>
                        </div>
                    `;
                } else {
                    console.error("Target container #invoice-details not found.");
                }
                return invoice;
            } else {
                console.warn(`Invoice with ID ${invoiceId} not found.`);
                return null;
            }
        } catch (error) {
            console.error("Error retrieving or parsing invoice data:", error);
            return null;
        }
    }
    // Logic to find the invoice in the 'invoices' array and populate the detail view.
    return {};
}

/**
 * Removes a specific invoice record from Local Storage.
 * @param {string} invoiceId - The ID of the invoice to delete.
 */
function deleteInvoice(invoiceId) {
    /**
     * Removes a specific invoice record from Local Storage.
     * @param {string} invoiceId - The unique identifier of the invoice to delete.
     */
    function deleteInvoice(invoiceId) {
        try {
            const invoicesJson = localStorage.getItem('invoices');
            if (!invoicesJson) {
                console.warn("Cannot delete: No invoice data exists.");
                return false;
            }

            const invoices = JSON.parse(invoicesJson);

            // Filter out the invoice with the matching ID
            const updatedInvoices = invoices.filter(inv => inv.id !== invoiceId);

            if (updatedInvoices.length === invoices.length) {
                console.warn(`Deletion failed: Invoice ID ${invoiceId} not found.`);
                return false;
            }

            // Save the updated array back to Local Storage
            localStorage.setItem('invoices', JSON.stringify(updatedInvoices));
            console.log(`Invoice ID ${invoiceId} successfully deleted.`);
            return true;

        } catch (error) {
            console.error("Error during invoice deletion:", error);
            return false;
        }
    }
    // Logic to filter the 'invoices' array and update Local Storage.
}

/**
 * Triggers the browser's native print dialog, applying specific CSS rules to ensure a clean, printable view.
 * @param {string} invoiceId - The ID of the invoice to print.
 */
function printInvoice(invoiceId) {
    // <PLACEHOLDER id="printInvoice"/>
    // Logic to set print-specific CSS context and call window.print().
}

/**
 * Generates a PDF version of the invoice for download using the browser's print functionality.
 * @param {string} invoiceId - The ID of the invoice to generate a PDF for.
 */
function generatePdf(invoiceId) {
    /**
     * Generates a PDF version of the invoice for download using the browser's print functionality.
     * This method relies on applying a specific print stylesheet and triggering the print dialog.
     *
     * @param {string} invoiceId The unique identifier of the invoice to generate.
     */
    function generatePdf(invoiceId) {
        if (!invoiceId) {
            console.error("generatePdf Error: invoiceId is required.");
            alert("Error: Invoice ID is missing.");
            return;
        }

        // 1. Simulate fetching the invoice data based on the ID
        // In a real application, this would involve an AJAX call (fetch) to an API.
        const invoiceData = fetchInvoiceData(invoiceId);

        if (!invoiceData) {
            console.error(`generatePdf Error: Invoice with ID ${invoiceId} not found.`);
            alert(`Error: Invoice ID ${invoiceId} not found.`);
            return;
        }

        // 2. Prepare the content for printing (DOM manipulation)
        const printContainer = document.getElementById('invoice-printable-area');
        if (!printContainer) {
            console.error("generatePdf Error: Target element 'invoice-printable-area' not found.");
            return;
        }

        // Inject the actual invoice data into the printable area
        printContainer.innerHTML = renderInvoice(invoiceData);

        // 3. Apply the print stylesheet (This is the core optimization step)
        // We use a specific class to ensure only the printable content is visible during print.
        document.body.classList.add('printing-mode');

        // 4. Trigger the print dialog
        window.print();

        // 5. Clean up the state after the print dialog is closed (or cancelled)
        // Note: The browser handles the actual printing. We reset the class immediately.
        setTimeout(() => {
            document.body.classList.remove('printing-mode');
        }, 500); // Small delay to ensure the print dialog is fully initiated
    }

    /**
     * Mock function to simulate fetching invoice data.
     * @param {string} id
     * @returns {object|null}
     */
    function fetchInvoiceData(id) {
        // Mock data retrieval
        if (id === "INV-12345") {
            return {
                invoiceId: id,
                date: new Date().toLocaleDateString(),
                total: 150.75,
                items: [
                    { description: "Service Fee", amount: 100.00 },
                    { description: "Tax", amount: 50.75 }
                ],
                details: "This is the detailed breakdown of the invoice. Please ensure all fields are legible when printing."
            };
        }
        return null;
    }

    /**
     * Helper function to render the invoice HTML structure.
     * @param {object} data
     * @returns {string} HTML string
     */
    function renderInvoice(data) {
        let itemsHtml = data.items.map(item => `
            <tr>
                <td>${item.description}</td>
                <td class="amount">${item.amount.toFixed(2)}</td>
            </tr>
        `).join('');

        return `
            <div class="invoice-header">
                <h1>Invoice #${data.invoiceId}</h1>
                <p>Date: ${data.date}</p>
            </div>
            <div class="invoice-details">
                <p>${data.details}</p>
                <p><strong>Total Amount:</strong> $${data.total.toFixed(2)}</p>
            </div>
            <table class="invoice-items">
                <thead>
                    <tr>
                        <th>Description</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
                    ${itemsHtml}
                </tbody>
            </table>
        `;
    }
    // Logic to trigger the print flow, typically by calling printInvoice(invoiceId).
}

// --- Initialization Example (Optional, for context) ---
/*
document.addEventListener('DOMContentLoaded', () => {
    loadInvoices((invoices) => {
        if (invoices.length > 0) {
            // Select the first invoice by default
            const firstInvoiceId = invoices[0].id;
            currentInvoiceId = firstInvoiceId;
            displayInvoiceDetails(firstInvoiceId);
            renderInvoice(invoices[0]);
        }
    });
});
*/