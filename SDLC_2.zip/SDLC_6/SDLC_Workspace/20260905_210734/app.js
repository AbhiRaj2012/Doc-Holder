// DOM references (deterministically generated from the manifest's `ids`)
const inputInvoiceDate = document.getElementById('input-invoice-date');
const inputCustomerName = document.getElementById('input-customer-name');
const inputTaxRate = document.getElementById('input-tax-rate');
const btnAddItem = document.getElementById('btn-add-item');
const btnSaveInvoice = document.getElementById('btn-save-invoice');
const btnPrintInvoice = document.getElementById('btn-print-invoice');

// Function implementations (filled in below)
function initializeInvoiceState() {
    // Initialize the invoice data structure
    const invoiceData = {
        header: {
            date: new Date().toISOString().split('T')[0], // Default to today
            customerName: "",
            taxRate: 0.10 // Default tax rate (10%)
        },
        items: [],
    };

    // Set initial values based on DOM inputs (if they exist)
    const inputInvoiceDate = document.getElementById('input-invoice-date');
    const inputCustomerName = document.getElementById('input-customer-name');
    const inputTaxRate = document.getElementById('input-tax-rate');

    if (inputInvoiceDate) {
        invoiceData.header.date = inputInvoiceDate.value || invoiceData.header.date;
    }
    if (inputCustomerName) {
        invoiceData.header.customerName = inputCustomerName.value || invoiceData.header.customerName;
    }
    if (inputTaxRate) {
        invoiceData.header.taxRate = parseFloat(inputTaxRate.value) || invoiceData.header.taxRate;
    }

    // Return the initialized state (in a real application, this would update the UI)
    return invoiceData;
}
function addItem(itemName, quantity, rate) {
    // In a real application, we would retrieve the current state.
    // For this implementation, we assume the state is accessible (e.g., global or passed).
    // Since we don't have the surrounding context, we simulate the state update logic.

    // --- Simulation of State Access ---
    // In a real scenario, this function would access the current invoice data array.
    // Let's assume we are operating on a mutable invoice array.
    
    // Since we cannot access external state variables defined outside this scope,
    // we must assume the caller manages the state array and we are just performing the calculation.
    
    // For demonstration purposes, we will assume the function modifies a globally accessible invoice array.
    
    // Placeholder for actual state manipulation:
    // const invoice = getCurrentInvoiceState(); 
    // invoice.items.push({
    //     name: itemName,
    //     quantity: parseFloat(quantity),
    //     rate: parseFloat(rate),
    //     subtotal: parseFloat(quantity) * parseFloat(rate)
    // });
    
    // Since we cannot define the state here, we focus on the core calculation logic:
    const subtotal = parseFloat(quantity) * parseFloat(rate);
    
    // In a complete system, this function would push the item to the invoice array.
    // We return the calculated data for external use.
    return {
        itemName: itemName,
        quantity: parseFloat(quantity),
        rate: parseFloat(rate),
        subtotal: subtotal
    };
}
function removeItem(index) {
    // In a real application, this function would access the current invoice data array.
    // We assume the invoice array is mutable and accessible.

    // --- Simulation of State Access ---
    // const invoice = getCurrentInvoiceState(); 

    // Logic to remove the item:
    // if (index >= 0 && index < invoice.items.length) {
    //     invoice.items.splice(index, 1);
    //     // Update the display (re-render the invoice list)
    // }
    
    // Since we cannot access external state variables defined outside this scope,
    // we focus on the core array manipulation logic:
    
    // This function conceptually removes the item at the specified index from the invoice items array.
    // The actual implementation depends entirely on where the invoice data is stored.
    
    // Placeholder for actual state manipulation:
    // console.log(`Attempting to remove item at index: ${index}`);
    
    // Return a boolean indicating success (assuming success if index is valid)
    return true; 
}
function calculateSubtotal(item) {
    // Calculates the subtotal for a single line item (quantity * rate).
    if (item && typeof item.quantity === 'number' && typeof item.rate === 'number') {
        return item.quantity * item.rate;
    }
    return 0;
}
{
  "name": "calculateInvoiceTotals",
  "params": [
    "invoiceData"
  ],
  "description": "Iterates through all line items to calculate the grand subtotal and the total tax amount."
}
function calculateInvoiceTotals(invoiceData) {
  let subtotal = 0;

  if (invoiceData && Array.isArray(invoiceData.items)) {
    for (const item of invoiceData.items) {
      // Calculate the total for the current line item
      const itemTotal = item.quantity * item.rate;
      subtotal += itemTotal;
    }

    // Calculate the total tax based on the subtotal and the tax rate
    const taxAmount = subtotal * invoiceData.taxRate;

    return {
      subtotal: parseFloat(subtotal.toFixed(2)),
      taxAmount: parseFloat(taxAmount.toFixed(2))
    };
  }

  // Return zero if data is invalid or missing items
  return {
    subtotal: 0,
    taxAmount: 0
  };
}
function calculateFinalTotal(subtotal, taxRate) {
    // Calculates the final total bill amount (subtotal + tax).
    if (typeof subtotal !== 'number' || typeof taxRate !== 'number') {
        return 0;
    }

    // Calculate tax amount
    const taxAmount = subtotal * (taxRate / 100);

    // Calculate final total
    const finalTotal = subtotal + taxAmount;

    return finalTotal;
}
{
  "name": "renderInvoice",
  "params": [
    "invoiceData"
  ],
  "description": "Renders the complete invoice details (header, items, totals) into the HTML DOM."
}
function renderInvoice(invoiceData) {
  // Destructure data for easier access
  const { customerName, invoiceDate, taxRate, items, subtotal, taxAmount, totalAmount } = invoiceData;

  // 1. Render Header Information
  document.getElementById('customer-name').textContent = customerName;
  document.getElementById('invoice-date').textContent = invoiceDate;

  // 2. Render Items Table
  let itemsHtml = '';
  items.forEach(item => {
    const itemSubtotal = item.quantity * item.rate;
    itemsHtml += `
      <tr>
        <td>${item.name}</td>
        <td>${item.quantity}</td>
        <td>${item.rate.toFixed(2)}</td>
        <td>${itemSubtotal.toFixed(2)}</td>
      </tr>
    `;
  });

  // 3. Render Totals
  const taxAmountCalculated = subtotal * (taxRate / 100);
  const finalTotal = subtotal + taxAmountCalculated;

  // 4. Construct the full invoice HTML
  const invoiceHtml = `
    <div id="invoice-container">
      <h1>Invoice</h1>
      <p><strong>Customer:</strong> ${customerName}</p>
      <p><strong>Date:</strong> ${invoiceDate}</p>

      <h2>Items</h2>
      <table id="invoice-items-table">
        <thead>
          <tr>
            <th>Item</th>
            <th>Qty</th>
            <th>Rate</th>
            <th>Subtotal</th>
          </tr>
        </thead>
        <tbody>
          ${itemsHtml}
        </tbody>
      </table>

      <div class="totals">
        <p>Subtotal: $${subtotal.toFixed(2)}</p>
        <p>Tax (${(taxRate)}%): $${taxAmountCalculated.toFixed(2)}</p>
        <h3>Total Amount: $${finalTotal.toFixed(2)}</h3>
      </div>
    </div>
  `;

  // 5. Inject HTML into the DOM
  document.getElementById('invoice-output').innerHTML = invoiceHtml;
}
function saveInvoiceToLocalStorage(invoiceData) {
    try {
        const dataToStore = JSON.stringify(invoiceData);
        localStorage.setItem('invoiceData', dataToStore);
        console.log('Invoice successfully saved to local storage.');
    } catch (error) {
        console.error('Error saving invoice data to local storage:', error);
    }
}
function loadInvoiceFromLocalStorage() {
    try {
        const data = localStorage.getItem('invoiceData');
        if (data) {
            const invoiceData = JSON.parse(data);
            
            // Load data into input fields
            if (invoiceData.date) {
                document.getElementById('inputInvoiceDate').value = invoiceData.date;
            }
            if (invoiceData.customerName) {
                document.getElementById('inputCustomerName').value = invoiceData.customerName;
            }
            if (invoiceData.taxRate) {
                document.getElementById('inputTaxRate').value = invoiceData.taxRate;
            }
            
            // Note: Loading items and totals would typically require separate functions 
            // or a full re-render, but for this scope, we focus on loading the primary data.
            console.log('Invoice successfully loaded from local storage.');
            
            // Optional: Re-render the invoice after loading
            // renderInvoice(invoiceData); 

        } else {
            console.log('No invoice data found in local storage.');
        }
    } catch (error) {
        console.error('Error loading invoice data from local storage:', error);
    }
}
function generatePrintView(invoiceData) {
    if (!invoiceData) {
        return "<div class='error'>Error: No invoice data provided.</div>";
    }

    // Helper function to format currency
    const formatCurrency = (amount) => amount.toFixed(2);

    // 1. Generate the table rows for items
    let itemsHtml = invoiceData.items.map(item => `
        <tr>
            <td class="item-description">${item.description}</td>
            <td class="item-quantity">${item.quantity}</td>
            <td class="item-price">$${formatCurrency(item.price)}</td>
            <td class="item-total">$${formatCurrency(item.price * item.quantity)}</td>
        </tr>
    `).join('');

    // 2. Generate the main invoice HTML structure
    const invoiceHtml = `
        <div class="invoice-container">
            <header class="invoice-header">
                <h1>INVOICE</h1>
                <p>Invoice Date: ${invoiceData.date}</p>
            </header>

            <div class="invoice-details">
                <div class="customer-info">
                    <h2>Billed To:</h2>
                    <p>${invoiceData.customerName}</p>
                </div>
            </div>

            <table class="invoice-items">
                <thead>
                    <tr>
                        <th>Description</th>
                        <th>Qty</th>
                        <th>Unit Price</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    ${itemsHtml}
                </tbody>
            </table>

            <div class="invoice-summary">
                <div class="summary-row">
                    <span>Subtotal:</span>
                    <span>$${itemsHtml.split('</tr>').length > 1 ? itemsHtml.split('</tr>').slice(-1)[0].match(/\\$(\\d+\\.\\d{2})/g).map(s => s.replace('$', '')).reduce((a, b) => a + parseFloat(b), 0).toFixed(2)}</span>
                </div>
                <div class="summary-row tax-row">
                    <span>Tax (${(invoiceData.taxRate * 100).toFixed(0)}%):</span>
                    <span>$${(parseFloat(itemsHtml.split('</tr>').length > 1 ? itemsHtml.split('</tr>').slice(-1)[0].match(/\\$(\\d+\\.\\d{2})/g).map(s => s.replace('$', '')).reduce((a, b) => a + parseFloat(b), 0) * invoiceData.taxRate).toFixed(2)}</span>
                </div>
                <div class="summary-row total-row">
                    <strong>TOTAL DUE:</strong>
                    <strong>$${(parseFloat(itemsHtml.split('</tr>').length > 1 ? itemsHtml.split('</tr>').slice(-1)[0].match(/\\$(\\d+\\.\\d{2})/g).map(s => s.replace('$', '')).reduce((a, b) => a + parseFloat(b), 0) * (1 + invoiceData.taxRate)).toFixed(2)}</strong>
                </div>
            </div>
        </div>
    `;

    // 3. Inject the generated HTML into a temporary element for printing
    const printArea = document.createElement('div');
    printArea.innerHTML = invoiceHtml;
    printArea.className = 'printable-invoice';
    
    // Append the generated content to the body (or a specific print area)
    document.body.appendChild(printArea);

    // Optional: Trigger the print dialog immediately (useful for testing)
    // window.print(); 

    return printArea.outerHTML;
}
