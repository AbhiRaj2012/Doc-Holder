// 1. Declare globals and DOM references
const customerNameInput = document.getElementById('input-customer-name');
const invoiceDateInput = document.getElementById('input-invoice-date');
const taxRateInput = document.getElementById('input-tax-rate');
const addItemButton = document.getElementById('btn-add-item');
const saveInvoiceButton = document.getElementById('btn-save-invoice');
const printInvoiceButton = document.getElementById('btn-print-invoice');

// State management
let invoiceData = {
    customerName: '',
    invoiceDate: '',
    taxRate: 0,
    items: []
};

// Helper function to update the state from inputs (simulating input reading)
const updateState = () => {
    invoiceData.customerName = customerNameInput.value;
    invoiceData.invoiceDate = invoiceDateInput.value;
    invoiceData.taxRate = parseFloat(taxRateInput.value) || 0;
};

// Helper function to calculate totals (FR 5.1)
const calculateTotals = () => {
    const items = invoiceData.items;
    const taxRate = invoiceData.taxRate;

    let subtotal = 0;
    items.forEach(item => {
        subtotal += item.quantity * item.unitRate;
    });

    const taxAmount = subtotal * (taxRate / 100);
    const grandTotal = subtotal + taxAmount;

    invoiceData.totals = {
        subtotal: subtotal,
        taxAmount: taxAmount,
        grandTotal: grandTotal
    };
};

// Helper function to render the invoice (FR 6.1)
const renderInvoice = () => {
    // This is a placeholder for actual DOM manipulation logic
    const invoiceContainer = document.getElementById('invoice-output');
    if (!invoiceContainer) return;

    let html = `
        <h2>Invoice</h2>
        <p>Customer Name: ${invoiceData.customerName}</p>
        <p>Date: ${invoiceData.invoiceDate}</p>
        <h3>Items:</h3>
        <table>
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Qty</th>
                    <th>Rate</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
    `;

    invoiceData.items.forEach((item, index) => {
        const itemTotal = item.quantity * item.unitRate;
        html += `
            <tr>
                <td>${item.name}</td>
                <td>${item.quantity}</td>
                <td>${item.unitRate.toFixed(2)}</td>
                <td>${itemTotal.toFixed(2)}</td>
            </tr>
        `;
    });

    html += `
            </tbody>
        </table>
        <h3>Totals:</h3>
        <p>Subtotal: $${invoiceData.totals.subtotal.toFixed(2)}</p>
        <p>Tax (${invoiceData.taxRate}%): $${invoiceData.totals.taxAmount.toFixed(2)}</p>
        <p>Grand Total: $${invoiceData.totals.grandTotal.toFixed(2)}</p>
    `;

    invoiceContainer.innerHTML = html;
};

// Helper function to load data (FR 1.1)
const loadInvoice = (key) => {
    const data = localStorage.getItem(key);
    if (data) {
        try {
            const loadedData = JSON.parse(data);
            invoiceData = loadedData;
            // Update input fields
            customerNameInput.value = invoiceData.customerName || '';
            invoiceDateInput.value = invoiceData.invoiceDate || '';
            taxRateInput.value = invoiceData.taxRate || 0;
            // Render the loaded data
            renderInvoice();
        } catch (e) {
            console.error("Error parsing Local Storage data:", e);
            invoiceData = { customerName: '', invoiceDate: '', taxRate: 0, items: [] };
        }
    } else {
        // Initialize default state if no data is found
        invoiceData = { customerName: '', invoiceDate: '', taxRate: 0, items: [] };
    }
};

// Helper function to save data (FR 3.1)
const saveInvoice = () => {
    localStorage.setItem('invoiceData', JSON.stringify(invoiceData));
};

// Helper function to add an item (FR 1.2)
const addItem = (itemName, quantity, unitRate) => {
    const newItem = {
        name: itemName,
        quantity: parseInt(quantity, 10),
        unitRate: parseFloat(unitRate)
    };
    invoiceData.items.push(newItem);
    calculateTotals();
    renderInvoice();
};

// Helper function to remove an item (FR 1.2)
const removeItem = (index) => {
    if (index >= 0 && index < invoiceData.items.length) {
        invoiceData.items.splice(index, 1);
        calculateTotals();
        renderInvoice();
    }
};

// Helper function to print the invoice (FR 3.3)
const printInvoice = () => {
    // In a real scenario, this would trigger window.print() on a specific print-optimized CSS view.
    // For this setup, we simulate the action.
    window.print();
};


// 2. Setup Event Listeners

// Load initial data on page load (assuming 'invoiceData' key)
loadInvoice('invoiceData');

// Input change listeners to keep state updated
customerNameInput.addEventListener('input', updateState);
invoiceDateInput.addEventListener('input', updateState);
taxRateInput.addEventListener('input', updateState);


// Add Item Listener
addItemButton.addEventListener('click', () => {
    const name = customerNameInput.value.trim();
    const quantity = prompt("Enter quantity for the new item:");
    const unitRate = prompt("Enter unit rate for the new item
function loadInvoice(key) {
    try {
        const data = localStorage.getItem(key);
        if (data) {
            return JSON.parse(data);
        }
        // Return a default empty structure if no data is found
        return {
            items: [],
            customer: { name: 'N/A', address: 'N/A' },
            subtotal: 0,
            taxRate: 0.08, // Default tax rate
            tax: 0,
            total: 0
        };
    } catch (error) {
        console.error("Error loading invoice data:", error);
        // Return a safe default structure on failure
        return {
            items: [],
            customer: { name: 'Error', address: 'Error' },
            subtotal: 0,
            taxRate: 0.08,
            tax: 0,
            total: 0
        };
    }
}

function saveInvoice(invoiceData) {
    try {
        const key = 'invoiceData';
        const dataString = JSON.stringify(invoiceData);
        localStorage.setItem(key, dataString);
        console.log("Invoice successfully saved to Local Storage.");
    } catch (error) {
        console.error("Error saving invoice data to Local Storage:", error);
        throw new Error("Failed to save data.");
    }
}

function addItem(itemName, quantity, unitRate) {
    const key = 'invoiceData';
    let invoice = loadInvoice(key);

    // 1. Add the new item
    const itemTotal = quantity * unitRate;
    invoice.items.push({
        name: itemName,
        quantity: quantity,
        unitRate: unitRate,
        total: itemTotal
    });

    // 2. Recalculate totals
    const subtotal = invoice.items.reduce((acc, item) => acc + item.total, 0);
    invoice.subtotal = subtotal;

    // Calculate tax based on subtotal and tax rate
    invoice.tax = subtotal * invoice.taxRate;
    invoice.total = subtotal + invoice.tax;

    // 3. Save the updated invoice
    saveInvoice(invoice);

    console.log(`Item "${itemName}" added successfully. New total: $${invoice.total.toFixed(2)}`);
}

function removeItem(index) {
    // This function assumes 'items' is the array being modified.
    // In a real application, this function would likely operate on a passed array
    // or be part of a class managing the state.
    if (index >= 0 && index < items.length) {
        items.splice(index, 1);
    }
}

function calculateTotals(items, taxRate) {
    let subtotal = 0;

    // Calculate subtotal
    for (const item of items) {
        // Assuming 'price' is the base price for calculation
        subtotal += item.price;
    }

    const taxAmount = subtotal * taxRate;
    const grandTotal = subtotal + taxAmount;

    return {
        subtotal: subtotal,
        taxAmount: taxAmount,
        grandTotal: grandTotal
    };
}

function renderInvoice(invoiceData) {
    const invoiceContainer = document.getElementById('invoice-output');
    if (!invoiceContainer) {
        console.error("Invoice container element not found.");
        return;
    }

    // 1. Render Customer Info
    const customerInfoHtml = `
        <div class="invoice-header">
            <h1>Invoice #${invoiceData.invoiceId}</h1>
            <p><strong>Customer:</strong> ${invoiceData.customerName}</p>
            <p><strong>Date:</strong> ${new Date().toLocaleDateString()}</p>
        </div>
    `;

    // 2. Render Items Table
    let itemsHtml = invoiceData.items.map(item => `
        <tr>
            <td>${item.name}</td>
            <td>$${item.price.toFixed(2)}</td>
            <td>$${(item.price * 0.1).toFixed(2)}</td> <!-- Example quantity column -->
        </tr>
    `).join('');

    // 3. Calculate Totals (re-using the logic from calculateTotals)
    const totals = calculateTotals(invoiceData.items, invoiceData.taxRate);

    // 4. Render Totals Summary
    const totalsHtml = `
        <div class="invoice-totals">
            <p>Subtotal: $${totals.subtotal.toFixed(2)}</p>
            <p>Tax (${(invoiceData.taxRate * 100).toFixed(0)}%): $${totals.taxAmount.toFixed(2)}</p>
            <h2>Grand Total: $${totals.grandTotal.toFixed(2)}</h2>
        </div>
    `;

    // Combine all parts into the final HTML
    invoiceContainer.innerHTML = `
        ${customerInfoHtml}
        <table class="invoice-items">
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Price</th>
                    <th>Qty</th>
                </tr>
            </thead>
            <tbody>
                ${itemsHtml}
            </tbody>
        </table>
        ${totalsHtml}
    `;
}

function printInvoice(invoiceData) {
    // 1. Create a temporary container for the invoice content
    const invoiceContainer = document.createElement('div');
    invoiceContainer.id = 'invoice-print-area';

    // 2. Generate the HTML content using template literals
    const invoiceHTML = `
        <style>
            /* Print-specific styles to ensure a clean printout */
            @media print {
                body {
                    margin: 0;
                    padding: 0;
                }
                #invoice-print-area {
                    width: 100%;
                    box-shadow: none;
                    border: none;
                }
            }
        </style>
        <div class="invoice-details">
            <h1>Invoice</h1>
            <div class="invoice-meta">
                <p><strong>Invoice ID:</strong> ${invoiceData.invoiceId}</p>
                <p><strong>Date:</strong> ${new Date().toLocaleDateString()}</p>
            </div>
            <div class="invoice-billing">
                <p><strong>Billed To:</strong> ${invoiceData.customerName}</p>
                <p><strong>Address:</strong> ${invoiceData.customerAddress}</p>
            </div>
            <h2>Items</h2>
            <table>
                <thead>
                    <tr>
                        <th>Description</th>
                        <th>Quantity</th>
                        <th>Price</th>
                    </tr>
                </thead>
                <tbody>
                    ${invoiceData.items.map(item => `
                        <tr>
                            <td>${item.description}</td>
                            <td>${item.quantity}</td>
                            <td>$${item.price.toFixed(2)}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
            <div class="invoice-totals">
                <p><strong>Subtotal:</strong> $${invoiceData.subtotal.toFixed(2)}</p>
                <p><strong>Tax (10%):</strong> $${(invoiceData.subtotal * 0.10).toFixed(2)}</p>
                <h3>Total Due: $${(invoiceData.subtotal * 1.10).toFixed(2)}</h3>
            </div>
        </div>
    `;

    // 3. Append the generated content to the body (or a specific print area)
    document.body.appendChild(invoiceContainer);
    invoiceContainer.innerHTML = invoiceHTML;

    // 4. Trigger the print dialog
    window.print();

    // 5. Clean up: Remove the generated content after a short delay (optional, but good practice)
    // Note: The print dialog usually handles the visual output, but removing the element ensures the page state is clean.
    setTimeout(() => {
        document.body.removeChild(invoiceContainer);
    }, 500);
}
