// DOM references (deterministically generated from the manifest's `ids`)
const canvasArea = document.getElementById('canvas-area');
const controlsContainer = document.getElementById('controls-container');
const colorPicker = document.getElementById('color-picker');
const brushSizeSelector = document.getElementById('brush-size-selector');
const toolModeSelector = document.getElementById('tool-mode-selector');
const clearCanvasButton = document.getElementById('clear-canvas-button');

// Function implementations (filled in below)
function initCanvas() {
    // 1. Get the canvas and context
    const canvas = canvasArea;
    if (!canvas) {
        console.error('Canvas element not found.');
        return;
    }
    const ctx = canvas.getContext('2d');

    // 2. Set initial default state variables
    // We will use these defaults if no state is loaded later.
    const defaultState = {
        color: '#000000', // Black
        size: 5,           // Default brush size
        toolMode: 'draw'   // Default tool mode
    };

    // Apply initial context settings
    ctx.fillStyle = defaultState.color;
    ctx.strokeStyle = defaultState.color;
    ctx.lineWidth = defaultState.size;

    // 3. Initialize state variables (These will be updated by loadState/saveState)
    // We store the state directly on the canvas or in a global scope if needed,
    // but for this implementation, we focus on setting up the initial context.
    
    // Note: The actual state variables (color, size, toolMode) will be managed
    // by loadState and saveState interacting with the UI elements.
}
function loadState() {
    const state = JSON.parse(localStorage.getItem('drawingState'));

    if (!state) {
        console.log('No saved state found. Using defaults.');
        return;
    }

    // Apply state to UI controls
    if (state.color) {
        colorPicker.value = state.color;
    }
    if (state.size) {
        brushSizeSelector.value = state.size;
    }
    if (state.toolMode) {
        toolModeSelector.value = state.toolMode;
    }

    // Apply state to canvas context (if applicable, though usually state is UI driven)
    // We ensure the canvas context reflects the loaded state if possible.
    const canvas = canvasArea;
    if (canvas) {
        const ctx = canvas.getContext('2d');
        if (state.color) {
            ctx.strokeStyle = state.color;
            ctx.fillStyle = state.color;
        }
        if (state.lineWidth) {
            ctx.lineWidth = state.lineWidth;
        }
    }
}
function saveState() {
    // 1. Read current state from UI controls
    const currentState = {
        color: colorPicker.value,
        size: parseInt(brushSizeSelector.value, 10),
        toolMode: toolModeSelector.value
    };

    // 2. Save the state to Local Storage
    try {
        localStorage.setItem('drawingState', JSON.stringify(currentState));
        console.log('Drawing state saved successfully.');
    } catch (error) {
        console.error('Failed to save state to Local Storage:', error);
    }
}
function setupEventListeners() {
    // Bind events for drawing interaction on the canvas area
    // Bind events for drawing interaction on the canvas area
    const canvasArea = canvasArea;
    if (!canvasArea) return;

    // Bind mouse events for drawing
    canvasArea.addEventListener('mousedown', handleMouseDown);
    canvasArea.addEventListener('mousemove', handleMouseMove);
    canvasArea.addEventListener('mouseup', handleMouseUp);

    // Bind touch events for drawing (for mobile support)
    canvasArea.addEventListener('touchstart', handleTouchStart);
    canvasArea.addEventListener('touchmove', handleTouchMove);
    canvasArea.addEventListener('touchend', handleTouchEnd);

    // Bind UI controls
    const colorPicker = colorPicker;
    const brushSizeSelector = brushSizeSelector;
    const toolModeSelector = toolModeSelector;
    const clearCanvasButton = clearCanvasButton;

    if (colorPicker) {
        colorPicker.addEventListener('input', updateColor);
    }
    if (brushSizeSelector) {
        brushSizeSelector.addEventListener('input', updateBrushSize);
    }
    if (toolModeSelector) {
        toolModeSelector.addEventListener('change', updateToolMode);
    }
    if (clearCanvasButton) {
        clearCanvasButton.addEventListener('click', clearCanvas);
    }
}

// Helper functions (assuming they exist in the scope for setupEventListeners)
function handleMouseDown(event) {
    // Placeholder: In a real implementation, this would set the initial state for drawing
}

function handleMouseMove(event) {
    // Placeholder: In a real implementation, this would trigger handleCanvasInteraction
}

function handleMouseUp(event) {
    // Placeholder: In a real implementation, this would finalize the stroke
}

function handleTouchStart(event) {
    // Placeholder: Handle touch start
}

function handleTouchMove(event) {
    // Placeholder: Handle touch move
}

function handleTouchEnd(event) {
    // Placeholder: Handle touch end
}

function updateColor(event) {
    // Placeholder: Update the current drawing color state
}

function updateBrushSize(event) {
    // Placeholder: Update the current brush size state
}

function updateToolMode(event) {
    // Placeholder: Update the current tool mode state
}


function handleCanvasInteraction(event, ctx, state) {
    const { x, y } = event;

    // Determine if the interaction is a mouse or touch event
    const clientX = event.clientX || event.touches ? event.touches[0].clientX : null;
    const clientY = event.clientY || event.touches ? event.touches[0].clientY : null;

    if (clientX === null || clientY === null) return;

    const mouseX = clientX;
    const mouseY = clientY;

    // Determine the action based on the current tool mode state
    const isErasing = state.toolMode === 'erase';

    if (isErasing) {
        // Erase action: Draw a line with the erase color/style
        applyStroke(ctx, mouseX, mouseY, mouseX, mouseY, state.color, state.size, true);
    } else {
        // Draw action: Draw a line with the current color/style
        applyStroke(ctx, mouseX, mouseY, mouseX, mouseY, state.color, state.size, false);
    }
}
function applyStroke(ctx, x1, y1, x2, y2, color, size, isErasing) {
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.strokeStyle = color;
    ctx.lineWidth = size;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (isErasing) {
        // Erasing typically involves drawing over the area with a specific style (e.g., white or transparent fill)
        // For simplicity in this context, we draw the line segment.
        ctx.stroke();
    } else {
        // Drawing
        ctx.stroke();
    }
}
function clearCanvas(ctx) {
    // Resets the entire canvas to a blank state by clearing the entire area.
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
}
function handleColorChange(newColor) {
    // Updates the current drawing color using the canvas context.
    // Assuming the drawing style is set via ctx.strokeStyle or ctx.fillStyle.
    ctx.strokeStyle = newColor;
    ctx.fillStyle = newColor;
    // In a real application, this state would also be saved to a global state object.
}
function handleSizeChange(newSize) {
    // Updates the current brush size using the canvas context.
    // Assuming the brush size is controlled by ctx.lineWidth.
    ctx.lineWidth = newSize;
}
