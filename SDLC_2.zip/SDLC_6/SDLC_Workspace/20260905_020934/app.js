document.addEventListener('DOMContentLoaded', () => {
    // 1. Declare Global State
    let currentInvoiceData = {
        invoiceDate: '',
        customerName: '',
        taxRate: 0,
        items: []
    };

    // 2. Set up Document References
    const invoiceDateInput = document.getElementById('invoice-date');
    const customerNameInput = document.getElementById('customer-name');
    const taxRateInput = document.getElementById('tax-rate');
    const addItemButton = document.getElementById('add-item-btn');
    const saveInvoiceButton = document.getElementById('save-invoice-btn');
    const printInvoiceButton = document.getElementById('print-invoice-btn');
    const itemNameInput = document.getElementById('item-name');
    const itemQuantityInput = document.getElementById('item-quantity');
    const itemRateInput = document.getElementById('item-rate');
    const invoiceOutputArea = document.getElementById('invoice-output-area');
    const totalBillDisplay = document.getElementById('total-bill-display');

    // --- Helper Function for Dynamic Item Management ---
    /**
     * Dynamically creates a new row for an item in the invoice table.
     * @param {string} name - The item name.
     * @param {number} quantity - The item quantity.
     * @param {number} rate - The item rate.
     */
    const addItemRow = (name = '', quantity = '', rate = '') => {
        const item = {
            name: name,
            quantity: parseFloat(quantity) || 0,
            rate: parseFloat(rate) || 0,
            subtotal: parseFloat(quantity) * parseFloat(rate) || 0
        };
        currentInvoiceData.items.push(item);
        updateTotalDisplay();
        renderItems();
    };

    /**
     * Renders the list of items into the invoice output area.
     */
    const renderItems = () => {
        if (currentInvoiceData.items.length === 0) {
            invoiceOutputArea.innerHTML = '<p>No items added yet.</p>';
            return;
        }

        let itemsHtml = '<table><thead><tr><th>Item</th><th>Qty</th><th>Rate</th><th>Subtotal</th></tr></thead><tbody>';
        
        currentInvoiceData.items.forEach(item => {
            itemsHtml += `
                <tr>
                    <td>${item.name}</td>
                    <td>${item.quantity}</td>
                    <td>${item.rate.toFixed(2)}</td>
                    <td>${item.subtotal.toFixed(2)}</td>
                </tr>
            `;
        });

        itemsHtml += '</tbody></table>';
        invoiceOutputArea.innerHTML = itemsHtml;
    };

    /**
     * Calculates and displays the final total bill amount.
     */
    const updateTotalDisplay = () => {
        const subtotal = currentInvoiceData.items.reduce((sum, item) => sum + item.subtotal, 0);
        const taxAmount = subtotal * (currentInvoiceData.taxRate / 100);
        const finalTotal = subtotal + taxAmount;

        totalBillDisplay.textContent = finalTotal.toFixed(2);
    };


    // --- Function Implementations (Event Listeners) ---

    // 1. Load Data from Storage on Initialization
    const loadInvoiceFromStorage = () => {
        try {
            const savedData = localStorage.getItem('invoiceData');
            if (savedData) {
                const data = JSON.parse(savedData);
                currentInvoiceData = data;
                
                // Populate header fields
                invoiceDateInput.value = currentInvoiceData.invoiceDate || '';
                customerNameInput.value = currentInvoiceData.customerName || '';
                taxRateInput.value = currentInvoiceData.taxRate || 0;

                // Populate items
                currentInvoiceData.items.forEach(item => {
                    // Note: We need to manually trigger the item addition logic here
                    addItemRow(item.name, item.quantity, item.rate);
                });

                // Re-render everything
                collectInvoiceData(
                    invoiceDateInput.value,
                    customerNameInput.value,
                    taxRateInput.value,
                    currentInvoiceData.items
                );

            } else {
                // Initialize with default empty state if no data is found
                console.log('No saved invoice data found. Starting fresh.');
            }
        } catch (error) {
            console.error('Error loading invoice data from storage:', error);
        }
    };

    // 2. Save Data to Storage
    const saveInvoiceToStorage = () => {
        try {
            // Ensure all necessary data is collected before saving
            collectInvoiceData(
                invoiceDateInput.value,
                customerNameInput.value,
                taxRateInput.value,
                currentInvoiceData.items
            );

            // Save the complete state
            localStorage.setItem('invoiceData', JSON.stringify(currentInvoiceData));
            alert('Invoice successfully saved to local storage!');
        } catch (error) {
            console.error('Error saving invoice data:', error);
            alert('Error saving invoice. Please check the console.');
        }
    };

    // 3. Generate Print View
    const generatePrintView = () => {
        // This function will be called with the final data to format the output
        // (Implementation of generatePrintView logic is deferred, but the call is set up)
        if (currentInvoiceData.items.length === 0) {
            alert("Please add items before generating a print view.");
            return;
        }
        // Placeholder: In a full implementation, this would trigger the print dialog
        console.log("Generating print view for invoice:", currentInvoiceData);
        // window.print(); // Actual print trigger
    };

    // 4. Core Data Collection and Calculation
    const collectInvoiceData = (date, name, rate, items) => {
        currentInvoiceData.invoiceDate = date;
        currentInvoiceData.customerName = name;
        currentInvoiceData.taxRate = parseFloat(rate) || 0;
        currentInvoiceData.items = items;
        
        calculateTotals(items, currentInvoiceData.taxRate);
        renderInvoice(currentInvoiceData);
    };

    const calculateTotals = (items, taxRate) => {
        let subtotal = 0;
        items.forEach(item => {
            subtotal += item.subtotal;
        });

        const taxAmount = subtotal * (taxRate / 100);
        const finalTotal = subtotal + taxAmount;

        // Update the display element
        totalBillDisplay.textContent = finalTotal.toFixed(2);
    };

    const renderInvoice = (invoiceData) => {
        // This function will be called with the final data to display the invoice
        // (Implementation of renderInvoice logic is deferred, but the call is set up)
        console.log("Rendering invoice structure:", invoiceData);
        // In a full implementation, this would populate invoiceOutputArea
    };


    // --- Event Listeners Setup ---

    // Load data when the page loads
    loadInvoiceFromStorage();

    // Event Listener for adding new items
    addItemButton.addEventListener('click', () => {
        const name = itemNameInput.value.trim();
        const quantity = itemQuantityInput.value.trim();
        const rate = itemRateInput.value.trim();

        if (name && quantity && rate) {
            addItemRow(name, quantity, rate);
            // Clear inputs after adding
            itemInputFieldsReset();
        } else {
            alert('Please fill in all item details (Name, Quantity, Rate).');
        }
    });

    // Event Listener for saving the invoice
    saveInvoiceButton.addEventListener('click', saveInvoiceToStorage);

    // Event Listener for printing the invoice
    printInvoiceButton.addEventListener('click', () => {
        // Ensure the latest data is calculated and rendered before printing
        collectInvoiceData(
            invoiceDateInput.value,
            customerNameInput.value,
            taxRateInput.value,
            currentInvoiceData.items
        );
        generatePrintView();
    });

    // Optional:

// --- Core Functions ---
function collectInvoiceData(invoiceDate, customerName, taxRate, items) {
    return {
        invoiceDate: invoiceDate,
        customerName: customerName,
        taxRate: parseFloat(taxRate) || 0,
        items: items || []
    };
}
function calculateTotals(items, taxRate) {
    let subtotal = 0;
    const itemTotals = [];

    // 1. Calculate subtotal for each line item
    for (const item of items) {
        const price = parseFloat(item.price) || 0;
        const tax = price * (taxRate / 100);
        const total = price + tax;

        itemTotals.push({
            ...item,
            subtotal: price,
            tax: tax,
            total: total
        });

        subtotal += price;
    }

    // 2. Calculate final totals
    const grandSubtotal = itemTotals.reduce((acc, current) => acc + current.subtotal, 0);
    const totalTax = grandSubtotal * (taxRate / 100);
    const finalTotal = grandSubtotal + totalTax;

    return {
        itemTotals: itemTotals,
        subtotal: grandSubtotal,
        taxAmount: totalTax,
        finalTotal: finalTotal
    };
}
function renderInvoice(invoiceData) {
    const outputElement = document.getElementById('invoice-output');
    if (!outputElement) {
        console.error("Target element 'invoice-output' not found.");
        return;
    }

    const { invoiceDate, customerName, taxRate, items } = invoiceData;

    // Helper function to format currency
    const formatCurrency = (amount) => amount.toFixed(2);

    // Build the item table rows
    const itemRows = items.map(item => `
        <tr>
            <td>${item.description}</td>
            <td style="text-align: right;">$${formatCurrency(item.price)}</td>
            <td style="text-align: right;">$${formatCurrency(item.subtotal)}</td>
            <td style="text-align: right;">$${formatCurrency(item.tax)}</td>
            <td style="text-align: right;">$${formatCurrency(item.total)}</td>
        </tr>
    `).join('');

    // Build the final HTML structure using template literals
    const invoiceHTML = `
        <div class="invoice-container">
            <h1>Invoice</h1>
            <p><strong>Invoice Date:</strong> ${invoiceDate}</p>
            <p><strong>Customer:</strong> ${customerName}</p>

            <table class="invoice-items">
                <thead>
                    <tr>
                        <th>Description</th>
                        <th style="text-align: right;">Price</th>
                        <th style="text-align: right;">Subtotal</th>
                        <th style="text-align: right;">Tax (${(taxRate)}%)</th>
                        <th style="text-align: right;">Total</th>
                    </tr>
                </thead>
                <tbody>
                    ${itemRows}
                </tbody>
            </table>

            <div class="invoice-totals">
                <p><strong>Subtotal:</strong> $${formatCurrency(items.reduce((sum, item) => sum + item.price, 0))}</p>
                <p><strong>Tax Amount:</strong> $${formatCurrency(items.reduce((sum, item) => sum + item.tax, 0))}</p>
                <h2>Grand Total: $${formatCurrency(items.reduce((sum, item) => sum + item.total, 0))}</h2>
            </div>
        </div>
    `;

    // Inject the generated HTML into the DOM
    outputElement.innerHTML = invoiceHTML;
}
function saveInvoiceToStorage(invoiceData) {
    try {
        const serializedData = JSON.stringify(invoiceData);
        localStorage.setItem('invoiceData', serializedData);
        console.log('Invoice successfully saved to local storage.');
    } catch (error) {
        console.error('Error saving invoice data to local storage:', error);
        throw new Error('Failed to save data.');
    }
}
function loadInvoiceFromStorage() {
    try {
        const serializedData = localStorage.getItem('invoiceData');

        if (serializedData === null) {
            console.log('No invoice data found in local storage.');
            return null;
        }

        const invoiceData = JSON.parse(serializedData);
        console.log('Invoice successfully loaded from local storage.');

        // Actual UI Population Logic (Example based on assumed structure)
        // In a real application, this is where you would manipulate the DOM.
        
        // Example: Populate total (Assuming an element with id 'invoice-total' exists)
        const totalElement = document.getElementById('invoice-total');
        if (totalElement) {
            totalElement.textContent = invoiceData.total.toFixed(2);
        }

        // Example: Populate item list (Assuming an element with id 'items-list' exists)
        const itemsListElement = document.getElementById('items-list');
        if (itemsListElement) {
            itemsListElement.innerHTML = invoiceData.items.map(item => `<li>${item.name}: $${item.price.toFixed(2)}</li>`).join('');
        }
        
        console.log('Loaded Invoice Data:', invoiceData);
        
        return invoiceData;

    } catch (error) {
        console.error('Error loading invoice data from local storage:', error);
        // Clear potentially corrupted data if parsing fails
        localStorage.removeItem('invoiceData');
        return null;
    }
}
function generatePrintView(invoiceData) {
    if (!invoiceData) {
        console.error('Cannot generate print view: No invoice data provided.');
        return;
    }

    // 1. Create the print-optimized HTML content
    const printContent = `
        <div class="invoice-print-container">
            <h1>Invoice</h1>
            <div class="invoice-details">
                <p><strong>Invoice ID:</strong> ${invoiceData.id}</p>
                <p><strong>Date:</strong> ${new Date(invoiceData.date).toLocaleDateString()}</p>
            </div>

            <h2>Items</h2>
            <table class="invoice-items">
                <thead>
                    <tr>
                        <th>Description</th>
                        <th>Price</th>
                    </tr>
                </thead>
                <tbody>
                    ${invoiceData.items.map(item => `
                        <tr>
                            <td>${item.name}</td>
                            <td>$${item.price.toFixed(2)}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>

            <div class="invoice-total">
                <h2>Total Amount: $${invoiceData.total.toFixed(2)}</h2>
            </div>
        </div>
    `;

    // 2. Temporarily inject the content into the body
    document.body.innerHTML = printContent;

    // 3. Trigger the print dialog
    window.print();

    // 4. Clean up the DOM after printing (optional, but good practice)
    // Note: The browser handles the actual print dialog, but we reset the body content afterward.
    setTimeout(() => {
        document.body.innerHTML = '<h1>Invoice Printed</h1><p>Data successfully printed.</p>';
    }, 500); 
}
