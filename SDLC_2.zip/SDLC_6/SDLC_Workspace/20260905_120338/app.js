// DOM References
const display = document.getElementById('display');
const btn0 = document.getElementById('btn-0');
const btn1 = document.getElementById('btn-1');
const btn2 = document.getElementById('btn-2');
const btn3 = document.getElementById('btn-3');
const btn4 = document.getElementById('btn-4');
const btn5 = document.getElementById('btn-5');
const btn6 = document.getElementById('btn-6');
const btn7 = document.getElementById('btn-7');
const btn8 = document.getElementById('btn-8');
const btn9 = document.getElementById('btn-9');
const btn-add = document.getElementById('btn-add');
const btn-subtract = document.getElementById('btn-subtract');
const btn-multiply = document.getElementById('btn-multiply');
const btn-divide = document.getElementById('btn-divide');
const btn-clear = document.getElementById('btn-clear');
const btn-equals = document.getElementById('btn-equals');

// State Variables
let currentInput = '';
let storedOperation = '';
let num1 = null;
let waitingForSecondOperand = false;

// Event Listeners Setup (Skeleton)
btn0.addEventListener('click', () => { /* logic for input 0 */ });
btn1.addEventListener('click', () => { /* logic for input 1 */ });
btn2.addEventListener('click', () => { /* logic for input 2 */ });
btn3.addEventListener('click', () => { /* logic for input 3 */ });
btn4.addEventListener('click', () => { /* logic for input 4 */ });
btn5.addEventListener('click', () => { /* logic for input 5 */ });
btn6.addEventListener('click', () => { /* logic for input 6 */ });
btn7.addEventListener('click', () => { /* logic for input 7 */ });
btn8.addEventListener('click', () => { /* logic for input 8 */ });
btn9.addEventListener('click', () => { /* logic for input 9 */ });
btn-add.addEventListener('click', () => { /* logic for operation selection */ });
btn-subtract.addEventListener('click', () => { /* logic for operation selection */ });
btn-multiply.addEventListener('click', () => { /* logic for operation selection */ });
btn-divide.addEventListener('click', () => { /* logic for operation selection */ });
btn-clear.addEventListener('click', () => { /* logic for clearing */ });
btn-equals.addEventListener('click', () => { /* logic for calculation */ });


// Function Definitions
// handleNumberInput(value)
// function handleNumberInput(value) {
//     // Implementation goes here
// }

// handleOperationSelection(operator)
// function handleOperationSelection(operator) {
//     // Implementation goes here
// }

// clearDisplay(displayElement)
// function clearDisplay(displayElement) {
//     // Implementation goes here
// }

// performCalculation(num1, operator, num2)
// function performCalculation(num1, operator, num2) {
//     // Implementation goes here
// }