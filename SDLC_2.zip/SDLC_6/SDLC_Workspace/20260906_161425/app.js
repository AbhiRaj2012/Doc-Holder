// DOM references (deterministically generated from the manifest's `ids`)
const canvasArea = document.getElementById('canvas-area');
const toolPalette = document.getElementById('tool-palette');
const colorPicker = document.getElementById('color-picker');
const brushSizeSelector = document.getElementById('brush-size-selector');
const toolDraw = document.getElementById('tool-draw');
const toolEraser = document.getElementById('tool-eraser');
const clearCanvasButton = document.getElementById('clear-canvas-button');
const brushSizeValue = document.getElementById('brush-size-value');

// Function implementations (filled in below)
function initializeCanvas(canvasElement) {
    // Get the 2D rendering context
    const context = canvasElement.getContext('2d');

    // Set initial state variables
    let isDrawing = false;
    let lastX = 0;
    let lastY = 0;

    // Set initial drawing properties
    context.strokeStyle = '#000000'; // Default color
    context.lineWidth = 5;           // Default brush size
    context.lineCap = 'round';       // Smooth lines
    context.lineJoin = 'round';      // Smooth corners

    // Note: In a real application, this function would also handle setting initial canvas dimensions
    // and potentially initializing state variables stored in a global scope or class instance.
}


// Helper functions required by setupEventListeners (assuming they exist in scope)

function handleColorChange(event) {
    const context = canvasArea.getContext('2d');
    context.strokeStyle = event.target.value;
}

function handleSizeChange(event) {
    const context = canvasArea.getContext('2d');
    // Update the global brush size value
    brushSizeValue = parseInt(event.target.value);
    context.lineWidth = brushSizeValue;
}

function handleToolSelection(event) {
    const tool = event.target.dataset.tool;
    if (tool === 'draw') {
        toolDraw.classList.add('active');
        toolEraser.classList.remove('active');
    } else if (tool === 'erase') {
        toolEraser.classList.add('active');
        toolDraw.classList.remove('active');
    }
}

function handleClearCanvas() {
    const context = canvasArea.getContext('2d');
    context.clearRect(0, 0, canvasArea.width, canvasArea.height);
}

// Note: handleMouseDown, handleMouseMove, and handleMouseUp are defined below as they are required by setupEventListeners.
function handleMouseDown(event, context, currentColor, currentSize) {
    // 1. Set drawing state
    isDrawing = true;

    // 2. Get coordinates relative to the canvas
    const rect = context.canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    // 3. Store the starting point
    lastX = x;
    lastY = y;

    // 4. Start a new path (if drawing is active)
    if (isDrawing) {
        context.beginPath();
        context.moveTo(lastX, lastY);
    }
}
function handleMouseMove(event, context, currentColor, currentSize) {
    // Ensure the context is 2D for drawing
    const ctx = context.getContext('2d');

    // Set drawing properties
    ctx.strokeStyle = currentColor;
    ctx.lineWidth = currentSize;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    // Start the path
    ctx.beginPath();
    
    // Move to the starting point (assuming event.offsetX/Y relative to canvas)
    // Note: In a real application, coordinates would be mapped based on canvas position.
    ctx.moveTo(event.offsetX, event.offsetY);

    // Draw the line to the current position
    ctx.lineTo(event.offsetX, event.offsetY);
    ctx.stroke();
}
function handleMouseUp(event, context) {
    // In a typical drawing scenario, MouseUp signals the end of the stroke.
    // If the drawing was continuous (handled by mousemove), this function
    // might finalize the stroke or stop the drawing state.
    
    // For this implementation, we ensure the path is closed or finalized if necessary.
    // Since handleMouseMove already draws, handleMouseUp primarily signals completion.
    
    // Example: If we were tracking a specific stroke, we would finalize it here.
    // context.closePath(); 
    
    // In a simple continuous drawing setup, this function often just stops the event handling.
    console.log("Drawing operation finalized.");
}
function applyToolSelection(tool, context) {
    // 'tool' determines the active mode (e.g., 'draw' or 'erase').
    // 'context' refers to the main application context or state object.

    if (tool === 'draw') {
        // Activate drawing mode
        context.setActiveTool('draw');
        // Update visual state (e.g., highlight toolDraw)
        toolDraw.classList.add('active');
        toolEraser.classList.remove('active');
    } else if (tool === 'erase') {
        // Activate erasing mode
        context.setActiveTool('erase');
        // Update visual state
        toolEraser.classList.add('active');
        toolDraw.classList.remove('active');
    } else {
        console.error("Invalid tool selected:", tool);
    }
}
function setDrawingColor(color) {
    const context = canvasArea.getContext('2d');
    context.strokeStyle = color;
    context.fillStyle = color;
}
function setBrushSize(size) {
    // Update the internal state variable
    brushSizeValue = size;

    // Optional: If the UI needs immediate visual feedback based on the selector
    // brushSizeSelector.value = size; 
}
function clearCanvas(context) {
    // Ensure the context is valid and clear the entire canvas area
    if (context) {
        context.clearRect(0, 0, canvasArea.width, canvasArea.height);
    }
}
function saveCanvasState(context) {
    const canvas = context.canvas;
    const dataUrl = canvas.toDataURL('image/png');
    // Store the data URL in local storage for persistence
    localStorage.setItem('canvasState', dataUrl);
    return dataUrl;
}
function loadCanvasState(context, dataUrl) {
    const canvas = context.canvas;
    const img = new Image();

    img.onload = function() {
        // Redraw the image onto the canvas
        context.drawImage(img, 0, 0);
    };

    img.src = dataUrl;
}
function loadPersistence(context) {
    const savedDataUrl = localStorage.getItem('canvasState');

    if (savedDataUrl) {
        // Load the saved state back onto the canvas
        loadCanvasState(context, savedDataUrl);
    }
}
{
  "name": "canvasAreaPointerDownHandler",
  "params": [
    "x",
    "y",
    "event"
  ],
  "description": "Called on pointer 'pointerdown' over the 'canvas-area' canvas (The primary drawing surface for all canvas operations.). x and y are ALREADY canvas-relative pixel coordinates, unified for both mouse and touch input by the deterministic wiring in setupEventListeners() \u2014 do NOT read event.offsetX/offsetY or event.touches yourself. Implement the actual drawing/interaction logic (e.g. begin/continue/end a stroke), updating whatever shared state this app uses to track the current interaction."
}
function canvasAreaPointerMoveHandler(x, y, event) {
    if (!isDrawing) return;

    if (currentTool === 'draw') {
        // Draw a line segment
        draw(lastX, lastY, x, y, currentSize, currentColor);
        lastX = x;
        lastY = y;
    } else if (currentTool === 'erase') {
        // Erase the area
        erase(lastX, lastY, x, y, currentSize);
        lastX = x;
        lastY = y;
    }
}
function canvasAreaPointerUpHandler(x, y, event) {
    if (!isDrawing) return;

    // End the drawing interaction
    isDrawing = false;
}
function toolDrawClickHandler() {
    // Logic to activate drawing mode.
    // In a real application, this would typically update the application state
    // and potentially trigger a redraw or change the active tool.
    // Example: handleToolSelection('draw');
    // Example: saveState();
}
function toolEraserClickHandler() {
    // Logic to activate eraser mode.
    // In a real application, this would typically update the application state
    // and potentially trigger a redraw or change the active tool.
    // Example: handleToolSelection('eraser');
    // Example: saveState();
}
function clearCanvasButtonClickHandler() {
    // Logic to clear all content from the canvas.
    // This typically involves clearing the canvas context or setting it to a blank state.
    // Example: clearCanvas(canvasArea);
    // Example: saveState();
}

// Event wiring (deterministically generated — do not remove)
{
  "name": "setupEventListeners",
  "params": [
    "canvasElement",
    "colorPicker",
    "sizeSelector",
    "toolPalette",
    "clearButton"
  ],
  "description": "Attaches all necessary event listeners (mouse/touch, UI controls) to the canvas and controls."
}
function setupEventListeners(canvasElement, colorPicker, sizeSelector, toolPalette, clearButton) {
  // --- 1. Canvas Drawing Event Handlers ---

  /**
   * Helper function to get coordinates relative to the canvas.
   * Handles both mouse and touch events.
   */
  const getCanvasCoordinates = (event) => {
    const rect = canvasElement.getBoundingClientRect();
    let clientX, clientY;

    if (event.touches && event.touches.length > 0) {
      clientX = event.touches[0].clientX;
      clientY = event.touches[0].clientY;
    } else {
      clientX = event.clientX;
      clientY = event.clientY;
    }

    return {
      x: clientX - rect.left,
      y: clientY - rect.top
    };
  };

  /**
   * Main drawing handler.
   * @param {Event} event - The mouse or touch event.
   */
  const handleDrawing = (event) => {
    event.preventDefault(); // Prevent scrolling on touch devices
    const { x, y } = getCanvasCoordinates(event);

    const ctx = canvasElement.getContext('2d');
    const isDrawing = event.type.startsWith('mouse') ? event.type === 'mousedown' : event.type === 'touchstart';

    if (isDrawing) {
      ctx.beginPath();
      ctx.moveTo(x, y);
    } else if (event.type.startsWith('move') || event.type.startsWith('touchmove')) {
      ctx.lineTo(x, y);
      ctx.stroke();
    }
  };

  /**
   * Stops drawing.
   * @param {Event} event - The mouse or touch up event.
   */
  const stopDrawing = (event) => {
    const ctx = canvasElement.getContext('2d');
    ctx.closePath();
  };

  // Attach drawing listeners to the canvas
  canvasElement.addEventListener('mousedown', handleDrawing);
  canvasElement.addEventListener('mousemove', handleDrawing);
  canvasElement.addEventListener('mouseup', stopDrawing);
  canvasElement.addEventListener('mouseout', stopDrawing);

  canvasElement.addEventListener('touchstart', handleDrawing);
  canvasElement.addEventListener('touchmove', handleDrawing);
  canvasElement.addEventListener('touchend', stopDrawing);


  // --- 2. UI Control Event Handlers ---

  // A. Color Picker
  colorPicker.addEventListener('input', (e) => {
    const ctx = canvasElement.getContext('2d');
    ctx.strokeStyle = e.target.value;
  });

  // B. Brush Size Selector
  sizeSelector.addEventListener('input', (e) => {
    const ctx = canvasElement.getContext('2d');
    ctx.lineWidth = e.target.value;
  });

  // C. Tool Selection (Draw/Erase)
  toolPalette.addEventListener('click', (e) => {
    const tool = e.target.dataset.tool;
    if (tool === 'draw') {
      canvasElement.style.cursor = 'crosshair';
      // Ensure drawing mode is set (assuming toolDraw handles the actual state change)
      // In a full app, this would toggle a global drawing state.
    } else if (tool === 'eraser') {
      canvasElement.style.cursor = 'cell';
      // Set context for erasing (assuming the drawing logic handles the erase mode)
      canvasElement.style.stroke = 'white'; // Erasing usually means drawing over white
    }
  });

  // D. Clear Canvas Button
  clearButton.addEventListener('click', () => {
    const ctx = canvasElement.getContext('2d');
    ctx.clearRect(0, 0, canvasElement.width, canvasElement.height);
  });
}

// Application entry point (deterministically generated — do not remove)
document.addEventListener('DOMContentLoaded', () => {
    setupEventListeners();
});
