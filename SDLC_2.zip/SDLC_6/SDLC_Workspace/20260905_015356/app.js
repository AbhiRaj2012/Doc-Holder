// --- DOM Element References ---

// --- Core Functions ---
function initializeInvoiceState(customerName, invoiceDate, taxRate) {
    const invoiceState = {
        customerName: customerName || "",
        invoiceDate: invoiceDate || new Date().toISOString().split('T')[0],
        taxRate: parseFloat(taxRate) || 0,
        items: []
    };
    return invoiceState;
}
function addItem(invoiceState, itemName, quantity, rate) {
    if (!invoiceState || !Array.isArray(invoiceState.items)) {
        throw new Error("Invalid invoice state provided. State must contain an 'items' array.");
    }

    const subtotal = parseFloat(quantity) * parseFloat(rate);

    const newItem = {
        name: itemName || "",
        quantity: parseFloat(quantity),
        rate: parseFloat(rate),
        subtotal: subtotal
    };

    invoiceState.items.push(newItem);
    return newItem;
}
function removeItem(invoiceState, index) {
    if (!invoiceState || !Array.isArray(invoiceState.items)) {
        throw new Error("Invalid invoice state provided. State must contain an 'items' array.");
    }

    if (index < 0 || index >= invoiceState.items.length) {
        throw new Error(`Index ${index} is out of bounds.`);
    }

    // Remove the item at the specified index
    const removedItem = invoiceState.items.splice(index, 1);
    
    // Return the removed item for potential use by the caller
    return removedItem;
}
function calculateLineItemSubtotal(quantity, rate) {
    if (typeof quantity !== 'number' || typeof rate !== 'number') {
        console.error("Invalid input types for line item calculation.");
        return 0;
    }
    return quantity * rate;
}
function calculateInvoiceTotals(invoiceData) {
    let grandSubtotal = 0;
    let totalTax = 0;
    let finalTotal = 0;

    if (!Array.isArray(invoiceData)) {
        console.error("Invalid invoiceData provided. Expected an array.");
        return { grandSubtotal: 0, totalTax: 0, finalTotal: 0 };
    }

    for (const item of invoiceData) {
        const subtotal = calculateLineItemSubtotal(item.quantity, item.rate);
        grandSubtotal += subtotal;
    }

    // --- Example Tax Calculation (Assuming a fixed 10% tax rate for demonstration) ---
    const TAX_RATE = 0.10;
    totalTax = grandSubtotal * TAX_RATE;
    finalTotal = grandSubtotal + totalTax;

    return {
        grandSubtotal: grandSubtotal,
        totalTax: totalTax,
        finalTotal: finalTotal
    };
}
function renderInvoice(invoiceData) {
    const invoiceContainer = document.getElementById('invoice-output');
    if (!invoiceContainer) {
        console.error("Element with ID 'invoice-output' not found. Cannot render invoice.");
        return;
    }

    // Clear previous content
    invoiceContainer.innerHTML = '';

    if (!invoiceData || invoiceData.length === 0) {
        invoiceContainer.innerHTML = '<p>No invoice items found.</p>';
        return;
    }

    // 1. Render Header
    const header = document.createElement('h2');
    header.textContent = 'Invoice Summary';
    invoiceContainer.appendChild(header);

    // 2. Render Line Items
    const itemsList = document.createElement('ul');
    itemsList.className = 'invoice-items';

    invoiceData.forEach(item => {
        const li = document.createElement('li');
        li.className = 'invoice-item';
        
        const subtotal = calculateLineItemSubtotal(item.quantity, item.rate);

        li.innerHTML = `
            <div class="item-details">
                <span>${item.quantity} x $${item.rate.toFixed(2)}</span>
                <span>Subtotal: $${subtotal.toFixed(2)}</span>
            </div>
        `;
        itemsList.appendChild(li);
    });

    invoiceContainer.appendChild(itemsList);

    // 3. Render Totals (Requires calculating totals first)
    const totals = calculateInvoiceTotals(invoiceData);

    const totalsDiv = document.createElement('div');
    totals.finalTotal = totals.finalTotal.toFixed(2);
    totals.totalTax = totals.totalTax.toFixed(2);

    totalsDiv.className = 'invoice-totals';
    totalsDiv.innerHTML = `
        <p>Grand Subtotal: $${totals.grandSubtotal.toFixed(2)}</p>
        <p>Tax (10%): $${totals.totalTax}</p>
        <hr>
        <h3>Total Due: $${totals.finalTotal}</h3>
    `;
    invoiceContainer.appendChild(totalsDiv);
}
function saveInvoiceData(invoiceData) {
    try {
        const dataToStore = JSON.stringify(invoiceData);
        localStorage.setItem('invoiceData', dataToStore);
        console.log('Invoice data successfully saved to Local Storage.');
    } catch (error) {
        console.error('Error saving invoice data to Local Storage:', error);
        throw new Error('Failed to save data.');
    }
}
function loadInvoiceData() {
    try {
        const storedData = localStorage.getItem('invoiceData');
        if (storedData) {
            const invoiceData = JSON.parse(storedData);
            console.log('Invoice data successfully loaded from Local Storage.');
            return invoiceData;
        } else {
            console.log('No invoice data found in Local Storage.');
            return null;
        }
    } catch (error) {
        console.error('Error loading invoice data from Local Storage:', error);
        // Clear potentially corrupted data if parsing fails
        localStorage.removeItem('invoiceData');
        return null;
    }
}
function generatePrintView(invoiceData) {
    if (!invoiceData) {
        return "<div class='error'>No invoice data provided for printing.</div>";
    }

    // Generate the HTML structure using template literals
    const printViewHTML = `
        <style>
            /* Basic print-specific styling */
            @media print {
                body {
                    margin: 0;
                    padding: 0;
                    font-family: sans-serif;
                }
                .invoice-container {
                    width: 100%;
                    box-shadow: none !important;
                    border: none !important;
                }
            }
            /* General styling for readability */
            .invoice-container {
                max-width: 800px;
                margin: 20px auto;
                padding: 30px;
                border: 1px solid #ccc;
                background-color: #fff;
            }
            .invoice-header {
                text-align: center;
                margin-bottom: 30px;
            }
            .invoice-details table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
            }
            .invoice-details th, .invoice-details td {
                border: 1px solid #ddd;
                padding: 8px;
                text-align: left;
            }
            .total-row td {
                font-weight: bold;
                border-top: 2px solid #000;
            }
        </style>
        <div class="invoice-container">
            <div class="invoice-header">
                <h1>INVOICE</h1>
                <p>Invoice ID: ${invoiceData.id}</p>
                <p>Date: ${new Date().toLocaleDateString()}</p>
            </div>

            <div class="invoice-details">
                <h2>Billed To:</h2>
                <p>${invoiceData.customerName}</p>
                <p>${invoiceData.customerAddress}</p>

                <h2>Invoice Details:</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${invoiceData.items.map(item => `
                            <tr>
                                <td>${item.description}</td>
                                <td>${item.quantity}</td>
                                <td>$${item.unitPrice.toFixed(2)}</td>
                                <td>$${(item.quantity * item.unitPrice).toFixed(2)}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                    <tfoot>
                        <tr class="total-row">
                            <td>TOTAL DUE:</td>
                            <td></td>
                            <td></td>
                            <td>$${invoiceData.total.toFixed(2)}</td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    `;

    // Return the generated HTML string
    return printViewHTML;
}
