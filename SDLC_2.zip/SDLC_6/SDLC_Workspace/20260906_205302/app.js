// DOM references (deterministically generated from the manifest's `ids`)
const customerNameInput = document.getElementById('customer-name-input');
const invoiceDateInput = document.getElementById('invoice-date-input');
const taxRateInput = document.getElementById('tax-rate-input');
const addItemButton = document.getElementById('add-item-button');
const itemListContainer = document.getElementById('item-list-container');
const invoiceSummaryContainer = document.getElementById('invoice-summary-container');
const saveInvoiceButton = document.getElementById('save-invoice-button');
const printInvoiceButton = document.getElementById('print-invoice-button');
const appContainer = document.getElementById('app-container');
const inputSection = document.getElementById('input-section');
const itemSection = document.getElementById('item-section');
const summarySection = document.getElementById('summary-section');
const subtotalDisplay = document.getElementById('subtotal-display');
const taxRateDisplay = document.getElementById('tax-rate-display');
const taxDisplay = document.getElementById('tax-display');
const totalDisplay = document.getElementById('total-display');

// Function implementations (filled in below)
{
  "name": "loadInvoiceData",
  "params": [],
  "description": "Loads the invoice data from Local Storage and initializes the UI."
}
function loadInvoiceData() {
  const savedData = localStorage.getItem('invoiceData');

  // 1. Initialize default state if no data is found
  if (!savedData) {
    // Initialize empty structure if no data exists
    initializeInvoiceUI();
    return;
  }

  try {
    const invoiceData = JSON.parse(savedData);

    // 2. Populate static fields
    customerNameInput.value = invoiceData.customerName || '';
    invoiceDateInput.value = invoiceData.invoiceDate || new Date().toISOString().split('T')[0];
    taxRateInput.value = invoiceData.taxRate || '0';

    // 3. Clear existing item list and summary
    const itemListContainer = itemListContainer;
    itemListContainer.innerHTML = '';
    
    // 4. Render itemized list
    if (invoiceData.items && invoiceData.items.length > 0) {
      invoiceData.items.forEach(item => {
        renderItemRow(itemListContainer, item);
      });
    } else {
      // Ensure the container is visible even if empty
      itemListContainer.innerHTML = '<p class="text-center text-gray-500 mt-4">No items added yet.</p>';
    }

    // 5. Calculate and display totals
    calculateTotals(invoiceData.items, invoiceData.taxRate);

    // 6. Attach event listeners (re-binding necessary since we cleared the DOM)
    attachEventListeners();

  } catch (error) {
    console.error("Error loading or parsing invoice data:", error);
    // Fallback to initialization if parsing fails
    initializeInvoiceUI();
  }
}

/**
 * Helper function to initialize the basic UI structure and default values.
 */
function initializeInvoiceUI() {
    // Set initial default values for inputs
    customerNameInput.value = '';
    invoiceDateInput.value = new Date().toISOString().split('T')[0];
    taxRateInput.value = '0';
    
    // Clear item list and summary
    itemListContainer.innerHTML = '';
    subtotalDisplay.textContent = '0.00';
    taxRateDisplay.textContent = '0.00%';
    taxDisplay.textContent = '0.00';
    totalDisplay.textContent = '0.00';
}

/**
 * Helper function to render a single item row in the list.
 * @param {HTMLElement} container - The container element to append the row to.
 * @param {object} item - The item data.
 */
function renderItemRow(container, item) {
    const row = document.createElement('div');
    row.className = 'item-row border-b py-2';
    row.innerHTML = `
        <div class="item-name w-1/3"><span>${item.name}</span></div>
        <div class="item-quantity w-1/4"><span>${item.quantity}</span></div>
        <div class="item-rate w-1/4"><span>$${item.rate.toFixed(2)}</span></div>
        <div class="item-subtotal w-1/4 text-right">$${(item.quantity * item.rate).toFixed(2)}</div>
    `;
    container.appendChild(row);
}

/**
 * Helper function to calculate totals and update the display.
 * @param {Array<object>} items - The list of invoice items.
 * @param {string} taxRateString - The tax rate as a string (e.g., "0.10").
 */
function calculateTotals(items, taxRateString) {
    let subtotal = 0;
    const taxRate = parseFloat(taxRateString) / 100;
    let taxAmount = 0;

    items.forEach(item => {
        subtotal += item.quantity * item.rate;
    });

    taxAmount = subtotal * taxRate;
    const total = subtotal + taxAmount;

    // Update display elements
    subtotalDisplay.textContent = subtotal.toFixed(2);
    taxRateDisplay.textContent = `${(parseFloat(taxRateString) * 100).toFixed(0)}%`;
    taxDisplay.textContent = taxAmount.toFixed(2);
    totalDisplay.textContent = total.toFixed(2);
}

/**
 * Helper function to attach necessary event listeners.
 */
function attachEventListeners() {
    // Add Item Listener
    addItemButton.addEventListener('click', addItem);

    // Save Invoice Listener
    saveInvoiceButton.addEventListener('click', saveInvoice);

    // Print Invoice Listener
    printInvoiceButton.addEventListener('click', printInvoice);
}

/**
 * Handles adding a new item row to the invoice.
 */
function addItem() {
    const itemName = document.querySelector('.item-name input').value.trim();
    const quantity = parseFloat(document.querySelector('.item-quantity input').value);
    const rate = parseFloat(document.querySelector('.item-rate input').value);

    if (!itemName || isNaN(quantity) || isNaN(rate) || quantity <= 0 || rate <= 0) {
        alert("Please enter valid Item Name, Quantity, and Rate.");
        return;
    }

    const itemListContainer = itemListContainer;
    const newItem = {
        name: itemName,
        quantity: quantity,
        rate: rate
    };

    renderItemRow(itemListContainer, newItem);

    // Recalculate totals after adding the item
    const taxRateInput = taxRateInput.value;
    const items = Array.from(itemListContainer.querySelectorAll('.item-row')).map(row => {
        // Simple way to extract data from the rendered row (requires careful DOM traversal)
        const name = row.querySelector('.item-name span').textContent;
        const quantity = parseFloat(row.querySelector('.item-quantity span').textContent);
        const rate = parseFloat(row.querySelector('.item-rate span').textContent.replace('$', ''));
        return { name, quantity, rate };
    });
    calculateTotals(items, taxRateInput);

    // Clear inputs for the next item
    document.querySelector('.item-name input').value = '';
    document.querySelector('.item-quantity input').value = '';
    document.querySelector('.item-rate input').value = '';
}

/**
 * Handles saving the current invoice data to Local Storage.
 */
function saveInvoice() {
    const customerName = customerNameInput.value;
    const invoiceDate = invoiceDateInput.value;
    const taxRate = taxRateInput.value;

    const items = [];
    const itemListContainer = itemListContainer;

    // Collect item data
    Array.from(itemListContainer.querySelectorAll('.item-row')).forEach(row => {
        items.push({
            name: row.querySelector('.item-name span').textContent,
            quantity: parseFloat(row.querySelector('.item-quantity span').textContent),
            rate: parseFloat(row.querySelector('.item-rate span').textContent.replace('$', ''))
        });
    });

    const invoiceData = {
        customerName: customerName,
        invoiceDate: invoiceDate,
        taxRate: taxRate,
        items: items
    };

    localStorage.setItem('invoiceData', JSON.stringify(invoiceData));
    alert('Invoice saved successfully to local storage!');
}

/**
 * Handles printing the invoice content.
 */
function printInvoice() {
    // Create a clean print view (this assumes CSS handles the layout for printing)
    const printWindow = window.open('', '_blank');
    
    // Get the content to print (the invoice structure)
    const invoiceContent = appContainer.innerHTML;

    // Create a minimal HTML document for printing
    printWindow.document.write('<html><head><title>Invoice Print</title>');
    printWindow.document.write('<style>');
    // Inject necessary print styles (assuming basic styling is defined elsewhere)
    printWindow.document.write(`
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { text-align: center; margin-bottom: 20px; }
        .invoice-details, .invoice-items, .invoice-summary { margin-bottom: 20px; border: 1px solid #ccc; padding: 15px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        .text-right { text-align: right; }
    `);
    printWindow.document.write('</style>');
    printWindow.document.write('</head><body>');
    
    // Inject the invoice content
    printWindow.document.write(invoiceContent);
    
    printWindow.document.write('</body></html>');
    
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
}

// Execute the main function when the script loads
loadInvoiceData();
function saveInvoiceData(invoiceData) {
    // 1. Gather all necessary data from the UI
    const customerName = customerNameInput.value.trim();
    const invoiceDate = invoiceDateInput.value;
    const taxRate = parseFloat(taxRateInput.value) || 0;

    const items = [];
    const itemListContainer = itemListContainer;
    
    // Iterate through dynamically added rows to collect item data
    const rows = itemListContainer.querySelectorAll('.invoice-item-row');
    rows.forEach(row => {
        const name = row.querySelector('.item-name').textContent.trim();
        const quantity = parseFloat(row.querySelector('.item-quantity').textContent);
        const rate = parseFloat(row.querySelector('.item-rate').textContent);

        if (name && !isNaN(quantity) && !isNaN(rate)) {
            items.push({ name, quantity, rate });
        }
    });

    // 2. Calculate totals
    let subtotal = 0;
    items.forEach(item => {
        subtotal += item.quantity * item.rate;
    });

    const taxAmount = subtotal * (taxRate / 100);
    const total = subtotal + taxAmount;

    // 3. Prepare the final data structure
    const dataToSave = {
        customerName: customerName,
        invoiceDate: invoiceDate,
        taxRate: taxRate,
        items: items,
        subtotal: subtotal,
        taxAmount: taxAmount,
        total: total
    };

    // 4. Save to Local Storage
    try {
        localStorage.setItem('invoiceData', JSON.stringify(dataToSave));
        console.log("Invoice data successfully saved.");
    } catch (error) {
        console.error("Error saving invoice data to Local Storage:", error);
    }
}
function addItemRow(name, quantity, rate) {
    const itemListContainer = itemListContainer;
    
    // Calculate subtotal for this specific item
    const subtotal = quantity * rate;

    // Create the row element
    const row = document.createElement('div');
    row.className = 'invoice-item-row';
    row.setAttribute('data-subtotal', subtotal.toFixed(2));

    // Populate the row content
    row.innerHTML = `
        <div class="item-name">
            <input type="text" class="item-name" value="${name}" data-name="${name}">
        </div>
        <div class="item-quantity">
            <input type="number" class="item-quantity" value="${quantity}" data-quantity="${quantity}">
        </div>
        <div class="item-rate">
            <input type="number" class="item-rate" value="${rate.toFixed(2)}" data-rate="${rate}">
        </div>
        <div class="item-subtotal">
            $${subtotal.toFixed(2)}
        </div>
        <button class="remove-item-button" type="button">Remove</button>
    `;

    // Append the new row
    itemListContainer.appendChild(row);

    // Add event listener for removing the row
    row.querySelector('.remove-item-button').addEventListener('click', () => {
        row.remove();
        // Note: In a full application, you would need a mechanism to recalculate totals here.
    });
}
function calculateItemSubtotal(quantity, rate) {
    return quantity * rate;
}
function calculateRunningSubtotal(items) {
    let runningSubtotal = 0;
    for (const item of items) {
        // Assuming each item object has a 'subtotal' property calculated previously,
        // or we calculate it here if the input structure is simple (e.g., array of {quantity, rate}).
        // For robustness, we assume 'items' is an array of objects, and we calculate the subtotal for each.
        const itemSubtotal = calculateItemSubtotal(item.quantity, item.rate);
        runningSubtotal += itemSubtotal;
    }
    return runningSubtotal;
}
function calculateTaxAmount(subtotal, taxRate) {
    return subtotal * taxRate;
}
function calculateTotalBill(subtotal, taxAmount) {
    const total = subtotal + taxAmount;

    // Update the display elements
    subtotalDisplay.textContent = subtotal.toFixed(2);
    taxDisplay.textContent = taxAmount.toFixed(2);
    totalDisplay.textContent = total.toFixed(2);

    return total;
}
{
  "name": "renderInvoice",
  "params": [
    "invoiceData"
  ],
  "description": "Renders the complete invoice data onto the HTML elements for display."
}
function renderInvoice(invoiceData) {
  // 1. Render Customer Information and Date
  document.querySelector(this.itemSection).innerHTML = `
    <div class="invoice-header">
      <h2>Invoice</h2>
      <p>Customer Name: ${invoiceData.customerName}</p>
      <p>Date: ${invoiceData.invoiceDate}</p>
    </div>
  `;

  // 2. Render Itemized List
  let itemRowsHtml = '';
  if (invoiceData.items && invoiceData.items.length > 0) {
    invoiceData.items.forEach(item => {
      const itemSubtotal = item.quantity * item.rate;
      itemRowsHtml += `
        <tr class="invoice-item">
          <td>${item.name}</td>
          <td>${item.quantity}</td>
          <td>$${item.rate.toFixed(2)}</td>
          <td>$${itemSubtotal.toFixed(2)}</td>
        </tr>
      `;
    });
  } else {
    itemRowsHtml = '<tr><td colspan="4">No items added yet.</td></tr>';
  }
  document.querySelector(this.itemListContainer).innerHTML = itemRowsHtml;

  // 3. Calculate Totals
  let subtotal = 0;
  invoiceData.items.forEach(item => {
    subtotal += item.quantity * item.rate;
  });

  const taxAmount = subtotal * invoiceData.taxRate;
  const totalAmount = subtotal + taxAmount;

  // 4. Display Summary
  document.querySelector(this.subtotalDisplay).textContent = `$${subtotal.toFixed(2)}`;
  document.querySelector(this.taxRateDisplay).textContent = `${(invoiceData.taxRate * 100).toFixed(1)}%`;
  document.querySelector(this.taxDisplay).textContent = `$${taxAmount.toFixed(2)}`;
  document.querySelector(this.totalDisplay).textContent = `$${totalAmount.toFixed(2)}`;
}
function exportInvoiceForPrint(invoiceData) {
    // 1. Prepare the print view (CSS manipulation)
    // In a real application, this would involve dynamically adding a print-specific class
    // or manipulating a print-only CSS stylesheet.
    
    // For this implementation, we focus on triggering the print dialog.
    
    // Optional: Temporarily hide non-essential elements (like buttons)
    const elementsToHide = [
        inputSection,
        itemSection,
        summarySection,
        document.getElementById('print-invoice-button')
    ];

    elementsToHide.forEach(el => {
        if (el) {
            el.style.display = 'none';
        }
    });

    // 2. Trigger the print dialog
    window.print();

    // 3. Restore the original state after the print dialog is closed (best effort)
    // Note: Restoring state perfectly requires careful management of the DOM state, 
    // but for a simple print trigger, we assume the print dialog handles the visual output.
    // A robust solution would involve saving and restoring the original state before calling window.print().
}
function addItemButtonClickHandler() {
    // Logic to handle adding a new item row.
    // This typically involves reading input values, creating a new row element,
    // appending it to itemListContainer, and recalculating totals.

    // Example placeholder logic:
    console.log("Add item button clicked. Initiating item addition process.");

    // In a real application, this is where you would:
    // 1. Read values from customerNameInput, invoiceDateInput, taxRateInput.
    // 2. Create a new item row element.
    // 3. Append the new row to itemListContainer.
    // 4. Recalculate subtotal, tax, and total.
    // 5. Call saveState() to persist the updated data.
    // saveState();
}
function saveInvoiceButtonClickHandler() {
    // Logic to serialize and save the current invoice data to Local Storage.

    // 1. Gather all necessary data from the DOM:
    const customerName = customerNameInput.value;
    const invoiceDate = invoiceDateInput.value;
    const taxRate = taxRateInput.value;

    // 2. Gather item data (assuming item rows exist in itemListContainer):
    // const items = getItemsFromList(itemListContainer); // Hypothetical function

    // 3. Gather calculated totals (assuming they are displayed):
    // const subtotal = parseFloat(document.getElementById('subtotalDisplay').textContent);
    // const tax = parseFloat(document.getElementById('taxDisplay').textContent);
    // const total = parseFloat(document.getElementById('totalDisplay').textContent);

    // 4. Create the invoice object:
    const invoiceData = {
        customerName: customerName,
        invoiceDate: invoiceDate,
        taxRate: taxRate,
        // items: items, // Include item details if necessary
        subtotal: 0, // Placeholder
        tax: 0,       // Placeholder
        total: 0      // Placeholder
    };

    // 5. Persist the data:
    try {
        localStorage.setItem('invoiceData', JSON.stringify(invoiceData));
        console.log("Invoice data successfully saved to Local Storage.");
    } catch (error) {
        console.error("Error saving invoice data to Local Storage:", error);
    }
}
function printInvoiceButtonClickHandler() {
    // Logic to trigger the browser's print dialog.

    // This function typically triggers the print command for the current document.
    window.print();

    console.log("Print dialog triggered.");
}

// Event wiring (deterministically generated — do not remove)
function setupEventListeners() {
    addItemButton.addEventListener('click', addItemButtonClickHandler);
    saveInvoiceButton.addEventListener('click', saveInvoiceButtonClickHandler);
    printInvoiceButton.addEventListener('click', printInvoiceButtonClickHandler);
}

// Application entry point (deterministically generated — do not remove)
document.addEventListener('DOMContentLoaded', () => {
    setupEventListeners();
});
