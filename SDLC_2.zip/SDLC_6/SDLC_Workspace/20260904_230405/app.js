/**
 * Web Application Core Skeleton
 * Optimized Vanilla JavaScript for Invoice and Data Management
 */

// --- DOM Element References (Assumed setup based on context) ---
// In a real application, these would be populated by document.getElementById()
const DOM = {
    // Example references (assuming IDs exist in the HTML)
    storage: document.getElementById('storage'),
    clientList: document.getElementById('client-list'),
    invoiceList: document.getElementById('invoice-list'),
    invoiceViewer: document.getElementById('invoice-viewer'),
    invoiceEditor: document.getElementById('invoice-editor'),
    invoiceForm: document.getElementById('invoice-form'),
    printButton: document.getElementById('print-button'),
    downloadButton: document.getElementById('download-button'),
};


/**
 * 1. Storage Management
 * Handles all interactions with localStorage.
 */
function storageManager() {
    /**
     * Handles all interactions with localStorage for persisting client data, service items, and invoice records.
     * Uses a consistent prefix for all stored data to prevent key collisions.
     */

    const STORAGE_PREFIX = 'app_data_';

    /**
     * Saves a structured object to localStorage under a specific key.
     * @param {string} key - The unique identifier for the data set.
     * @param {any} data - The data to be stored (will be JSON stringified).
     * @returns {boolean} True if successful, false otherwise.
     */
    function save(key, data) {
        try {
            const serializedData = JSON.stringify(data);
            localStorage.setItem(STORAGE_PREFIX + key, serializedData);
            return true;
        } catch (error) {
            console.error(`StorageManager Error: Failed to save data for key "${key}".`, error);
            return false;
        }
    }

    /**
     * Loads a structured object from localStorage under a specific key.
     * @param {string} key - The unique identifier for the data set.
     * @returns {any | null} The parsed data object, or null if not found or parsing fails.
     */
    function load(key) {
        try {
            const serializedData = localStorage.getItem(STORAGE_PREFIX + key);
            if (serializedData === null) {
                return null;
            }
            return JSON.parse(serializedData);
        } catch (error) {
            console.error(`StorageManager Error: Failed to load or parse data for key "${key}".`, error);
            return null;
        }
    }

    /**
     * Deletes a specific data set from localStorage.
     * @param {string} key - The unique identifier for the data set.
     * @returns {boolean} True if the item was successfully deleted, false otherwise.
     */
    function delete(key) {
        try {
            localStorage.removeItem(STORAGE_PREFIX + key);
            return true;
        } catch (error) {
            console.error(`StorageManager Error: Failed to delete data for key "${key}".`, error);
            return false;
        }
    }

    // --- Public Interface ---

    /**
     * Saves client data.
     * @param {object} clientData - The client object to save.
     * @returns {boolean} Success status.
     */
    function saveClientData(clientData) {
        return save('clients', clientData);
    }

    /**
     * Loads client data.
     * @returns {object | null} The loaded client array.
     */
    function loadClientData() {
        return load('clients');
    }

    /**
     * Saves item data.
     * @param {object} itemData - The item object to save.
     * @returns {boolean} Success status.
     */
    function saveItemData(itemData) {
        return save('items', itemData);
    }

    /**
     * Loads item data.
     * @returns {object | null} The loaded item array.
     */
    function loadItemData() {
        return load('items');
    }

    /**
     * Saves invoice records.
     * @param {object} invoiceData - The invoice record to save.
     * @returns {boolean} Success status.
     */
    function saveInvoiceData(invoiceData) {
        return save('invoices', invoiceData);
    }

    /**
     * Loads invoice records.
     * @returns {object | null} The loaded invoice array.
     */
    function loadInvoiceData() {
        return load('invoices');
    }
}

/**
 * 2. Client Management (CRUD)
 * Manages client records.
 */
function clientManager() {
    // <PLACEHOLDER id="clientManager"/>
}

/**
 * 3. Item Management (CRUD)
 * Manages service items/products.
 */
function itemManager() {
    // <PLACEHOLDER id="itemManager"/>
}

/**
 * 4. Invoice Creation and Association
 * Manages the creation and linking of invoice records.
 */
function invoiceCreator() {
    /**
     * Handles the creation and association of new invoice records (FR 1.3, 1.4, 1.5).
     * @param {object} invoiceData - The data for the new invoice.
     * @param {Array<object>} lineItems - The list of items for the invoice.
     * @param {object} client - The client details to associate.
     * @returns {object} The newly created invoice object.
     */
    function invoiceCreator(invoiceData, lineItems, client) {
        // 1. Generate a unique ID (simulating database ID generation)
        const newInvoiceId = Date.now().toString();

        // 2. Construct the full invoice structure
        const newInvoice = {
            id: newInvoiceId,
            date: new Date().toISOString().split('T')[0],
            client: {
                id: client.id || 'C' + newInvoiceId, // Ensure client linkage
                name: client.name,
                address: client.address
            },
            lineItems: lineItems,
            total: lineItems.reduce((sum, item) => sum + (item.price * item.quantity), 0),
            status: 'Draft'
        };

        // 3. Store the invoice in the application state (simulated storage)
        if (!window.invoices) {
            window.invoices = [];
        }
        window.invoices.push(newInvoice);

        console.log(`Invoice created successfully with ID: ${newInvoiceId}`);
        return newInvoice;
    }
}

/**
 * 5. Invoice Listing
 * Retrieves and displays the list of all invoices.
 */
function invoiceLister() {
    /**
     * Retrieves and displays the list of all generated invoices (FR 2.1).
     * @param {HTMLElement} container - The DOM element where the list will be rendered.
     */
    function invoiceLister(container) {
        if (!window.invoices || window.invoices.length === 0) {
            container.innerHTML = '<p>No invoices found.</p>';
            return;
        }

        // Clear previous content
        container.innerHTML = '';

        // Build the list structure
        const ul = document.createElement('ul');
        ul.className = 'invoice-list';

        window.invoices.forEach(invoice => {
            const li = document.createElement('li');
            li.className = 'invoice-item';
            // Use template literals for clean, efficient rendering
            li.innerHTML = `
                <strong>Invoice ID:</strong> ${invoice.id} | 
                <strong>Client:</strong> ${invoice.client.name} | 
                <strong>Date:</strong> ${invoice.date} | 
                <strong>Total:</strong> $${invoice.total.toFixed(2)}
            `;
            ul.appendChild(li);
        });

        container.appendChild(ul);
    }
}

/**
 * 6. Invoice Viewing
 * Retrieves the full data set for a specific invoice.
 */
function invoiceViewer() {
    /**
     * Retrieves the full data set for a specific invoice based on an ID (FR 2.2).
     * @param {string} invoiceId - The unique ID of the invoice to retrieve.
     * @param {HTMLElement} container - The DOM element where the invoice details will be rendered.
     */
    function invoiceViewer(invoiceId, container) {
        // 1. Find the specific invoice in the state
        const invoice = window.invoices.find(inv => inv.id === invoiceId);

        if (!invoice) {
            container.innerHTML = `<p class="error">Error: Invoice with ID ${invoiceId} not found.</p>`;
            return;
        }

        // 2. Construct the detailed HTML structure
        let lineItemsHtml = '';
        if (invoice.lineItems && invoice.lineItems.length > 0) {
            lineItemsHtml = '<ul>';
            invoice.lineItems.forEach(item => {
                lineItemsHtml += `<li>${item.quantity} x ${item.name}: $${item.price.toFixed(2)} (Subtotal: $${(item.price * item.quantity).toFixed(2)})</li>`;
            });
            lineItemsHtml += '</ul>';
        } else {
            lineItemsHtml = '<p>No line items found for this invoice.</p>';
        }

        // 3. Render the full invoice details
        container.innerHTML = `
            <div class="invoice-details">
                <h2>Invoice Details (ID: ${invoice.id})</h2>
                <p><strong>Date:</strong> ${invoice.date}</p>
                <p><strong>Status:</strong> ${invoice.status}</p>
                <p><strong>Client:</strong> ${invoice.client.name} (${invoice.client.address})</p>
                <hr>
                <h3>Line Items:</h3>
                ${lineItemsHtml}
                <hr>
                <h3>Total Amount Due: $${invoice.total.toFixed(2)}</h3>
            </div>
        `;
    }
}

/**
 * 7. Invoice Editing
 * Allows the user to modify any field within a selected invoice record.
 */
function invoiceEditor() {
    /**
     * Allows the user to modify any field within a selected invoice record.
     * This function handles the logic for updating the underlying data structure
     * and reflecting changes in the UI.
     *
     * @param {string} invoiceId - The unique ID of the invoice to edit.
     * @param {string} fieldName - The name of the field to be edited (e.g., 'amount', 'description').
     * @param {string} newValue - The new value for the field.
     * @returns {boolean} True if the update was successful, false otherwise.
     */
    function invoiceEditor(invoiceId, fieldName, newValue) {
        // 1. Locate the invoice data (Simulated data access)
        const invoices = window.invoices || [];
        const invoiceIndex = invoices.findIndex(inv => inv.id === invoiceId);

        if (invoiceIndex === -1) {
            console.error(`Invoice with ID ${invoiceId} not found.`);
            return false;
        }

        // 2. Validate the input (Basic check for numeric fields)
        if (fieldName === 'amount' || fieldName === 'tax' || fieldName === 'total') {
            const numericValue = parseFloat(newValue);
            if (isNaN(numericValue) || numericValue < 0) {
                console.error(`Invalid numeric value provided for field: ${fieldName}`);
                return false;
            }
            invoices[invoiceIndex][fieldName] = numericValue;
        } else {
            // Handle string fields
            invoices[invoiceIndex][fieldName] = newValue.trim();
        }

        // 3. Persist the change (Simulated storage update)
        window.invoices = invoices; // Update the global state
        console.log(`Invoice ${invoiceId} updated: ${fieldName} set to ${newValue}`);

        // 4. Refresh the UI (Crucial for stability)
        refreshInvoiceDisplay(invoiceId);

        return true;
    }

    /**
     * Helper function to refresh the specific invoice display in the DOM.
     * This ensures the UI accurately reflects the updated data.
     * @param {string} invoiceId
     */
    function refreshInvoiceDisplay(invoiceId) {
        const invoice = window.invoices.find(inv => inv.id === invoiceId);
        if (!invoice) return;

        // Example DOM update logic (assuming an element with ID 'invoice-view' exists)
        const viewElement = document.getElementById(`invoice-view-${invoiceId}`);
        if (viewElement) {
            // Highly optimized update: only update the necessary fields
            viewElement.querySelector('[data-field="amount"]').textContent = invoice.amount.toFixed(2);
            viewElement.querySelector('[data-field="description"]').textContent = invoice.description;
            // ... update other fields dynamically
        }
    }
}

/**
 * 8. Invoice Deletion
 * Removes a generated invoice record.
 */
function invoiceDeleter() {
    /**
     * Removes a generated invoice record from storage.
     * This function ensures data integrity by removing the record and updating the UI.
     *
     * @param {string} invoiceId - The unique ID of the invoice to delete.
     * @returns {boolean} True if the deletion was successful, false otherwise.
     */
    function invoiceDeleter(invoiceId) {
        if (!window.invoices) {
            console.error("No invoice data found in storage.");
            return false;
        }

        const initialLength = window.invoices.length;
        
        // Filter out the invoice to be deleted
        window.invoices = window.invoices.filter(invoice => invoice.id !== invoiceId);

        if (window.invoices.length < initialLength) {
            console.log(`Invoice ${invoiceId} successfully deleted.`);
            
            // Refresh the UI to reflect the change
            document.getElementById(`invoice-view-${invoiceId}`)?.remove();
            
            return true;
        } else {
            console.error(`Failed to delete invoice ${invoiceId}: Record not found.`);
            return false;
        }
    }
}

/**
 * 9. Invoice Formatting
 * Generates the final, printable HTML or text representation.
 */
function invoiceFormatter() {
    // <PLACEHOLDER id="invoiceFormatter"/>
}

/**
 * 10. Printing
 * Triggers the browser's native print dialog.
 */
function printInvoice() {
    /**
     * Triggers the browser's native print dialog using the formatted invoice view.
     * This function relies on the CSS media query (@media print) to ensure only the invoice
     * content is printed cleanly.
     */
    function printInvoice() {
        // The window.print() method is the most reliable way to trigger the native print dialog.
        // It relies on the CSS styling (specifically @media print) to handle the visual formatting.
        window.print();
    }
}

/**
 * 11. Downloading
 * Converts the formatted invoice data into a downloadable file format.
 */
function downloadInvoice() {
    /**
     * Converts the formatted invoice data into a downloadable file format (e.g., plain text or CSV).
     * For maximum compatibility and simplicity in Vanilla JS, we will generate a plain text file.
     *
     * @param {Array<Object>} invoiceData - The structured data of the invoice.
     * @returns {void}
     */
    function downloadInvoice(invoiceData) {
        if (!invoiceData || invoiceData.length === 0) {
            console.error("Download failed: No invoice data provided.");
            return;
        }

        // 1. Format the data into a readable string (e.g., CSV or plain text)
        let content = "--- INVOICE ---

";
        content += `Invoice Date: ${new Date().toLocaleDateString()}

`;
        content += "Item | Quantity | Unit Price | Total
";
        content += "--------------------------------------------------
";

        let subtotal = 0;

        invoiceData.forEach(item => {
            const lineTotal = item.quantity * item.price;
            subtotal += lineTotal;
            content += `${item.name} | ${item.quantity} | $${item.price.toFixed(2)} | $${lineTotal.toFixed(2)}
`;
        });

        // 2. Calculate totals
        const taxRate = invoiceData.taxRate || 0;
        const taxAmount = subtotal * (taxRate / 100);
        const finalTotal = subtotal + taxAmount;

        content += "
--------------------------------------------------
";
        content += `Subtotal: $${subtotal.toFixed(2)}
`;
        content += `Tax (${taxRate}%): $${taxAmount.toFixed(2)}
`;
        content += `TOTAL DUE: $${finalTotal.toFixed(2)}
`;

        // 3. Create a Blob and trigger the download
        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `invoice_${new Date().toISOString().split('T')[0]}.txt`;
        
        // Programmatically click the link to initiate download
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }
}

/**
 * 12. Invoice Calculation
 * Performs all necessary financial calculations.
 */
function invoiceCalculator() {
    /**
     * Performs all necessary financial calculations for an invoice, including
     * calculating subtotals, taxes, and final totals.
     *
     * @param {Array<Object>} items - An array of invoice line items. Each item must have 'quantity' and 'price'.
     * @param {number} taxRate - The tax rate percentage (e.g., 8.5 for 8.5%).
     * @returns {Object} An object containing the calculated financial summary.
     */
    function invoiceCalculator(items, taxRate) {
        if (!Array.isArray(items) || items.length === 0) {
            return { subtotal: 0, tax: 0, total: 0, error: "No items provided." };
        }

        let subtotal = 0;

        // 1. Calculate Subtotal
        for (const item of items) {
            // Ensure quantity and price are treated as numbers for calculation
            const quantity = parseFloat(item.quantity) || 0;
            const price = parseFloat(item.price) || 0;
            
            subtotal += quantity * price;
        }

        // 2. Calculate Tax
        const taxDecimal = taxRate / 100;
        const taxAmount = subtotal * taxDecimal;

        // 3. Calculate Final Total
        const finalTotal = subtotal + taxAmount;

        // Return the structured result, ensuring high precision for financial data
        return {
            subtotal: parseFloat(subtotal.toFixed(2)),
            tax: parseFloat(taxAmount.toFixed(2)),
            total: parseFloat(finalTotal.toFixed(2))
        };
    }
}


// --- Initialization and Event Binding (Skeleton) ---

/**
 * Initializes the application by setting up event listeners.
 */
function initializeApp() {
    // Bind event listeners here (e.g., DOM.printButton.addEventListener('click', printInvoice))
    console.log("Application skeleton initialized. Ready for logic implementation.");
}

// Execute initialization
initializeApp();