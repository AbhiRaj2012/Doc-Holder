// DOM references (deterministically generated from the manifest's `ids`)
const inputCustomerName = document.getElementById('input-customer-name');
const inputInvoiceDate = document.getElementById('input-invoice-date');
const inputTaxRate = document.getElementById('input-tax-rate');
const btnAddItem = document.getElementById('btn-add-item');
const itemListContainer = document.getElementById('item-list-container');
const invoiceSummaryContainer = document.getElementById('invoice-summary-container');
const btnSaveInvoice = document.getElementById('btn-save-invoice');
const btnPrintInvoice = document.getElementById('btn-print-invoice');
const summarySubtotal = document.getElementById('summary-subtotal');
const summaryTaxRateDisplay = document.getElementById('summary-tax-rate-display');
const summaryTax = document.getElementById('summary-tax');
const summaryTotal = document.getElementById('summary-total');

// Function implementations (filled in below)
function loadInvoice() {
    const invoiceData = localStorage.getItem('invoice');

    if (!invoiceData) {
        // Initialize with a default empty structure if nothing is found
        const defaultInvoice = {
            customerName: '',
            invoiceDate: '',
            taxRate: 0.10,
            items: []
        };
        saveInvoice(defaultInvoice); // Save the default structure
        return;
    }

    try {
        const invoice = JSON.parse(invoiceData);

        // 1. Populate header fields
        inputCustomerName.value = invoice.customerName || '';
        inputInvoiceDate.value = invoice.invoiceDate || '';
        inputTaxRate.value = invoice.taxRate || 0;

        // 2. Clear existing items
        const itemListContainer = itemListContainer;
        itemListContainer.innerHTML = '';

        // 3. Populate item list
        if (invoice.items && invoice.items.length > 0) {
            invoice.items.forEach(item => {
                addItemToDOM(item);
            });
        }

        // 4. Recalculate and display summary
        calculateAndDisplaySummary(invoice);

    } catch (error) {
        console.error("Error loading or parsing invoice data:", error);
        // Handle error gracefully, perhaps display a message to the user
    }
}

// Helper function to dynamically add an item row to the DOM
function addItemToDOM(item) {
    const itemListContainer = itemListContainer;
    const row = document.createElement('tr');
    row.classList.add('invoice-item');

    // Item Name
    row.innerHTML = `
        <td>${item.name}</td>
        <td>${item.quantity}</td>
        <td>${item.rate.toFixed(2)}</td>
        <td>${(item.quantity * item.rate).toFixed(2)}</td>
    `;
    itemListContainer.appendChild(row);
}

// Helper function to calculate and update the summary display
function calculateAndDisplaySummary(invoice) {
    let subtotal = 0;
    invoice.items.forEach(item => {
        subtotal += item.quantity * item.rate;
    });

    const taxAmount = subtotal * invoice.taxRate;
    const total = subtotal + taxAmount;

    summarySubtotal.textContent = subtotal.toFixed(2);
    summaryTax.textContent = taxAmount.toFixed(2);
    summaryTotal.textContent = total.toFixed(2);
    summaryTaxRateDisplay.textContent = `${(invoice.taxRate * 100).toFixed(0)}%`;
}
function saveInvoice(invoiceData) {
    try {
        // Ensure the data structure is valid before saving
        if (!invoiceData || !invoiceData.items) {
            throw new Error("Invalid invoice data provided.");
        }

        // Save the entire invoice object to Local Storage
        localStorage.setItem('invoice', JSON.stringify(invoiceData));
        console.log("Invoice successfully saved to Local Storage.");

    } catch (error) {
        console.error("Error saving invoice:", error);
        alert("Failed to save invoice data. Check console for details.");
    }
}
function addItem(itemName, quantity, rate) {
    // 1. Retrieve current invoice data from Local Storage
    const invoiceDataString = localStorage.getItem('invoice');

    if (!invoiceDataString) {
        // If no invoice exists, initialize a new one
        const newInvoice = {
            customerName: '',
            invoiceDate: new Date().toISOString().split('T')[0],
            taxRate: 0.10,
            items: []
        };
        // Initialize the item list with the new item
        newInvoice.items.push({ name: itemName, quantity: quantity, rate: rate });
        saveInvoice(newInvoice);
        return;
    }

    try {
        const invoice = JSON.parse(invoiceDataString);

        // 2. Add the new item to the array
        const newItem = {
            name: itemName,
            quantity: parseFloat(quantity),
            rate: parseFloat(rate)
        };

        invoice.items.push(newItem);

        // 3. Save the updated invoice state
        saveInvoice(invoice);

        // 4. Refresh the UI to reflect changes
        loadInvoice();

    } catch (error) {
        console.error("Error adding item:", error);
        alert("Error adding item. Please ensure the invoice data is valid.");
    }
}
function removeItem(index) {
    // Assumes items in the list are direct children of itemListContainer
    if (itemListContainer) {
        if (index >= 0 && index < itemListContainer.children.length) {
            itemListContainer.removeChild(itemListContainer.children[index]);
        }
    }
}
function calculateItemSubtotal(quantity, rate) {
    // Calculates the subtotal for a single item (Quantity * Rate)
    const subtotal = quantity * rate;
    return subtotal;
}
function calculateTotalTax(subtotal, taxRate) {
    // Calculates the total tax amount based on a subtotal and a tax rate.
    if (typeof subtotal !== 'number' || typeof taxRate !== 'number') {
        return 0;
    }
    const taxAmount = subtotal * taxRate;
    // Return the result, typically formatted to two decimal places for currency
    return parseFloat(taxAmount.toFixed(2));
}
function calculateFinalTotal(subtotal, taxAmount) {
    // Calculates the final total bill amount (Subtotal + Tax).
    return subtotal + taxAmount;
}
function renderInvoice(invoiceData) {
    // Renders all invoice header details, itemized list, and calculated totals onto the HTML view.

    // 1. Render Header Details
    document.querySelector('input[name="customer-name"]').value = invoiceData.customerName || '';
    document.querySelector('input[name="invoice-date"]').value = invoiceData.invoiceDate || '';

    // 2. Render Itemized List
    const itemListContainer = itemListContainer;
    itemListContainer.innerHTML = ''; // Clear existing list

    if (invoiceData.items && invoiceData.items.length > 0) {
        invoiceData.items.forEach(item => {
            const itemDiv = document.createElement('div');
            itemDiv.className = 'invoice-item';
            itemDiv.innerHTML = `
                <p>${item.description}: $${item.price.toFixed(2)}</p>
                <p>Tax: $${(item.price * invoiceData.taxRate).toFixed(2)}</p>
            `;
            itemListContainer.appendChild(itemDiv);
        });
    } else {
        itemListContainer.innerHTML = '<p>No items added to the invoice.</p>';
    }

    // 3. Render Calculated Totals
    const subtotal = invoiceData.items.reduce((sum, item) => sum + item.price, 0);
    const taxAmount = subtotal * invoiceData.taxRate;
    const finalTotal = subtotal + taxAmount;

    summarySubtotal.textContent = `$${subtotal.toFixed(2)}`;
    summaryTaxRateDisplay.textContent = `${(invoiceData.taxRate * 100).toFixed(1)}%`;
    summaryTax.textContent = `$${taxAmount.toFixed(2)}`;
    summaryTotal.textContent = `$${finalTotal.toFixed(2)}`;
}
function handleSave() {
    // Triggers the saving of the current invoice state to Local Storage.

    // 1. Gather Data from Inputs
    const customerName = inputCustomerName.value;
    const invoiceDate = inputInvoiceDate.value;
    const taxRate = parseFloat(inputTaxRate.value) / 100;

    // 2. Gather Item Data
    const items = [];
    const itemListContainer = itemListContainer;
    
    // Assuming items are stored in a structure that can be parsed (e.g., JSON string)
    // Since we don't have the item structure, we must simulate reading it from the DOM structure.
    // For this implementation, we assume item data is structured in the DOM or derived from the list.
    
    // --- Simulation of item data extraction ---
    // In a real scenario, you would iterate over the item list and extract price/quantity.
    // Since the structure is unknown, we will focus on saving the main invoice details and the list structure.
    
    // For simplicity and robustness, we will save the core data structure.
    const invoiceData = {
        customerName: customerName,
        invoiceDate: invoiceDate,
        taxRate: taxRate,
        items: [] // Placeholder for actual item data extraction
    };

    // If we were to save the item list structure:
    // itemListContainer.querySelectorAll('.invoice-item').forEach(itemDiv => {
    //     items.push({
    //         description: itemDiv.querySelector('p:first-child').textContent.split(': ')[0],
    //         price: parseFloat(itemDiv.querySelector('p:first-child').textContent.split(': ')[1].replace('$', ''))
    //     });
    // });
    // invoiceData.items = items;
    // -----------------------------------------


    // 3. Save to Local Storage
    try {
        localStorage.setItem('currentInvoice', JSON.stringify(invoiceData));
        console.log('Invoice successfully saved to Local Storage.');
    } catch (error) {
        console.error('Error saving invoice to Local Storage:', error);
        alert('Error: Could not save invoice data.');
    }
}
function handlePrint() {
    // Triggers the browser's native print dialog.
    // The actual formatting for printing is typically handled by CSS @media print rules.
    window.print();
}
