// DOM references (deterministically generated from the manifest's `ids`)
const customerName = document.getElementById('customer-name');
const customerAddress = document.getElementById('customer-address');
const taxRate = document.getElementById('tax-rate');
const addItemBtn = document.getElementById('add-item-btn');
const invoicePreview = document.getElementById('invoice-preview');
const saveInvoiceBtn = document.getElementById('save-invoice-btn');
const printInvoiceBtn = document.getElementById('print-invoice-btn');
const ledgerDisplay = document.getElementById('ledger-display');
const invoiceDetailsView = document.getElementById('invoice-details-view');
const clearFormBtn = document.getElementById('clear-form-btn');

// Function implementations (filled in below)
function addItem(itemName, quantity, rate) {
    // Assume 'invoiceItems' is the global array holding the invoice line items.
    // We need to ensure the data structure is updated and then trigger a recalculation/render.

    // 1. Create the new item object
    const newItem = {
        name: itemName,
        quantity: parseFloat(quantity),
        rate: parseFloat(rate),
        subtotal: parseFloat(quantity) * parseFloat(rate)
    };

    // 2. Add the item to the invoice data structure (assuming 'invoiceItems' exists)
    if (typeof invoiceItems === 'undefined') {
        invoiceItems = [];
    }
    invoiceItems.push(newItem);

    // 3. Trigger recalculation and rendering
    calculateInvoiceTotals(invoiceItems, taxRate);
    renderInvoice(invoiceItems);
}
function calculateInvoiceTotals(items, taxRate) {
    let subtotal = 0;

    // 1. Calculate the subtotal of all items
    for (const item of items) {
        subtotal += item.subtotal;
    }

    // 2. Calculate the tax amount
    const taxAmount = subtotal * (taxRate / 100);

    // 3. Calculate the grand total
    const grandTotal = subtotal + taxAmount;

    // Store results in a structure for rendering
    const totals = {
        subtotal: subtotal,
        taxAmount: taxAmount,
        grandTotal: grandTotal
    };

    // Store totals globally or in a scope accessible by renderInvoice
    invoiceTotals = totals;
}
function renderInvoice(invoiceData) {
    // Ensure the necessary global variables are accessible (assuming they are defined elsewhere)
    // For demonstration, we assume invoiceData contains the items and the calculated totals.

    if (!invoiceData || invoiceData.length === 0) {
        invoicePreview.innerHTML = '<h2>Invoice is empty. Add items to begin.</h2>';
        ledgerDisplay.innerHTML = '';
        return;
    }

    // 1. Render the item list to the invoice preview area
    let itemRows = '';
    invoiceData.forEach(item => {
        itemRows += `
            <tr>
                <td>${item.name}</td>
                <td>${item.quantity}</td>
                <td>$${item.rate.toFixed(2)}</td>
                <td>$${item.subtotal.toFixed(2)}</td>
            </tr>
        `;
    });

    const itemTableHTML = `
        <table>
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Qty</th>
                    <th>Rate</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                ${itemRows}
            </tbody>
        </table>
    `;

    invoicePreview.innerHTML = itemTableHTML;

    // 2. Render the totals to the ledger display area
    const totals = invoiceTotals || { subtotal: 0, taxAmount: 0, grandTotal: 0 };

    ledgerDisplay.innerHTML = `
        <h3>Invoice Summary</h3>
        <p>Subtotal: $${totals.subtotal.toFixed(2)}</p>
        <p>Tax (${(taxRate || 0).toFixed(2)}%): $${totals.taxAmount.toFixed(2)}</p>
        <hr>
        <strong>Grand Total: $${totals.grandTotal.toFixed(2)}</strong>
    `;
}
function saveInvoice(invoiceData) {
    const invoices = loadInvoices() || [];

    // Generate a unique ID (using timestamp for simplicity, though a UUID would be better in production)
    const id = Date.now().toString();

    // Add the new invoice to the array
    invoices.push({ id: id, ...invoiceData });

    // Save the updated array back to Local Storage
    localStorage.setItem('invoices', JSON.stringify(invoices));
}
function loadInvoices() {
    try {
        const data = localStorage.getItem('invoices');
        if (data) {
            return JSON.parse(data);
        }
        // Return an empty array if no data is found
        return [];
    } catch (error) {
        console.error("Error loading invoices from Local Storage:", error);
        return [];
    }
}
function renderLedger(invoices) {
    const ledgerDisplay = document.getElementById('ledgerDisplay');
    if (!ledgerDisplay) {
        console.error("Element with ID 'ledgerDisplay' not found.");
        return;
    }

    // Clear previous content
    ledgerDisplay.innerHTML = '';

    if (!invoices || invoices.length === 0) {
        ledgerDisplay.innerHTML = '<p>No invoices found in the ledger.</p>';
        return;
    }

    // Render each invoice
    invoices.forEach(invoice => {
        const invoiceElement = document.createElement('div');
        invoiceElement.className = 'invoice-item';
        
        // Use template literals for clean rendering
        invoiceElement.innerHTML = `
            <h3>Invoice ID: ${invoice.id}</h3>
            <p><strong>Customer:</strong> ${invoice.customerName || 'N/A'}</p>
            <p><strong>Address:</strong> ${invoice.customerAddress || 'N/A'}</p>
            <p><strong>Tax Rate:</strong> ${invoice.taxRate || 'N/A'}</p>
            <hr>
        `;
        
        ledgerDisplay.appendChild(invoiceElement);
    });
}
function handleSaveClick() {
    // 1. Gather data from the form elements
    const customerName = document.getElementById('customerName').value; // Assuming input IDs exist
    const customerAddress = document.getElementById('customerAddress').value;
    const taxRate = document.getElementById('taxRate').value;

    // 2. Simulate saving the data (In a real application, this would be an API call)
    const invoiceData = {
        id: Date.now(), // Simple unique ID simulation
        customerName: customerName,
        customerAddress: customerAddress,
        taxRate: taxRate,
        timestamp: new Date().toISOString()
    };

    // 3. Update the ledger view
    const ledgerDisplay = document.getElementById('ledgerDisplay');
    
    if (invoiceData) {
        const newEntry = `Invoice saved successfully! ID: ${invoiceData.id}. Customer: ${invoiceData.customerName}.`;
        
        // Append the new entry to the ledger display
        ledgerDisplay.innerHTML += `<p>${newEntry}</p>`;
        
        // Optionally clear the form after saving
        // document.getElementById('invoiceForm').reset();
    } else {
        console.error("Error: Could not gather invoice data for saving.");
    }
}
function printInvoice(invoiceId) {
    // In a real application, you would fetch the specific invoice data based on invoiceId
    // and populate the print view.

    // For demonstration, we assume the invoice details are available in the invoiceDetailsView
    const invoiceDetailsView = document.getElementById('invoiceDetailsView');
    
    if (!invoiceId) {
        alert("Error: Invoice ID is required to print.");
        return;
    }

    // Simulate loading the invoice content (e.g., fetching data based on invoiceId)
    const invoiceContent = `
        <h1>Invoice Details (ID: ${invoiceId})</h1>
        <p>This is the content of the invoice that will be printed.</p>
        <p>Customer Name: John Doe</p>
        <p>Address: 123 Main St</p>
        <p>Tax Rate: 10%</p>
        <hr>
        <p>Generated on: ${new Date().toLocaleDateString()}</p>
    `;

    // Create a temporary window/element to display the content for printing
    const printWindow = window.open('', '_blank');
    printWindow.document.write('<html><head><title>Invoice Print</title></head><body>');
    printWindow.document.write(invoiceContent);
    printWindow.document.write('</body></html>');
    printWindow.document.close();

    // Trigger the print dialog
    printWindow.focus();
    printWindow.print();
}
