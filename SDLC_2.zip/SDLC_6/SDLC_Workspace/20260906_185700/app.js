// DOM references (deterministically generated from the manifest's `ids`)
const inputCustomerName = document.getElementById('input-customer-name');
const inputInvoiceDate = document.getElementById('input-invoice-date');
const inputTaxRate = document.getElementById('input-tax-rate');
const itemListContainer = document.getElementById('item-list-container');
const addItemButton = document.getElementById('add-item-button');
const invoiceOutputArea = document.getElementById('invoice-output-area');
const saveInvoiceButton = document.getElementById('save-invoice-button');
const printInvoiceButton = document.getElementById('print-invoice-button');
const appContainer = document.getElementById('app-container');
const inputSection = document.getElementById('input-section');
const itemTableHeader = document.getElementById('item-table-header');
const itemList = document.getElementById('item-list');
const invoiceDetails = document.getElementById('invoice-details');
const displayCustomerName = document.getElementById('display-customer-name');
const displayInvoiceDate = document.getElementById('display-invoice-date');
const displaySubtotal = document.getElementById('display-subtotal');
const displayTaxRate = document.getElementById('display-tax-rate');
const displayTax = document.getElementById('display-tax');
const displayTotal = document.getElementById('display-total');

// Function implementations (filled in below)
function loadInvoice() {
    const invoiceData = JSON.parse(localStorage.getItem('invoiceData'));

    if (!invoiceData) {
        // Initialize defaults if no data exists
        inputCustomerName.value = '';
        inputInvoiceDate.value = new Date().toISOString().split('T')[0];
        inputTaxRate.value = '0.10'; // Default tax rate
        itemList.innerHTML = '';
        displayCustomerName.textContent = 'Customer Name';
        displayInvoiceDate.textContent = new Date().toLocaleDateString();
        displaySubtotal.textContent = '0.00';
        displayTax.textContent = '0.00';
        displayTotal.textContent = '0.00';
        return;
    }

    // Populate customer details
    inputCustomerName.value = invoiceData.customerName || '';
    inputInvoiceDate.value = invoiceData.invoiceDate || '';
    inputTaxRate.value = invoiceData.taxRate || '0.10';

    // Clear existing items
    const itemListContainer = itemListContainer;
    itemListContainer.innerHTML = '';

    // Populate item list
    invoiceData.items.forEach(item => {
        const itemRow = document.createElement('tr');
        itemRow.innerHTML = `
            <td>${item.name}</td>
            <td>${item.quantity}</td>
            <td>${item.rate.toFixed(2)}</td>
            <td>${(item.quantity * item.rate).toFixed(2)}</td>
        `;
        itemListContainer.appendChild(itemRow);
    });

    // Recalculate totals
    let subtotal = 0;
    invoiceData.items.forEach(item => {
        subtotal += item.quantity * item.rate;
    });

    const taxAmount = subtotal * parseFloat(inputTaxRate.value);
    const total = subtotal + taxAmount;

    // Update display fields
    displayCustomerName.textContent = invoiceData.customerName || 'Customer Name';
    displayInvoiceDate.textContent = invoiceData.invoiceDate || '';
    displaySubtotal.textContent = subtotal.toFixed(2);
    displayTax.textContent = taxAmount.toFixed(2);
    displayTotal.textContent = total.toFixed(2);
}
function saveInvoice() {
    // 1. Gather Customer and Invoice details
    const customerName = inputCustomerName.value.trim();
    const invoiceDate = inputInvoiceDate.value.trim();
    const taxRate = parseFloat(inputTaxRate.value);

    // 2. Gather Item data
    const items = [];
    const itemListContainer = itemListContainer;

    // Iterate through the item list to extract data
    const rows = itemListContainer.querySelectorAll('tr');
    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        if (cells.length >= 4) {
            const name = cells[0].textContent.trim();
            const quantity = parseFloat(cells[1].textContent);
            const rate = parseFloat(cells[2].textContent);
            const subtotal = quantity * rate;

            items.push({
                name: name,
                quantity: quantity,
                rate: rate,
                subtotal: subtotal
            });
        }
    });

    // 3. Calculate totals (re-calculation for safety)
    let subtotal = items.reduce((acc, item) => acc + item.subtotal, 0);
    const taxAmount = subtotal * taxRate;
    const total = subtotal + taxAmount;

    // 4. Prepare data for storage
    const invoiceData = {
        customerName: customerName,
        invoiceDate: invoiceDate,
        taxRate: taxRate,
        items: items,
        subtotal: subtotal,
        tax: taxAmount,
        total: total
    };

    // 5. Save to Local Storage
    localStorage.setItem('invoiceData', JSON.stringify(invoiceData));
    console.log('Invoice saved successfully.');
}
function addItem(itemName, quantity, rate) {
    const itemListContainer = itemListContainer;

    if (!itemName || !quantity || !rate) {
        console.error("Missing required item details.");
        return;
    }

    const itemSubtotal = parseFloat(quantity) * parseFloat(rate);

    // Create the new row element
    const itemRow = document.createElement('tr');
    itemRow.innerHTML = `
        <td>${itemName}</td>
        <td>${quantity}</td>
        <td>${rate.toFixed(2)}</td>
        <td>${itemSubtotal.toFixed(2)}</td>
    `;

    // Append the new row to the list
    itemListContainer.appendChild(itemRow);

    // Recalculate totals
    let currentSubtotal = 0;
    const rows = itemListContainer.querySelectorAll('tr');

    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        if (cells.length >= 4) {
            const quantity = parseFloat(cells[1].textContent);
            const rate = parseFloat(cells[2].textContent);
            const itemSubtotal = quantity * rate;
            currentSubtotal += itemSubtotal;
        }
    });

    const taxRate = parseFloat(inputTaxRate.value);
    const taxAmount = currentSubtotal * taxRate;
    const total = currentSubtotal + taxAmount;

    // Update display fields
    displaySubtotal.textContent = currentSubtotal.toFixed(2);
    displayTax.textContent = taxAmount.toFixed(2);
    displayTotal.textContent = total.toFixed(2);
}
function calculateItemSubtotal(quantity, rate) {
    return quantity * rate;
}
function calculateTotals(itemSubtotals) {
    if (!itemSubtotals || itemSubtotals.length === 0) {
        return {
            subtotal: 0,
            tax: 0,
            total: 0
        };
    }

    const subtotal = itemSubtotals.reduce((sum, current) => sum + current, 0);
    const taxRate = parseFloat(inputTaxRate.value) || 0;
    const tax = subtotal * (taxRate / 100);
    const total = subtotal + tax;

    return {
        subtotal: subtotal,
        tax: tax,
        total: total
    };
}
function renderInvoice(invoiceData) {
    // 1. Render Customer and Date Details
    displayCustomerName.textContent = invoiceData.customerName;
    displayInvoiceDate.textContent = invoiceData.invoiceDate;

    // 2. Render Line Items
    const itemList = itemList;
    itemList.innerHTML = ''; // Clear existing list

    invoiceData.items.forEach(item => {
        const row = itemList.insertRow();
        
        // Quantity
        row.insertCell().textContent = item.quantity;
        
        // Rate
        row.insertCell().textContent = item.rate.toFixed(2);
        
        // Subtotal
        const subtotalCell = row.insertCell();
        subtotalCell.textContent = item.subtotal.toFixed(2);
    });

    // 3. Calculate and Render Totals
    const totals = calculateTotals(invoiceData.items.map(item => item.subtotal));

    displaySubtotal.textContent = totals.subtotal.toFixed(2);
    displayTax.textContent = totals.tax.toFixed(2);
    displayTotal.textContent = totals.total.toFixed(2);
}
function printInvoice() {
    // Trigger the browser's print dialog.
    // In a real-world scenario, this function would typically ensure that
    // the CSS for printing (e.g., hiding navigation, adjusting margins)
    // is applied before calling window.print().
    window.print();
}
