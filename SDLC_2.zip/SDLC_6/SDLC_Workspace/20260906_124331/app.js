// DOM references (deterministically generated from the manifest's `ids`)
const headerContainer = document.getElementById('header-container');
const itemListContainer = document.getElementById('item-list-container');
const itemRowTemplate = document.getElementById('item-row-template');
const itemNameInput = document.getElementById('item-name-input');
const itemQuantityInput = document.getElementById('item-quantity-input');
const itemRateInput = document.getElementById('item-rate-input');
const itemSubtotalDisplay = document.getElementById('item-subtotal-display');
const overallSubtotalDisplay = document.getElementById('overall-subtotal-display');
const taxAmountDisplay = document.getElementById('tax-amount-display');
const finalTotalDisplay = document.getElementById('final-total-display');
const invoiceApp = document.getElementById('invoice-app');
const customerName = document.getElementById('customer-name');
const invoiceDate = document.getElementById('invoice-date');
const taxRate = document.getElementById('tax-rate');
const invoiceItems = document.getElementById('invoice-items');
const totalsSection = document.getElementById('totals-section');
const actions = document.getElementById('actions');
const addItemBtn = document.getElementById('add-item-btn');
const saveInvoiceBtn = document.getElementById('save-invoice-btn');
const printInvoiceBtn = document.getElementById('print-invoice-btn');

// Function implementations (filled in below)
function loadInvoiceData() {
    try {
        const data = localStorage.getItem('invoiceData');
        if (!data) {
            // Initialize default state if no data exists
            const defaultInvoice = {
                customerName: 'Client Name',
                invoiceDate: new Date().toISOString().split('T')[0],
                taxRate: 0.10,
                items: []
            };
            saveInvoiceData(defaultInvoice); // Save default state
            return;
        }

        const invoiceData = JSON.parse(data);

        // 1. Populate Header Data
        customerName.value = invoiceData.customerName || '';
        invoiceDate.value = invoiceData.invoiceDate || '';
        taxRate.value = (invoiceData.taxRate * 100).toFixed(2); // Display as percentage
        
        // 2. Populate Items
        const itemListContainer = itemListContainer;
        itemListContainer.innerHTML = ''; // Clear existing rows
        
        invoiceData.items.forEach(item => {
            addItemRow(item.name, item.quantity, item.rate);
        });

        // 3. Recalculate Totals (This step is crucial for a functional load)
        // Note: Since we don't have the full calculation logic here, we assume the totals are recalculated 
        // by the main application logic after loading the items.
        // For a complete implementation, we would call a function to recalculate totals based on invoiceItems.

    } catch (error) {
        console.error("Error loading invoice data:", error);
    }
}
function saveInvoiceData(invoiceData) {
    try {
        // Ensure items are correctly formatted before saving
        const itemsToSave = invoiceData.items.map(item => ({
            name: itemNameInput.value,
            quantity: parseFloat(itemQuantityInput.value) || 0,
            rate: parseFloat(itemRateInput.value) || 0,
        }));

        const dataToStore = {
            customerName: customerName.value,
            invoiceDate: invoiceDate.value,
            taxRate: parseFloat(taxRate.value) / 100, // Store as decimal
            items: itemsToSave,
            // Totals would typically be calculated and stored here too
        };

        localStorage.setItem('invoiceData', JSON.stringify(dataToStore));
        console.log("Invoice data saved successfully.");

    } catch (error) {
        console.error("Error saving invoice data:", error);
    }
}
function addItemRow(name = '', quantity = '', rate = '') {
    const itemListContainer = itemListContainer;
    const itemRowTemplate = itemRowTemplate;

    // 1. Create the new row element
    const newRow = itemRowTemplate.content.cloneNode(true);
    
    // 2. Populate the inputs in the new row
    const nameInput = newRow.querySelector('.item-name-input');
    const quantityInput = newRow.querySelector('.item-quantity-input');
    const rateInput = newRow.querySelector('.item-rate-input');
    const subtotalDisplay = newRow.querySelector('.item-subtotal-display');

    nameInput.value = name;
    quantityInput.value = quantity;
    rateInput.value = rate;

    // 3. Calculate the subtotal for this row
    const subtotal = parseFloat(quantity) * parseFloat(rate);
    subtotalDisplay.textContent = subtotal.toFixed(2);

    // 4. Append the new row to the list
    itemListContainer.appendChild(newRow);

    // 5. Trigger recalculation of overall totals (assuming the main app handles this)
    // In a real application, you would call a function here to update overallSubtotalDisplay, taxAmountDisplay, etc.
    // For this implementation, we just ensure the row is added.
}
function calculateItemSubtotal(rate, quantity) {
    // Calculates the subtotal for a single item (Rate * Quantity).
    return rate * quantity;
}
function calculateInvoiceTotals(items, taxRate) {
    let overallSubtotal = 0;

    // 1. Calculate overall subtotal
    for (const item of items) {
        // Assuming item.subtotal is already calculated or calculated here
        const itemSubtotal = calculateItemSubtotal(item.rate, item.quantity);
        overallSubtotal += itemSubtotal;
    }

    // 2. Calculate tax amount
    const taxAmount = overallSubtotal * taxRate;

    // 3. Calculate final total
    const finalTotal = overallSubtotal + taxAmount;

    // Update DOM displays
    overallSubtotalDisplay.textContent = overallSubtotal.toFixed(2);
    taxAmountDisplay.textContent = taxAmount.toFixed(2);
    finalTotalDisplay.textContent = finalTotal.toFixed(2);

    return {
        overallSubtotal: overallSubtotal,
        taxAmount: taxAmount,
        finalTotal: finalTotal
    };
}
function renderInvoice(invoiceData) {
    // Update Header Information
    customerName.textContent = invoiceData.customerName || 'N/A';
    invoiceDate.textContent = invoiceData.invoiceDate || new Date().toLocaleDateString();
    taxRate.value = (invoiceData.taxRate * 100).toFixed(2); // Assuming taxRate is stored as a decimal (e.g., 0.08)

    // Clear existing item list
    const itemListContainer = itemListContainer;
    itemListContainer.innerHTML = '';

    // Render Itemized List
    invoiceData.items.forEach(item => {
        const row = document.createElement('div');
        row.className = 'item-row'; // Assuming a class for styling
        row.innerHTML = `
            <div class="item-name">${item.name}</div>
            <div class="item-details">
                <span>Rate: $${item.rate.toFixed(2)}</span>
                <span>Quantity: ${item.quantity}</span>
                <span>Subtotal: $${item.subtotal.toFixed(2)}</span>
            </div>
        `;
        itemListContainer.appendChild(row);
    });

    // Update Totals Section
    const { overallSubtotal, taxAmount, finalTotal } = invoiceData.totals;

    overallSubtotalDisplay.textContent = `$${overallSubtotal.toFixed(2)}`;
    taxAmountDisplay.textContent = `$${taxAmount.toFixed(2)}`;
    finalTotalDisplay.textContent = `$${finalTotal.toFixed(2)}`;
}
function printInvoice() {
    // Triggers the browser's print dialog.
    // In a real-world scenario, before calling this, one might add CSS media queries
    // or use window.print() with specific print styles to ensure optimal formatting.
    window.print();
}
