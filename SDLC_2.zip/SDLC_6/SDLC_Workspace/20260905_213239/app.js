// DOM references (deterministically generated from the manifest's `ids`)
const inputCustomerName = document.getElementById('input-customer-name');
const inputInvoiceDate = document.getElementById('input-invoice-date');
const inputTaxRate = document.getElementById('input-tax-rate');
const btnAddItem = document.getElementById('btn-add-item');
const itemRowTemplate = document.getElementById('item-row-template');
const inputItemName = document.getElementById('input-item-name');
const inputItemQuantity = document.getElementById('input-item-quantity');
const inputItemRate = document.getElementById('input-item-rate');
const btnRemoveItem = document.getElementById('btn-remove-item');
const btnSaveInvoice = document.getElementById('btn-save-invoice');
const btnPrintInvoice = document.getElementById('btn-print-invoice');

// Function implementations (filled in below)
function initializeInvoiceState(customerName, invoiceDate, taxRate) {
  // Set the customer name
  document.getElementById('inputCustomerName').value = customerName;

  // Set the invoice date
  document.getElementById('inputInvoiceDate').value = invoiceDate;

  // Set the tax rate
  document.getElementById('inputTaxRate').value = taxRate;
}
function addItem(itemName, quantity, rate) {
    // 1. Get current invoice data (assuming we manage an array of items)
    // In a real scenario, we would retrieve the current state.
    // For demonstration, we simulate adding an item to a conceptual list.
    
    const newItem = {
        id: Date.now(), // Simple unique ID generation
        name: itemName,
        quantity: quantity,
        rate: rate,
        total: quantity * rate
    };

    // 2. Create the HTML row using the template
    const rowHtml = itemRowTemplate.innerHTML;
    const newRow = rowHtml.replace('<!-- ITEM_ROW_CONTENT -->', `
        <tr data-item-id="${newItem.id}">
            <td>${newItem.name}</td>
            <td>${newItem.quantity}</td>
            <td>${newItem.rate}</td>
            <td>${newItem.total.toFixed(2)}</td>
            <td><button class="btn-remove-item" data-item-id="${newItem.id}">Remove</button></td>
        </tr>
    `);

    // 3. Insert the new row into the invoice container (assuming an invoice body element exists)
    const invoiceBody = document.getElementById('invoiceBody');
    if (invoiceBody) {
        invoiceBody.insertAdjacentHTML('beforeend', newRow);
    }

    // 4. Trigger recalculation (Placeholder: In a full app, this would update totals)
    console.log(`Item added: ${itemName}. Recalculation triggered.`);
}
function removeItem(itemId) {
    // 1. Find the element corresponding to the item to be removed
    const itemRow = document.querySelector(`tr[data-item-id="${itemId}"]`);

    if (itemRow) {
        // 2. Remove the row from the DOM
        itemRow.remove();

        // 3. Trigger recalculation (Placeholder: In a full app, this would update totals)
        console.log(`Item with ID ${itemId} removed. Recalculation triggered.`);
    } else {
        console.error(`Error: Item with ID ${itemId} not found.`);
    }
}
function calculateLineItemTotal(quantity, rate) {
    // Calculates the subtotal for a single line item (Quantity * Rate).
    if (typeof quantity !== 'number' || typeof rate !== 'number') {
        return 0;
    }
    return quantity * rate;
}
function calculateInvoiceTotals(items, taxRate) {
    // Iterates through all line items, calculates subtotals, and determines the grand total including tax.
    let grandSubtotal = 0;

    if (!items || items.length === 0) {
        return { subtotal: 0, tax: 0, total: 0 };
    }

    for (const item of items) {
        const lineTotal = calculateLineItemTotal(item.quantity, item.rate);
        grandSubtotal += lineTotal;
    }

    const taxAmount = grandSubtotal * taxRate;
    const finalTotal = grandSubtotal + taxAmount;

    return {
        subtotal: grandSubtotal,
        tax: taxAmount,
        total: finalTotal
    };
}
function renderInvoice(invoiceData) {
    // Renders the complete invoice data (header, items, totals) to the HTML DOM.
    const invoiceContainer = document.getElementById('invoice-container');

    if (!invoiceContainer) {
        console.error("Invoice container element not found.");
        return;
    }

    // 1. Render Header Information
    invoiceContainer.innerHTML = `
        <div class="invoice-header">
            <h1>Invoice</h1>
            <p>Date: ${invoiceData.invoiceDate}</p>
            <p>Customer: ${invoiceData.customerName}</p>
        </div>
        <div class="invoice-items">
    `;

    // 2. Render Line Items
    invoiceData.items.forEach(item => {
        const lineTotal = calculateLineItemTotal(item.quantity, item.rate);
        const itemHtml = `
            <div class="invoice-item">
                <div class="item-details">
                    <strong>${item.name}</strong> (Qty: ${item.quantity} @ ${item.rate.toFixed(2)})
                </div>
                <div class="item-total">$${lineTotal.toFixed(2)}</div>
            </div>
        `;
        invoiceContainer.innerHTML += itemHtml;
    });

    // 3. Render Totals
    const totals = calculateInvoiceTotals(invoiceData.items, invoiceData.taxRate);

    invoiceContainer.innerHTML += `
        </div>
        <div class="invoice-totals">
            <p>Subtotal: $${totals.subtotal.toFixed(2)}</p>
            <p>Tax (${(invoiceData.taxRate * 100).toFixed(0)}%): $${totals.tax.toFixed(2)}</p>
            <h2>Grand Total: $${totals.total.toFixed(2)}</h2>
        </div>
    `;
}
function saveInvoice(invoiceData) {
    // In a real application, this function would validate the data,
    // potentially calculate totals, and then serialize the result.
    
    // For demonstration, we assume invoiceData is an object containing all necessary fields.
    // We serialize it to a JSON string, which is suitable for storage or API transmission.
    try {
        const jsonString = JSON.stringify(invoiceData, null, 2);
        console.log("Invoice saved successfully. JSON output:");
        console.log(jsonString);
        
        // In a real scenario, you might store this data in localStorage or send it via fetch.
        return jsonString;
    } catch (error) {
        console.error("Error saving invoice data:", error);
        throw new Error("Failed to serialize invoice data.");
    }
}
function printInvoice(invoiceData) {
    // This function generates a printable view of the invoice.
    // In a real application, this would involve manipulating the DOM to hide non-essential elements
    // and applying specific print styles (e.g., using @media print).

    // 1. Prepare the content for printing (Simulated DOM update)
    const printWindow = window.open('', '_blank');
    
    // Create the HTML content for printing
    const printContent = `
        <html>
        <head>
            <title>Invoice Print</title>
            <style>
                /* Basic print-specific styling */
                body { font-family: Arial, sans-serif; margin: 20px; }
                h1 { text-align: center; }
                table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                .invoice-details { margin-bottom: 20px; }
            </style>
        </head>
        <body>
            <h1>Invoice</h1>
            <div class="invoice-details">
                <p><strong>Customer Name:</strong> ${invoiceData.customerName}</p>
                <p><strong>Invoice Date:</strong> ${invoiceData.invoiceDate}</p>
                <p><strong>Tax Rate:</strong> ${invoiceData.taxRate}%</p>
            </div>
            <h2>Items</h2>
            <table>
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Quantity</th>
                        <th>Rate</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    ${invoiceData.items.map(item => `
                        <tr>
                            <td>${item.name}</td>
                            <td>${item.quantity}</td>
                            <td>${item.rate}</td>
                            <td>${(item.quantity * item.rate).toFixed(2)}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
            <hr>
            <h2>Subtotal: $${invoiceData.subtotal.toFixed(2)}</h2>
            <h2>Tax: $${invoiceData.taxAmount.toFixed(2)}</h2>
            <h2>Total Due: $${invoiceData.total.toFixed(2)}</h2>
        </body>
        </html>
    `;

    // Write the content to the new window
    printWindow.document.write(printContent);
    printWindow.document.close();

    // 2. Trigger the print dialog
    printWindow.focus();
    printWindow.print();
}
