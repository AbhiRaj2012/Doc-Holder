// DOM references (deterministically generated from the manifest's `ids`)
const customerNameInput = document.getElementById('customer-name-input');
const invoiceDateInput = document.getElementById('invoice-date-input');
const taxRateInput = document.getElementById('tax-rate-input');
const addLineItemBtn = document.getElementById('add-line-item-btn');
const removeLineItemBtn = document.getElementById('remove-line-item-btn');
const saveInvoiceBtn = document.getElementById('save-invoice-btn');
const viewLedgerBtn = document.getElementById('view-ledger-btn');
const printInvoiceBtn = document.getElementById('print-invoice-btn');
const invoicePreviewArea = document.getElementById('invoice-preview-area');
const ledgerView = document.getElementById('ledger-view');

// Function implementations (filled in below)
function loadInvoices() {
    try {
        const invoicesJson = localStorage.getItem('invoices');
        if (invoicesJson) {
            return JSON.parse(invoicesJson);
        }
        return [];
    } catch (error) {
        console.error("Error loading invoices from localStorage:", error);
        return [];
    }
}
function saveInvoice(invoiceData) {
    try {
        const invoices = loadInvoices();
        invoices.push(invoiceData);
        localStorage.setItem('invoices', JSON.stringify(invoices));
        console.log("Invoice saved successfully.");
    } catch (error) {
        console.error("Error saving invoice to localStorage:", error);
        throw new Error("Failed to save invoice data.");
    }
}
function renderLedger(invoices) {
    const ledgerView = document.getElementById('ledgerView');
    if (!ledgerView) {
        console.error("Ledger View element not found.");
        return;
    }

    // Clear previous content
    ledgerView.innerHTML = '';

    if (!invoices || invoices.length === 0) {
        ledgerView.innerHTML = '<p>No invoices found in the ledger.</p>';
        return;
    }

    // Build the HTML list
    const ul = document.createElement('ul');
    ul.className = 'invoice-list';

    invoices.forEach(invoice => {
        const li = document.createElement('li');
        li.className = 'invoice-item';
        
        // Use template literals for clean rendering
        li.innerHTML = `
            <div class="invoice-header">
                <h3>Invoice #${invoice.id || 'N/A'}</h3>
                <p>Customer: ${invoice.customerName || 'N/A'}</p>
                <p>Date: ${new Date(invoice.date).toLocaleDateString()}</p>
                <p>Total: $${invoice.total ? invoice.total.toFixed(2) : '0.00'}</p>
            </div>
        `;
        ul.appendChild(li);
    });

    ledgerView.appendChild(ul);
}
function handleAddItem(itemName, quantity, rate) {
    // 1. Calculate the line item total
    const lineTotal = calculateLineItemTotal(quantity, rate);

    // 2. Create the new row element
    const row = document.createElement('tr');
    row.classList.add('invoice-line-item');
    row.innerHTML = `
        <td><input type="text" class="item-name" value="${itemName}" required></td>
        <td><input type="number" class="item-quantity" value="${quantity}" required></td>
        <td><input type="number" class="item-rate" value="${rate}" required></td>
        <td class="item-total">$${lineTotal.toFixed(2)}</td>
        <td><button class="remove-line-item-btn" data-index="${invoicePreviewArea.children.length - 1}">Remove</button></td>
    `;

    // 3. Append the new row to the invoice preview area
    invoicePreviewArea.appendChild(row);

    // 4. Attach event listener for removal (delegation)
    const removeButton = row.querySelector('.remove-line-item-btn');
    removeButton.addEventListener('click', (e) => {
        const index = parseInt(e.target.dataset.index);
        removeItem(index);
    });

    // 5. Recalculate overall totals (Placeholder logic - actual total calculation depends on full invoice structure)
    updateInvoiceTotals();
}
function removeItem(index) {
    // Ensure the index is valid
    if (index >= 0 && index < invoicePreviewArea.children.length) {
        // Remove the element
        invoicePreviewArea.removeChild(invoicePreviewArea.children[index]);

        // Recalculate totals after removal
        updateInvoiceTotals();
    } else {
        console.error("Invalid index provided for line item removal.");
    }
}
function calculateLineItemTotal(quantity, rate) {
    // Calculate the subtotal: Quantity * Rate
    const total = quantity * rate;
    return total;
}
function calculateInvoiceTotals(invoiceData) {
    let subtotal = 0;
    let taxAmount = 0;

    if (!invoiceData || invoiceData.length === 0) {
        return { subtotal: 0, tax: 0, grandTotal: 0 };
    }

    // Calculate subtotal from line items
    invoiceData.forEach(item => {
        // Assuming each item has a 'amount' property
        subtotal += parseFloat(item.amount) || 0;
    });

    // Calculate tax
    const taxRate = parseFloat(document.getElementById('taxRateInput').value) / 100;
    taxAmount = subtotal * taxRate;

    // Calculate grand total
    const grandTotal = subtotal + taxAmount;

    return {
        subtotal: subtotal,
        tax: taxAmount,
        grandTotal: grandTotal
    };
}
function renderInvoicePreview(invoiceData) {
    const invoicePreviewArea = document.getElementById('invoicePreviewArea');
    if (!invoicePreviewArea) {
        console.error("Element with ID 'invoicePreviewArea' not found.");
        return;
    }

    let html = `
        <div class="invoice-preview">
            <h1>Invoice</h1>
            <p><strong>Invoice Date:</strong> ${document.getElementById('invoiceDateInput').value}</p>
            <p><strong>Customer:</strong> ${document.getElementById('customerNameInput').value}</p>
            
            <table>
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
    `;

    // Render line items
    invoiceData.forEach(item => {
        html += `
            <tr>
                <td>${item.description || 'Item'}</td>
                <td>$${parseFloat(item.amount).toFixed(2)}</td>
            </tr>
        `;
    });

    html += `
                </tbody>
            </table>

            <h2>Summary</h2>
            <p>Subtotal: $${(invoiceData.reduce((sum, item) => sum + parseFloat(item.amount), 0)).toFixed(2)}</p>
            <p>Tax (${(document.getElementById('taxRateInput').value || 0)}%): $${(invoiceData.reduce((sum, item) => sum + parseFloat(item.amount), 0) * (document.getElementById('taxRateInput').value || 0) / 100).toFixed(2)}</p>
            <h3>Grand Total: $${(invoiceData.reduce((sum, item) => sum + parseFloat(item.amount), 0) + (invoiceData.reduce((sum, item) => sum + parseFloat(item.amount), 0) * (document.getElementById('taxRateInputInput').value || 0) / 100)).toFixed(2)}</h3>
        </div>
    `;

    invoicePreviewArea.innerHTML = html;
}
function printInvoice(invoiceData) {
    // Ensure the invoice is rendered before attempting to print
    if (!invoiceData) {
        console.error("No invoice data provided to printInvoice.");
        return;
    }

    // 1. Render the invoice preview
    renderInvoicePreview(invoiceData);

    // 2. Trigger the print dialog
    window.print();
}
function initializeApp() {
    // --- 1. Setup Event Listeners ---

    // Input listeners (for real-time updates or state tracking)
    const customerNameInput = document.getElementById('customer-name-input');
    const invoiceDateInput = document.getElementById('invoice-date-input');
    const taxRateInput = document.getElementById('tax-rate-input');

    // Action button listeners
    const addLineItemBtn = document.getElementById('add-line-item-btn');
    const removeLineItemBtn = document.getElementById('remove-line-item-btn');
    const saveInvoiceBtn = document.getElementById('save-invoice-btn');
    const viewLedgerBtn = document.getElementById('view-ledger-btn');
    const printInvoiceBtn = document.getElementById('print-invoice-btn');
    const invoicePreviewArea = document.getElementById('invoice-preview-area');
    const ledgerView = document.getElementById('ledger-view');

    // Attach listeners
    if (customerNameInput) {
        customerNameInput.addEventListener('input', handleInputChange);
    }
    if (invoiceDateInput) {
        invoiceDateInput.addEventListener('input', handleInputChange);
    }
    if (taxRateInput) {
        taxRateInput.addEventListener('input', handleInputChange);
    }

    if (addLineItemBtn) {
        addLineItemBtn.addEventListener('click', handleAddItem);
    }
    if (removeLineItemBtn) {
        removeLineItemBtn.addEventListener('click', handleRemoveItem);
    }
    if (saveInvoiceBtn) {
        saveInvoiceBtn.addEventListener('click', handleSaveInvoice);
    }
    if (viewLedgerBtn) {
        viewLedgerBtn.addEventListener('click', viewLedger);
    }
    if (printInvoiceBtn) {
        printInvoiceBtn.addEventListener('click', printInvoice);
    }

    // --- 2. Initialize Application State and Load Data ---

    // In a real application, this is where you would load data from localStorage,
    // initialize the line item array, and set default values.
    loadSavedData();
    initializeState();

    // Ensure initial UI state is correct (e.g., hiding ledger)
    ledgerView.style.display = 'none';

    console.log('Application initialized successfully.');
}

// --- Helper Functions (Simulated logic for completeness) ---

function handleInputChange(event) {
    // Placeholder for state update logic
    const target = event.target;
    const inputId = target.id;
    // console.log(`${inputId} changed: ${target.value}`);
}



function handleRemoveItem() {
    // Placeholder for removing a line item from the state
    console.log('Remove line item clicked.');
}

function handleSaveInvoice() {
    // Placeholder for saving the current state
    console.log('Invoice saved.');
}

function viewLedger() {
    // Placeholder for switching view
    ledgerView.style.display = 'block';
    invoicePreviewArea.style.display = 'none';
}



function loadSavedData() {
    // Simulate loading data from storage
    console.log('Loading saved data...');
}

function initializeState() {
    // Simulate setting initial application state
    console.log('Initializing application state.');
}

// Execute initialization when the DOM is ready
document.addEventListener('DOMContentLoaded', initializeApp);
