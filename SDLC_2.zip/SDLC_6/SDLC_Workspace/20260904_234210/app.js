// --- DOM Element References ---
const inputInvoiceTitle = document.getElementById('input-invoice-title');
const inputInvoiceNumber = document.getElementById('input-invoice-number');
const inputInvoiceDate = document.getElementById('input-invoice-date');
const clientAddBtn = document.getElementById('client-add-btn');
const clientList = document.getElementById('client-list');
const lineItemAddBtn = document.getElementById('line-item-add-btn');
const lineItemRowContainer = document.getElementById('line-item-row-container');
const calculateSubtotalBtn = document.getElementById('calculate-subtotal-btn');
const calculateGrandTotalBtn = document.getElementById('calculate-grand-total-btn');
const invoicePreview = document.getElementById('invoice-preview');
const saveInvoiceBtn = document.getElementById('save-invoice-btn');
const invoiceListView = document.getElementById('invoice-list-view');
const loadInvoiceBtn = document.getElementById('load-invoice-btn');
const printInvoiceBtn = document.getElementById('print-invoice-btn');
const downloadInvoiceBtn = document.getElementById('download-invoice-btn');

// --- State Management (Local Storage Keys) ---
const STORAGE_KEY_CLIENTS = 'invoice_clients';
const STORAGE_KEY_INVOICES = 'invoice_data';

/**
 * Loads all saved invoices and clients from Local Storage.
 * @param {string} storageKey - The key for the data to load.
 * @returns {object} An object containing clients and invoices.
 */
function loadData(storageKey) {
    try {
        const clients = JSON.parse(localStorage.getItem(storageKey)) || [];
        const invoices = JSON.parse(localStorage.getItem(storageKey)) || [];
        return { clients, invoices };
    } catch (error) {
        console.error("Error loading data from Local Storage:", error);
        return { clients: [], invoices: [] };
    }
}

/**
 * Saves the current state of invoices and clients to Local Storage.
 * @param {string} storageKey - The key for the data to save.
 * @param {object} data - The data object to save (containing clients and invoices).
 */
function saveData(storageKey, data) {
    try {
        localStorage.setItem(storageKey, JSON.stringify(data));
    } catch (error) {
        console.error("Error saving data to Local Storage:", error);
    }
}

/**
 * Adds a new client object to the client list.
 * @param {object} clientData - The data for the new client (must include an ID).
 */
function addClient(clientData) {
    const storageKey = STORAGE_KEY_CLIENTS;
    try {
        const clients = JSON.parse(localStorage.getItem(storageKey)) || [];
        // Ensure clientData has a unique ID if it doesn't already
        if (!clientData.id) {
            clientData.id = Date.now().toString(); // Simple unique ID generation
        }
        clients.push(clientData);
        localStorage.setItem(storageKey, JSON.stringify(clients));
        renderClientList(); // Refresh the client list display
    } catch (error) {
        console.error("Error adding client to Local Storage:", error);
    }
}

/**
 * Removes a client from the client list.
 * @param {string} clientId - The ID of the client to remove.
 */
function deleteClient(clientId) {
    const storageKey