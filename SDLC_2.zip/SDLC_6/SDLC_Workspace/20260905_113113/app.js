// --- DOM Element References ---
const inputCustomerName = document.getElementById('input-customer-name');
const inputInvoiceDate = document.getElementById('input-invoice-date');
const inputTaxRate = document.getElementById('input-tax-rate');
const btnAddItem = document.getElementById('btn-add-item');
const btnSaveInvoice = document.getElementById('btn-save-invoice');
const btnPrintInvoice = document.getElementById('btn-print-invoice');

// --- State Management ---
let invoiceData = {
    customerName: '',
    invoiceDate: '',
    taxRate: 0,
    lineItems: []
};

// --- Core Functions ---

/**
 * Adds a new line item to the invoice data structure.
 * @param {string} itemName
 * @param {number} quantity
 * @param {number} rate
 */
function addItem(itemName, quantity, rate) {
    // In a real application, this function would operate on a mutable invoice array.
    // For demonstration, we assume 'invoiceData' is the array we are modifying.
    
    const newItem = {
        id: Date.now() + Math.random(), // Simple unique ID generation
        name: itemName,
        quantity: quantity,
        rate: rate
    };

    // Assuming 'invoiceData' is accessible (e.g., a global or passed context)
    if (typeof invoiceData !== 'undefined' && Array.isArray(invoiceData)) {
        invoiceData.push(newItem);
        return newItem;
    } else {
        console.error("Invoice data structure is not accessible.");
        return null;
    }
}
// 


/**
 * Removes a specific line item from the invoice data structure based on its ID.
 * @param {string} itemId
 */
function removeItem(itemId) {
    // Assuming 'invoiceData' is the array we are modifying.
    
    if (typeof invoiceData !== 'undefined' && Array.isArray(invoiceData)) {
        const initialLength = invoiceData.length;
        
        // Filter out the item with the matching ID
        invoiceData = invoiceData.filter(item => item.id !== itemId);
        
        if (invoiceData.length < initialLength) {
            return true; // Item was successfully removed
        } else {
            return false; // Item not found
        }
    } else {
        console.error("Invoice data structure is not accessible.");
        return false;
    }
}
// 


/**
 * Calculates the subtotal for a single line item (Quantity * Rate).
 * @param {number} quantity
 * @param {number} rate
 * @returns {number} The calculated subtotal.
 */
function calculateLineItemSubtotal(quantity, rate) {
    // Calculates the subtotal for a single line item (Quantity * Rate).
    
    if (typeof quantity !== 'number' || typeof rate !== 'number' || isNaN(quantity) || isNaN(rate)) {
        throw new Error("Quantity and Rate must be valid numbers.");
    }

    const subtotal = quantity * rate;
    return subtotal;
}
// 


/**
 * Calculates the total sum of all line item subtotals.
 * @param {Array<Object>} lineItems
 * @returns {number} The total subtotal.
 */
function calculateInvoiceSubtotal(lineItems) {
    if (!Array.isArray(lineItems)) {
        return 0;
    }

    return lineItems.reduce((total, item) => {
        // Assuming each item in lineItems has a 'subtotal' property
        const itemSubtotal = typeof item.subtotal === 'number' ? item.subtotal : 0;
        return total + itemSubtotal;
    }, 0);
}
// 


/**
 * Calculates the total tax amount based on the subtotal and tax rate.
 * @param {number} subtotal
 * @param {number} taxRate
 * @returns {number} The calculated tax amount.
 */
function calculateTaxAmount(subtotal, taxRate) {
    if (typeof subtotal !== 'number' || typeof taxRate !== 'number') {
        return 0;
    }

    // Ensure taxRate is treated as a decimal (e.g., 0.08 for 8%)
    const rate = parseFloat(taxRate);
    const subtotalAmount = parseFloat(subtotal);

    if (isNaN(subtotalAmount) || isNaN(rate)) {
        return 0;
    }

    return subtotalAmount * rate;
}
// 


/**
 * Calculates the final total bill amount (Subtotal + Tax).
 * @param {number} subtotal
 * @param {number} taxAmount
 * @returns {number} The final total.
 */
function calculateFinalTotal(subtotal, taxAmount) {
    if (typeof subtotal !== 'number' || typeof taxAmount !== 'number') {
        return 0;
    }

    return subtotal + taxAmount;
}
// 


/**
 * Updates the DOM to display the real-time, cumulative invoice preview.
 * @param {Object} invoiceData
 */
function renderInvoicePreview(invoiceData) {
    if (!invoiceData) {
        console.warn("renderInvoicePreview called with null or undefined data.");
        // Optionally clear the preview if no data is provided
        document.getElementById('invoice-preview-container').innerHTML = '';
        return;
    }

    const container = document.getElementById('invoice-preview-container');
    if (!container) {
        console.error("Element with ID 'invoice-preview-container' not found.");
        return;
    }

    // Use template literals to construct the HTML preview
    const htmlContent = `
        <h2>Invoice Preview</h2>
        <div class="invoice-details">
            <p><strong>Invoice ID:</strong> ${invoiceData.id || 'N/A'}</p>
            <p><strong>Date:</strong> ${new Date(invoiceData.date).toLocaleDateString()}</p>
            <h3>Items:</h3>
            <ul>
                ${invoiceData.items ? invoiceData.items.map(item => `<li>${item.description}: $${item.amount.toFixed(2)}</li>`).join('') : '<li>No items found</li>'}
            </ul>
            <h3>Total: $${invoiceData.total ? invoiceData.total.toFixed(2) : '0.00'}</h3>
        </div>
    `;

    container.innerHTML = htmlContent;
}
// 


/**
 * Stores the complete invoice data into the browser's local storage.
 * @param {Object} invoiceData
 */
function saveInvoice(invoiceData) {
    if (!invoiceData) {
        console.error("Cannot save null or undefined invoice data.");
        return;
    }

    try {
        // Store the data as a JSON string in local storage
        localStorage.setItem('lastInvoice', JSON.stringify(invoiceData));
        console.log("Invoice successfully saved to local storage.");
    } catch (error) {
        console.error("Error saving invoice data to local storage:", error);
        throw new Error("Failed to save data.");
    }
}
// 


/**
 * Retrieves and loads the last saved invoice data from local storage.
 * @returns {Object | null} The loaded invoice data or null if none exists.
 */
function loadInvoice() {
    try {
        // Retrieve the data from local storage
        const savedDataString = localStorage.getItem('lastInvoice');

        if (savedDataString) {
            // Parse the JSON string back into an object
            const invoiceData = JSON.parse(savedDataString);
            console.log("Invoice successfully loaded from local storage.");
            
            // In a real application, you would typically pass this data to a rendering function
            return invoiceData;
        } else {
            console.log("No saved invoice found in local storage.");
            return null;
        }
    } catch (error) {
        console.error("Error loading invoice data from local storage:", error);
        // Clear potentially corrupted data if parsing fails
        localStorage.removeItem('lastInvoice');
        return null;
    }
}
// 


/**
 * Generates a printable HTML view of the finalized invoice data.
 * @param {Object} invoiceData
 */
function generatePrintView(invoiceData) {
    if (!invoiceData) {
        return "<div style='color: red;'>Error: Invoice data is missing.</div>";
    }

    // Helper function to format currency
    const formatCurrency = (amount) => {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
        }).format(amount);
    };

    // Generate the table rows for items
    let itemsHtml = invoiceData.items.map(item => `
        <tr>
            <td style="padding: 8px; border: 1px solid #ddd; text-align: left;">${item.description}</td>
            <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${item.quantity}</td>
            <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${formatCurrency(item.price)}</td>
            <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${formatCurrency(item.quantity * item.price)}</td>
        </tr>
    `).join('');

    // Construct the full HTML view using template literals
    const printViewHtml = `
        <style>
            /* Styles optimized for printing */
            body {
                font-family: Arial, sans-serif;
                margin: 20px;
                font-size: 12pt;
            }
            .invoice-container {
                max-width: 800px;
                margin: 0 auto;
                border: 1px solid #ccc;
                padding: 30px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }
            h1 {
                text-align: center;
                border-bottom: 2px solid #333;
                padding-bottom: 10px;
                margin-bottom: 20px;
            }
            .header-info, .totals {
                margin-bottom: 20px;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
            }
            th, td {
                border: 1px solid #ddd;
                padding: 10px;
            }
            th {
                background-color: #f2f2f2;
                text-align: left;
            }
            .total-row td {
                font-weight: bold;
                text-align: right;
                background-color: #e9e9e9;
            }
            .footer {
                margin-top: 40px;
                text-align: right;
            }
        </style>

        <div class="invoice-container">
            <h1>Invoice #${invoiceData.invoiceNumber}</h1>

            <div class="header-info">
                <p><strong>Date:</strong> ${invoiceData.date}</p>
                <p><strong>Invoice ID:</strong> ${invoiceData.invoiceNumber}</p>
            </div>

            <div class="customer-info">
                <p><strong>Billed To:</strong> ${invoiceData.customerName}</p>
                <p><strong>Address:</strong> ${invoiceData.customerAddress}</p>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>Description</th>
                        <th>Quantity</th>
                        <th>Unit Price</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
                    ${itemsHtml}
                </tbody>
            </table>

            <div class="totals">
                <table style="width: 300px; margin-left: auto;">
                    <tr>
                        <td>Subtotal:</td>
                        <td style="text-align: right;">${formatCurrency(invoiceData.subtotal)}</td>
                    </tr>
                    <tr>
                        <td>Tax (5%):</td>
                        <td style="text-align: right;">${formatCurrency(invoiceData.taxAmount)}</td>
                    </tr>
                    <tr class="total-row">
                        <td><strong>Total Due:</strong></td>
                        <td style="text-align: right;"><strong>${formatCurrency(invoiceData.total)}</strong></td>
                    </tr>
                </table>
            </div>

            <div class="footer">
                <p>Thank you for your business!</p>
            </div>
        </div>
    `;

    return printViewHtml;
}
// 


// --- Event Listeners (Setup) ---

// Example setup for event listeners (not required to be implemented, but necessary for functionality)
// btnAddItem.addEventListener('click', handleAddItem);
// btnSaveInvoice.addEventListener('click', handleSaveInvoice);
// btnPrintInvoice.addEventListener('click', handlePrintInvoice);