// DOM references (deterministically generated from the manifest's `ids`)
const customerNameInput = document.getElementById('customer-name-input');
const invoiceDateInput = document.getElementById('invoice-date-input');
const taxRateInput = document.getElementById('tax-rate-input');
const addItemBtn = document.getElementById('add-item-btn');
const removeItemBtn = document.getElementById('remove-item-btn');
const saveInvoiceBtn = document.getElementById('save-invoice-btn');
const printInvoiceBtn = document.getElementById('print-invoice-btn');
const invoiceForm = document.getElementById('invoice-form');
const ledgerView = document.getElementById('ledger-view');
const invoiceDetailsDisplay = document.getElementById('invoice-details-display');
const invoicePrintArea = document.getElementById('invoice-print-area');

// Function implementations (filled in below)
function initApp() {
    // 1. Set up event listeners
    document.addEventListener('DOMContentLoaded', () => {
        // Attach listener for saving the invoice
        const saveButton = document.getElementById('save-invoice-btn');
        if (saveButton) {
            saveButton.addEventListener('click', handleSaveInvoice);
        }

        // Attach listener for printing the invoice
        const printButton = document.getElementById('print-invoice-btn');
        if (printButton) {
            printButton.addEventListener('click', handlePrintInvoice);
        }

        // Attach listener for adding items (assuming this handles dynamic form updates)
        const addItemButton = document.getElementById('add-item-btn');
        if (addItemButton) {
            addItemButton.addEventListener('click', handleAddItem);
        }

        // Attach listener for removing items
        const removeItemButton = document.getElementById('remove-item-btn');
        if (removeItemButton) {
            removeItemButton.addEventListener('click', handleRemoveItem);
        }

        // 2. Load initial data
        loadInvoices();
    });
}
function loadInvoices() {
    const invoices = JSON.parse(localStorage.getItem('invoices')) || [];

    // Clear existing ledger view
    const ledgerView = document.getElementById('ledger-view');
    if (ledgerView) {
        ledgerView.innerHTML = '';
    }

    if (invoices.length === 0) {
        ledgerView.innerHTML = '<p class="text-center mt-4">No invoices found.</p>';
        return;
    }

    // Render invoices
    invoices.forEach((invoice, index) => {
        const invoiceElement = document.createElement('div');
        invoiceElement.className = 'invoice-card';
        invoiceElement.innerHTML = `
            <h3>Invoice #${index + 1}</h3>
            <p><strong>Customer:</strong> ${invoice.customerName || 'N/A'}</p>
            <p><strong>Date:</strong> ${invoice.date || 'N/A'}</p>
            <p><strong>Total:</strong> $${invoice.total ? invoice.total.toFixed(2) : '0.00'}</p>
            <button class="view-details-btn" data-index="${index}">View Details</button>
        `;
        ledgerView.appendChild(invoiceElement);
    });
}
function saveInvoice(invoiceData) {
    try {
        const invoices = JSON.parse(localStorage.getItem('invoices')) || [];
        
        // Ensure invoiceData is a valid object before saving
        if (typeof invoiceData !== 'object' || invoiceData === null) {
            throw new Error("Invalid invoice data provided.");
        }

        invoices.push(invoiceData);
        localStorage.setItem('invoices', JSON.stringify(invoices));
        
        console.log('Invoice saved successfully.');
        
        // Optionally refresh the view after saving
        loadInvoices();

    } catch (error) {
        console.error('Error saving invoice to Local Storage:', error);
        alert('Failed to save invoice. Please check the data format.');
    }
}
function addInvoiceItemRow(itemName, quantity, rate) {
    // 1. Calculate the subtotal
    const subtotal = calculateItemSubtotal(quantity, rate);

    // 2. Create the new row element
    const row = document.createElement('tr');
    row.className = 'invoice-item-row';

    // 3. Create cells for item details
    const nameCell = document.createElement('td');
    nameCell.textContent = itemName;
    row.appendChild(nameCell);

    const quantityCell = document.createElement('td');
    quantityCell.textContent = quantity;
    row.appendChild(quantityCell);

    const rateCell = document.createElement('td');
    rateCell.textContent = rate.toFixed(2); // Format rate to two decimal places
    row.appendChild(rateCell);

    const subtotalCell = document.createElement('td');
    subtotalCell.textContent = subtotal.toFixed(2);
    row.appendChild(subtotalCell);

    // 4. Create remove button
    const removeButton = document.createElement('button');
    removeButton.textContent = 'Remove';
    removeButton.className = 'remove-item-btn';
    removeButton.onclick = () => {
        row.remove();
        calculateInvoiceTotals(); // Recalculate totals after removal
    };
    row.appendChild(removeButton);

    // 5. Append the row to the invoice form
    invoiceForm.appendChild(row);

    // 6. Recalculate totals after adding the item
    calculateInvoiceTotals();
}
function calculateItemSubtotal(quantity, rate) {
    if (typeof quantity !== 'number' || typeof rate !== 'number') {
        console.error("Invalid input for subtotal calculation.");
        return 0;
    }
    return quantity * rate;
}
function calculateInvoiceTotals() {
    let grandSubtotal = 0;
    const invoiceRows = invoiceForm.querySelectorAll('.invoice-item-row');

    // 1. Calculate the grand subtotal from all items
    invoiceRows.forEach(row => {
        // Assuming the subtotal is the 4th cell (index 3) in the row
        const subtotalText = row.querySelector('td:nth-child(4)').textContent;
        const itemSubtotal = parseFloat(subtotalText);
        grandSubtotal += itemSubtotal;
    });

    // 2. Get tax rate
    const taxRate = parseFloat(taxRateInput.value) / 100; // Convert percentage input to decimal

    // 3. Calculate tax
    const taxAmount = grandSubtotal * taxRate;

    // 4. Calculate final total
    const finalTotal = grandSubtotal + taxAmount;

    // 5. Display results
    const displayHTML = `
        <div class="invoice-totals">
            <p>Subtotal: $${grandSubtotal.toFixed(2)}</p>
            <p>Tax (${(taxRate * 100).toFixed(0)}%): $${taxAmount.toFixed(2)}</p>
            <hr>
            <h3>Total Bill: $${finalTotal.toFixed(2)}</h3>
        </div>
    `;

    invoiceDetailsDisplay.innerHTML = displayHTML;
}
function renderInvoiceForm(invoiceData) {
    // Populate basic header fields
    if (invoiceData.customerName) {
        document.getElementById('customerNameInput').value = invoiceData.customerName;
    }
    if (invoiceData.invoiceDate) {
        document.getElementById('invoiceDateInput').value = invoiceData.invoiceDate;
    }
    if (invoiceData.taxRate) {
        document.getElementById('taxRateInput').value = invoiceData.taxRate;
    }

    // Note: Handling dynamic item lists (if applicable) would require additional logic based on invoiceData.items
    // For this implementation, we focus on the direct data population.
}
function generateInvoiceHTML(invoiceData) {
    // Calculate totals
    let subtotal = 0;
    let taxAmount = 0;
    let total = 0;

    if (invoiceData.items && Array.isArray(invoiceData.items)) {
        invoiceData.items.forEach(item => {
            // Assuming items have a 'price' and 'quantity'
            subtotal += item.price * item.quantity;
        });
    }

    const taxRate = parseFloat(invoiceData.taxRate) || 0;
    taxAmount = subtotal * (taxRate / 100);
    total = subtotal + taxAmount;

    // Generate the HTML string
    let html = `
        <div class="invoice-container">
            <h1>Invoice</h1>
            <div class="invoice-header">
                <p><strong>Invoice Date:</strong> ${invoiceData.invoiceDate}</p>
                <p><strong>Customer:</strong> ${invoiceData.customerName}</p>
            </div>

            <table class="invoice-items">
                <thead>
                    <tr>
                        <th>Description</th>
                        <th>Quantity</th>
                        <th>Unit Price</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
    `;

    // Add item rows
    if (invoiceData.items && Array.isArray(invoiceData.items)) {
        invoiceData.items.forEach(item => {
            const itemAmount = (item.price * item.quantity).toFixed(2);
            html += `
                <tr>
                    <td>${item.description || 'Item'}</td>
                    <td>${item.quantity}</td>
                    <td>$${item.price.toFixed(2)}</td>
                    <td>$${itemAmount}</td>
                </tr>
            `;
        });
    } else {
        html += `<tr><td colspan="4">No items found.</td></tr>`;
    }

    html += `
                </tbody>
            </table>

            <div class="invoice-totals">
                <p><strong>Subtotal:</strong> $${subtotal.toFixed(2)}</p>
                <p><strong>Tax (${(taxRate)}%):</strong> $${taxAmount.toFixed(2)}</p>
                <h3>Total Due: $${total.toFixed(2)}</h3>
            </div>
        </div>
    `;

    return html;
}
function printInvoice(invoiceHTML) {
    // Create a temporary window for printing
    const printWindow = window.open('', '_blank');

    // Write the generated HTML content into the new window
    printWindow.document.write('<html><head><title>Invoice Print</title>');
    printWindow.document.write('<style>');
    // Add basic print-friendly CSS (optional, but good practice)
    printWindow.document.write(`
        body { font-family: Arial, sans-serif; margin: 20px; }
        .invoice-container { max-width: 800px; margin: auto; border: 1px solid #ccc; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        .invoice-totals { margin-top: 20px; text-align: right; }
        .invoice-totals h3 { color: #333; }
    `);
    printWindow.document.write('</style></head><body>');

    // Write the actual invoice content
    printWindow.document.write(invoiceHTML);

    printWindow.document.write('</body></html>');

    // Wait for content to load and trigger print
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
}
