// DOM references (deterministically generated from the manifest's `ids`)
const timerDisplay = document.getElementById('timer-display');
const modeDisplay = document.getElementById('mode-display');
const workDurationInput = document.getElementById('work-duration-input');
const breakDurationInput = document.getElementById('break-duration-input');
const startPauseBtn = document.getElementById('start-pause-btn');
const resetBtn = document.getElementById('reset-btn');
const stopSessionBtn = document.getElementById('stop-session-btn');
const taskInputField = document.getElementById('task-input-field');
const addTaskBtn = document.getElementById('add-task-btn');
const taskListContainer = document.getElementById('task-list-container');
const taskItemTemplate = document.getElementById('task-item-template');

// Function implementations (filled in below)
function loadState() {
    try {
        const state = localStorage.getItem('timerAppState');
        if (state) {
            const data = JSON.parse(state);

            // Load session durations
            if (data.workDuration !== undefined) {
                workDurationInput.value = data.workDuration;
                breakDurationInput.value = data.breakDuration;
            }

            // Load tasks
            if (data.tasks) {
                // Clear existing list
                taskListContainer.innerHTML = '';
                data.tasks.forEach(taskText => {
                    const task = document.createElement('div');
                    task.className = 'task-item'; // Assuming a class exists for styling
                    task.innerHTML = `<span>${taskText}</span>`;
                    taskListContainer.appendChild(task);
                });
            }
        }
    } catch (error) {
        console.error("Error loading state from local storage:", error);
    }
}
function saveState() {
    // 1. Get current durations
    const workDuration = workDurationInput.value;
    const breakDuration = breakDurationInput.value;

    // 2. Get current tasks
    const tasks = [];
    const taskItems = taskListContainer.querySelectorAll('.task-item span');
    taskItems.forEach(span => {
        tasks.push(span.textContent);
    });

    const state = {
        workDuration: workDuration,
        breakDuration: breakDuration,
        tasks: tasks
    };

    try {
        localStorage.setItem('timerAppState', JSON.stringify(state));
    } catch (error) {
        console.error("Error saving state to local storage:", error);
    }
}
function setSessionDurations(workDuration, breakDuration) {
    if (typeof workDuration !== 'number' || typeof breakDuration !== 'number' || workDuration <= 0 || breakDuration <= 0) {
        console.error("Invalid duration provided. Durations must be positive numbers.");
        return false;
    }

    try {
        const state = {
            workDuration: workDuration,
            breakDuration: breakDuration
        };
        localStorage.setItem('timerAppState', JSON.stringify(state));

        // Update the input fields immediately
        workDurationInput.value = workDuration;
        breakDurationInput.value = breakDuration;

        return true;
    } catch (error) {
        console.error("Error setting session durations in local storage:", error);
        return false;
    }
}
function initializeTimer(workDuration, breakDuration) {
    // State variables initialization (assuming these are managed globally or in a closure)
    let timeRemaining = workDuration;
    let mode = 'work'; // Start in work mode
    let intervalId = null;

    // Update DOM displays
    timerDisplay.textContent = workDuration;
    modeDisplay.textContent = 'Work';

    // Set input values (optional, but good practice if inputs are used for setup)
    workDurationInput.value = workDuration;
    breakDurationInput.value = breakDuration;

    // Ensure the timer is stopped before starting a new session
    pauseTimer();
}
function startTimer() {
    // Check if the timer is currently paused (if it is, resume it)
    if (modeDisplay.textContent === 'Paused') {
        // If paused, we need to re-initialize the time based on the current mode
        // (This logic assumes that the state variables for work/break durations are accessible)
        // For simplicity in this implementation, we assume the state variables are correctly loaded.
    }

    // If the timer is not running, start it
    if (intervalId === null) {
        // Determine the initial duration based on the current mode
        let initialDuration = (modeDisplay.textContent === 'Work') ? parseFloat(workDurationInput.value) : parseFloat(breakDurationInput.value);
        timeRemaining = initialDuration;
        timerDisplay.textContent = initialDuration;

        // Start the interval
        intervalId = setInterval(() => {
            timeRemaining--;
            timerDisplay.textContent = timeRemaining;

            if (timeRemaining <= 0) {
                clearInterval(intervalId);
                handleSessionEnd(); // Placeholder for session end logic
                // Optionally switch to break mode here
            }
        }, 1000);
    }
}
function pauseTimer() {
    // Stop the countdown
    if (intervalId !== null) {
        clearInterval(intervalId);
        intervalId = null;
    }

    // Update the display and state
    modeDisplay.textContent = 'Paused';
    timerDisplay.textContent = 'Paused'; // Or display the current time remaining if desired

    // Note: In a full application, you would also save the current 'timeRemaining' state here.
}
function resetTimer() {
    // Reset the timer back to the full work duration.
    
    // 1. Reset the time remaining to the full work duration.
    // We assume workDurationInput holds the target duration.
    const workDuration = parseFloat(workDurationInput.value) || 0;
    
    // Update the display to show the full work duration.
    updateTimerDisplay(workDuration, 'Work');
}
function updateTimerDisplay(timeRemaining, mode) {
    // Updates the DOM elements to display the current time remaining and the active session mode (Work/Break).

    // Update the timer display
    timerDisplay.textContent = timeRemaining;

    // Update the mode display
    modeDisplay.textContent = mode;
}
function switchMode(currentMode) {
    // Switches the timer mode between Work and Break based on session completion.
    
    // Note: In a real application, this function would contain the complex logic
    // to determine if the current session (Work or Break) is complete,
    // calculate the next state, and update the timer accordingly.
    
    // For this implementation, we focus on updating the display based on the input mode.
    
    if (currentMode === 'Work') {
        // Transitioning from Work to Break
        updateTimerDisplay(breakDurationInput.value, 'Break');
    } else if (currentMode === 'Break') {
        // Transitioning from Break back to Work
        updateTimerDisplay(workDurationInput.value, 'Work');
    }
    
    // A full implementation would also handle stopping/starting the timer here.
}
function addTask(taskDescription) {
    // 1. Get the task description from the input field
    const description = taskDescription.trim();

    if (description === "") {
        console.error("Task description cannot be empty.");
        return;
    }

    // 2. Create the new task object (assuming tasks are stored in a global array)
    const newTask = {
        id: Date.now(), // Simple unique ID
        description: description,
        completed: false
    };

    // 3. Add the task to the internal state (assuming 'tasks' array exists)
    // NOTE: In a real application, this state management would be more robust.
    if (typeof tasks === 'undefined') {
        // Initialize tasks array if it doesn't exist
        tasks = [];
    }
    tasks.push(newTask);

    // 4. Re-render the entire list
    renderTasks();

    // 5. Clear the input field
    taskInputField.value = '';
}
function renderTasks() {
    // Clear the existing list container
    taskListContainer.innerHTML = '';

    // Iterate over the tasks array and generate HTML
    if (typeof tasks === 'undefined' || tasks.length === 0) {
        // If no tasks exist, display a placeholder or nothing
        return;
    }

    tasks.forEach(task => {
        // Clone the template to create a new task item
        const taskElement = taskItemTemplate.content.cloneNode(true);

        // Set the task ID and description
        taskElement.dataset.taskId = task.id;
        taskElement.innerHTML = `
            <input type="checkbox" class="task-completion-checkbox" ${task.completed ? 'checked' : ''}>
            <span class="task-description">${task.description}</span>
        `;

        // Add event listener for toggling completion
        taskElement.querySelector('.task-completion-checkbox').addEventListener('change', () => {
            toggleTaskCompletion(task.id);
        });

        // Append the new task item to the container
        taskListContainer.appendChild(taskElement);
    });
}
function toggleTaskCompletion(taskId) {
    // 1. Find the task in the internal state
    const taskIndex = tasks.findIndex(task => task.id === taskId);

    if (taskIndex === -1) {
        console.error(`Task with ID ${taskId} not found.`);
        return;
    }

    // 2. Toggle the completion status
    tasks[taskIndex].completed = !tasks[taskIndex].completed;

    // 3. Re-render the list to reflect the change
    renderTasks();
}
function deleteTask(taskId) {
    // Assume tasks are stored in a global array named 'tasks'
    // and that a function exists to render the list based on this array.

    if (!taskId) {
        console.error("Task ID must be provided.");
        return;
    }

    // 1. Filter the tasks array to exclude the task with the matching ID.
    // We assume 'tasks' is the array holding all task objects.
    const tasks = window.tasks || []; // Fallback assumption for demonstration

    const updatedTasks = tasks.filter(task => task.id !== taskId);

    // 2. Update the global state (if applicable)
    window.tasks = updatedTasks;

    // 3. Re-render the task list in the DOM.
    renderTaskList(updatedTasks);
}
