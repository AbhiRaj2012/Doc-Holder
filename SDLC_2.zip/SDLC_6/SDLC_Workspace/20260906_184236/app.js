// DOM references (deterministically generated from the manifest's `ids`)
const canvasArea = document.getElementById('canvas-area');
const toolPalette = document.getElementById('tool-palette');
const colorPicker = document.getElementById('color-picker');
const strokeWidthSelector = document.getElementById('stroke-width-selector');
const eraserTool = document.getElementById('eraser-tool');
const clearCanvasButton = document.getElementById('clear-canvas-button');
const strokeWidthValue = document.getElementById('stroke-width-value');

// Function implementations (filled in below)
function initializeCanvas() {
    const canvas = canvasArea;
    if (!canvas) {
        console.error("Canvas element not found.");
        return;
    }

    const ctx = canvas.getContext("2d");

    // Initialize drawing state variables
    let isDrawing = false;
    let currentColor = "#000000"; // Default black
    let currentStrokeWidth = 5;
    let toolMode = "pen"; // Default drawing tool

    // Set initial canvas properties
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.strokeStyle = currentColor;
    ctx.lineWidth = currentStrokeWidth;

    console.log("Canvas initialized. Drawing state ready.");
}
function setupEventListeners(canvas, colorPicker, widthSelector, clearButton) {
    // --- 1. Canvas Drawing Events ---
    const ctx = canvas.getContext("2d");

    // Helper function to get coordinates relative to the canvas
    const getMousePos = (e) => {
        const rect = canvas.getBoundingClientRect();
        let clientX, clientY;

        if (e.touches && e.touches.length > 0) {
            clientX = e.touches[0].clientX;
            clientY = e.touches[0].clientY;
        } else {
            clientX = e.clientX;
            clientY = e.clientY;
        }

        return {
            x: clientX - rect.left,
            y: clientY - rect.top
        };
    };

    const handleStart = (e) => {
        e.preventDefault(); // Prevent default scrolling/zooming on touch
        const pos = getMousePos(e);
        
        // Assume drawing starts on pointer down
        handlePointerDown({ clientX: pos.x, clientY: pos.y, type: 'mousedown' });
    };

    const handleMove = (e) => {
        if (!isDrawing) return;
        e.preventDefault();
        const pos = getMousePos(e);

        ctx.lineTo(pos.x, pos.y);
        ctx.stroke();
    };

    const handleEnd = () => {
        isDrawing = false;
        ctx.closePath();
    };

    // Mouse Events
    canvas.addEventListener("mousedown", handleStart);
    canvas.addEventListener("mousemove", handleMove);
    canvas.addEventListener("mouseup", handleEnd);
    canvas.addEventListener("mouseout", handleEnd);

    // Touch Events (for mobile support)
    canvas.addEventListener("touchstart", handleStart);
    canvas.addEventListener("touchmove", handleMove);
    canvas.addEventListener("touchend", handleEnd);


    // --- 2. UI Control Event Listeners ---

    // Color Picker
    colorPicker.addEventListener("input", (e) => {
        currentColor = e.target.value;
        ctx.strokeStyle = currentColor;
    });

    // Stroke Width Selector
    widthSelector.addEventListener("input", (e) => {
        const newWidth = parseFloat(e.target.value);
        currentStrokeWidth = newWidth;
        ctx.lineWidth = currentStrokeWidth;
        strokeWidthValue.value = currentStrokeWidth; // Update the display value
    });

    // Eraser Tool (Example implementation)
    eraserTool.addEventListener("click", () => {
        ctx.strokeStyle = "#FFFFFF"; // Set color to white for erasing effect
        ctx.lineWidth = 50; // Make the eraser wide
    });

    // Clear Button
    clearButton.addEventListener("click", () => {
        // Clear the entire canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);
    });
}
function handlePointerDown(event) {
    // Determine if the event is a mouse or touch event
    const isMouse = event.type === 'mousedown';
    const isTouch = event.type === 'touchstart';

    if (isMouse || isTouch) {
        // Ensure we are only handling the first pointer
        if (event.button !== undefined && event.button !== 0) return; // Ignore right clicks if needed

        // Start drawing state
        isDrawing = true;

        // Get coordinates (handling both mouse and touch events)
        let clientX, clientY;

        if (isMouse) {
            clientX = event.clientX;
            clientY = event.clientY;
        } else if (isTouch) {
            clientX = event.touches[0].clientX;
            clientY = event.touches[0].clientY;
        } else {
            return;
        }

        // Call the main drawing function (which would be attached in setupEventListeners)
        // For this isolated function, we assume the context (ctx, isDrawing, etc.) is accessible.
        // Since we are implementing the core logic, we simulate the state change.
        
        // In a real setup, this function would call the logic defined in setupEventListeners.
        // For demonstration purposes, we just confirm the state change:
        console.log(`Pointer Down detected at (${clientX}, ${clientY}). Starting path.`);
    }
}
function handlePointerMove(event) {
    // Assuming 'ctx' is the canvas context, and drawing state variables (startX, startY, currentTool, etc.) are accessible in the scope.

    // 1. Get coordinates relative to the canvas
    const rect = canvasArea.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    // 2. Set drawing properties (assuming these are managed by the application state)
    // Example: Set the current color and width based on UI inputs
    const color = getDrawingColor(); // Placeholder for actual state retrieval
    const width = getDrawingWidth(); // Placeholder for actual state retrieval

    // 3. Draw the line segment
    drawStroke(ctx, startX, startY, x, y, color, width);

    // 4. Update the starting point for the next segment
    startX = x;
    startY = y;
}
function handlePointerUp(event) {
    // 1. Finalize the drawing action.
    // In a real application, this is where you might save the completed stroke data
    // or finalize the current path.

    // 2. Reset the drawing state for the next stroke.
    // Example: Stop the drawing flag
    isDrawing = false;

    // Note: If the drawing state is managed by a class or global variables,
    // the reset logic would be applied here.
}
function drawStroke(ctx, x1, y1, x2, y2, color, width) {
    // Set the drawing style
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.lineCap = 'round'; // Makes the ends of lines look better

    // Start a new path
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);

    // Render the line
    ctx.stroke();
}
function applyEraser(ctx, x, y, width) {
    // Set the fill style to the background color (erasing)
    ctx.fillStyle = '#FFFFFF'; // Assuming a standard white background for erasure
    ctx.fillRect(x, y, width, ctx.canvas.height - y);
}
function clearCanvas(ctx) {
    // Clears the entire canvas area
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
}
function saveCanvasState(canvas) {
    // Saves the current state of the canvas as a PNG data URL
    const dataURL = canvas.toDataURL('image/png');
    // In a real application, you would typically use this dataURL for saving or display.
    // For this function implementation, we return the data URL.
    return dataURL;
}
function loadCanvasState(canvas, imageDataUrl) {
    const ctx = canvas.getContext('2d');

    if (!imageDataUrl) {
        console.error("No image data URL provided for loading.");
        return;
    }

    const img = new Image();
    img.onload = () => {
        // Clear the canvas before loading new state
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        // Draw the loaded image onto the canvas
        ctx.drawImage(img, 0, 0);
    };

    img.onerror = () => {
        console.error("Error loading image data.");
    };

    img.src = imageDataUrl;
}
function updateState(color, width, toolMode) {
    // 1. Update Color Picker
    if (typeof color === 'string') {
        colorPicker.value = color;
    }

    // 2. Update Stroke Width
    if (typeof width === 'number') {
        strokeWidthValue = width;
        // Update the visual display if necessary (assuming strokeWidthValue is bound to a display element)
        // For demonstration, we ensure the global variable is updated.
    }

    // 3. Update Tool Mode (Example logic based on toolMode)
    if (toolMode === 'eraser') {
        eraserTool.classList.add('active');
        // Optionally hide drawing tools
    } else {
        eraserTool.classList.remove('active');
        // Optionally show drawing tools
    }

    console.log(`State updated: Color=${color}, Width=${width}, ToolMode=${toolMode}`);
}
