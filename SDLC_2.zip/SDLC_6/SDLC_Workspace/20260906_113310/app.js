// DOM references (deterministically generated from the manifest's `ids`)
const inputCustomerName = document.getElementById('input-customer-name');
const inputInvoiceDate = document.getElementById('input-invoice-date');
const inputTaxRate = document.getElementById('input-tax-rate');
const btnAddItem = document.getElementById('btn-add-item');
const itemRowTemplate = document.getElementById('item-row-template');
const btnSaveInvoice = document.getElementById('btn-save-invoice');
const btnPrintInvoice = document.getElementById('btn-print-invoice');
const invoiceSummarySubtotal = document.getElementById('invoice-summary-subtotal');
const invoiceSummaryTax = document.getElementById('invoice-summary-tax');
const invoiceSummaryTotal = document.getElementById('invoice-summary-total');

// Function implementations (filled in below)
{
  "name": "loadInvoiceData",
  "params": [],
  "description": "Loads invoice data (header and items) from Local Storage and initializes the UI."
}
{
  "name": "loadInvoiceData",
  "params": [],
  "description": "Loads invoice data (header and items) from Local Storage and initializes the UI."
}
function loadInvoiceData() {
  const STORAGE_KEY = 'invoiceData';

  // 1. Retrieve data from Local Storage
  const storedData = localStorage.getItem(STORAGE_KEY);
  let invoiceData = {};

  if (storedData) {
    try {
      invoiceData = JSON.parse(storedData);
    } catch (e) {
      console.error("Error parsing stored invoice data:", e);
      invoiceData = {}; // Reset if parsing fails
    }
  }

  // 2. Initialize Header Fields
  const customerName = invoiceData.customerName || '';
  const invoiceDate = invoiceData.invoiceDate || '';
  const taxRate = invoiceData.taxRate || 0;
  const items = invoiceData.items || [];

  inputCustomerName.value = customerName;
  inputInvoiceDate.value = invoiceDate;
  inputTaxRate.value = taxRate;

  // 3. Clear existing item rows and recalculate totals
  const itemContainer = document.getElementById('item-list');
  itemContainer.innerHTML = '';

  let subtotal = 0;
  let taxAmount = 0;

  // 4. Render Itemized List and Calculate Totals
  items.forEach(item => {
    const itemSubtotal = parseFloat(item.quantity) * parseFloat(item.rate);
    subtotal += itemSubtotal;
    taxAmount += itemSubtotal * (taxRate / 100);

    const row = document.createElement('div');
    row.className = 'invoice-item';
    row.innerHTML = `
      <input type="text" class="item-name" value="${item.name}" readonly>
      <input type="number" class="item-quantity" value="${item.quantity}" readonly>
      <input type="number" class="item-rate" value="${item.rate}" readonly>
      <input type="text" class="item-subtotal" readonly>${itemSubtotal.toFixed(2)}
    `;
    itemContainer.appendChild(row);
  });

  // 5. Calculate and Display Final Totals
  const finalTotal = subtotal + taxAmount;

  document.getElementById('invoice-summary-subtotal').textContent = subtotal.toFixed(2);
  document.getElementById('invoice-summary-tax').textContent = taxAmount.toFixed(2);
  document.getElementById('invoice-summary-total').textContent = finalTotal.toFixed(2);

  // 6. Attach Event Listeners (Delegation for dynamic items)

  // Add Item Listener
  btnAddItem.addEventListener('click', () => {
    const itemName = document.querySelector('.item-name').value;
    const itemQuantity = parseFloat(document.querySelector('.item-quantity').value);
    const itemRate = parseFloat(document.querySelector('.item-rate').value);

    if (itemName && !isNaN(itemQuantity) && !isNaN(itemRate)) {
      const itemSubtotal = itemQuantity * itemRate;

      const newRow = document.createElement('div');
      newRow.className = 'invoice-item';
      newRow.innerHTML = `
        <input type="text" class="item-name" value="${itemName}" readonly>
        <input type="number" class="item-quantity" value="${itemQuantity}" readonly>
        <input type="number" class="item-rate" value="${itemRate}" readonly>
        <input type="text" class="item-subtotal" readonly>${itemSubtotal.toFixed(2)}
      `;
      itemContainer.appendChild(newRow);

      // Recalculate totals after adding the item
      recalculateTotals(itemContainer, subtotal, taxAmount, taxRate);
    } else {
      alert("Please enter valid Item Name, Quantity, and Rate.");
    }
  });

  // Save Invoice Listener
  btnSaveInvoice.addEventListener('click', () => {
    const currentItems = [];
    const customerNameVal = inputCustomerName.value;
    const invoiceDateVal = inputInvoiceDate.value;
    const taxRateVal = parseFloat(inputTaxRate.value);

    // Collect item data
    document.querySelectorAll('.invoice-item').forEach(row => {
      const name = row.querySelector('.item-name').value;
      const quantity = parseFloat(row.querySelector('.item-quantity').value);
      const rate = parseFloat(row.querySelector('.item-rate').value);
      currentItems.push({ name, quantity, rate });
    });

    const dataToSave = {
      customerName: customerNameVal,
      invoiceDate: invoiceDateVal,
      taxRate: taxRateVal,
      items: currentItems
    };

    localStorage.setItem(STORAGE_KEY, JSON.stringify(dataToSave));
    alert('Invoice saved successfully to local storage!');
  });

  // Print Invoice Listener
  btnPrintInvoice.addEventListener('click', () => {
    window.print();
  });
}

// Helper function to recalculate totals based on current DOM state
function recalculateTotals(container, currentSubtotal, currentTax, taxRate) {
    let newSubtotal = 0;
    let newTax = 0;

    Array.from(container.querySelectorAll('.invoice-item')).forEach(row => {
        const quantity = parseFloat(row.querySelector('.item-quantity').value) || 0;
        const rate = parseFloat(row.querySelector('.item-rate').value) || 0;
        const itemSubtotal = quantity * rate;
        newSubtotal += itemSubtotal;
    });

    const newTaxAmount = newSubtotal * (taxRate / 100);

    document.getElementById('invoice-summary-subtotal').textContent = newSubtotal.toFixed(2);
    document.getElementById('invoice-summary-tax').textContent = newTaxAmount.toFixed(2);
    document.getElementById('invoice-summary-total').textContent = (newSubtotal + newTaxAmount).toFixed(2);
}

// Initialize the application when the script loads
document.addEventListener('DOMContentLoaded', loadInvoiceData);

/**
 * Helper function to re-render the item list and recalculate totals based on current data.
 * @param {object} data - The current invoice data object.
 */
function renderItems(data) {
    const itemContainer = document.getElementById('item-list');
    let subtotal = 0;
    let taxAmount = 0;

    data.items.forEach(item => {
        const itemTotal = item.quantity * item.rate;
        subtotal += itemTotal;
        taxAmount += itemTotal * data.taxRate;

        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.name}</td>
            <td><input type="number" class="item-quantity" value="${item.quantity}" step="1"></td>
            <td><input type="number" class="item-rate" value="${item.rate}" step="0.01"></td>
            <td>$${itemTotal.toFixed(2)}</td>
        `;
        itemContainer.appendChild(row);
    });

    const finalTotal = subtotal + taxAmount;

    document.getElementById('invoice-summary-subtotal').textContent = `$${subtotal.toFixed(2)}`;
    document.getElementById('invoice-summary-tax').textContent = `$${taxAmount.toFixed(2)}`;
    document.getElementById('invoice-summary-total').textContent = `$${finalTotal.toFixed(2)}`;
}

/**
 * Helper function to recalculate totals based on the current invoice data.
 * This function is called whenever item quantities or rates are updated.
 * @param {object} data - The current invoice data object.
 */


// Initialize the application when the script loads
loadInvoiceData();
function addItemRow(rate, quantity) {
    // 1. Create the new row element
    const row = document.createElement('div');
    row.className = 'invoice-item-row'; // Add a class for styling
    row.setAttribute('data-rate', rate);
    row.setAttribute('data-quantity', quantity);

    // 2. Populate the row using the template
    const template = document.getElementById('item-row-template');
    if (template) {
        // Assuming itemRowTemplate is a string or a structure that can be populated
        // We will construct the row content dynamically based on the template structure
        row.innerHTML = `
            <div class="item-details">
                <input type="number" class="item-rate" placeholder="Rate" value="${rate}" min="0" step="0.01">
                <input type="number" class="item-quantity" placeholder="Quantity" value="${quantity}" min="1" step="1">
                <div class="item-subtotal">
                    Subtotal: <span class="item-subtotal-value">0.00</span>
                </div>
            </div>
            <button class="remove-item">Remove</button>
        `;
        
        // 3. Append the row to the item list container
        const itemContainer = document.getElementById('item-list-container'); // Assuming this is the target container
        if (itemContainer) {
            itemContainer.appendChild(row);
        }
    } else {
        console.error("Item row template not found.");
    }
}
function calculateItemSubtotal(rate, quantity) {
    // Ensure inputs are treated as numbers
    const rateNum = parseFloat(rate) || 0;
    const quantityNum = parseFloat(quantity) || 0;

    // Calculate the subtotal
    const subtotal = rateNum * quantityNum;

    // Update the display element associated with this item row
    const rowElement = document.querySelector(`[data-rate="${rate}"], [data-quantity="${quantity}"]`).closest('.invoice-item-row');
    
    if (rowElement) {
        const subtotalSpan = rowElement.querySelector('.item-subtotal-value');
        if (subtotalSpan) {
            subtotalSpan.textContent = subtotal.toFixed(2);
        }
    }

    return subtotal;
}
function calculateGrandSubtotal(itemSubtotals) {
    if (!Array.isArray(itemSubtotals)) {
        return 0;
    }
    return itemSubtotals.reduce((sum, current) => sum + current, 0);
}
function calculateTaxAmount(grandSubtotal, taxRate) {
    if (typeof grandSubtotal !== 'number' || typeof taxRate !== 'number') {
        return 0;
    }
    return grandSubtotal * taxRate;
}
function calculateFinalTotal(grandSubtotal, taxAmount) {
    if (typeof grandSubtotal !== 'number' || typeof taxAmount !== 'number') {
        return 0;
    }
    return grandSubtotal + taxAmount;
}
function renderInvoice(invoiceData) {
    // 1. Render Header Details
    inputCustomerName.value = invoiceData.customerName || '';
    inputInvoiceDate.value = invoiceData.invoiceDate || '';
    inputTaxRate.value = invoiceData.taxRate || 0;

    // 2. Render Itemized List
    const itemListContainer = document.getElementById('invoice-items-list');
    itemListContainer.innerHTML = ''; // Clear previous items

    if (invoiceData.items && invoiceData.items.length > 0) {
        invoiceData.items.forEach(item => {
            const row = document.createElement('div');
            row.className = 'invoice-item-row';
            row.innerHTML = `
                <div class="item-description">${item.description}</div>
                <div class="item-quantity">${item.quantity}</div>
                <div class="item-price">$${item.price.toFixed(2)}</div>
                <div class="item-total">$${(item.price * item.quantity).toFixed(2)}</div>
            `;
            itemListContainer.appendChild(row);
        });
    } else {
        itemListContainer.innerHTML = '<p class="no-items">No items added yet.</p>';
    }

    // 3. Calculate Totals
    let subtotal = 0;
    invoiceData.items.forEach(item => {
        subtotal += item.price * item.quantity;
    });

    const taxAmount = subtotal * (invoiceData.taxRate / 100);
    const total = subtotal + taxAmount;

    // 4. Update Summary Fields
    document.getElementById('invoice-summary-subtotal').textContent = `$${subtotal.toFixed(2)}`;
    document.getElementById('invoice-summary-tax').textContent = `$${taxAmount.toFixed(2)}`;
    document.getElementById('invoice-summary-total').textContent = `$${total.toFixed(2)}`;
}
function saveInvoiceData(invoiceData) {
    try {
        // Store the entire invoice object in Local Storage
        localStorage.setItem('currentInvoice', JSON.stringify(invoiceData));
        console.log('Invoice data successfully saved to Local Storage.');
    } catch (error) {
        console.error('Error saving invoice data to Local Storage:', error);
        alert('Error: Could not save invoice data. Local Storage might be full or unavailable.');
    }
}
function printInvoice() {
    // Trigger the browser's native print dialog.
    // The CSS @media print rules should handle the specific formatting.
    window.print();
}
