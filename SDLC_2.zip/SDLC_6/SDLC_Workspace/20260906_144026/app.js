// DOM references (deterministically generated from the manifest's `ids`)
const canvasArea = document.getElementById('canvas-area');
const controlsPanel = document.getElementById('controls-panel');
const colorPicker = document.getElementById('color-picker');
const brushSizeSelector = document.getElementById('brush-size-selector');
const eraserTool = document.getElementById('eraser-tool');
const clearCanvasButton = document.getElementById('clear-canvas-button');

// Function implementations (filled in below)
function initializeCanvas(canvasElement) {
    const ctx = canvasElement.getContext('2d');

    // Ensure the canvas covers the entire viewport
    canvasElement.width = window.innerWidth;
    canvasElement.height = window.innerHeight;

    // Set initial drawing properties
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#000000'; // Default color
    ctx.lineWidth = 5; // Default brush size
}
function setupEventListeners(canvasElement, colorPicker, sizeSelector, eraserButton, clearButton) {
    const ctx = canvasElement.getContext('2d');

    // --- Drawing Event Handlers ---
    const handleDrawingStart = (event) => {
        handleStartDrawing(event, ctx);
    };

    const handleDrawing = (event) => {
        const { offsetX, offsetY } = event;
        ctx.lineTo(offsetX, offsetY);
        ctx.stroke();
    };

    const handleDrawingEnd = () => {
        ctx.closePath();
    };

    // Mouse Events
    canvasElement.addEventListener('mousedown', handleDrawingStart);
    canvasElement.addEventListener('mousemove', handleDrawing);
    canvasElement.addEventListener('mouseup', handleDrawingEnd);
    canvasElement.addEventListener('mouseout', handleDrawingEnd);

    // Touch Events (for mobile support)
    canvasElement.addEventListener('touchstart', (e) => {
        e.preventDefault(); // Prevent scrolling
        handleDrawingStart(e.touches[0]);
    });
    canvasElement.addEventListener('touchmove', (e) => {
        e.preventDefault();
        handleDrawing(e.touches[0]);
    });
    canvasElement.addEventListener('touchend', handleDrawingEnd);


    // --- UI Control Event Handlers ---

    // Color Picker
    colorPicker.addEventListener('input', (e) => {
        ctx.strokeStyle = e.target.value;
    });

    // Size Selector
    sizeSelector.addEventListener('input', (e) => {
        ctx.lineWidth = e.target.value;
    });

    // Eraser Tool
    eraserButton.addEventListener('mousedown', (e) => {
        ctx.strokeStyle = 'white'; // Set color to white (or background color) for erasing effect
        ctx.lineWidth = 50; // Make the brush very large for erasing
    });
    eraserButton.addEventListener('mouseup', () => {
        ctx.strokeStyle = '#000000'; // Reset color
        ctx.lineWidth = 5; // Reset brush size
    });
    eraserButton.addEventListener('mousemove', (e) => {
        // Redraw the line with the new settings
        ctx.lineTo(e.offsetX, e.offsetY);
        ctx.stroke();
    });

    // Clear Canvas Button
    clearButton.addEventListener('click', () => {
        ctx.clearRect(0, 0, canvasElement.width, canvasElement.height);
    });
}
function handleStartDrawing(event, context) {
    // Determine if the event is a mouse event or a touch event
    let clientX, clientY;

    if (event.type.startsWith('touch')) {
        // Handle touch events
        clientX = event.touches[0].clientX;
        clientY = event.touches[0].clientY;
    } else {
        // Handle mouse events
        clientX = event.clientX;
        clientY = event.clientY;
    }

    // Get coordinates relative to the canvas
    const rect = context.canvas.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;

    // Start a new path
    context.beginPath();
    context.moveTo(x, y);
}
function handleDrawing(event, context, isErasing, color, size) {
    // In a real application, this function would typically update the current drawing state
    // or prepare the path based on the mouse position.
    // For this implementation, we assume the coordinates are captured and ready for the next step.
    
    const rect = context.canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    // Store the starting point for the stroke
    context.beginPath();
    context.moveTo(x, y);
}
function handleEndDrawing(context) {
    // Finalizes the drawing path. This is where the actual stroke is executed.
    // In a complete system, the path data would be retrieved from the context.
    
    // Since we don't have the full path data from handleDrawing, we simulate the finalization step
    // by assuming the path is ready to be drawn based on the context state.
    
    // A typical implementation would look like this:
    // context.stroke(); 
    
    // For demonstration purposes, we ensure the context is ready for the next operation.
    console.log("Drawing path finalized.");
}
function applyStroke(context, x1, y1, x2, y2, isErasing, color, size) {
    // Determine the style based on the erasing mode
    if (isErasing) {
        // If erasing, we typically clear the area (e.g., draw white)
        context.strokeStyle = 'white';
        context.lineWidth = size;
    } else {
        // If drawing, use the specified color
        context.strokeStyle = color;
        context.lineWidth = size;
    }

    // Apply the stroke
    context.beginPath();
    context.moveTo(x1, y1);
    context.lineTo(x2, y2);
    context.stroke();
}
function clearCanvas(context) {
    // Get the dimensions of the canvas
    const width = context.canvas.width;
    const height = context.canvas.height;

    // Clear the entire canvas area
    context.clearRect(0, 0, width, height);
}
function saveCanvasData(context) {
    // 1. Get the canvas element
    const canvas = context.canvas;

    // 2. Serialize the canvas content to a Data URL (PNG format)
    const dataURL = canvas.toDataURL('image/png');

    // 3. Store the data URL in LocalStorage
    try {
        localStorage.setItem('canvasData', dataURL);
    } catch (e) {
        console.error('Failed to save canvas data to LocalStorage:', e);
    }
}
function loadCanvasData(context) {
    // 1. Retrieve the data URL from LocalStorage
    const dataURL = localStorage.getItem('canvasData');

    if (dataURL) {
        // 2. Get the canvas element
        const canvas = context.canvas;

        // 3. Create a new Image object to load the data
        const img = new Image();
        
        // 4. Set the source of the image
        img.src = dataURL;

        // 5. Wait for the image to load before drawing it
        img.onload = function() {
            // Redraw the canvas with the loaded image
            context.drawImage(img, 0, 0);
        };
    } else {
        console.log('No canvas data found in LocalStorage.');
    }
}
function updateState(color, size, isErasing) {
    // Update the color picker based on the input color
    if (typeof color === 'string') {
        colorPicker.value = color;
    }

    // Update the brush size selector based on the input size
    if (typeof size === 'number') {
        brushSizeSelector.value = size;
    }

    // Update the eraser tool state
    if (typeof isErasing === 'boolean') {
        // Assuming eraserTool is a button or a class toggle element
        if (isErasing) {
            eraserTool.classList.add('active'); // Example state change
            eraserTool.setAttribute('data-mode', 'erase');
        } else {
            eraserTool.classList.remove('active');
            eraserTool.setAttribute('data-mode', 'draw');
        }
    }

    // Note: In a real application, these updates would also trigger a redraw on the canvasArea.
}
