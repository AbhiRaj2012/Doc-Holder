"""
Offline Agentic SDLC — Vanilla Web App Generator (v8)
=======================================================
Runs entirely against a local Ollama server (no network calls).
Builds a 3-file vanilla web app (index.html / style.css / app.js) using
four cooperating agents orchestrated with LangGraph.

Includes context-aware generation, self-healing chunked implementation,
deterministic DOM validation, and cross-run DeepEval benchmark tracking.
"""

import os
import re
import json
import operator
import subprocess
import tempfile
from pathlib import Path
from datetime import datetime
from typing import TypedDict, Annotated, Optional

from langgraph.graph import StateGraph, END
from langchain_ollama import ChatOllama

# Optional DeepEval LLM-as-judge dependency. Set telemetry opt-out before import.
os.environ.setdefault("DEEPEVAL_TELEMETRY_OPT_OUT", "YES")
try:
    from deepeval.models.base_model import DeepEvalBaseLLM
    from deepeval.metrics import GEval
    from deepeval.test_case import LLMTestCase, LLMTestCaseParams
    DEEPEVAL_AVAILABLE = True
except Exception:
    DEEPEVAL_AVAILABLE = False

# ==========================================
# 1. INITIALIZATION & CONFIGURATION
# ==========================================
# Ensure correct local Ollama model tag is used.
MODEL_NAME = "gemma4:e2b"          # small/quantized instruction model
OLLAMA_URL = "http://localhost:11434"
MAX_ATTEMPTS = 3                   # coder<->reviewer retries per file
CHUNK_SIZE = 3                     # functions implemented per LLM call

# Increased context window to prevent empty-response cascades during app.js review.
NUM_CTX = 24576
NUM_PREDICT_TEXT = 3000            # code/requirements generation budget
NUM_PREDICT_JSON = 1200            # manifest sections / reviewer verdicts

llm = ChatOllama(
    model=MODEL_NAME,
    base_url=OLLAMA_URL,
    num_predict=NUM_PREDICT_TEXT,
    num_ctx=NUM_CTX,
    temperature=0.1,
)

# Secondary client forces JSON output for structured tasks to prevent parsing errors.
llm_json = ChatOllama(
    model=MODEL_NAME,
    base_url=OLLAMA_URL,
    num_predict=NUM_PREDICT_JSON,
    num_ctx=NUM_CTX,
    temperature=0.1,
    format="json",
)


def invoke_text(client: ChatOllama, prompt: str, retries: int = 1) -> str:
    """Call LLM and retry once if response is genuinely empty."""
    content = ""
    for _ in range(retries + 1):
        content = client.invoke(prompt).content
        if content and content.strip():
            return content
    return content


# ==========================================
# 2. STATE DEFINITION
# ==========================================
class AgentState(TypedDict):
    user_input: str
    run_dir: Path
    project_brief: str                                    # short, concise — used by Coder/Reviewer
    requirements: str                                      # full spec — Architect-only
    manifest: dict
    task_stack: list[dict]                                 # Planner's execution queue
    feedback: dict                                         # reviewer -> coder, {} means clean
    attempts: int                                          # attempts on the CURRENT file
    last_revision_mode: str                                # how the current file was (re)built
    validation_errors: Annotated[dict, operator.ior]       # files still failing at max attempts
    eval_matrix: Annotated[dict, operator.ior]             # per-file quality metrics


# ==========================================
# 3. PERSONAS
# ==========================================
SCOPER_PERSONA = (
    "You are a professional project requirement analyst who scopes small "
    "vanilla-JS web apps precisely and concisely."
)
ARCHITECT_PERSONA = (
    "You are a professional software architect who plans small vanilla "
    "HTML/CSS/JS apps and outputs strict, minimal JSON."
)
CODER_PERSONA = (
    "You are a professional front-end engineer who writes clean, stable, "
    "bug-free vanilla HTML/CSS/JS."
)
REVIEWER_PERSONA = (
    "You are a meticulous code reviewer and QA engineer who checks "
    "front-end code against a spec and flags UI/logic/syntax flaws."
)

# Plain template fragments kept separate to avoid f-string brace escaping issues.
IMPL_FORMAT_NOTE = """Format EACH function exactly like this, one block per function:
<IMPL id="functionName">
function functionName(args) {
    // actual logic here
}
</IMPL>"""

PATCH_FORMAT_NOTE = """Output ONLY one or more SEARCH/REPLACE blocks that fix the issue above.
Do NOT rewrite the whole file — only the minimal lines that must change.
Copy the SEARCH text EXACTLY as it appears in CURRENT CODE below (same
whitespace, same characters). Keep each block as short as possible — just
enough lines to uniquely locate the spot. You may repeat the block for
multiple separate fixes.

<<<<<<< SEARCH
<exact lines to find>
=======
<replacement lines>
>>>>>>> REPLACE"""


# ==========================================
# 4. PERSISTENCE & PARSING HELPERS
# ==========================================
def write_log(run_dir: Path, step: str, details: str) -> None:
    """Append-only execution log for post-run auditing."""
    log_file = run_dir / "execution_log.txt"
    timestamp = datetime.now().strftime("%H:%M:%S")
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"\n[{timestamp}] === {step.upper()} ===\n")
        f.write(str(details) + "\n")
        f.write("-" * 80 + "\n")


def save_artifact(run_dir: Path, filename: str, content: str) -> str:
    """Flush content to disk immediately to maintain disk-as-source-of-truth."""
    (run_dir / filename).write_text(content, encoding="utf-8")
    return content


def load_artifact(run_dir: Path, filename: str) -> str:
    """Read current durable file copy to ensure revisions build on actual disk state."""
    path = run_dir / filename
    return path.read_text(encoding="utf-8") if path.exists() else ""


def extract_json(text: str) -> dict:
    """Salvage JSON object from LLM output as a defensive fallback."""
    clean = re.sub(r"```(?:json)?", "", text, flags=re.IGNORECASE).replace("```", "")
    start, end = clean.find("{"), clean.rfind("}")
    if start == -1 or end == -1:
        return {}
    try:
        return json.loads(clean[start:end + 1], strict=False)
    except Exception as e:
        print(f"   [!] JSON parse error: {e}")
        return {}


def extract_code(response_text: str) -> str:
    """Extract code from markdown fences, gracefully handling truncated closures."""
    if not response_text:
        return ""
    match = re.search(r"```(?:[a-zA-Z]*)\n?(.*?)\n?```", response_text, re.DOTALL)
    if match:
        return match.group(1).strip()
    match = re.search(r"```(?:[a-zA-Z]*)\n?(.*)", response_text, re.DOTALL)
    return match.group(1).strip() if match else response_text.strip()


def focused_context(manifest: dict, keys: list[str]) -> dict:
    """Slice manifest down to only the sections needed by a given file."""
    return {k: manifest.get(k, {}) for k in keys}


# ==========================================
# 5. JS STRUCTURAL HELPERS (deterministic, no LLM)
# ==========================================
def _mask_js_comments(code: str) -> str:
    """Mask JS comments to spaces so structural searches ignore commented-out code."""
    out = list(code)
    i, n = 0, len(code)
    while i < n:
        if code[i] == "/" and i + 1 < n and code[i + 1] == "/":
            while i < n and code[i] != "\n":
                out[i] = " "
                i += 1
        elif code[i] == "/" and i + 1 < n and code[i + 1] == "*":
            out[i] = out[i + 1] = " "
            i += 2
            while i < n and not (code[i] == "*" and i + 1 < n and code[i + 1] == "/"):
                if code[i] != "\n":
                    out[i] = " "
                i += 1
            if i < n:
                out[i] = out[i + 1] = " "
                i += 2
        else:
            i += 1
    return "".join(out)


_GEID_CALL_RE = re.compile(r"""document\.getElementById\(\s*['"]([^'"]+)['"]\s*\)""")


def find_bad_getelementbyid_ids(code: str, valid_ids: set) -> list[str]:
    """Find literal getElementById calls using IDs not found in the manifest."""
    found = _GEID_CALL_RE.findall(_mask_js_comments(code))
    return sorted({fid for fid in found if fid not in valid_ids})


def _tokenize_id(id_str: str) -> set:
    """Split an ID into lowercase tokens for casing/plural-agnostic fuzzy matching."""
    spaced = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", id_str)
    tokens = {t.lower() for t in re.split(r"[^a-zA-Z0-9]+", spaced) if t}
    return {t[:-1] if len(t) > 3 and t.endswith("s") and not t.endswith("ss") else t for t in tokens}


def best_id_match(bad_id: str, valid_ids: list, min_overlap: float = 0.5) -> Optional[str]:
    """Fuzzy match an incorrect ID to the closest real manifest ID."""
    bad_tokens = _tokenize_id(bad_id)
    if not bad_tokens:
        return None
    best, best_score = None, 0.0
    for real_id in valid_ids:
        real_tokens = _tokenize_id(real_id)
        if not real_tokens:
            continue
        overlap = len(bad_tokens & real_tokens) / len(bad_tokens | real_tokens)
        if overlap > best_score:
            best, best_score = real_id, overlap
    return best if best_score >= min_overlap else None


def autofix_getelementbyid_ids(code: str, id_var_map: dict) -> tuple[str, list[str]]:
    """Deterministically replace wrong getElementById calls with correct existing variables."""
    valid_ids = list(id_var_map.keys())
    masked = _mask_js_comments(code)
    out, fixes, last = [], [], 0
    for m in _GEID_CALL_RE.finditer(masked):
        found_id = m.group(1)
        replacement = None
        if found_id not in id_var_map:
            match = best_id_match(found_id, valid_ids)
            if match:
                replacement = id_var_map[match]
                fixes.append(f"getElementById('{found_id}') -> {replacement}  (matched real id '{match}')")
        out.append(code[last:m.start()])
        out.append(replacement if replacement else code[m.start():m.end()])
        last = m.end()
    out.append(code[last:])
    return "".join(out), fixes


INTERACTIVE_LISTENER_ELEMENTS = {"button", "canvas"}
_TEMPLATE_LIKE_ELEMENTS = {"template"}
_VALUE_BEARING_ELEMENTS = {"input", "textarea", "select"}


def compute_event_bindings(ids: list[dict]) -> list[dict]:
    """Determine necessary DOM events for interactive elements (e.g., click, pointerdown)."""
    id_var_map = compute_id_var_map(ids)
    bindings = []
    for item in ids:
        el_id = item.get("id", "")
        el = (item.get("element") or "").lower()
        var = id_var_map.get(el_id)
        if not var or el not in INTERACTIVE_LISTENER_ELEMENTS:
            continue
        if el == "button":
            bindings.append({"id": el_id, "var": var, "element": el,
                              "events": [("click", f"{var}ClickHandler")]})
        else:  # canvas
            bindings.append({"id": el_id, "var": var, "element": el,
                              "events": [("pointerdown", f"{var}PointerDownHandler"),
                                         ("pointermove", f"{var}PointerMoveHandler"),
                                         ("pointerup", f"{var}PointerUpHandler")]})
    return bindings


def synthesize_event_handler_functions(ids: list[dict], existing_functions: list[dict]) -> list[dict]:
    """Generate manifest function entries for synthesized event handlers."""
    existing_names = {f.get("name") for f in existing_functions if f.get("name")}
    purposes = {i.get("id"): i.get("purpose", "") for i in ids}
    synthesized = []
    for b in compute_event_bindings(ids):
        purpose = purposes.get(b["id"], "")
        for event_name, handler_name in b["events"]:
            if handler_name in existing_names:
                continue
            if b["element"] == "canvas":
                desc = (
                    f"Called on pointer '{event_name}' over the '{b['id']}' canvas ({purpose}). "
                    "x and y are ALREADY canvas-relative pixel coordinates, unified for both mouse and "
                    "touch input by the deterministic wiring in setupEventListeners() — do NOT read "
                    "event.offsetX/offsetY or event.touches yourself. Implement the actual drawing/"
                    "interaction logic (e.g. begin/continue/end a stroke), updating whatever shared state "
                    "this app uses to track the current interaction."
                )
                params = ["x", "y", "event"]
            else:
                desc = (
                    f"Handles a click on the '{b['id']}' button ({purpose}). Call whatever business-logic "
                    "function(s) elsewhere in this file actually perform the action, then persist state "
                    "(e.g. call saveState()) if this app defines one."
                )
                params = []
            synthesized.append({"name": handler_name, "params": params, "description": desc})
            existing_names.add(handler_name)
    return synthesized


def find_ids_missing_event_listener(code: str, ids: list[dict]) -> list[str]:
    """Flag interactive elements missing an addEventListener assignment."""
    id_var_map = compute_id_var_map(ids)
    masked = _mask_js_comments(code)
    missing = []
    for item in ids:
        if (item.get("element") or "").lower() not in INTERACTIVE_LISTENER_ELEMENTS:
            continue
        var = id_var_map.get(item.get("id", ""))
        if var and not re.search(rf"{re.escape(var)}\.addEventListener\(", masked):
            missing.append(item["id"])
    return missing


def find_invalid_dom_property_access(code: str, ids: list[dict]) -> list[str]:
    """Flag improper DOM accesses like .content on non-templates or .value on non-inputs."""
    id_var_map = compute_id_var_map(ids)
    masked = _mask_js_comments(code)
    issues = []
    for item in ids:
        var = id_var_map.get(item.get("id", ""))
        element = (item.get("element") or "").lower()
        if not var or not element:
            continue
        if element not in _TEMPLATE_LIKE_ELEMENTS and re.search(rf"\b{re.escape(var)}\.content\b", masked):
            issues.append(
                f"'{var}.content' is used, but '{var}' is a <{element}> per the manifest, not a "
                "<template> — only real <template> elements have a `.content` DocumentFragment; this will "
                "be undefined and the next call on it (e.g. .cloneNode) will throw."
            )
        if (element not in _VALUE_BEARING_ELEMENTS and element not in _TEMPLATE_LIKE_ELEMENTS
                and re.search(rf"\b{re.escape(var)}\.value\b", masked)):
            issues.append(
                f"'{var}.value' is used, but '{var}' is a <{element}> per the manifest, which has no "
                "`.value` property — only input/textarea/select elements do. Use `.textContent` or "
                "`.innerHTML` instead."
            )
    return issues


_BARE_CALL_RE = re.compile(r"(?<![.\w$])([A-Za-z_$][\w$]*)\s*\(")
_JS_CONTROL_KEYWORDS = {
    "if", "for", "while", "switch", "catch", "function", "return", "typeof", "new", "in", "of",
    "do", "else", "try", "finally", "void", "delete", "instanceof", "yield", "await", "async",
    "with", "throw", "let", "const", "var",
}
_JS_BUILTIN_CALLS = {
    "parseInt", "parseFloat", "isNaN", "isFinite", "setTimeout", "setInterval", "clearInterval",
    "clearTimeout", "alert", "confirm", "prompt", "Number", "String", "Boolean", "Array", "Object",
    "Date", "Map", "Set", "Symbol", "Promise", "RegExp", "encodeURIComponent", "decodeURIComponent",
    "requestAnimationFrame", "cancelAnimationFrame", "structuredClone", "fetch", "Error", "TypeError",
    "RangeError", "console",
}


def find_declared_js_function_names(code: str) -> set:
    """Find all top-level declared JS function names in the file."""
    masked = _mask_js_comments(code)
    names = set(re.findall(r"function\s+([A-Za-z_$][\w$]*)\s*\(", masked))
    names |= set(re.findall(
        r"(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:\([^)]*\)|[A-Za-z_$][\w$]*)\s*=>", masked
    ))
    names |= set(re.findall(r"(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*function\b", masked))
    return names


def find_undefined_function_calls(code: str, ids: list[dict]) -> list[str]:
    """Flag bare calls to undefined functions not present in file or built-ins."""
    masked = _mask_js_comments(code)
    declared = find_declared_js_function_names(code)
    dom_vars = set(compute_id_var_map(ids).values())
    known = declared | dom_vars | _JS_BUILTIN_CALLS | _JS_CONTROL_KEYWORDS
    return sorted({m.group(1) for m in _BARE_CALL_RE.finditer(masked) if m.group(1) not in known})


_TOP_LEVEL_DECL_RE = re.compile(r"^(?:const|let|var)\s+([A-Za-z_$][\w$]*)\b", re.MULTILINE)


def find_undeclared_state_variables(code: str) -> list[str]:
    """Flag shared mutable variables accessed across functions without top-level declarations."""
    masked = _mask_js_comments(code)
    top_level_declared = set(_TOP_LEVEL_DECL_RE.findall(masked))
    param_names = set()
    for m in re.finditer(r"function\s+[A-Za-z_$][\w$]*\s*\(([^)]*)\)", masked):
        param_names |= {p.strip().split("=")[0].strip() for p in m.group(1).split(",") if p.strip()}

    usage_by_name: dict[str, set] = {}
    for fname in find_declared_js_function_names(code):
        span = locate_js_function(code, fname)
        if not span:
            continue
        body = masked[span[0]:span[1]]
        found_here = set()
        for pattern in (
            r"\b([A-Za-z_$][\w$]*)\.push\(",
            r"\b([A-Za-z_$][\w$]*)\.findIndex\(",
            r"\b([A-Za-z_$][\w$]*)\.filter\(\s*[\w$]",
            r"typeof\s+([A-Za-z_$][\w$]*)\s*===?\s*['\"]undefined['\"]",
            # Boolean interaction flags (e.g. `isDrawing = true` in one handler,
            # `isDrawing = false` in another) — a real bug class seen in
            # practice: the flag is assigned in multiple places but never
            # actually declared anywhere, so it's implicitly a `window`
            # global (or throws under strict mode) rather than real state.
            r"\b([A-Za-z_$][\w$]*)\s*=\s*(?:true|false)\b",
            # setInterval/clearInterval id variables (e.g. `intervalId`) —
            # assigned in a start function, read in a stop/reset function,
            # and just as often never declared at the top level either.
            r"\b([A-Za-z_$][\w$]*)\s*=\s*set(?:Interval|Timeout)\(",
            r"clear(?:Interval|Timeout)\(\s*([A-Za-z_$][\w$]*)\s*\)",
        ):
            found_here.update(re.findall(pattern, body))
        for name in found_here:
            usage_by_name.setdefault(name, set()).add(fname)

    # NOTE: earlier revisions of this check also matched generic
    # `name++`/`name--`/`name === null`/`name !== null` patterns. Dropped —
    # those match ordinary local loop counters (`for (let i = 0; ...; i++)`,
    # a `let i` inside a for-loop's own init clause isn't caught by
    # `_TOP_LEVEL_DECL_RE`, which only matches declarations at the START of
    # a line) that coincidentally share a name across two functions without
    # being shared state at all — a false positive that would sink
    # perfectly fine generated code in the same "whack-a-mole" pattern this
    # harness has already had to fix once (see getElementById id-matching).
    ignore = {"self", "window", "document", "e", "event", "err", "error"} | _JS_BUILTIN_CALLS
    return sorted(
        name for name, funcs in usage_by_name.items()
        if len(funcs) >= 2 and name not in top_level_declared and name not in param_names and name not in ignore
    )


_LS_CALL_RE = re.compile(r"""localStorage\.(?:setItem|getItem)\(\s*['"]([^'"]+)['"]""")


def find_localstorage_schema_conflicts(code: str) -> list[str]:
    """Flag the SAME localStorage key being treated as an array in one
    place and a plain object/dictionary in another.

    Correlated per-key, within the ENCLOSING FUNCTION of each key's own
    setItem/getItem call, rather than "any array signal anywhere in the
    file + any dict-bracket signal anywhere in the file" (too coarse — a
    totally unrelated `settings[key] = value` lookup elsewhere in the file
    would flag a perfectly fine 'tasks' array) or a fixed character window
    (still leaks into a neighboring function on a short file). Using real
    function boundaries means only code that actually shares a call site
    with that key counts as evidence about that key's shape.
    """
    masked = _mask_js_comments(code)
    # Map every char offset to the (start, end) of whichever declared
    # function's body contains it, so a localStorage call can be matched
    # back to its own enclosing function's source text only.
    spans = [
        (s, e) for name in find_declared_js_function_names(code)
        for (s, e, truncated) in find_all_function_spans(code, name) if not truncated
    ]

    def enclosing_body(pos: int) -> str:
        for s, e in spans:
            if s <= pos < e:
                return masked[s:e]
        return masked  # no enclosing function found (top-level call) — fall back to whole file

    key_signals: dict[str, set] = {}
    for m in _LS_CALL_RE.finditer(masked):
        key = m.group(1)
        body = enclosing_body(m.start())
        if re.search(r"\.push\(|\.forEach\(|\.map\(|\.filter\(", body):
            key_signals.setdefault(key, set()).add("array-style (.push/.forEach/.map/.filter)")
        if re.search(r"\[\s*[A-Za-z_$][\w$]*\s*\]\s*=(?!=)|Object\.keys\(|delete\s+[A-Za-z_$][\w$]*\[", body):
            key_signals.setdefault(key, set()).add("dictionary-style (bracket-key assignment)")

    flagged = []
    for key, signals in key_signals.items():
        if len(signals) >= 2:
            flagged.append(
                f"localStorage key '{key}' is read/written near BOTH {' AND '.join(sorted(signals))} — "
                "pick ONE shape (an array of objects, e.g. [{id, ...}], is usually simplest) and use it "
                "everywhere this key is read or written."
            )
    return flagged


def find_placeholder_logic_functions(code: str, functions: list[dict]) -> list[str]:
    """Flag manifest functions left as dead-end mocks or empty loops."""
    masked = _mask_js_comments(code)
    flagged = []
    for f in functions:
        name, params = f.get("name"), f.get("params") or []
        if not name:
            continue
        span = locate_js_function(code, name)
        if not span:
            continue
        body = masked[span[0]:span[1]]
        inner = body[body.find("{") + 1: body.rfind("}")].strip()
        single_return = re.fullmatch(
            r"return\s+(?:['\"][^'\"]*['\"]|-?\d+(?:\.\d+)?|true|false|null)\s*;?", inner
        )
        # A zero-arg function trivially "ignores its params" (there are
        # none to use), so `not params` alone must also qualify a hardcoded
        # single-return as a stub. Previously this whole check was SKIPPED
        # for any function with an empty params list — which is exactly
        # the shape of most button click handlers and no-arg action
        # functions (startTimer(), resetTimer(), addTask()...), i.e.
        # precisely the "dead-end mock" functions this check exists to
        # catch, silently exempted from it.
        params_used = params and any(re.search(rf"\b{re.escape(p)}\b", inner) for p in params)
        if single_return and not params_used:
            flagged.append(name)
        elif re.search(r"(?:for|while)\s*\([^)]*\)\s*\{\s*\}", inner):
            flagged.append(name)
    return flagged


def extract_html_ids(html_code: str) -> list:
    """Extract all ID attributes natively present in generated HTML."""
    seen, ids = set(), []
    for m in re.finditer(r'''\bid\s*=\s*["\']([^"\']+)["\']''', html_code):
        val = m.group(1)
        if val and val not in seen:
            seen.add(val)
            ids.append(val)
    return ids


def merged_app_js_ids(manifest_ids: list, html_code: str) -> list:
    """Union of manifest IDs and dynamically added HTML structural IDs."""
    known = {i.get("id") for i in manifest_ids if i.get("id")}
    extra = [eid for eid in extract_html_ids(html_code) if eid and eid not in known]
    return list(manifest_ids) + [
        {"id": eid, "element": "unknown",
         "purpose": "(structural id present in the generated HTML; not originally in the manifest)"}
        for eid in extra
    ]


def extract_html_classes(html_code: str) -> set:
    """Extract all used class tokens from HTML."""
    classes = set()
    for m in re.finditer(r'''class\s*=\s*["\']([^"\']*)["\']''', html_code):
        classes.update(c for c in m.group(1).split() if c)
    return classes


def extract_css_class_selectors(css_code: str) -> set:
    """Extract all targeted class selectors from CSS."""
    masked = re.sub(r"/\*.*?\*/", " ", css_code, flags=re.DOTALL)
    return set(re.findall(r"\.([a-zA-Z_][\w-]*)", masked))


def find_css_html_mismatch(html_code: str, css_code: str, min_orphan_ratio: float = 0.5) -> Optional[str]:
    """Flag when a large ratio of HTML classes have no matching CSS styling rules."""
    html_classes = extract_html_classes(html_code)
    if not html_classes:
        return None
    css_classes = extract_css_class_selectors(css_code)
    orphaned = html_classes - css_classes
    if len(orphaned) / len(html_classes) >= min_orphan_ratio:
        sample = ", ".join(sorted(orphaned)[:6])
        return (f"{len(orphaned)} of {len(html_classes)} classes used in index.html have no matching CSS rule "
                f"(e.g. {sample}) — style.css looks like it was written without seeing the actual HTML markup.")
    return None


def find_all_function_spans(code: str, name: str) -> list[tuple[int, int, bool]]:
    """Locate all JS function spans via brace counting."""
    masked = _mask_js_comments(code)
    spans = []
    cursor = 0
    while True:
        m = re.search(rf'function\s+{re.escape(name)}\s*\([^)]*\)\s*\{{', masked[cursor:])
        if not m:
            break
        abs_start = cursor + m.start()
        open_pos = cursor + m.end() - 1
        depth, end, truncated = 0, None, True
        for j in range(open_pos, len(masked)):
            if masked[j] == "{":
                depth += 1
            elif masked[j] == "}":
                depth -= 1
                if depth == 0:
                    end, truncated = j + 1, False
                    break
        if end is None:
            end = len(code)
        spans.append((abs_start, end, truncated))
        if end <= abs_start:  # safety valve against a pathological zero-width match
            break
        cursor = end
    return spans


def locate_js_function(code: str, name: str) -> Optional[tuple[int, int, bool]]:
    """Return the primary span for a given function name, or None if not found."""
    spans = find_all_function_spans(code, name)
    return spans[0] if spans else None


def splice_js_function(code: str, name: str, new_impl: str) -> str:
    """Replace exactly one function definition, leaving everything else untouched."""
    new_impl = new_impl.strip()
    span = locate_js_function(code, name)
    if span is None:
        return code.rstrip() + "\n\n" + new_impl + "\n"
    start, end, _truncated = span
    return code[:start] + new_impl + code[end:]


def placeholder_pattern(name: str) -> re.Pattern:
    return re.compile(rf'//\s*<PLACEHOLDER[^>]*\b{re.escape(name)}\b[^>]*/?>', re.IGNORECASE)


def remaining_placeholders(code: str, functions: list[dict]) -> list[dict]:
    """Identify manifest functions still marked with an unfilled <PLACEHOLDER>."""
    return [f for f in functions if placeholder_pattern(f["name"]).search(code)]


def find_duplicate_function_names(code: str) -> list[str]:
    """Identify functions defined more than once in the file."""
    seen, dupes = set(), []
    for n in re.findall(r"function\s+(\w+)\s*\(", _mask_js_comments(code)):
        if n in seen and n not in dupes:
            dupes.append(n)
        seen.add(n)
    return dupes


def _is_stub_function_body(body: str) -> bool:
    """Check if a function block is an unimplemented placeholder stub."""
    inner = body[body.find("{") + 1: body.rfind("}")]
    return "Implementation goes here" in body or _mask_js_comments(inner).strip() == ""


def dedupe_js_functions(code: str) -> tuple[str, list[str]]:
    """Deterministically collapse duplicate function blocks, keeping real implementations over stubs."""
    removed = []
    for name in find_duplicate_function_names(code):
        spans = find_all_function_spans(code, name)
        if len(spans) <= 1:
            continue

        def score(span):
            s, e, truncated = span
            if truncated:
                return (-1, 0)
            body = code[s:e]
            is_stub = _is_stub_function_body(body)
            return (0 if is_stub else 1, len(body))

        best = max(spans, key=score)
        for span in sorted(spans, key=lambda sp: sp[0], reverse=True):
            if span is best:
                continue
            s, e, _ = span
            code = code[:s] + code[e:]
            removed.append(name)
    return code, removed


def guess_broken_function(code: str, functions: list[dict], ids: Optional[list[dict]] = None) -> Optional[str]:
    """Deterministically guess which broken function a revision should target."""
    names = [f["name"] for f in functions]
    for name in names:
        span = locate_js_function(code, name)
        if span and span[2]:
            return name
    for name in names:
        if placeholder_pattern(name).search(code):
            return name
    if ids:
        valid_ids = {i.get("id") for i in ids if i.get("id")}
        bad_ids = set(find_bad_getelementbyid_ids(code, valid_ids))
        if bad_ids:
            masked = _mask_js_comments(code)
            for name in names:
                span = locate_js_function(code, name)
                if span:
                    body = masked[span[0]:span[1]]
                    if any(f"'{bid}'" in body or f'"{bid}"' in body for bid in bad_ids):
                        return name
        if find_ids_missing_event_listener(code, ids) and locate_js_function(code, "setupEventListeners"):
            return "setupEventListeners"
        dom_prop_issues = find_invalid_dom_property_access(code, ids)
        if dom_prop_issues:
            flagged_patterns = re.findall(r"'([\w$]+\.(?:content|value))'", " ".join(dom_prop_issues))
            masked = _mask_js_comments(code)
            for name in names:
                span = locate_js_function(code, name)
                if span:
                    body = masked[span[0]:span[1]]
                    if any(pat in body for pat in flagged_patterns):
                        return name
    undefined_calls = set(find_undefined_function_calls(code, ids or []))
    if undefined_calls:
        masked = _mask_js_comments(code)
        for name in names:
            span = locate_js_function(code, name)
            if span:
                body = masked[span[0]:span[1]]
                if any(re.search(rf"(?<![.\w$]){re.escape(uc)}\s*\(", body) for uc in undefined_calls):
                    return name
    placeholder_logic = set(find_placeholder_logic_functions(code, functions))
    if placeholder_logic:
        for name in names:
            if name in placeholder_logic:
                return name
    for name in names:
        if locate_js_function(code, name) is None and not re.search(rf'\b{re.escape(name)}\s*\(', code):
            return name
    return None


_RESERVED_JS = {
    "class", "function", "const", "let", "var", "return", "if", "else", "for", "while",
    "new", "delete", "typeof", "instanceof", "in", "of", "default", "case", "switch",
    "break", "continue", "this", "null", "true", "false", "void", "yield", "await",
    "async", "import", "export", "extends", "super", "try", "catch", "finally", "throw",
    "do", "with", "static", "get", "set",
}


def id_to_var_name(id_str: str) -> str:
    """Deterministically convert HTML ID into a valid JS identifier to prevent syntax errors."""
    parts = [p for p in re.split(r"[^a-zA-Z0-9]+", id_str.strip()) if p]
    if not parts:
        return "_el"
    first, rest = parts[0], parts[1:]
    name = first[:1].lower() + first[1:] if first[:1].isalpha() else "_" + first
    for p in rest:
        name += p[:1].upper() + p[1:]
    if not name or name[0].isdigit():
        name = "_" + name
    if name in _RESERVED_JS:
        name += "El"
    return name


def compute_id_var_map(ids: list[dict]) -> dict[str, str]:
    """Generate a dictionary mapping HTML IDs to unique JS variable names."""
    id_var_map: dict[str, str] = {}
    for item in ids:
        el_id = item.get("id", "")
        if not el_id:
            continue
        var = id_to_var_name(el_id)
        base_var, n = var, 1
        while var in id_var_map.values():  # two ids collided to the same name — disambiguate
            n += 1
            var = f"{base_var}{n}"
        id_var_map[el_id] = var
    return id_var_map


def build_js_skeleton(ids: list[dict], functions: list[dict]) -> tuple[str, dict[str, str]]:
    """Build deterministic app.js scaffold (DOM references, event listeners, and function placeholders) without LLM calls."""
    id_var_map = compute_id_var_map(ids)
    lines = ["// DOM references (deterministically generated from the manifest's `ids`)"]
    for el_id, var in id_var_map.items():
        lines.append(f"const {var} = document.getElementById('{el_id}');")
    lines.append("")
    lines.append("// Function implementations (filled in below)")
    known_function_names = set()
    for f in functions:
        name = f.get("name")
        if name:
            lines.append(f'// <PLACEHOLDER id="{name}"/>')
            known_function_names.add(name)

    bindings = compute_event_bindings(ids)
    lines.append("")
    lines.append("// Event wiring (deterministically generated — do not remove)")
    lines.append("function setupEventListeners() {")
    for b in bindings:
        var = b["var"]
        if b["element"] == "canvas":
            lines.append(f"    {var}.style.touchAction = 'none';")
        for event_name, handler_name in b["events"]:
            if handler_name not in known_function_names:
                continue  # architect_agent always adds these; skip defensively if it somehow didn't
            if b["element"] == "canvas":
                lines.append(f"    {var}.addEventListener('{event_name}', (e) => {{")
                lines.append(f"        const rect = {var}.getBoundingClientRect();")
                lines.append(f"        {handler_name}(e.clientX - rect.left, e.clientY - rect.top, e);")
                lines.append("    });")
            else:
                lines.append(f"    {var}.addEventListener('{event_name}', {handler_name});")
    lines.append("}")
    lines.append("")
    lines.append("// Application entry point (deterministically generated — do not remove)")
    lines.append("document.addEventListener('DOMContentLoaded', () => {")
    if "loadState" in known_function_names:
        lines.append("    loadState();")
    lines.append("    setupEventListeners();")
    lines.append("});")
    return "\n".join(lines) + "\n", id_var_map


# ==========================================
# 6. GENERIC PATCH HELPERS (for html/css and JS issues that aren't one function)
# ==========================================
PATCH_BLOCK_RE = re.compile(
    r"<{3,}\s*SEARCH\s*\r?\n(.*?)\r?\n={3,}\s*\r?\n(.*?)\r?\n>{3,}\s*REPLACE",
    re.DOTALL,
)


def apply_patches(original: str, patch_text: str) -> tuple[str, list[str]]:
    """Apply SEARCH/REPLACE blocks to original code, handling partial matches gracefully."""
    blocks = PATCH_BLOCK_RE.findall(patch_text)
    if not blocks:
        return original, ["model returned no SEARCH/REPLACE blocks"]

    code = original
    failures = []
    for search, replace in blocks:
        search, replace = search.strip("\n"), replace.strip("\n")
        if not search:
            continue
        if code.count(search) == 1:
            code = code.replace(search, replace, 1)
            continue
        # Tolerant retry: match ignoring trailing whitespace per line.
        lines = code.split("\n")
        norm_lines = [ln.rstrip() for ln in lines]
        search_lines = [ln.rstrip() for ln in search.split("\n")]
        matches = [
            i for i in range(len(norm_lines) - len(search_lines) + 1)
            if norm_lines[i:i + len(search_lines)] == search_lines
        ]
        if len(matches) == 1:
            i = matches[0]
            lines = lines[:i] + replace.split("\n") + lines[i + len(search_lines):]
            code = "\n".join(lines)
            continue
        failures.append(search[:80].replace("\n", " ⏎ "))
    return code, failures


# ==========================================
# 7. HEURISTICS (free, deterministic pre-checks before spending an LLM call)
# ==========================================
def node_syntax_check(code: str) -> Optional[str]:
    """Real syntax check via `node --check`, silently skipped if Node is unavailable."""
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False, encoding="utf-8") as tf:
            tf.write(code)
            tmp_path = tf.name
        result = subprocess.run(["node", "--check", tmp_path], capture_output=True, text=True, timeout=10)
        if result.returncode != 0:
            return f"JavaScript syntax error (node --check): {result.stderr.strip()[:300]}"
    except FileNotFoundError:
        return None  # Node not installed — this check is a bonus, not a requirement
    except Exception:
        return None  # never let a broken bonus check block the pipeline
    finally:
        if tmp_path:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
    return None


def heuristic_precheck(
    filename: str, code: str, functions: Optional[list[dict]] = None, ids: Optional[list[dict]] = None,
    html_code: Optional[str] = None,
) -> Optional[str]:
    """Catch common model failure modes deterministically before invoking Reviewer LLM."""
    if not code.strip():
        return "File is empty."
    if filename.endswith(".js"):
        if "PLACEHOLDER" in code:
            return "A '<PLACEHOLDER .../>' marker is still present — a function was never implemented."
        dupes = find_duplicate_function_names(code)
        if dupes:
            return f"Duplicate function declaration(s): {', '.join(dupes)} — defined more than once."
        bad_ident = re.search(r"\b(?:const|let|var)\s+[A-Za-z_$][\w$]*-[\w$-]*\s*=", code)
        if bad_ident:
            return (f"Invalid JS identifier '{bad_ident.group(0).strip(' =')}' — hyphens aren't legal in "
                     "variable names (a hyphen is the subtraction operator).")
        if functions:
            missing = [f["name"] for f in functions if f.get("name") and locate_js_function(code, f["name"]) is None]
            if missing:
                return (f"Required function(s) not actually implemented: {', '.join(missing)} — declared in the "
                        "manifest but no real (non-comment) function definition was found for them.")
        if ids:
            valid_ids = {i.get("id") for i in ids if i.get("id")}
            bad_ids = find_bad_getelementbyid_ids(code, valid_ids)
            if bad_ids:
                return (f"getElementById() called with id(s) not found anywhere (manifest or actual HTML): "
                        f"{', '.join(bad_ids)} — this always returns null and the next line to use it will "
                        "throw. Reuse the existing top-level DOM reference variable instead of calling "
                        "getElementById again.")
            unbound = find_ids_missing_event_listener(code, ids)
            if unbound:
                return (f"Interactive element(s) with no addEventListener bound anywhere in this file: "
                        f"{', '.join(unbound)} — these controls will do nothing when clicked/touched. Wire "
                        "each one up inside setupEventListeners().")
            dom_prop_issues = find_invalid_dom_property_access(code, ids)
            if dom_prop_issues:
                return dom_prop_issues[0]
        undefined_calls = find_undefined_function_calls(code, ids or [])
        if undefined_calls:
            return (f"Call(s) to function(s) that are never defined anywhere in this file: "
                    f"{', '.join(undefined_calls)} — this throws ReferenceError the moment that code path "
                    "runs. Either implement the missing function or call the correct existing one.")
        state_issues = find_undeclared_state_variables(code)
        if state_issues:
            return (f"Variable(s) used as shared state across multiple functions but never declared at the "
                    f"top level of the file: {', '.join(state_issues)} — declare them once at the top "
                    "(e.g. `let tasks = [];`) instead of letting each function assume they already exist.")
        storage_issues = find_localstorage_schema_conflicts(code)
        if storage_issues:
            return storage_issues[0]
        if functions:
            placeholder_logic = find_placeholder_logic_functions(code, functions)
            if placeholder_logic:
                return (f"Function(s) look like dead-end placeholder logic — they ignore their parameters "
                        f"and just return a hardcoded value, or contain an empty loop: "
                        f"{', '.join(placeholder_logic)}. Implement the real logic instead.")
    if filename == "style.css" and html_code:
        mismatch = find_css_html_mismatch(html_code, code)
        if mismatch:
            return mismatch
    opens, closes = code.count("{"), code.count("}")
    if opens != closes:
        return f"Unbalanced braces ({opens} '{{' vs {closes} '}}') — file looks truncated."
    if filename.endswith(".js"):
        p_opens, p_closes = code.count("("), code.count(")")
        if p_opens != p_closes:
            return f"Unbalanced parentheses ({p_opens} '(' vs {p_closes} ')') — file looks truncated."
        node_issue = node_syntax_check(code)
        if node_issue:
            return node_issue
    if filename.endswith(".html") and ("<html" not in code.lower() or "</html>" not in code.lower()):
        return "Missing a complete <html>...</html> root — file looks truncated."
    return None


def guard_against_regression(
    run_dir: Path, filename: str, old_code: str, new_code: str, mode: str,
    functions: list[dict], ids: Optional[list[dict]] = None, html_code: Optional[str] = None,
) -> tuple[str, str]:
    """Safety net preventing revisions from overwriting working code with worse/corrupted output."""
    if filename == "app.js" and new_code.strip():
        new_code, removed = dedupe_js_functions(new_code)
        if removed:
            write_log(run_dir, f"Coder (dedupe) - {filename}",
                      f"Collapsed duplicate definitions: {', '.join(sorted(set(removed)))}")
            mode = f"{mode}+dedupe"
        if ids:
            new_code, id_fixes = autofix_getelementbyid_ids(new_code, compute_id_var_map(ids))
            if id_fixes:
                write_log(run_dir, f"Coder (id autofix) - {filename}", "\n".join(id_fixes))
                mode = f"{mode}+idfix"

    old_issue = heuristic_precheck(filename, old_code, functions, ids, html_code)
    new_issue = heuristic_precheck(filename, new_code, functions, ids, html_code)

    if not new_code.strip() and old_code.strip():
        write_log(run_dir, f"Coder (patch rejected) - {filename}",
                  "Model returned empty output; keeping the previous version untouched.")
        return old_code, f"{mode}_rejected_empty"

    if new_issue and not old_issue:
        write_log(run_dir, f"Coder (patch rejected) - {filename}",
                  f"New version introduced a new problem ('{new_issue}') the previous version "
                  "didn't have; keeping the previous version.")
        return old_code, f"{mode}_rejected_regression"

    return new_code, mode


# ==========================================
# 8. SHARED LLM-CALL BUILDERS
# ==========================================
def implement_single_function(
    brief: str, func_meta: dict, extra_note: str = "", id_var_map: Optional[dict] = None
) -> str:
    """Generate or repair a single JS function using deterministic ID mappings."""
    note = f"\nISSUE TO FIX: {extra_note}" if extra_note else ""
    var_note = (
        f"\nExisting DOM reference variables — use these EXACT names, do not redeclare them: "
        f"{json.dumps(id_var_map, indent=2)}" if id_var_map else ""
    )
    prompt = (
        f"{CODER_PERSONA}\n"
        f"PROJECT: {brief}\n"
        f"Implement exactly this ONE JavaScript function, nothing else:\n"
        f"{json.dumps(func_meta, indent=2)}{note}{var_note}\n\n"
        "RULES:\n"
        "1. Assume the DOM element references at the top of app.js already exist — reuse them, don't redeclare.\n"
        "2. Use template literals (backticks) for any multi-line string.\n"
        "3. Output ONLY the function body, inside a ``` block. No explanation, "
        "no other functions.\n"
    )
    return extract_code(invoke_text(llm, prompt))


def request_patch(filename: str, brief: str, ctx_str: str, issue: str, instruction: str, current_code: str) -> str:
    """Request minimal SEARCH/REPLACE blocks instead of rewriting the full file."""
    prompt = (
        f"{CODER_PERSONA}\n"
        f"PROJECT: {brief}\n"
        f"RELEVANT CONTEXT: {ctx_str}\n\n"
        f"ISSUE with `{filename}`: {issue}\n"
        f"FIX INSTRUCTION: {instruction}\n\n"
        f"CURRENT `{filename}`:\n```\n{current_code}\n```\n\n"
        f"{PATCH_FORMAT_NOTE}\n"
    )
    return invoke_text(llm, prompt)


def full_rewrite(filename: str, brief: str, ctx_str: str, issue: str, instruction: str, current_code: str) -> str:
    """Regenerate the entire file as a last-resort fallback safely guarded by pre-checks."""
    prompt = (
        f"{CODER_PERSONA}\n"
        f"Fix `{filename}` based on reviewer feedback. Keep everything that "
        "already works — only change what the feedback calls out.\n\n"
        f"RELEVANT CONTEXT: {ctx_str}\n"
        f"ISSUE: {issue}\n"
        f"INSTRUCTION: {instruction}\n"
        f"CURRENT CODE:\n```\n{current_code}\n```\n"
        "Output the entire fixed file. Output ONLY code inside a ``` block.\n"
    )
    return extract_code(invoke_text(llm, prompt))


# ==========================================
# 8b. EVALUATION (DeepEval LLM-as-judge scores + a human-readable report)
# ==========================================
if DEEPEVAL_AVAILABLE:
    class OllamaEvalModel(DeepEvalBaseLLM):
        """Offline GEval wrapper leveraging the same local Ollama model."""

        def __init__(self, chat_model: ChatOllama, name: str):
            self._chat = chat_model
            self._name = name

        def load_model(self):
            return self._chat

        def generate(self, prompt: str) -> str:
            return invoke_text(self._chat, prompt)

        async def a_generate(self, prompt: str) -> str:
            return self.generate(prompt)

        def get_model_name(self) -> str:
            return self._name


def _build_deepeval_metrics() -> list:
    """Construct GEval logic metrics once to reduce LLM overhead across evaluated files."""
    judge = OllamaEvalModel(llm, MODEL_NAME)
    return [
        GEval(
            name="Correctness",
            criteria=(
                "The ACTUAL_OUTPUT is a generated code file. Using the requirements and manifest given in "
                "INPUT as ground truth: does every document.getElementById(...) call use an id that is "
                "actually listed under the manifest's ids? Does every required function's logic plausibly "
                "match its described purpose? Flag any obvious runtime bug (null references, wrong variable "
                "or id names, mismatched types)."
            ),
            evaluation_params=[LLMTestCaseParams.INPUT, LLMTestCaseParams.ACTUAL_OUTPUT],
            model=judge,
            threshold=0.6,
        ),
        GEval(
            name="Completeness",
            criteria=(
                "Using the requirements and manifest given in INPUT as the spec, does ACTUAL_OUTPUT actually "
                "implement every required id/function with real logic — not left as a comment, a TODO, or an "
                "empty stub?"
            ),
            evaluation_params=[LLMTestCaseParams.INPUT, LLMTestCaseParams.ACTUAL_OUTPUT],
            model=judge,
            threshold=0.6,
        ),
    ]


def deepeval_score_file(filename: str, code: str, ctx: dict, requirements: str, metrics: list) -> Optional[dict]:
    """Score a finished file safely bypassing metric evaluation failures."""
    if not DEEPEVAL_AVAILABLE or not code.strip():
        return None
    test_case = LLMTestCase(
        input=f"REQUIREMENTS:\n{requirements}\n\nRELEVANT MANIFEST:\n{json.dumps(ctx, indent=2)}",
        actual_output=code,
    )
    results = {}
    for metric in metrics:
        try:
            metric.measure(test_case)
            score = round(metric.score, 2) if metric.score is not None else None
            results[metric.name] = {"score": score, "reason": metric.reason}
        except Exception as e:
            results[metric.name] = {"score": None, "reason": f"DeepEval metric failed: {e}"}
    return results


def compute_custom_score(entry: dict) -> Optional[float]:
    """Calculate a deterministic, non-LLM quality score based on revision attempts."""
    if entry.get("status") != "PASS":
        return 0.0
    attempts = entry.get("attempts", 1)
    return round(max(0.25, 1.0 - 0.25 * (attempts - 1)), 2)


def extract_review_history(run_dir: Path, filename: str) -> list[str]:
    """Extract reviewer verdicts for a file directly from execution logs."""
    log_path = run_dir / "execution_log.txt"
    if not log_path.exists():
        return []
    text = log_path.read_text(encoding="utf-8")
    pattern = re.compile(
        rf"=== REVIEWER[^=\n]*-\s*{re.escape(filename.upper())}\s*===\n(.*?)\n-{{10,}}", re.DOTALL
    )
    return [m.strip() for m in pattern.findall(text)]


def render_evaluation_markdown(overall: dict, report: dict) -> str:
    """Render human-readable JSON evaluation results into markdown format."""
    lines = ["# Evaluation Report", "", f"**Files passed:** {overall['files_passed']}"]
    lines.append(f"**Average custom (harness-verified) score:** {overall['custom_score_avg']} / 1.0")
    if "deepeval_avg_score" in overall:
        lines.append(f"**Average DeepEval score:** {overall['deepeval_avg_score']} / 1.0")
    if not overall["deepeval_available"]:
        lines.append("\n_DeepEval isn't installed (`pip install deepeval`) — showing deterministic results only._")
    lines.append("")

    for filename, data in report.items():
        lines.append(f"## {filename}")
        lines.append(
            f"- Status: **{data.get('status', '?')}** "
            f"(attempts: {data.get('attempts', '?')}, {data.get('chars', '?')} chars, "
            f"last action: `{data.get('last_action', '?')}`)"
        )
        lines.append(f"- Custom score (harness-verified): **{data.get('custom_score')}**")
        history = data.get("review_history") or []
        if len(history) > 1:
            lines.append(f"- Review history ({len(history)} pass(es)):")
            for h in history:
                lines.append(f"  - {h}")
        deval = data.get("deepeval")
        if deval:
            lines.append("- DeepEval scores:")
            for name, res in deval.items():
                score_str = res["score"] if res["score"] is not None else "n/a"
                lines.append(f"  - **{name}**: {score_str} — {res['reason']}")
            deval_scores = [m["score"] for m in deval.values() if m.get("score") is not None]
            if deval_scores and data.get("custom_score") is not None:
                deval_avg = sum(deval_scores) / len(deval_scores)
                if abs(deval_avg - data["custom_score"]) >= 0.4:
                    lines.append(
                        f"  - ⚠️ **Disagreement**: DeepEval averages {deval_avg:.2f} but the harness-verified "
                        f"score is {data['custom_score']:.2f} — trust the custom score here (see "
                        "`compute_custom_score`'s docstring for why)."
                    )
        lines.append("")
    return "\n".join(lines)


# ==========================================
# 8c. CROSS-RUN BENCHMARK TRACKING
# ==========================================
def benchmark_history_path() -> Path:
    return Path(__file__).resolve().parent / "benchmark_history.jsonl"


def load_benchmark_history() -> list:
    """Load JSONL benchmark data, skipping any unparseable partial lines."""
    path = benchmark_history_path()
    if not path.exists():
        return []
    records = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            records.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return records


def append_benchmark_record(record: dict) -> list:
    """Append one run's summary statistics directly to benchmark history."""
    with open(benchmark_history_path(), "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")
    return load_benchmark_history()


def render_benchmark_svg(records: list) -> str:
    """Generate self-contained SVG tracking charts across all executed runs."""
    W, H, PAD = 640, 260, 42
    n = len(records)
    if n == 0:
        return (f'<svg xmlns="[http://www.w3.org/2000/svg](http://www.w3.org/2000/svg)" width="{W}" height="120">'
                f'<text x="20" y="60" font-family="sans-serif" font-size="13">'
                f'No runs tracked yet.</text></svg>')

    def x_for(i):
        return PAD + (i / max(n - 1, 1)) * (W - 2 * PAD)

    def y_for(s):
        return H - PAD - s * (H - 2 * PAD)

    def series_svg(key: str, color: str):
        pts = [(i, r[key]) for i, r in enumerate(records) if r.get(key) is not None]
        if not pts:
            return "", None
        poly = " ".join(f"{x_for(i):.1f},{y_for(s):.1f}" for i, s in pts)
        dots = "".join(
            f'<circle cx="{x_for(i):.1f}" cy="{y_for(s):.1f}" r="3" fill="{color}">'
            f'<title>run {i + 1}: {s:.2f}</title></circle>'
            for i, s in pts
        )
        avg = sum(s for _, s in pts) / len(pts)
        return f'<polyline points="{poly}" fill="none" stroke="{color}" stroke-width="2"/>{dots}', avg

    deepeval_svg, deepeval_avg = series_svg("deepeval_avg_score", "#2563eb")
    custom_svg, custom_avg = series_svg("custom_score_avg", "#16a34a")

    gridlines = "".join(
        f'<line x1="{PAD}" y1="{y_for(g):.1f}" x2="{W - PAD}" y2="{y_for(g):.1f}" stroke="#e5e7eb" stroke-width="1"/>'
        f'<text x="4" y="{y_for(g) + 4:.1f}" font-size="10" fill="#6b7280">{g:.1f}</text>'
        for g in (0.0, 0.25, 0.5, 0.75, 1.0)
    )
    legend = (
        f'<circle cx="{PAD}" cy="16" r="4" fill="#2563eb"/><text x="{PAD + 10}" y="20" font-size="11" fill="#374151">'
        f'DeepEval avg{f" ({deepeval_avg:.2f})" if deepeval_avg is not None else ""}</text>'
        f'<circle cx="{PAD + 160}" cy="16" r="4" fill="#16a34a"/>'
        f'<text x="{PAD + 170}" y="20" font-size="11" fill="#374151">'
        f'Custom avg{f" ({custom_avg:.2f})" if custom_avg is not None else ""}</text>'
    )
    return f'''<svg xmlns="[http://www.w3.org/2000/svg](http://www.w3.org/2000/svg)" width="{W}" height="{H}" font-family="sans-serif">
<rect width="{W}" height="{H}" fill="white"/>
{gridlines}
{deepeval_svg}
{custom_svg}
{legend}
<text x="{PAD}" y="{H - 8}" font-size="11" fill="#374151">Run 1</text>
<text x="{W - PAD - 40}" y="{H - 8}" font-size="11" fill="#374151">Run {n}</text>
</svg>'''


def render_benchmark_html(records: list) -> str:
    """Format benchmark SVG and HTML table for browser rendering."""
    scored_deepeval = [r["deepeval_avg_score"] for r in records if r.get("deepeval_avg_score") is not None]
    scored_custom = [r["custom_score_avg"] for r in records if r.get("custom_score_avg") is not None]
    all_time_deepeval = round(sum(scored_deepeval) / len(scored_deepeval), 2) if scored_deepeval else "n/a"
    all_time_custom = round(sum(scored_custom) / len(scored_custom), 2) if scored_custom else "n/a"

    rows = []
    for i, r in enumerate(records):
        cfg = r.get("llm_config", {})
        rows.append(
            f"<tr><td>{i + 1}</td><td>{r.get('timestamp', '')}</td>"
            f"<td>{cfg.get('model', '')}</td><td>{cfg.get('num_ctx', '')}</td>"
            f"<td>{r.get('app_brief', '')[:60]}</td>"
            f"<td>{r.get('files_passed', '')}</td>"
            f"<td>{r.get('custom_score_avg', 'n/a')}</td>"
            f"<td>{r.get('deepeval_avg_score', 'n/a')}</td></tr>"
        )
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Agentic SDLC — Benchmark History</title>
<style>
body {{ font-family: system-ui, sans-serif; margin: 2rem; color: #111827; max-width: 900px; }}
table {{ border-collapse: collapse; margin-top: 1rem; width: 100%; }}
th, td {{ border: 1px solid #e5e7eb; padding: 6px 10px; text-align: left; font-size: 13px; }}
th {{ background: #f9fafb; }}
</style></head>
<body>
<h1>Benchmark History</h1>
<p>{len(records)} run(s) tracked — all-time avg custom score: <b>{all_time_custom}</b>
&nbsp;|&nbsp; all-time avg DeepEval score: <b>{all_time_deepeval}</b></p>
{render_benchmark_svg(records)}
<table>
<tr><th>#</th><th>Timestamp</th><th>Model</th><th>num_ctx</th><th>App</th>
<th>Files passed</th><th>Custom avg</th><th>DeepEval avg</th></tr>
{"".join(rows)}
</table>
</body></html>"""


# ==========================================
# 9. AGENT NODES
# ==========================================
def requirement_agent(state: AgentState):
    """Agent 1 — Scoper. Produces a bulleted functional spec."""
    print("\n📝 [Agent 1: Scoper] Drafting requirements...")
    prompt = f"""
{SCOPER_PERSONA}

Analyze this request: "{state['user_input']}"
First, provide a clear **Project Name** and a brief **Project Description** at the very top of your response. 
Then, Draft a concise, bulleted functional requirements list: what interfaces (UI
elements) it needs, and what functionality/behaviour it must have. Ignore
non-functional fluff (performance, security, deployment). Keep it short and
concrete enough that a small local model can build from it.
"""
    reqs = invoke_text(llm, prompt).strip()
    save_artifact(state["run_dir"], "requirements.txt", reqs)
    write_log(state["run_dir"], "Requirements", reqs)
    if len(reqs) < 40 or reqs.lower().startswith(("please provide", "i am ready", "i need more")):
        msg = f"Requirements draft looks empty/refusal-shaped ({len(reqs)} chars) — check that the app idea wasn't blank."
        print(f"   ⚠️  {msg}")
        write_log(state["run_dir"], "Requirements (WARNING)", msg)
    return {"requirements": reqs, "project_brief": state["user_input"].strip()}


def architect_agent(state: AgentState):
    """Agent 2 — Architect/Planner. Produces the 3-section manifest and builds the Coder's task stack."""
    print("📐 [Agent 2: Architect] Building manifest & task stack...")
    reqs = state["requirements"]

    layout = {}
    for _ in range(MAX_ATTEMPTS):
        p = (
            f"{ARCHITECT_PERSONA}\nReqs: {reqs}\n"
            'Output JSON for the CSS layout strategy only. Format: '
            '{"layout": {"container": "grid/flex rule", "notes": "short layout notes"}}'
        )
        layout = extract_json(invoke_text(llm_json, p))
        if layout.get("layout"):
            break

    ids = {}
    for _ in range(MAX_ATTEMPTS):
        p = (
            f"{ARCHITECT_PERSONA}\nReqs: {reqs}\n"
            "Output JSON listing every interactive HTML element AND every container/wrapper element that "
            "will hold dynamically added or repeated content (e.g. a list or table body that rows get "
            "appended into) — not just buttons and inputs. If the requirements describe adding/removing "
            "items, include an id for the element they get added to. "
            'Format: {"ids": [{"id": "btn-submit", "element": "button", "purpose": "submits the form"}, '
            '{"id": "item-list", "element": "div", "purpose": "container that item rows are appended into"}]}'
        )
        ids = extract_json(invoke_text(llm_json, p))
        if ids.get("ids"):
            break

    functions = {}
    for _ in range(MAX_ATTEMPTS):
        p = (
            f"{ARCHITECT_PERSONA}\nReqs: {reqs}\n"
            "Output JSON listing every JS function needed. "
            'Format: {"functions": [{"name": "calculateTotal", "params": ["a", "b"], "description": "adds a and b"}]}'
        )
        functions = extract_json(invoke_text(llm_json, p))
        if functions.get("functions"):
            break

    manifest = {
        "layout": layout.get("layout", {}),
        "ids": ids.get("ids", []),
        "functions": functions.get("functions", []),
    }

    handler_functions = synthesize_event_handler_functions(manifest["ids"], manifest["functions"])
    if handler_functions:
        manifest["functions"] = manifest["functions"] + handler_functions
        write_log(state["run_dir"], "Architect (event wiring synthesized)",
                  f"Added {len(handler_functions)} deterministic event-handler function(s) to the manifest: "
                  f"{', '.join(f['name'] for f in handler_functions)}")

    save_artifact(state["run_dir"], "manifest.json", json.dumps(manifest, indent=2))
    write_log(state["run_dir"], "Manifest", json.dumps(manifest, indent=2))

    if not manifest["ids"] and not manifest["functions"]:
        msg = ("Manifest has no ids and no functions after retries — the requirements this was "
               "built from were likely empty or degenerate. The generated app will be trivial.")
        print(f"   ⚠️  {msg}")
        write_log(state["run_dir"], "Architect (WARNING)", msg)

    task_stack = [
        {"file": "index.html", "context_keys": ["layout", "ids"],
         "purpose": "Build the DOM structure using exactly these ids and this layout."},
        {"file": "style.css", "context_keys": ["layout"],
         "purpose": "Style the layout below; must visually support every id's element type."},
        {"file": "app.js", "context_keys": ["ids", "functions"],
         "purpose": "Implement exactly these functions and wire them to exactly these ids."},
    ]

    return {"manifest": manifest, "task_stack": task_stack, "validation_errors": {}, "eval_matrix": {}}


def _generate_app_js(run_dir: Path, brief: str, ctx: dict) -> str:
    """Build deterministic framework and generate functions in chunks, applying immediate self-healing."""
    funcs = ctx.get("functions", [])
    ids = ctx.get("ids", [])

    print("   ↳ generating skeleton (deterministic — no LLM call)...")
    skeleton, id_var_map = build_js_skeleton(ids, funcs)
    save_artifact(run_dir, "app.js", skeleton)  # persist skeleton before filling it in
    write_log(run_dir, "Coder (deterministic skeleton)",
              f"{skeleton}\n\nid -> variable map: {json.dumps(id_var_map, indent=2)}")

    print("   ↳ implementing functions in chunks...")
    var_map_note = (
        f"\nExisting DOM reference variables — use these EXACT names, do not redeclare them: "
        f"{json.dumps(id_var_map, indent=2)}\n"
    )
    for i in range(0, len(funcs), CHUNK_SIZE):
        chunk = funcs[i:i + CHUNK_SIZE]
        impl_prompt = (
            f"{CODER_PERSONA}\nImplement exactly these functions: {json.dumps(chunk, indent=2)}\n"
            f"{var_map_note}\n"
            "CRITICAL: use template literals (backticks) for any multi-line string, "
            "never double quotes for multi-line strings.\n\n"
            f"{IMPL_FORMAT_NOTE}\n"
        )
        impl_resp = invoke_text(llm, impl_prompt)
        matched_any = False
        for f in chunk:
            name = f["name"]
            pattern = rf'<IMPL\s+id=["\']?{re.escape(name)}["\']?\s*>\s*(.*?)\s*</IMPL>'
            m = re.search(pattern, impl_resp, re.DOTALL | re.IGNORECASE)
            if m:
                matched_any = True
                skeleton = placeholder_pattern(name).sub(
                    lambda _mo: m.group(1).strip().replace("\\", "\\\\"), skeleton
                )
        if not matched_any:
            write_log(run_dir, "Coder (chunk raw — no IMPL match)", impl_resp)
        save_artifact(run_dir, "app.js", skeleton)  # persist after every chunk, not just at the end

    print("   ↳ self-healing any missed functions...")
    for f in remaining_placeholders(skeleton, funcs):
        new_impl = implement_single_function(
            brief, f, "This function was never filled in — implement it now.", id_var_map
        )
        if new_impl.strip():
            skeleton = placeholder_pattern(f["name"]).sub(lambda _mo: new_impl.replace("\\", "\\\\"), skeleton, count=1)
            save_artifact(run_dir, "app.js", skeleton)
            write_log(run_dir, f"Coder (self-heal) - {f['name']}", new_impl)
        else:
            write_log(run_dir, f"Coder (self-heal FAILED) - {f['name']}",
                      "Model returned nothing even for a single function; left as a placeholder for the Reviewer/revision loop to pick up.")

    skeleton, removed = dedupe_js_functions(skeleton)
    if removed:
        write_log(run_dir, "Coder (dedupe)", f"Collapsed duplicate definitions: {', '.join(sorted(set(removed)))}")
        save_artifact(run_dir, "app.js", skeleton)

    print("   ↳ auto-fixing any wrong-id getElementById() calls...")
    skeleton, id_fixes = autofix_getelementbyid_ids(skeleton, id_var_map)
    if id_fixes:
        write_log(run_dir, "Coder (id autofix)", "\n".join(id_fixes))
        save_artifact(run_dir, "app.js", skeleton)

    return skeleton


def coder_agent(state: AgentState):
    """Agent 3 — Coder. Generates or patches the current file on disk."""
    run_dir = state["run_dir"]
    task = state["task_stack"][0]
    filename = task["file"]
    attempts = state["attempts"]
    is_revision = attempts > 0
    is_last_attempt = attempts + 1 >= MAX_ATTEMPTS
    manifest = state["manifest"]
    ctx = focused_context(manifest, task["context_keys"])
    html_code = load_artifact(run_dir, "index.html") if filename in ("style.css", "app.js") else ""
    effective_ids = manifest.get("ids", [])

    if filename == "app.js":
        effective_ids = merged_app_js_ids(manifest.get("ids", []), html_code)
        ctx = dict(ctx)
        ctx["ids"] = effective_ids
        ctx["dom_variable_names"] = compute_id_var_map(effective_ids)
    ctx_str = json.dumps(ctx, indent=2)
    brief = state["project_brief"]

    print(f"\n💻 [Agent 3: Coder] {'Revising' if is_revision else 'Writing'} "
          f"{filename} (attempt {attempts + 1}/{MAX_ATTEMPTS})...")

    if not is_revision:
        if filename == "app.js":
            code = _generate_app_js(run_dir, brief, ctx)
        elif filename == "style.css":
            prompt = (
                f"{CODER_PERSONA}\nWrite `{filename}`.\n"
                f"PROJECT: {brief}\n"
                f"TASK: {task['purpose']}\n"
                f"RELEVANT CONTEXT (layout notes): {ctx_str}\n\n"
                f"THE ACTUAL HTML YOU ARE STYLING — use EXACTLY these classes and ids, do not invent your "
                f"own class names:\n```html\n{html_code}\n```\n\n"
                "RULES:\n"
                "- Every selector you write must target a class or id that actually appears in the HTML above.\n"
                "- Output ONLY raw CSS inside a ``` block.\n"
            )
            code = extract_code(invoke_text(llm, prompt))
        else:
            prompt = (
                f"{CODER_PERSONA}\nWrite `{filename}`.\n"
                f"PROJECT: {brief}\n"
                f"TASK: {task['purpose']}\n"
                f"RELEVANT CONTEXT: {ctx_str}\n\n"
                "RULES:\n"
                "- If HTML: link style.css and app.js, no inline styles or scripts.\n"
                "- Output ONLY raw code inside a ``` block.\n"
            )
            code = extract_code(invoke_text(llm, prompt))
        mode = "initial"

    else:
        current_code = load_artifact(run_dir, filename)
        fb = state["feedback"]  # {"issue": ..., "instruction": ..., "target": ...}
        issue, instruction = fb.get("issue", ""), fb.get("instruction", "")
        target = None

        if filename == "app.js":
            target = fb.get("target") or None
            if target not in [f["name"] for f in manifest.get("functions", [])]:
                target = guess_broken_function(current_code, manifest.get("functions", []), effective_ids)

        if target:
            print(f"   ↳ targeted function patch: {target}()")
            func_meta = next((f for f in manifest["functions"] if f["name"] == target), {"name": target})
            id_var_map = compute_id_var_map(effective_ids)
            new_impl = implement_single_function(brief, func_meta, instruction or issue, id_var_map)
            code = splice_js_function(current_code, target, new_impl) if new_impl.strip() else current_code
            mode = f"function_patch:{target}"
        elif issue or instruction:
            print("   ↳ requesting scoped SEARCH/REPLACE patch...")
            patch_prompt_ctx = ctx_str
            if filename == "style.css":
                patch_prompt_ctx = f"{ctx_str}\n\nTHE ACTUAL HTML BEING STYLED:\n```html\n{html_code}\n```"
            patch_text = request_patch(filename, brief, patch_prompt_ctx, issue, instruction, current_code)
            code, failures = apply_patches(current_code, patch_text)
            if not failures:
                mode = "search_replace"
            elif is_last_attempt:
                print("   ↳ patch failed to apply and this is the final attempt — "
                      "trying a full rewrite (guarded — cannot make things worse).")
                code = full_rewrite(filename, brief, patch_prompt_ctx, issue, instruction, current_code)
                mode = "last_resort_full_rewrite"
            else:
                write_log(run_dir, f"Coder (patch — unmatched blocks) - {filename}", "\n".join(failures))
                code, mode = current_code, "search_replace_partial_noop"
        else:
            print("   ↳ no actionable feedback from the Reviewer — leaving the file unchanged.")
            write_log(run_dir, f"Coder (no actionable feedback) - {filename}",
                      "Reviewer FAILed the file but gave no issue/instruction/target; skipping this "
                      "revision rather than editing speculatively.")
            code, mode = current_code, "skipped_no_feedback"

        code, mode = guard_against_regression(
            run_dir, filename, current_code, code, mode, manifest.get("functions", []), effective_ids, html_code
        )

    save_artifact(run_dir, filename, code)
    write_log(run_dir, f"Coder ({mode}) - {filename}", code)
    return {"last_revision_mode": mode}


def reviewer_agent(state: AgentState):
    """Agent 4 — Reviewer. Audits generated artifacts, utilizing free heuristics before LLM fallback."""
    run_dir = state["run_dir"]
    task = state["task_stack"][0]
    filename = task["file"]
    attempts = state["attempts"]
    code = load_artifact(run_dir, filename)
    functions = state["manifest"].get("functions", [])
    ids = state["manifest"].get("ids", [])
    html_code = load_artifact(run_dir, "index.html") if filename in ("style.css", "app.js") else ""
    if filename == "app.js":
        ids = merged_app_js_ids(ids, html_code)

    print(f"🔎 [Agent 4: Reviewer] Auditing {filename}...")

    heuristic_issue = heuristic_precheck(filename, code, functions, ids, html_code)
    if heuristic_issue:
        status = "FAIL"
        target = guess_broken_function(code, functions, ids) if filename == "app.js" else None
        fb = {"issue": heuristic_issue, "instruction": "Fix exactly this, nothing else.", "target": target}
        write_log(run_dir, f"Reviewer (heuristic) - {filename}", f"{heuristic_issue} | target={target}")
    else:
        ctx = focused_context(state["manifest"], task["context_keys"])
        prompt = (
            f"{REVIEWER_PERSONA}\n\n"
            f"Review `{filename}` against the relevant spec below.\n"
            f"PROJECT: {state['project_brief']}\n"
            f"RELEVANT MANIFEST SECTION(S): {json.dumps(ctx, indent=2)}\n\n"
            f"CODE:\n```\n{code}\n```\n\n"
            "Fail it if ANY of these are true:\n"
            "1. It ends abruptly / has unclosed tags or brackets (truncation).\n"
            "2. It drifts from the manifest above (wrong ids, missing/extra functions, wrong layout).\n"
            "3. There's an obvious syntax or logic bug.\n\n"
            "Respond with ONLY this JSON, nothing else:\n"
            '{"status": "PASS", "issue": "", "instruction": "", "target": ""}\n'
            "or\n"
            '{"status": "FAIL", "issue": "<what is wrong>", '
            '"instruction": "<one specific, actionable sentence on what to fix>", '
            '"target": "<function name at fault, or empty if not one specific function>"}\n'
        )
        raw = invoke_text(llm_json, prompt, retries=1)
        if not raw.strip():
            status = "PASS"
            fb = {"issue": "", "instruction": "", "target": None}
            write_log(run_dir, f"Reviewer (LLM empty — trusting heuristic) - {filename}",
                      "No verdict after retry (likely context-window overflow); "
                      "accepted on the strength of the heuristic pass alone.")
        else:
            parsed = extract_json(raw)
            status = str(parsed.get("status", "")).upper()
            if status not in ("PASS", "FAIL"):
                status = "PASS" if "PASS" in raw[:30].upper() else "FAIL"
            fb = {
                "issue": parsed.get("issue", "") or ("" if status == "PASS" else raw.strip()[:200]),
                "instruction": parsed.get("instruction", ""),
                "target": parsed.get("target") or None,
            }
            write_log(run_dir, f"Reviewer (LLM) - {filename}", f"{status}: {fb['issue']} | target={fb['target']}")

    finished = status == "PASS" or (attempts + 1 >= MAX_ATTEMPTS)

    if finished:
        ok = status == "PASS"
        print(f"   {'✅' if ok else '⚠️ '} {filename}: {'PASS' if ok else 'FAIL (max attempts reached)'}")
        eval_entry = {filename: {
            "attempts": attempts + 1,
            "status": status,
            "chars": len(code),
            "last_action": state.get("last_revision_mode", "initial"),
        }}
        errors = {} if ok else {filename: fb["issue"]}
        return {
            "feedback": {},
            "attempts": 0,
            "task_stack": state["task_stack"][1:],   # pop — move to next file
            "validation_errors": errors,
            "eval_matrix": eval_entry,
        }

    print(f"   ❌ Issues found: {fb['issue'][:80]}")
    return {"feedback": fb, "attempts": attempts + 1}


def evaluator_agent(state: AgentState):
    """Agent 5 — Evaluator. Compiles evaluation reports and updates cross-run benchmarks."""
    run_dir = state["run_dir"]
    manifest = state["manifest"]
    print("\n📊 [Agent 5: Evaluator] Scoring the finished app...")

    files = ["index.html", "style.css", "app.js"]
    ctx_by_file = {
        "index.html": focused_context(manifest, ["layout", "ids"]),
        "style.css": focused_context(manifest, ["layout"]),
        "app.js": focused_context(manifest, ["ids", "functions"]),
    }
    deepeval_metrics = _build_deepeval_metrics() if DEEPEVAL_AVAILABLE else []

    report = {}
    for filename in files:
        code = load_artifact(run_dir, filename)
        entry = dict(state["eval_matrix"].get(filename, {}))
        entry["review_history"] = extract_review_history(run_dir, filename)
        entry["custom_score"] = compute_custom_score(entry)
        entry["deepeval"] = deepeval_score_file(filename, code, ctx_by_file[filename], state["requirements"],
                                                 deepeval_metrics)
        report[filename] = entry

    pass_count = sum(1 for f in report.values() if f.get("status") == "PASS")
    custom_scores = [f["custom_score"] for f in report.values() if f.get("custom_score") is not None]
    overall = {
        "files_passed": f"{pass_count}/{len(files)}",
        "deepeval_available": DEEPEVAL_AVAILABLE,
        "custom_score_avg": round(sum(custom_scores) / len(custom_scores), 2) if custom_scores else 0.0,
    }
    deepeval_all_scores = [
        m["score"] for f in report.values() if f.get("deepeval")
        for m in f["deepeval"].values() if m and m.get("score") is not None
    ]
    if deepeval_all_scores:
        overall["deepeval_avg_score"] = round(sum(deepeval_all_scores) / len(deepeval_all_scores), 2)

    save_artifact(run_dir, "evaluation.json", json.dumps({"overall": overall, "files": report}, indent=2))
    save_artifact(run_dir, "evaluation.md", render_evaluation_markdown(overall, report))
    write_log(run_dir, "Evaluator", json.dumps(overall, indent=2))

    benchmark_record = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "run_dir": str(run_dir),
        "app_brief": state.get("project_brief", "")[:200],
        "llm_config": {
            "model": MODEL_NAME,
            "num_ctx": NUM_CTX,
            "num_predict_text": NUM_PREDICT_TEXT,
            "num_predict_json": NUM_PREDICT_JSON,
            "max_attempts": MAX_ATTEMPTS,
            "chunk_size": CHUNK_SIZE,
        },
        "files_passed": overall["files_passed"],
        "custom_score_avg": overall["custom_score_avg"],
        "deepeval_available": DEEPEVAL_AVAILABLE,
        "deepeval_avg_score": overall.get("deepeval_avg_score"),
        "per_file": {fn: {"status": d.get("status"), "attempts": d.get("attempts")} for fn, d in report.items()},
    }
    history = append_benchmark_record(benchmark_record)
    (benchmark_history_path().parent / "benchmark_history.html").write_text(
        render_benchmark_html(history), encoding="utf-8"
    )

    score_note = (f" | avg DeepEval score: {overall['deepeval_avg_score']}/1.0" if "deepeval_avg_score" in overall
                  else " | DeepEval not installed — deterministic results only")
    print(f"   Files passed: {overall['files_passed']} | custom score: {overall['custom_score_avg']}/1.0{score_note}")
    print(f"   📈 Benchmark: {len(history)} run(s) tracked — see {benchmark_history_path().name} / "
          f"benchmark_history.html")
    return {}


# ==========================================
# 10. ORCHESTRATION & GRAPH ROUTING
# ==========================================
def route_review(state: AgentState):
    if not state["feedback"]:
        return "coder" if state["task_stack"] else "end"
    return "coder"


workflow = StateGraph(AgentState)
workflow.add_node("scoper", requirement_agent)
workflow.add_node("architect", architect_agent)
workflow.add_node("coder", coder_agent)
workflow.add_node("reviewer", reviewer_agent)
workflow.add_node("evaluator", evaluator_agent)

workflow.set_entry_point("scoper")
workflow.add_edge("scoper", "architect")
workflow.add_edge("architect", "coder")
workflow.add_edge("coder", "reviewer")
workflow.add_conditional_edges("reviewer", route_review, {"coder": "coder", "end": "evaluator"})
workflow.add_edge("evaluator", END)

app = workflow.compile()


# ==========================================
# 11. EXECUTION BOOTSTRAP
# ==========================================
if __name__ == "__main__":
    print("=" * 70)
    print("  Offline Agentic SDLC — Vanilla Web App Generator (Ollama)")
    print("=" * 70)
    user_input = input("\nWhat web application do you want to build?\n> ").strip()
    while not user_input:
        print("Please describe the app you want to build — it can't be empty.")
        user_input = input("> ").strip()

    run_dir = Path.cwd() / "SDLC_Workspace" / datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir.mkdir(parents=True, exist_ok=True)
    print(f"\n🚀 Workspace: {run_dir}")

    final_state = app.invoke({
        "user_input": user_input,
        "run_dir": run_dir,
        "attempts": 0,
        "feedback": {},
        "last_revision_mode": "initial",
        "validation_errors": {},
        "eval_matrix": {},
    })

    eval_matrix = final_state.get("eval_matrix", {})
    errors = final_state.get("validation_errors", {})

    print("\n" + "=" * 70)
    if errors:
        print(f"⚠️  Done — {len(errors)} file(s) still failing after {MAX_ATTEMPTS} attempts:")
        for f, msg in errors.items():
            print(f"   - {f}: {msg[:100]}")
    else:
        print("🎉 All files passed review.")
    print(f"📁 Output dir:     {run_dir}")
    print(f"📊 Evaluation:     {run_dir / 'evaluation.md'}  (human-readable)")
    print(f"                   {run_dir / 'evaluation.json'}  (raw, for tooling)")
    print(f"📈 Benchmark:      {benchmark_history_path().parent / 'benchmark_history.html'}  (trend across all runs)")
    print(f"🧾 Full log:       {run_dir / 'execution_log.txt'}")
    print("=" * 70)