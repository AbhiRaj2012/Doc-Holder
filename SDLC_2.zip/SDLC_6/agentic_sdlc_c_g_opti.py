"""
Offline Agentic SDLC — Vanilla Web App Generator (Optimized)
=============================================================
Runs entirely against a local Ollama server.
Features Hybrid JS Skeletons, Strict Context Isolation,
and highly structured Professional Personas to prevent context collapse.
"""

import os
import re
import json
import operator
from pathlib import Path
from datetime import datetime
from typing import TypedDict, Annotated, Optional

from langgraph.graph import StateGraph, END
from langchain_ollama import ChatOllama

# ==========================================
# 1. INITIALIZATION & CONFIGURATION
# ==========================================
MODEL_NAME = "gemma4:e2b"  # Adjust to your local model
OLLAMA_URL = "http://localhost:11434"
MAX_ATTEMPTS = 3
CHUNK_SIZE = 3

llm = ChatOllama(
    model=MODEL_NAME,
    base_url=OLLAMA_URL,
    num_predict=2500,
    temperature=0.1,
)

llm_json = ChatOllama(
    model=MODEL_NAME,
    base_url=OLLAMA_URL,
    num_predict=1500,
    temperature=0.1,
    format="json",
)

# ==========================================
# 2. STATE DEFINITION
# ==========================================
class AgentState(TypedDict):
    user_input: str
    run_dir: Path
    project_brief: str
    requirements: str
    manifest: dict
    task_stack: list[dict]
    feedback: dict
    attempts: int
    last_revision_mode: str
    validation_errors: Annotated[dict, operator.ior]
    eval_matrix: Annotated[dict, operator.ior]


# ==========================================
# 3. PROFESSIONAL PERSONAS
# ==========================================
SCOPER_PERSONA = "You are a professional Project Requirement Analyst, who evaluates user requests to draft precise functional requirements, and have a great experience in scoping Vanilla JS web apps."
ARCHITECT_PERSONA = "You are a professional Software Architect, who plans modular HTML/CSS/JS applications and outputs strict JSON blueprints, and have a great experience in scalable frontend architecture."
CODER_PERSONA = "You are a professional Front-End Engineer, who writes clean, stable, bug-free vanilla HTML/CSS/JS code, and have a great experience in building responsive web applications."
REVIEWER_PERSONA = "You are a professional Code Reviewer and QA Engineer, who strictly audits code against technical manifests, and have a great experience in identifying UI/logic flaws and syntax truncation."

IMPL_FORMAT_NOTE = """Format EACH function exactly like this, one block per function:
<IMPL id="functionName">
function functionName(args) {
    // actual logic here
}
</IMPL>"""

PATCH_FORMAT_NOTE = """Output ONLY SEARCH/REPLACE blocks to fix the specific issue.
<<<<<<< SEARCH
<exact lines to find>
=======
<replacement lines>
>>>>>>> REPLACE"""


# ==========================================
# 4. PERSISTENCE & PARSING HELPERS
# ==========================================
def write_log(run_dir: Path, step: str, details: str) -> None:
    log_file = run_dir / "execution_log.txt"
    timestamp = datetime.now().strftime("%H:%M:%S")
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"\n[{timestamp}] === {step.upper()} ===\n")
        f.write(str(details) + "\n")
        f.write("-" * 80 + "\n")

def save_artifact(run_dir: Path, filename: str, content: str) -> str:
    (run_dir / filename).write_text(content, encoding="utf-8")
    return content

def load_artifact(run_dir: Path, filename: str) -> str:
    path = run_dir / filename
    return path.read_text(encoding="utf-8") if path.exists() else ""

def extract_json(text: str) -> dict:
    clean = re.sub(r"```(?:json)?", "", text, flags=re.IGNORECASE).replace("```", "")
    start, end = clean.find("{"), clean.rfind("}")
    if start == -1 or end == -1: return {}
    try: return json.loads(clean[start:end + 1], strict=False)
    except: return {}

def extract_code(response_text: str) -> str:
    match = re.search(r"```(?:[a-zA-Z]*)\n?(.*?)\n?```", response_text, re.DOTALL)
    if match: return match.group(1).strip()
    match = re.search(r"```(?:[a-zA-Z]*)\n?(.*)", response_text, re.DOTALL)
    return match.group(1).strip() if match else response_text.strip()

def focused_context(manifest: dict, keys: list[str]) -> dict:
    return {k: manifest.get(k, {}) for k in keys}


# ==========================================
# 5. JS STRUCTURAL HELPERS
# ==========================================
def placeholder_pattern(name: str) -> re.Pattern:
    return re.compile(rf'//\s*<PLACEHOLDER[^>]*\b{re.escape(name)}\b[^>]*/?>', re.IGNORECASE)

def remaining_placeholders(code: str, functions: list[dict]) -> list[dict]:
    return [f for f in functions if placeholder_pattern(f["name"]).search(code)]

# ==========================================
# 6. GENERIC PATCH HELPERS
# ==========================================
PATCH_BLOCK_RE = re.compile(r"<{3,}\s*SEARCH\s*\r?\n(.*?)\r?\n={3,}\s*\r?\n(.*?)\r?\n>{3,}\s*REPLACE", re.DOTALL)

def apply_patches(original: str, patch_text: str) -> tuple[str, list[str]]:
    blocks = PATCH_BLOCK_RE.findall(patch_text)
    if not blocks: return original, ["model returned no SEARCH/REPLACE blocks"]
    code = original
    failures = []
    for search, replace in blocks:
        search, replace = search.strip("\n"), replace.strip("\n")
        if not search: continue
        if code.count(search) == 1:
            code = code.replace(search, replace, 1)
        else:
            failures.append(search[:80].replace("\n", " ⏎ "))
    return code, failures

# ==========================================
# 7. HEURISTICS
# ==========================================
def heuristic_precheck(filename: str, code: str) -> Optional[str]:
    if not code.strip(): return "File is empty."
    if filename.endswith(".js") and "PLACEHOLDER" in code:
        return "A '<PLACEHOLDER .../>' marker is still present — a function was never implemented."
    opens, closes = code.count("{"), code.count("}")
    if opens != closes:
        return f"Unbalanced braces ({opens} '{{' vs {closes} '}}') — file looks truncated."
    if filename.endswith(".html") and ("<html" not in code.lower() or "</html>" not in code.lower()):
        return "Missing a complete <html>...</html> root — file looks truncated."
    return None


# ==========================================
# 8. SHARED LLM-CALL BUILDERS
# ==========================================
def implement_single_function(brief: str, func_meta: dict, extra_note: str = "") -> str:
    note = f"\nISSUE TO FIX: {extra_note}" if extra_note else ""
    prompt = (
        f"{CODER_PERSONA}\nPROJECT: {brief}\n"
        f"Implement exactly this ONE JavaScript function, nothing else:\n"
        f"{json.dumps(func_meta, indent=2)}{note}\n\n"
        "RULES:\n1. Assume DOM references already exist.\n2. Use template literals (backticks) for multi-line strings.\n"
        "3. Output ONLY the function body, inside a ``` block.\n"
    )
    return extract_code(llm.invoke(prompt).content)

def full_rewrite(filename: str, brief: str, ctx_str: str, issue: str, instruction: str, current_code: str) -> str:
    prompt = (
        f"{CODER_PERSONA}\nFix `{filename}` based on reviewer feedback.\n\n"
        f"RELEVANT CONTEXT: {ctx_str}\nISSUE: {issue}\nINSTRUCTION: {instruction}\n"
        f"CURRENT CODE:\n```\n{current_code}\n```\n"
        "Output the entire fixed file inside a ``` block.\n"
    )
    return extract_code(llm.invoke(prompt).content)


# ==========================================
# 9. AGENT NODES
# ==========================================
def requirement_agent(state: AgentState):
    print("\n📝 [Agent 1: Scoper] Drafting requirements...")
    prompt = f"{SCOPER_PERSONA}\n\nAnalyze this request: \"{state['user_input']}\"\nDraft a concise, bulleted functional requirements list. Ignore non-functional fluff."
    reqs = llm.invoke(prompt).content.strip()
    save_artifact(state["run_dir"], "requirements.txt", reqs)
    write_log(state["run_dir"], "Requirements", reqs)
    return {"requirements": reqs, "project_brief": state["user_input"].strip()}


def architect_agent(state: AgentState):
    print("📐 [Agent 2: Architect] Building manifest & task stack...")
    reqs = state["requirements"]

    # FIX 1: Robust Validation against empty lists
    layout = {}
    for _ in range(MAX_ATTEMPTS):
        p = f'{ARCHITECT_PERSONA}\nReqs: {reqs}\nOutput JSON for the CSS layout strategy only. Format: {{"layout": {{"container": "grid/flex rule", "notes": "notes"}}}}'
        layout = extract_json(llm_json.invoke(p).content)
        if isinstance(layout.get("layout"), dict) and layout.get("layout"): break

    ids = {}
    for _ in range(MAX_ATTEMPTS):
        p = f'{ARCHITECT_PERSONA}\nReqs: {reqs}\nOutput JSON listing interactive HTML elements. Format: {{"ids": [{{"id": "btn-submit", "purpose": "submits"}}]}}'
        ids = extract_json(llm_json.invoke(p).content)
        if isinstance(ids.get("ids"), list) and len(ids.get("ids")) > 0: break

    functions = {}
    for _ in range(MAX_ATTEMPTS):
        p = f'{ARCHITECT_PERSONA}\nReqs: {reqs}\nOutput JSON listing JS functions. Format: {{"functions": [{{"name": "calc", "params": ["a"], "description": "adds"}}]}}'
        functions = extract_json(llm_json.invoke(p).content)
        if isinstance(functions.get("functions"), list) and len(functions.get("functions")) > 0: break

    manifest = {"layout": layout.get("layout", {}), "ids": ids.get("ids", []), "functions": functions.get("functions", [])}
    manifest_str = json.dumps(manifest, indent=2)
    save_artifact(state["run_dir"], "manifest.json", manifest_str)
    write_log(state["run_dir"], "Manifest", manifest_str)

    task_stack = [
        {"file": "index.html", "context_keys": ["layout", "ids"], "purpose": "Build the DOM structure."},
        {"file": "style.css", "context_keys": ["layout"], "purpose": "Style the layout."},
        {"file": "app.js", "context_keys": ["ids", "functions"], "purpose": "Implement exactly these functions."},
    ]
    return {"manifest": manifest, "task_stack": task_stack, "validation_errors": {}, "eval_matrix": {}}


def _generate_app_js(run_dir: Path, brief: str, ctx: dict) -> str:
    """FIX 2: Hybrid Skeleton Generation."""
    print("   ↳ generating hybrid skeleton (LLM Setup + Python Placeholders)...")
    ctx_str = json.dumps(ctx, indent=2)

    # 1. LLM generates Variables, DOM refs, and Event Listeners
    skel_prompt = f"""
    {CODER_PERSONA}
    Write the initial JS setup for this project: {brief}
    CONTEXT: {ctx_str}
    
    RULES:
    1. Declare global state variables.
    2. Set up document.getElementById references using the provided IDs.
    3. Attach event listeners to the DOM elements.
    4. CRITICAL: DO NOT write any actual function declarations or logic for the items in the "functions" list. Only write the event listeners calling them.
    
    Output ONLY javascript inside a ``` block.
    """
    setup_code = extract_code(llm.invoke(skel_prompt).content)

    # 2. Python deterministically appends the placeholders to prevent hallucinations
    skeleton = setup_code + "\n\n// --- Core Functions ---\n"
    funcs = ctx.get("functions", [])
    for f in funcs:
        skeleton += f"// <PLACEHOLDER id=\"{f['name']}\"/>\n"

    save_artifact(run_dir, "app.js", skeleton)

    print("   ↳ implementing functions in chunks...")
    for i in range(0, len(funcs), CHUNK_SIZE):
        chunk = funcs[i:i + CHUNK_SIZE]
        impl_prompt = (
            f"{CODER_PERSONA}\nImplement exactly these functions: {json.dumps(chunk, indent=2)}\n\n"
            "CRITICAL: use template literals (backticks) for multi-line strings.\n\n"
            f"{IMPL_FORMAT_NOTE}\n"
        )
        impl_resp = llm.invoke(impl_prompt).content
        for f in chunk:
            name = f["name"]
            pattern = rf'<IMPL\s+id=["\']?{re.escape(name)}["\']?\s*>\s*(.*?)\s*</IMPL>'
            m = re.search(pattern, impl_resp, re.DOTALL | re.IGNORECASE)
            if m:
                skeleton = placeholder_pattern(name).sub(
                    lambda _mo: m.group(1).strip().replace("\\", "\\\\"), skeleton
                )
        save_artifact(run_dir, "app.js", skeleton)

    print("   ↳ self-healing any missed functions...")
    for f in remaining_placeholders(skeleton, funcs):
        new_impl = implement_single_function(brief, f, "This function was missed.")
        skeleton = placeholder_pattern(f["name"]).sub(lambda _mo: new_impl.replace("\\", "\\\\"), skeleton, count=1)
        save_artifact(run_dir, "app.js", skeleton)
        write_log(run_dir, f"Coder (self-heal) - {f['name']}", new_impl)

    return skeleton


def coder_agent(state: AgentState):
    run_dir = state["run_dir"]
    task = state["task_stack"][0]
    filename = task["file"]
    attempts = state["attempts"]
    is_revision = attempts > 0
    is_last_attempt = attempts + 1 >= MAX_ATTEMPTS

    ctx = focused_context(state["manifest"], task["context_keys"])
    ctx_str = json.dumps(ctx, indent=2)
    brief = state["project_brief"]

    print(f"\n💻 [Agent 3: Coder] {'Revising' if is_revision else 'Writing'} {filename} (attempt {attempts + 1}/{MAX_ATTEMPTS})...")

    if not is_revision:
        if filename == "app.js":
            code = _generate_app_js(run_dir, brief, ctx)
        else:
            prompt = f"{CODER_PERSONA}\nWrite `{filename}`.\nPROJECT: {brief}\nTASK: {task['purpose']}\nRELEVANT CONTEXT: {ctx_str}\nRULES:\n- If HTML: link style.css and app.js.\n- Output ONLY raw code inside a ``` block.\n"
            code = extract_code(llm.invoke(prompt).content)
        mode = "initial"

    else:
        current_code = load_artifact(run_dir, filename)
        fb = state["feedback"]
        issue, instruction = fb.get("issue", ""), fb.get("instruction", "")

        print("   ↳ requesting scoped SEARCH/REPLACE patch...")
        patch_prompt = f"{CODER_PERSONA}\nPROJECT: {brief}\nRELEVANT CONTEXT: {ctx_str}\nISSUE: {issue}\nINSTRUCTION: {instruction}\nCURRENT `{filename}`:\n```\n{current_code}\n```\n{PATCH_FORMAT_NOTE}\n"
        patch_text = llm.invoke(patch_prompt).content

        code, failures = apply_patches(current_code, patch_text)
        if not failures:
            mode = "search_replace"
        elif is_last_attempt:
            print("   ↳ patch failed on final attempt — falling back to full rewrite/regeneration.")
            if filename == "app.js":
                code = _generate_app_js(run_dir, brief, ctx)
            else:
                code = full_rewrite(filename, brief, ctx_str, issue, instruction, current_code)
            mode = "last_resort_full_rewrite"
        else:
            write_log(run_dir, f"Coder (patch — unmatched blocks) - {filename}", "\n".join(failures))
            mode = "search_replace_partial"

    save_artifact(run_dir, filename, code)
    write_log(run_dir, f"Coder ({mode}) - {filename}", code)
    return {"last_revision_mode": mode}


def reviewer_agent(state: AgentState):
    run_dir = state["run_dir"]
    current_task = state["task_stack"][0]
    filename = current_task["file"]
    attempts = state["attempts"]
    code = load_artifact(run_dir, filename)

    print(f"🔎 [Agent 4: Reviewer] Auditing {filename}...")

    heuristic_issue = heuristic_precheck(filename, code)
    if heuristic_issue:
        status = "FAIL"
        fb = {"issue": heuristic_issue, "instruction": "Fix exactly this, nothing else."}
        write_log(run_dir, f"Reviewer (heuristic) - {filename}", heuristic_issue)
    else:
        ctx = focused_context(state["manifest"], current_task["context_keys"])
        prompt = (
            f"{REVIEWER_PERSONA}\n\nReview `{filename}` against the spec.\n"
            f"PROJECT: {state['project_brief']}\nRELEVANT MANIFEST: {json.dumps(ctx, indent=2)}\n\n"
            f"CODE:\n```\n{code}\n```\n\n"
            "Fail it if ANY are true: 1. Truncation 2. Drifts from manifest 3. Syntax/logic bug.\n"
            'Respond ONLY with JSON:\n{"status": "PASS/FAIL", "issue": "what is wrong", "instruction": "how to fix"}'
        )
        raw = llm_json.invoke(prompt).content
        parsed = extract_json(raw)
        status = str(parsed.get("status", "")).upper()

        if status not in ("PASS", "FAIL"):
            status = "PASS" if "PASS" in raw[:30].upper() else "FAIL"

        # FIX 3: Failsafe for empty reviewer issues
        issue_text = parsed.get("issue", "").strip()
        if not issue_text or len(issue_text) < 5:
            if status == "FAIL":
                issue_text = "Critical syntax or structural error detected. Please fix the broken elements."

        fb = {
            "issue": issue_text,
            "instruction": parsed.get("instruction", "Fix the file to match the manifest.")
        }
        write_log(run_dir, f"Reviewer (LLM) - {filename}", f"{status}: {fb['issue']}")

    finished = status == "PASS" or (attempts + 1 >= MAX_ATTEMPTS)

    if finished:
        ok = status == "PASS"
        print(f"   {'✅' if ok else '⚠️ '} {filename}: {'PASS' if ok else 'FAIL (max attempts reached)'}")
        eval_entry = {filename: {"attempts": attempts + 1, "status": status, "chars": len(code), "last_action": state.get("last_revision_mode", "initial")}}
        errors = {} if ok else {filename: fb["issue"]}
        return {
            "feedback": {},
            "attempts": 0,
            "task_stack": state["task_stack"][1:],
            "validation_errors": errors,
            "eval_matrix": eval_entry,
        }

    print(f"   ❌ Issues found: {fb['issue'][:80]}")
    return {"feedback": fb, "attempts": attempts + 1}

# ==========================================
# 10. ORCHESTRATION & GRAPH ROUTING
# ==========================================
def route_review(state: AgentState):
    if not state["feedback"]:
        return "coder" if state["task_stack"] else "end"
    return "coder"

workflow = StateGraph(AgentState)
workflow.add_node("scoper", requirement_agent)
workflow.add_node("architect", architect_agent)
workflow.add_node("coder", coder_agent)
workflow.add_node("reviewer", reviewer_agent)

workflow.set_entry_point("scoper")
workflow.add_edge("scoper", "architect")
workflow.add_edge("architect", "coder")
workflow.add_edge("coder", "reviewer")
workflow.add_conditional_edges("reviewer", route_review, {"coder": "coder", "end": END})

app = workflow.compile()

# ==========================================
# 11. EXECUTION BOOTSTRAP
# ==========================================
if __name__ == "__main__":
    print("=" * 70)
    print("  Offline Agentic SDLC — Vanilla Web App Generator (Optimized)")
    print("=" * 70)
    user_input = input("\nWhat web application do you want to build?\n> ").strip()

    run_dir = Path.cwd() / "SDLC_Workspace" / datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir.mkdir(parents=True, exist_ok=True)
    print(f"\n🚀 Workspace: {run_dir}")

    final_state = app.invoke({
        "user_input": user_input,
        "run_dir": run_dir,
        "attempts": 0,
        "feedback": {},
        "last_revision_mode": "initial",
        "validation_errors": {},
        "eval_matrix": {},
    })

    eval_matrix = final_state.get("eval_matrix", {})
    errors = final_state.get("validation_errors", {})
    save_artifact(run_dir, "evaluation.json", json.dumps({"files": eval_matrix, "unresolved": errors}, indent=2))

    print("\n" + "=" * 70)
    if errors:
        print(f"⚠️  Done — {len(errors)} file(s) still failing after {MAX_ATTEMPTS} attempts:")
        for f, msg in errors.items():
            print(f"   - {f}: {msg[:100]}")
    else:
        print("🎉 All files passed review.")
    print(f"📁 Output dir:   {run_dir}")
    print("=" * 70)