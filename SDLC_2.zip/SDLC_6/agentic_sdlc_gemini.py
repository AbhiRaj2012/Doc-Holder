import os
import re
import json
import operator
from pathlib import Path
from datetime import datetime
from typing import TypedDict, Annotated

from langgraph.graph import StateGraph, END
from langchain_ollama import ChatOllama

# ==========================================
# 1. INITIALIZATION & CONFIGURATION
# ==========================================
llm = ChatOllama(
    model="gemma4:e2b",
    base_url="http://localhost:11434",
    num_predict=2000,
    temperature=0.1
)


# ==========================================
# 2. STATE & MEMORY MANAGEMENT
# ==========================================
class AgentState(TypedDict):
    user_input: str
    run_dir: Path
    requirements: str
    manifest: dict
    file_system: dict
    pending_files: list[str]
    current_file: str
    feedback: str
    attempts: int
    validation_errors: Annotated[dict, operator.ior]


def write_log(run_dir: Path, step: str, details: str):
    """Keeps the log of execution to track down/monitor working flow & failure."""
    log_file = run_dir / "execution_log.txt"
    timestamp = datetime.now().strftime("%H:%M:%S")
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"\n[{timestamp}] === {step.upper()} ===\n")
        f.write(str(details) + "\n")
        f.write("-" * 80 + "\n")


def extract_json(text: str) -> dict:
    """Helper to salvage JSON from small models."""
    clean_text = re.sub(r"```(?:json)?", "", text, flags=re.IGNORECASE).replace("```", "")
    start = clean_text.find('{')
    end = clean_text.rfind('}')
    if start != -1 and end != -1:
        try:
            return json.loads(clean_text[start:end + 1], strict=False)
        except Exception as e:
            print(f"   [!] JSON Parse Error: {e}")
            return {}
    return {}


# ==========================================
# 3. AGENT NODES
# ==========================================

def requirement_agent(state: AgentState):
    print("\n📝 [Agent 1: Scoper] Analyzing Requirements...")
    prompt = f"""
    You are a professional Project Requirement Analyzer, who checks the user's request and drafts a detailed functional requirements document. You have a great experience in scoping Vanilla JS web apps.

    Analyze this request: "{state['user_input']}"
    Draft a concise, bulleted list of functional requirements (what interfaces, and what functionality the software should be capable of).
    Ignore non-functional fluff.
    """
    reqs = llm.invoke(prompt).content.strip()
    write_log(state["run_dir"], "Requirements", reqs)
    (state["run_dir"] / "req.txt").write_text(reqs, encoding="utf-8")
    return {"requirements": reqs}


def architect_agent(state: AgentState):
    print("📐 [Agent 2: Architect] Building Manifest...")

    persona = "You are a professional Project Architect/Planner, who checks the requirements and creates a strict JSON manifest. You have a great experience in web architecture."

    # Split generation to prevent token crash
    p_layout = f"{persona}\nRequirements: {state['requirements']}\nOutput JSON for layout structure. Format: {{\"layout\": {{\"container\": \"grid/flex rule\"}}}}"
    layout_data = extract_json(llm.invoke(p_layout).content)

    p_ids = f"{persona}\nRequirements: {state['requirements']}\nOutput JSON for required HTML IDs. Format: {{\"ids\": [\"btn-submit\", \"input-name\"]}}"
    id_data = extract_json(llm.invoke(p_ids).content)

    p_funcs = f"{persona}\nRequirements: {state['requirements']}\nOutput JSON for JS functions. Format: {{\"functions\": [{{\"name\": \"calc\", \"description\": \"does math\"}}]}}"
    func_data = extract_json(llm.invoke(p_funcs).content)

    manifest = {
        "layout": layout_data.get("layout", {}),
        "ids": id_data.get("ids", []),
        "functions": func_data.get("functions", [])
    }

    manifest_json = json.dumps(manifest, indent=2)
    write_log(state["run_dir"], "Manifest", manifest_json)
    (state["run_dir"] / "manifest.json").write_text(manifest_json, encoding="utf-8")

    target_files = ["index.html", "style.css", "app.js"]
    return {
        "manifest": manifest,
        "pending_files": target_files,
        "file_system": {f: "" for f in target_files},
        "validation_errors": {}
    }


def coder_agent(state: AgentState):
    current_file = state["pending_files"][0]
    is_revision = state["attempts"] > 0
    manifest = state["manifest"]
    persona = "You are a professional Coder, who writes highly optimized Vanilla HTML/CSS/JS. You have a great experience in building stable web apps with clean code."

    print(f"\n💻 [Agent 3: Coder] Writing {current_file} (Attempt {state['attempts'] + 1}/3)...")

    # Handle Revision Loop
    if is_revision:
        prompt = f"""
        {persona}
        Fix `{current_file}` based on Reviewer feedback.
        FEEDBACK: {state['feedback']}
        CURRENT CODE:
        ```
        {state['file_system'][current_file]}
        ```
        Output the entirely fixed file. Output ONLY code inside ``` blocks.
        """
        response = llm.invoke(prompt).content

    # Handle JS Chunking with Surgical Injection
    elif current_file == "app.js":
        print("   ↳ Generating JS Skeleton...")
        skel_prompt = f"""
        {persona}
        Write a JS skeleton for these functions: {manifest['functions']}. 
        RULES:
        1. Set up global variables and DOM references.
        2. DO NOT write the logic for the functions.
        3. Inside every function, write exactly this comment: // <PLACEHOLDER id="functionName"/>
        Output ONLY code inside ``` blocks.
        """
        skeleton_resp = llm.invoke(skel_prompt).content
        skel_match = re.search(r"```(?:javascript|js)?\n?(.*?)\n?```", skeleton_resp, re.DOTALL)
        skeleton = skel_match.group(1).strip() if skel_match else skeleton_resp.strip()

        print("   ↳ Implementing functions in chunks...")
        funcs = manifest["functions"]
        for i in range(0, len(funcs), 3):
            chunk = funcs[i:i + 3]
            names = [f["name"] for f in chunk]
            impl_prompt = f"""
            {persona}
            Implement these functions: {json.dumps(chunk, indent=2)}.
            For each function, format it exactly like this:
            <IMPL id="functionName">
            // actual logic here
            </IMPL>
            """
            impl_resp = llm.invoke(impl_prompt).content

            # Surgically inject code into the skeleton
            for name in names:
                pattern = rf'<IMPL id="{name}">\s*(.*?)\s*</IMPL>'
                impl_match = re.search(pattern, impl_resp, re.DOTALL | re.IGNORECASE)
                if impl_match:
                    func_code = impl_match.group(1).strip()
                    skeleton = re.sub(rf'//\s*<PLACEHOLDER id=["\']?{name}["\']?\s*/>', func_code, skeleton,
                                      flags=re.IGNORECASE)

        response = f"```javascript\n{skeleton}\n```"

    # Handle HTML/CSS
    else:
        focus = ""
        if current_file == "index.html":
            focus = f"Focus strictly on elements: {manifest['ids']}. CRITICAL RULE: DO NOT WRITE <style> OR <script> BLOCKS. Only use <link rel='stylesheet' href='style.css'> and <script src='app.js'></script>."
        elif current_file == "style.css":
            focus = f"Focus strictly on layout: {manifest['layout']}."

        prompt = f"""
        {persona}
        Write `{current_file}`.
        REQUIREMENTS: {state['requirements']}
        {focus}
        Output ONLY raw code inside ``` blocks.
        """
        response = llm.invoke(prompt).content

    # Extract Code
    match = re.search(r"```(?:[a-zA-Z]+)?\n?(.*?)\n?```", response, re.DOTALL)
    clean_code = match.group(1).strip() if match else response.strip()

    fs = state["file_system"].copy()
    fs[current_file] = clean_code
    write_log(state["run_dir"], f"Coder Output - {current_file}", clean_code)

    return {"file_system": fs, "current_file": current_file}


def reviewer_agent(state: AgentState):
    current_file = state["current_file"]
    code = state["file_system"][current_file]
    attempts = state["attempts"] + 1
    persona = "You are a professional Code Reviewer and QA Bug Finder, who evaluates written code against a manifest. You have a great experience in finding UI/logic flaws and truncation."

    print(f"🔎 [Agent 4: Reviewer] Auditing {current_file}...")

    prompt = f"""
    {persona}
    Review this code for `{current_file}` against Manifest: {state['manifest']}
    CODE:
    ```
    {code}
    ```
    CRITICAL CHECKS:
    1. Is it truncated? Are there missing closing brackets or tags at the bottom?
    2. HTML: Are there illegal `<style>` blocks?
    3. JS: Are there empty `// Implementation logic goes here` stubs?

    If 100% perfect, output ONLY the word "PASS".
    If there is an issue, return what the problem is, the line/part, and what to do with it. Do not say PASS.
    """
    feedback = llm.invoke(prompt).content.strip()
    write_log(state["run_dir"], f"Reviewer Feedback - {current_file}", feedback)

    if "PASS" in feedback[:15].upper() or attempts >= 3:
        print(f"   ✅ {current_file} Passed (or max retries hit)!")

        file_path = state["run_dir"] / current_file
        file_path.write_text(code, encoding="utf-8")

        # Log error if it failed 3 times
        if "PASS" not in feedback[:15].upper():
            state["validation_errors"][current_file] = feedback

        return {
            "feedback": "",
            "attempts": 0,
            "pending_files": state["pending_files"][1:]
        }

    print(f"   ❌ Issues found: {feedback[:60]}...")
    return {"feedback": feedback, "attempts": attempts}


# ==========================================
# 4. ORCHESTRATION & GRAPH ROUTING
# ==========================================
def route_review(state: AgentState):
    if state["feedback"] == "":
        if len(state["pending_files"]) > 0:
            return "coder"
        return "end"
    return "coder"


workflow = StateGraph(AgentState)
workflow.add_node("scoper", requirement_agent)
workflow.add_node("architect", architect_agent)
workflow.add_node("coder", coder_agent)
workflow.add_node("reviewer", reviewer_agent)

workflow.set_entry_point("scoper")
workflow.add_edge("scoper", "architect")
workflow.add_edge("architect", "coder")
workflow.add_edge("coder", "reviewer")
workflow.add_conditional_edges("reviewer", route_review, {
    "coder": "coder",
    "end": END
})

app = workflow.compile()

# ==========================================
# 5. EXECUTION BOOTSTRAP
# ==========================================
if __name__ == "__main__":
    user_input = input("\nWhat web application do you want to build?\n> ")

    run_dir = Path.cwd() / "SDLC_Workspace" / datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n🚀 Workspace created: {run_dir}")

    final_state = app.invoke({
        "user_input": user_input,
        "run_dir": run_dir,
        "attempts": 0,
        "feedback": "",
        "validation_errors": {}
    })

    errors = final_state.get("validation_errors", {})
    if errors:
        (run_dir / "validation.json").write_text(json.dumps(errors, indent=2), encoding="utf-8")
        print(f"\n⚠️ Workflow complete with {len(errors)} unresolved files (saved to validation.json).")
    else:
        print(f"\n🎉 Workflow Complete! Files perfectly saved to {run_dir}")