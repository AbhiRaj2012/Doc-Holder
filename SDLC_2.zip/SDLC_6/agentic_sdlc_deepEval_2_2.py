"""
Offline Agentic SDLC — Vanilla Web App Generator (v3)
=======================================================
Runs entirely against a local Ollama server (no network calls at all).
Builds a 3-file vanilla web app (index.html / style.css / app.js) using
four cooperating agents orchestrated with LangGraph:

    User input
        |
        v
    Agent 1  Scoper      -> writes requirements.txt + a 1-line project brief
        |
        v
    Agent 2  Architect   -> writes manifest.json (layout / ids / functions)
        |                   + builds the Coder's task stack
        v
    Agent 3  Coder    <-------------------+
        |                                 |
        v                                 | FAIL (loop back, same file,
    Agent 4  Reviewer  -------------------+   PATCH — never a full rewrite)
        |
        | PASS -> pop file, next task in stack
        v
    task_stack empty? -> END

v3 changelog — what broke and why
-----------------------------------
The v2 run's own artifacts showed a NEW failure mode, worse than v1's: the
Reviewer twice returned a verdict with a completely EMPTY `issue` field
("FAIL:  | target=None"), the Coder's resulting "fix" duplicated several
functions (a full implementation immediately followed by its own empty
`{ // Implementation goes here }` stub — `renderInvoicePreview`, `addItem`,
`removeItem`, `saveInvoice` all appear twice), and the run finally died with
`app.js` overwritten by a genuinely EMPTY file (evaluation.json: "chars": 0,
"File is empty."). That's a regression from v1 — v1 at least left a
truncated-but-substantial file behind; v3's predecessor destroyed a mostly-
working ~150-line file entirely.

Root cause: neither `ChatOllama` client set `num_ctx`. Ollama's default
context window (2048-4096 tokens depending on version/model) is easily
exceeded once app.js itself is ~150+ lines and gets embedded whole into
every review/patch/rewrite prompt alongside the persona, manifest section,
and instructions. Once the prompt alone approaches the context limit, there
is no room left to generate ANY output tokens, and Ollama returns an empty
completion. That single empty completion then cascades: an empty review
gives the Coder no real issue to fix, so it patches speculatively (which is
what produced the duplicated functions); the file gets longer as a result,
making the NEXT review even more likely to overflow context and come back
empty too; eventually the final attempt's full-rewrite ALSO comes back
empty, and the old code (until now) had no protection against being
overwritten by that emptiness.

Three independent fixes, in order of how much they matter:

1. ROOT CAUSE — both `ChatOllama` clients now set `num_ctx` explicitly
   (see NUM_CTX below) to a much larger window than Ollama's default, and
   every LLM call for code/JSON goes through `invoke_text()`, which retries
   once on a genuinely empty response before giving up. This alone should
   prevent the empty-response cascade from ever starting.
2. NEVER MAKE IT WORSE (new safety net) — `guard_against_regression()` runs
   after every REVISION (patch / function-splice / last-resort rewrite,
   never after a true first-time generation) and compares the new code to
   the old code with the same free heuristic checks the Reviewer uses. If
   the new version is empty, or introduces a problem the old version didn't
   have, the old version is kept and the attempt is logged as rejected —
   disk is only ever updated with a version that is at least as sound as
   what was already there. This is what would have stopped app.js from
   ever being overwritten with an empty file, independent of whatever LLM
   hiccup causes the empty output next time.
3. DETERMINISTIC DEDUP (new, no LLM involved) — `dedupe_js_functions()` is
   run on app.js after every generation/repair step. If the same function
   name ends up declared twice (exactly what happened here), it keeps
   whichever copy is the real implementation (not a stub, not truncated)
   and deletes the other — the harness-over-model principle applied to a
   corruption pattern that's now been observed in practice rather than
   just anticipated.

Everything from v1/v2 that already worked is unchanged: self-healing
chunked generation for app.js, patch-not-rewrite revisions, vertical +
horizontal context economy (brief vs. full requirements; manifest section
slicing), disk-as-source-of-truth, and free heuristics before any LLM
review call.

v4 changelog — three runs all logged "PASS" and all shipped broken apps
--------------------------------------------------------------------------
v3's NUM_CTX/guard/dedupe fixes worked as designed — nothing was truncated
or overwritten with garbage. But three separate runs still shipped an app
whose app.js could never actually run, and the Reviewer said PASS every
time. Reading the *content* of what got built (not just whether the run
completed) turned up two real bugs the v3 harness had no way to catch:

1. A commented-out declaration was indistinguishable from a real one.
   One run's "finished" app.js had every required function only as a
   comment (`// function handleNumberInput(value) {`) — never a real
   `function handleNumberInput(value) { ... }`. That happened because the
   model paraphrased the required `// <PLACEHOLDER id="name"/>` marker
   into its own comment style instead of using it verbatim, which meant
   the self-heal pass (which searches for that exact marker) found
   nothing to heal — it wasn't broken, it correctly saw zero placeholders,
   because none existed in the format it knew how to look for. Worse: the
   OLD `find_all_function_spans` used a plain regex over the raw string,
   so it matched "function handleNumberInput(value) {" *inside that very
   comment* and reported the function as present. Every downstream check
   built on that function — self-heal, dedupe, the reviewer's own
   sanity checks — inherited the same false confidence.
   Fix: `_mask_js_comments()` blanks out comment text (same length, same
   offsets) before any structural search runs, so a commented-out
   declaration is now invisible to `find_all_function_spans`,
   `find_duplicate_function_names`, and everything built on them.

2. The skeleton step still asked the model to invent DOM variable names
   from ids, and it produced `const btn-add = document.getElementById(...)`
   — a hard JS syntax error, since '-' is the subtraction operator and
   isn't legal inside an identifier. This is a request no amount of
   rewording reliably fixes on a weak model; it's a mechanical
   transformation with one right answer, which is exactly the kind of
   step that belongs in Python, not in a prompt.
   Fix: `build_js_skeleton()` / `id_to_var_name()` / `compute_id_var_map()`
   generate the ENTIRE DOM-reference block and every `<PLACEHOLDER>`
   marker deterministically — zero LLM calls, zero chance of an invalid
   identifier or a paraphrased marker — and the resulting id->variable
   map is threaded through every later prompt (chunk implementation,
   self-heal, targeted patches, full rewrites) so the model is only ever
   asked to write function BODIES, never to invent variable names again.

Two more checks close the gap between "looks structurally fine" and
"is actually the app that was asked for", independent of whether the
small review LLM notices:

3. `heuristic_precheck` now takes the manifest's `functions` list and
   fails a file where a required function isn't found as a real
   (comment-masked) declaration — this is the check that would have
   caught the bug in point 1 even if the placeholder-marker fix above
   hadn't existed, and it also fails on invalid hyphenated identifiers as
   a second line of defense against the bug in point 2 surviving into a
   later hand-authored revision.
4. `node_syntax_check()` shells out to `node --check` (best-effort — silently
   skipped if Node isn't installed) as a real, deterministic parse instead
   of brace/paren counting. This is what would have caught
   `const btn-add = ...` immediately, with zero LLM involvement and zero
   ambiguity, on any machine that has Node.

Finally, two silent-cascade guards: one run's requirements.txt was the
model asking "please provide the project request" back (the app
description was left blank), which flowed into an empty manifest, which
flowed into a trivial app that trivially "passed" because there was
nothing in the spec to fail it against. `requirement_agent` now flags a
suspiciously short/refusal-shaped draft, `architect_agent` now flags a
manifest with no ids and no functions, and the CLI now refuses to start
a run on a blank app description — so a degenerate run is loud instead of
silently shipping something that looks like a completed, passing build.

v5 changelog — a fourth run: correct structure, wrong ids, false PASS
--------------------------------------------------------------------------
A billing-ledger run built genuinely well-structured app.js (deterministic
skeleton worked, dedupe correctly collapsed two duplicated functions) —
and still shipped multiple functions that throw at runtime, because
several of them re-queried the DOM with the WRONG id string instead of
reusing the exact variables the skeleton had already declared, e.g.:
    const invoicePreviewArea = document.getElementById('invoicePreviewArea');
The manifest's real id is `invoice-preview-area`; `'invoicePreviewArea'`
(the camelCase VARIABLE name, used as an id STRING) matches no element,
so this always returns null, and the very next line to touch it throws.
One instance even had a typo layered on top: `'taxRateInputInput'`. This
is syntactically perfect JS — brace/paren counting and `node --check`
both see nothing wrong — so nothing in v4 could catch it. Worse: the
Reviewer's LLM call for this file came back empty even after a retry
(NUM_CTX=8192 wasn't enough for a ~300-line file plus a 10-function/10-id
manifest embedded in one review prompt), so v4's deliberate "trust the
heuristic pass rather than fabricate a FAIL" fallback (see v4 above)
accepted it — reasonably, given what the heuristic layer could see at
the time, which is exactly the gap this version closes.
  - `find_bad_getelementbyid_ids()` cross-references every literal
    `document.getElementById('...')` call against the manifest's actual
    ids — the one list that defines which id strings are real — and
    `heuristic_precheck` now fails a file that calls getElementById with
    anything not on that list. `guess_broken_function` also uses it to
    target the exact offending function for a single-function patch,
    same as the existing truncation/placeholder checks.
  - NUM_CTX raised from 8192 given the concrete overflow evidence above;
    the docstring now also points at `ollama show <model>` since raising
    NUM_CTX past a model's real trained context doesn't create capacity
    that isn't there.

Separately, a real request: the evaluation output was a raw JSON dump of
attempts/status/chars — accurate, but not something a person could read
as a story of how a run went. Two additions, both best-effort so neither
can break a run:
  - `evaluator_agent` — a 5th graph node, run once after the task stack
    empties. It doesn't gate anything (the Reviewer loop above already
    decided pass/fail); it scores and reports on what's already final.
  - DeepEval's GEval (LLM-as-judge, using the SAME local Ollama model —
    see `OllamaEvalModel`, so this stays fully offline) scores each file
    0.0-1.0 on Correctness and Completeness, with a written reason.
    Genuinely optional: `DEEPEVAL_AVAILABLE` is False and every DeepEval
    call is skipped cleanly if `deepeval` isn't installed — the pipeline
    keeps working exactly as before either way.
  - Both evaluation.json (machine-readable, joined with each file's full
    Reviewer history pulled straight out of execution_log.txt — see
    `extract_review_history`, another disk-is-source-of-truth read
    instead of new parallel state) and evaluation.md (a human-readable
    report — status, attempts, the FAIL->FAIL->PASS history, DeepEval
    scores and reasons) are written every run now.

v6 changelog — two more real runs: whack-a-mole patching, and a judge
that shares the generator's blind spots
--------------------------------------------------------------------------
Two more billing-app runs both ended app.js at FAIL after 3 attempts,
both for the SAME v5 bug class (wrong-id getElementById calls) — but v5's
fix (detect + target one function) wasn't enough to actually clear it:

1. Whack-a-mole: `review_history` across both runs shows the SAME set of
   bad ids surviving 2-3 attempts in a row, with the TARGET function
   changing between attempts (`initializeInvoiceState`, then
   `calculateInvoiceTotals`, then `renderInvoice`...). The bug wasn't in
   one function — the same "call getElementById with the camelCase
   variable name instead of reusing the top-level const" mistake was
   repeated across 4-5 DIFFERENT functions in the same generation. A
   targeted single-function patch (v5) can only fix one function per
   attempt; with a 3-attempt budget and the bug spread across more
   functions than that, it could never fully clear — every retry's
   heuristic re-scan found the same or a shuffled list of bad ids, because
   fixing function A never touched the identical bug sitting in B, C, D.
   Fix: `autofix_getelementbyid_ids()` — instead of flagging a wrong id
   and hoping a retry fixes it, `best_id_match()` fuzzy-matches it (token
   overlap; 'inputCustomerName' vs real id 'customer-name' share every
   word, just re-cased) against the manifest's real ids and, above a
   confidence threshold, deterministically replaces the WHOLE
   `getElementById(...)` call with the correct existing top-level
   variable. One pass, every occurrence, whole file, zero LLM calls —
   wired into both the initial generation (`_generate_app_js`) and every
   revision (`guard_against_regression`), so this bug class is now fixed
   at the source almost every time instead of spending retry budget on it.
   Genuinely ambiguous ids (below the confidence threshold — e.g.
   'invoice-container' when the real ids are 'invoice-output' and
   'invoice-body', a coin flip) are deliberately left alone rather than
   risk pointing at the wrong element; those still fall through to the
   heuristic-FAIL + targeted-patch path from v5, which is why that path
   was kept rather than replaced.

2. A judge with the generator's blind spots: in BOTH runs, DeepEval's
   GEval scored app.js 1.0/1.0 on Correctness AND Completeness — the
   exact file that failed review 3 times in a row for a reproducible,
   confirmed bug. The judge is the SAME small local model that wrote the
   bug, so asking it to grade its own work for the same mistake it just
   made isn't independent verification — it shares the blind spot rather
   than catching it. That's a known limitation of same-model-as-judge
   setups in general, not a defect in DeepEval itself.
   Fix: `compute_custom_score()` — a second, deterministic score (0-1)
   based ONLY on what the harness itself actually verified (did it pass
   review, and how many attempts did that take), completely independent
   of any LLM opinion. Both scores are now shown side by side in
   evaluation.md, with an explicit disagreement flag when they diverge —
   the custom score is the one to trust when they do.

Separately, the requested benchmark tracking: `evaluator_agent` now also
appends a record — timestamp, the exact LLM config used (model, num_ctx,
num_predict, max_attempts, chunk_size — see NUM_PREDICT_TEXT/JSON below),
files_passed, and both scores — to `benchmark_history.jsonl`, a file that
lives next to the SCRIPT (not inside the per-run workspace) and
accumulates across every run ever made. `benchmark_history.html` is
regenerated each run: a self-contained SVG trend chart (no charting
library, no CDN — has to stay usable fully offline) of both scores over
time, plus a table of every run's config, alongside the all-time average
of each. This is what lets you tell whether a harness change (or a model
swap) is actually moving quality, rather than reading one run at a time.

v7 changelog — "3/3 passed" and "2/3 passed" both shipped a broken app
--------------------------------------------------------------------------
Two more real runs, reported by the user as visibly broken in the browser
(unresponsive buttons, wrong-looking layout) despite one showing 3/3
files passed. Reading the actual generated files instead of just the
scores turned up two root causes, both structural gaps in the workflow
rather than one-off model mistakes:

1. STYLE.CSS IS GENERATED BLIND. The task stack has always given style.css
   only the abstract `layout` manifest section (e.g. "use grid") — it has
   NEVER seen the actual index.html. HTML and CSS are two fully
   independent LLM calls with no shared class-name vocabulary, so they
   predictably invented different ones: the real run's HTML wrapped
   everything in `id="invoice-app"`; CSS's main layout rule styled a
   `.invoice-container` CLASS that existed nowhere on the page, so the
   grid layout silently never applied. Buttons had no `class` attribute
   at all in the HTML; CSS styled `.btn-add-item`/`.btn-action` anyway.
   10 of the stylesheet's 11 selectors matched nothing. That's the
   reported "broken CSS, unresponsive-looking buttons" — the buttons
   work, they're just completely unstyled, which looks unresponsive.
   Fix, two layers:
     - `coder_agent` now hands style.css the ACTUAL generated index.html
       verbatim, with an explicit "use exactly these classes and ids, do
       not invent your own" instruction — for the initial generation AND
       every revision/patch prompt.
     - `find_css_html_mismatch()` — a deterministic backstop: if most of
       index.html's classes have no matching CSS rule at all, that's a
       heuristic FAIL, independent of whether the instruction above was
       followed. Confirmed against the real broken files: correctly
       flags the 10/11-orphaned run, and confirmed clean (no false
       positive) against a genuinely matching stylesheet.

2. THE MANIFEST ISN'T THE ONLY SOURCE OF TRUTH FOR WHAT IDS EXIST — but
   every app.js check (v5/v6) treated it as if it were. A real manifest
   had `item-row-template` (the template for ONE row) but no id at all
   for the container that holds every row — the Architect's ids prompt
   only really thinks in individual controls, not wrappers. The HTML
   Coder reasonably added `id="item-list-container"` anyway. But because
   it was never in the manifest, v6's getElementById check WRONGLY
   flagged that real, correct id as fake — while the model's genuinely
   wrong guesses elsewhere in the same file (`invoice-items-list`,
   `item-list`) had no correct answer in their fuzzy-match candidate pool
   to resolve to, since the one real answer wasn't in it. Neither
   `find_bad_getelementbyid_ids` nor `autofix_getelementbyid_ids` could
   do their job — not because the logic was wrong, but because they were
   validated against an incomplete ground truth. 3 patch attempts across
   2 separate runs never converged, because no attempt was ever told the
   right answer.
   Fix: `merged_app_js_ids()` — once index.html exists, extract every id
   ACTUALLY present in it (`extract_html_ids`) and union it with the
   manifest's ids. This merged list, not the manifest alone, is now what
   every app.js prompt, the DOM-reference skeleton, the bad-id detector,
   and the autofixer are all built against. Also gave `_tokenize_id` light
   plural normalization ('items' -> 'item') so a singular/plural mismatch
   doesn't sink an otherwise-confident fuzzy match. Confirmed against the
   real bug: the false positive on `item-list-container` is gone, and
   `invoice-items-list` now correctly autofixes to the real container
   variable — zero LLM calls, resolved on the very first pass.
   Complementary prevention at the source: the Architect's ids-generation
   prompt now explicitly asks for container/wrapper ids for any
   dynamically-added or repeated content, not just individual controls —
   reducing how often this gap occurs at all, with the merge above as the
   safety net for whenever it still does.

Separately, in the 3/3 run, `app.js` overflowed the Reviewer's context for
a THIRD time (see NUM_CTX below) — heuristic-only, no LLM verdict. DeepEval
(same model, different prompt shape) caught a real bug in that same file
(`addItem` not storing fields `generateInvoicePreview` needed) that the
Reviewer never got the chance to. NUM_CTX raised again, but flagged
explicitly as a diminishing-returns lever now, not a solved problem —
see the comment above NUM_CTX for what to try next if it recurs.

1. LIGHTWEIGHT — the SDLC loop itself is still only langgraph +
   langchain-ollama; everything that runs during generation/review is
   stdlib. DeepEval (section 8b) is the one exception, and it's opt-in by
   installation, not by config: the pipeline runs identically with or
   without it, it only adds LLM-judged scores to the final report if
   present. Nothing during the actual build depends on it.
2. CONTEXT ECONOMY — two separate cuts:
     a) VERTICAL — the Architect is the only agent that ever sees the full
        multi-paragraph requirements.txt. Every other agent gets the
        one-line project brief instead.
     b) HORIZONTAL — the manifest has 3 independent sections
        (layout / ids / functions). Every prompt only receives the
        section(s) that file actually needs (`focused_context`).
   Together these are what let a tiny model (2B-4B class) stay precise —
   see NUM_CTX above for the third piece of context economy: making sure
   the window itself is big enough for what these two cuts still leave in.
3. DISK IS THE SOURCE OF TRUTH — no generated file ever lives only in
   LangGraph state / RAM, AND (new in v3) disk is never overwritten with
   something worse than what was already durable there. The Evaluator's
   review-history (v5) is read straight back out of execution_log.txt for
   the same reason, rather than kept as a second copy in graph state.
4. SELF-HEALING GENERATION — after app.js's chunked implementation pass,
   any function whose `<PLACEHOLDER>` marker is still standing gets one
   immediate, individually targeted retry before the file is ever handed
   to the Reviewer.
5. PATCH, NEVER REWRITE — a revision is scoped to exactly what the
   Reviewer flagged: a single spliced function for app.js when one can be
   identified, minimal SEARCH/REPLACE blocks otherwise, and a full
   single-shot rewrite only as a last resort on the final attempt — which,
   as of v3, can never actually destroy a good file (see fix #2 above).
6. HARNESS OVER MODEL — free, deterministic heuristic checks (brace/paren
   balance, leftover placeholders, duplicate declarations, unknown
   getElementById ids, orphaned CSS classes (v7), missing root tags) run
   before any review LLM call, and confident cases of the getElementById
   check (v6) are auto-repaired outright rather than merely flagged — see
   `autofix_getelementbyid_ids`. Ollama's native `format="json"` mode is
   used for structured calls.
7. OBSERVABILITY — every agent step, self-heal, dedup, patch, and autofix
   attempt is appended to execution_log.txt. A final Evaluator node turns
   that log plus the run's eval_matrix into evaluation.json/.md per run —
   status, attempts, review history, a deterministic custom score, and
   DeepEval scores when available (v6: shown side by side, with a
   disagreement flag, since an LLM judge sharing the generator's model
   isn't independent — see the v6 changelog).
8. TRACK ACROSS RUNS, NOT JUST WITHIN ONE (v6) — `evaluator_agent` also
   appends every run's LLM config + scores to `benchmark_history.jsonl`,
   next to the script, and regenerates a self-contained trend chart
   (`benchmark_history.html`) from it — so a harness or model change's
   effect on quality is visible over many runs, not just guessed at from
   the last one.
9. LATER FILES SEE EARLIER FILES, FOR REAL (v7) — the manifest is a plan,
   not the ground truth for what index.html actually contains once it
   exists. style.css is now given the real generated HTML verbatim rather
   than styling from the abstract layout notes alone, and app.js's id
   pool is the manifest MERGED with every id actually found in the real
   HTML (`merged_app_js_ids`) — a Coder reasonably adding a structural id
   the Architect never planned for shouldn't make every later check treat
   it as fake.

v8 changelog — apps that "passed" but were dead in the browser
--------------------------------------------------------------------------
A cross-project review of several finished apps (a Pomodoro/task tracker
among them — see this run's own execution_log.txt) turned up a class of
bug that v1-v7's file-by-file, syntax-level checks structurally could not
see: every individual function looked fine in isolation, but the FILE AS
A WHOLE never actually worked, because the Coder never connects the
pieces together. Concretely, in the Pomodoro run: no button anywhere had
an `addEventListener` (the "Start/Pause" button did nothing), `tasks` and
`intervalId` were each declared with `let` INSIDE one function only and
then read/written from sibling functions as if they were shared globals,
`renderTasks()`'s task-list template lookup called `.content.cloneNode()`
on a plain `<li>` (only a real `<template>` has `.content`), `loadState`
persisted tasks as an array of strings while every other task function
assumed an array of `{id, description, completed}` objects, and
`deleteTask()` ended with a call to `renderTaskList(...)` — a function
that was never defined anywhere (the real one is `renderTasks`). None of
this is a syntax error; `node --check` and the old heuristics saw nothing
wrong, and the Reviewer's context window overflowed and got skipped, so
this shipped as a false "3/3 passed".
1. MANDATORY EVENT WIRING, SYNTHESIZED, NOT PROMPTED — `build_js_skeleton`
   now deterministically writes a `setupEventListeners()` function that
   attaches a real `addEventListener` for EVERY button/canvas id in the
   manifest, plus a `DOMContentLoaded` entry point that calls
   `loadState()` (if that function exists) and `setupEventListeners()` —
   zero LLM calls, so a button can never simply be forgotten again.
   Each attached listener targets a real handler function
   (`compute_event_bindings` / `synthesize_event_handler_functions`,
   wired into `architect_agent`) which is added to the manifest's
   `functions` list like any other function — it goes through the exact
   same chunked-implementation / self-heal / dedupe / heuristic-precheck
   pipeline as everything else, so "the Agent fails to bind event
   listeners" is fixed at the harness level, not by asking the model to
   remember to do it. Canvas pointer input is wired through the Pointer
   Events API (`pointerdown`/`pointermove`/`pointerup`), which unifies
   mouse AND touch into one event stream with coordinates already made
   canvas-relative before the handler function ever sees them — this is
   what closes the "event.offsetX/offsetY on a touch object" bug class,
   since the generated handler functions never touch a raw event's
   coordinate properties at all.
2. DANGLING CALLS TO NEVER-DEFINED FUNCTIONS — `find_undefined_function_calls`
   flags a bare `someName(...)` call (i.e. not `.someName(...)`, which
   would be a method call) where `someName` is neither a declared function
   in the file, a DOM reference variable, nor a common JS builtin. This is
   exactly what would have caught `renderTaskList(...)` being called when
   only `renderTasks` was ever defined.
3. DOM PROPERTY / ELEMENT-TYPE MISMATCHES — `find_invalid_dom_property_access`
   cross-checks the manifest's declared element type for each id against
   how its variable is actually used: `.content` on anything that isn't a
   real `<template>`, `.value` on anything that isn't an actual form
   control (input/textarea/select). Both are semantically invalid but
   syntactically perfect JS, so nothing before this could see them.
4. FRAGMENTED STATE, CAUGHT STRUCTURALLY — `find_undeclared_state_variables`
   flags a name that's used with a "shared mutable state" signature
   (`.push(`, `.findIndex(`, `typeof X === 'undefined'`, `X++`, `X ===
   null`, ...) in TWO OR MORE different functions, but is never declared
   with `let`/`const`/`var` anywhere at the top level of the file — the
   `tasks`/`intervalId` bug above, generalized.
5. LOCALSTORAGE SHAPE CONSISTENCY — `find_localstorage_schema_conflicts`
   flags a file that mixes array-style operations (`.push`/`.forEach`/
   `.map`) with dictionary-style bracket-key operations
   (`obj[dynamicKey] =`, `Object.keys(...)`) on data going through
   `localStorage` — the array-of-strings-vs-array-of-objects split seen
   in the real run.
6. DEAD-END PLACEHOLDER LOGIC — `find_placeholder_logic_functions` flags a
   manifest function that IS present (so it already passed every earlier
   check) but ignores every parameter it declared and just returns one
   hardcoded literal, or contains a loop with a completely empty body —
   "looks finished, does nothing" mock logic that a syntax/structure check
   can never catch on its own.
All six are free, deterministic, zero-LLM checks wired into the existing
`heuristic_precheck` gate (so they block a false PASS the same way the
v4-v7 checks already do) and into `guess_broken_function` (so a genuine
hit still gets a precise single-function patch instead of a blind full
rewrite) — no new code path, no change to the harness's overall shape.
"""

import os
import re
import json
import operator
import subprocess
import tempfile
from pathlib import Path
from datetime import datetime
from typing import TypedDict, Annotated, Optional

from langgraph.graph import StateGraph, END
from langchain_ollama import ChatOllama

# Optional: DeepEval, for the Evaluator stage's LLM-as-judge scores. This is
# a genuinely heavy dependency next to the "keep it lightweight" principle,
# so it's treated the same way Node was for node_syntax_check — a bonus
# check the pipeline works fine without. DEEPEVAL_TELEMETRY_OPT_OUT must be
# set BEFORE the import (it's read at import time) or DeepEval will try to
# phone home, which breaks the "totally offline" requirement.
os.environ.setdefault("DEEPEVAL_TELEMETRY_OPT_OUT", "YES")
try:
    from deepeval.models.base_model import DeepEvalBaseLLM
    from deepeval.metrics import GEval
    from deepeval.test_case import LLMTestCase, LLMTestCaseParams
    DEEPEVAL_AVAILABLE = True
except Exception:
    DEEPEVAL_AVAILABLE = False

# ==========================================
# 1. INITIALIZATION & CONFIGURATION
# ==========================================
# Check `ollama list` for the exact tag you have pulled locally and adjust —
# Gemma's small "effective parameter" variants are usually tagged
# "gemma3n:e2b" / "gemma3n:e4b" rather than "gemma4:e2b"; verify before running.
MODEL_NAME = "gemma4:e2b"          # small/quantized instruction model
OLLAMA_URL = "http://localhost:11434"
MAX_ATTEMPTS = 3                   # coder<->reviewer retries per file
CHUNK_SIZE = 3                     # functions implemented per LLM call

# THIS IS THE FIX FOR THE EMPTY-RESPONSE CASCADE DESCRIBED ABOVE. Ollama's
# default context window is much smaller than a persona + manifest section +
# a ~150-line app.js all embedded in one prompt. Raised twice already and
# STILL not enough: even at 16384, a run's app.js review came back empty
# after a retry a third separate time — and that empty verdict wasn't a
# free pass, it's what let a real data-flow bug (addItem not storing fields
# generateInvoicePreview needed) reach FAIL-free "PASS" with nobody actually
# reviewing the logic. Raised again accordingly, but treat this as a
# diminishing-returns lever, not a guaranteed fix: if it's still overflowing
# at this size, the review PROMPT is probably the thing to shrink next
# (e.g. trimming restated function descriptions the code already reflects),
# not just the ceiling — and separately check `ollama show <model>` for the
# model's actual trained context length, since requesting num_ctx beyond
# that doesn't give it real capacity it was never trained with.
NUM_CTX = 24576
NUM_PREDICT_TEXT = 3000            # code/requirements generation budget
NUM_PREDICT_JSON = 1200            # manifest sections / reviewer verdicts

llm = ChatOllama(
    model=MODEL_NAME,
    base_url=OLLAMA_URL,
    num_predict=NUM_PREDICT_TEXT,
    num_ctx=NUM_CTX,
    temperature=0.1,
)

# A second handle using Ollama's native structured-output mode. Every call
# that expects JSON back (manifest sections, reviewer verdicts) goes through
# this one instead of `llm` — it costs nothing extra and meaningfully cuts
# down on "small model wrapped its JSON in prose" parse failures. Drop the
# `format="json"` kwarg if your installed langchain-ollama predates it.
llm_json = ChatOllama(
    model=MODEL_NAME,
    base_url=OLLAMA_URL,
    num_predict=NUM_PREDICT_JSON,
    num_ctx=NUM_CTX,
    temperature=0.1,
    format="json",
)


def invoke_text(client: ChatOllama, prompt: str, retries: int = 1) -> str:
    """Call an LLM and retry (once, by default) if it comes back genuinely
    empty. Local models occasionally return nothing under context pressure
    or transient load; a bare retry is cheap and often succeeds. Callers
    still need to handle a persistently empty result — this only removes
    the common transient case."""
    content = ""
    for _ in range(retries + 1):
        content = client.invoke(prompt).content
        if content and content.strip():
            return content
    return content


# ==========================================
# 2. STATE DEFINITION
# ==========================================
class AgentState(TypedDict):
    user_input: str
    run_dir: Path
    project_brief: str                                    # short, concise — used by Coder/Reviewer
    requirements: str                                      # full spec — Architect-only
    manifest: dict
    task_stack: list[dict]                                 # Planner's execution queue
    feedback: dict                                         # reviewer -> coder, {} means clean
    attempts: int                                          # attempts on the CURRENT file
    last_revision_mode: str                                # how the current file was (re)built
    validation_errors: Annotated[dict, operator.ior]       # files still failing at max attempts
    eval_matrix: Annotated[dict, operator.ior]             # per-file quality metrics


# ==========================================
# 3. PERSONAS
# ==========================================
SCOPER_PERSONA = (
    "You are a professional project requirement analyst who scopes small "
    "vanilla-JS web apps precisely and concisely."
)
ARCHITECT_PERSONA = (
    "You are a professional software architect who plans small vanilla "
    "HTML/CSS/JS apps and outputs strict, minimal JSON."
)
CODER_PERSONA = (
    "You are a professional front-end engineer who writes clean, stable, "
    "bug-free vanilla HTML/CSS/JS."
)
REVIEWER_PERSONA = (
    "You are a meticulous code reviewer and QA engineer who checks "
    "front-end code against a spec and flags UI/logic/syntax flaws."
)

# Plain (non f-string) template fragments that contain a lot of literal
# `{ }` — kept separate and concatenated in, rather than escaped inline,
# so nothing here has to double up braces to survive an f-string.
IMPL_FORMAT_NOTE = """Format EACH function exactly like this, one block per function:
<IMPL id="functionName">
function functionName(args) {
    // actual logic here
}
</IMPL>"""

PATCH_FORMAT_NOTE = """Output ONLY one or more SEARCH/REPLACE blocks that fix the issue above.
Do NOT rewrite the whole file — only the minimal lines that must change.
Copy the SEARCH text EXACTLY as it appears in CURRENT CODE below (same
whitespace, same characters). Keep each block as short as possible — just
enough lines to uniquely locate the spot. You may repeat the block for
multiple separate fixes.

<<<<<<< SEARCH
<exact lines to find>
=======
<replacement lines>
>>>>>>> REPLACE"""


# ==========================================
# 4. PERSISTENCE & PARSING HELPERS
# ==========================================
def write_log(run_dir: Path, step: str, details: str) -> None:
    """Append-only execution log so a run can be audited after the fact."""
    log_file = run_dir / "execution_log.txt"
    timestamp = datetime.now().strftime("%H:%M:%S")
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"\n[{timestamp}] === {step.upper()} ===\n")
        f.write(str(details) + "\n")
        f.write("-" * 80 + "\n")


def save_artifact(run_dir: Path, filename: str, content: str) -> str:
    """Flush content to disk immediately. Nothing in this workflow is ever
    allowed to exist ONLY in RAM/state — this is called the instant any
    artifact (requirements, manifest, a code file, a self-heal, a patch)
    is produced."""
    (run_dir / filename).write_text(content, encoding="utf-8")
    return content


def load_artifact(run_dir: Path, filename: str) -> str:
    """Read the current durable copy of a file. The Coder and Reviewer both
    use this instead of trusting in-memory state, so a revision is always
    built on top of exactly what's on disk."""
    path = run_dir / filename
    return path.read_text(encoding="utf-8") if path.exists() else ""


def extract_json(text: str) -> dict:
    """Salvage a JSON object from a small model's output. Even with
    format="json" this stays as a defensive fallback (older Ollama/lib
    versions, or a model that still wraps its answer in prose)."""
    clean = re.sub(r"```(?:json)?", "", text, flags=re.IGNORECASE).replace("```", "")
    start, end = clean.find("{"), clean.rfind("}")
    if start == -1 or end == -1:
        return {}
    try:
        return json.loads(clean[start:end + 1], strict=False)
    except Exception as e:
        print(f"   [!] JSON parse error: {e}")
        return {}


def extract_code(response_text: str) -> str:
    """Pull code out of a ``` fence. Falls back gracefully if the model
    truncates output and never closes the fence (common on small models)."""
    if not response_text:
        return ""
    match = re.search(r"```(?:[a-zA-Z]*)\n?(.*?)\n?```", response_text, re.DOTALL)
    if match:
        return match.group(1).strip()
    match = re.search(r"```(?:[a-zA-Z]*)\n?(.*)", response_text, re.DOTALL)
    return match.group(1).strip() if match else response_text.strip()


def focused_context(manifest: dict, keys: list[str]) -> dict:
    """Slice the manifest down to only the section(s) a given file needs.
    This is the core of the horizontal context-economy principle:
    index.html never sees `functions`, app.js never sees `layout`, etc."""
    return {k: manifest.get(k, {}) for k in keys}


# ==========================================
# 5. JS STRUCTURAL HELPERS (deterministic, no LLM)
# ==========================================
def _mask_js_comments(code: str) -> str:
    """Same-length copy of `code` with `//` and `/* */` comment contents
    blanked to spaces (newlines kept, so line numbers still line up).
    Every index still matches the original string 1:1, so callers can
    search this masked copy for real code structure and then slice the
    ORIGINAL `code` using the offsets they find.

    This exists because of a bug observed in practice: a model wrote
        // handleNumberInput(value)
        // function handleNumberInput(value) {
        //     // Implementation goes here
        // }
    instead of a real implementation, and the OLD span-finder (a plain
    regex over the raw string) matched "function handleNumberInput(value) {"
    inside that comment as if it were a genuine declaration — so every
    downstream check (placeholder self-heal, dedupe, the reviewer's
    "is this function real" check) was fooled into thinking the function
    existed. Searching the masked copy instead means a commented-out
    declaration is invisible to all of them.

    Limitation: this is a lightweight masker, not a full JS tokenizer — a
    literal `//` or `/*` inside a string/template literal (e.g. a URL)
    would be mis-masked. That's an accepted trade-off for a dependency-free
    heuristic; `node_syntax_check` below is the authoritative check when
    Node is available and doesn't share this limitation.
    """
    out = list(code)
    i, n = 0, len(code)
    while i < n:
        if code[i] == "/" and i + 1 < n and code[i + 1] == "/":
            while i < n and code[i] != "\n":
                out[i] = " "
                i += 1
        elif code[i] == "/" and i + 1 < n and code[i + 1] == "*":
            out[i] = out[i + 1] = " "
            i += 2
            while i < n and not (code[i] == "*" and i + 1 < n and code[i + 1] == "/"):
                if code[i] != "\n":
                    out[i] = " "
                i += 1
            if i < n:
                out[i] = out[i + 1] = " "
                i += 2
        else:
            i += 1
    return "".join(out)


_GEID_CALL_RE = re.compile(r"""document\.getElementById\(\s*['"]([^'"]+)['"]\s*\)""")


def find_bad_getelementbyid_ids(code: str, valid_ids: set) -> list[str]:
    """Every literal-string `document.getElementById('...')` call, cross-
    checked against the manifest's actual ids.

    This closes a real bug: a generated app.js redeclared a DOM reference
    inside a function using `document.getElementById('invoicePreviewArea')`
    — the camelCase VARIABLE name, not the real id `invoice-preview-area` —
    and several other functions did the same for other elements (one had a
    literal typo, `taxRateInputInput`). Every one of those calls returns
    null, and the next line to touch it throws `TypeError: Cannot read
    properties of null`. Nothing previously checked for this: it's
    syntactically perfect JS, so brace/paren counting and `node --check`
    both see nothing wrong — it's a semantic bug that only makes sense
    once you know which ids are actually real, which is exactly the
    manifest's `ids` section. Searched on the comment-masked copy so an
    example inside a comment doesn't get flagged."""
    found = _GEID_CALL_RE.findall(_mask_js_comments(code))
    return sorted({fid for fid in found if fid not in valid_ids})


def _tokenize_id(id_str: str) -> set:
    """Split an id/identifier into lowercase word tokens, splitting both
    camelCase boundaries and kebab/snake separators — e.g.
    'inputCustomerName' and 'input-customer-name' both -> {'input',
    'customer', 'name'}. This is what lets a wrong id be matched back to
    the real one regardless of which casing convention the model used.
    Also strips a trailing 's' on longer tokens ('items' -> 'item') so a
    singular/plural mismatch ('invoice-items-list' vs the real
    'item-list-container') doesn't sink an otherwise-confident match."""
    spaced = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", id_str)
    tokens = {t.lower() for t in re.split(r"[^a-zA-Z0-9]+", spaced) if t}
    return {t[:-1] if len(t) > 3 and t.endswith("s") and not t.endswith("ss") else t for t in tokens}


def best_id_match(bad_id: str, valid_ids: list, min_overlap: float = 0.5) -> Optional[str]:
    """Best-effort fuzzy match of a wrong id to the closest REAL manifest
    id, by Jaccard token overlap. Every wrong id observed in practice was
    the same words as a real id, just re-cased or reordered
    ('inputCustomerName' vs 'customer-name-input', 'invoiceDateInput' vs
    'invoice-date') rather than a genuinely different id — that's what
    makes this reliable enough to auto-apply rather than just flag.
    Returns None (no fix applied) below the similarity threshold, so a
    genuinely ambiguous case still falls through to the LLM/heuristic
    loop instead of being silently mismatched to the wrong element."""
    bad_tokens = _tokenize_id(bad_id)
    if not bad_tokens:
        return None
    best, best_score = None, 0.0
    for real_id in valid_ids:
        real_tokens = _tokenize_id(real_id)
        if not real_tokens:
            continue
        overlap = len(bad_tokens & real_tokens) / len(bad_tokens | real_tokens)
        if overlap > best_score:
            best, best_score = real_id, overlap
    return best if best_score >= min_overlap else None


def autofix_getelementbyid_ids(code: str, id_var_map: dict) -> tuple[str, list[str]]:
    """Deterministically repair `document.getElementById('wrongId')` calls
    in ONE pass over the whole file, no LLM call: every occurrence whose
    id fuzzy-matches a real one (see `best_id_match`) gets replaced with
    the EXISTING top-level variable for that id — fixing the wrong id and
    removing a redundant DOM query in the same edit.

    This exists because of a failure pattern seen across two separate
    real runs: the same wrong-id bug was repeated across 4-5 different
    functions in one file, but the revision loop only ever targets ONE
    function per attempt (see `guess_broken_function`) — so with a
    3-attempt budget, whack-a-mole patching could never fully clear it;
    every retry's heuristic re-scan found the exact same (or a shuffled)
    list of bad ids, because fixing function A never touched the same bug
    sitting in functions B, C, and D. Fixing every occurrence at once,
    deterministically, sidesteps the retry budget entirely for this bug
    class. Returns (fixed_code, list of human-readable fixes applied —
    for logging; empty list means nothing confident enough to fix)."""
    valid_ids = list(id_var_map.keys())
    masked = _mask_js_comments(code)
    out, fixes, last = [], [], 0
    for m in _GEID_CALL_RE.finditer(masked):
        found_id = m.group(1)
        replacement = None
        if found_id not in id_var_map:
            match = best_id_match(found_id, valid_ids)
            if match:
                replacement = id_var_map[match]
                fixes.append(f"getElementById('{found_id}') -> {replacement}  (matched real id '{match}')")
        out.append(code[last:m.start()])
        out.append(replacement if replacement else code[m.start():m.end()])
        last = m.end()
    out.append(code[last:])
    return "".join(out), fixes


# ------------------------------------------------------------------------
# v8: cross-file wiring / DOM-property / state / storage consistency
# checks — all deterministic, no LLM involved. See the v8 changelog above
# for the concrete real-run bug each one closes.
# ------------------------------------------------------------------------
INTERACTIVE_LISTENER_ELEMENTS = {"button", "canvas"}
_TEMPLATE_LIKE_ELEMENTS = {"template"}
_VALUE_BEARING_ELEMENTS = {"input", "textarea", "select"}


def compute_event_bindings(ids: list[dict]) -> list[dict]:
    """For every button/canvas id in the manifest, decide (in plain
    Python, deterministically) which DOM event(s) it needs and what the
    handler function should be called. Buttons get a single 'click'
    handler. Canvases get the three Pointer Events (`pointerdown` /
    `pointermove` / `pointerup`) — the Pointer Events API is what a
    browser uses to represent BOTH mouse and touch input as one unified
    event stream, which is what makes it possible to hand the handler
    function already-normalized, canvas-relative coordinates regardless
    of whether the input was a mouse or a finger (see `build_js_skeleton`
    for where those coordinates actually get computed).
    Returns one descriptor per id: {"id", "var", "element", "events":
    [(event_name, handler_function_name), ...]}."""
    id_var_map = compute_id_var_map(ids)
    bindings = []
    for item in ids:
        el_id = item.get("id", "")
        el = (item.get("element") or "").lower()
        var = id_var_map.get(el_id)
        if not var or el not in INTERACTIVE_LISTENER_ELEMENTS:
            continue
        if el == "button":
            bindings.append({"id": el_id, "var": var, "element": el,
                              "events": [("click", f"{var}ClickHandler")]})
        else:  # canvas
            bindings.append({"id": el_id, "var": var, "element": el,
                              "events": [("pointerdown", f"{var}PointerDownHandler"),
                                         ("pointermove", f"{var}PointerMoveHandler"),
                                         ("pointerup", f"{var}PointerUpHandler")]})
    return bindings


def synthesize_event_handler_functions(ids: list[dict], existing_functions: list[dict]) -> list[dict]:
    """Turn every binding from `compute_event_bindings` into a real
    manifest function entry (skipping any name the Architect's own
    functions pass already produced). Wiring these into `manifest
    ["functions"]` — instead of inventing a second, parallel "handler"
    concept — means every existing stage (chunked implementation,
    self-heal, dedupe, heuristic_precheck's 'required function' check,
    guess_broken_function's targeting) already knows how to generate,
    validate, and repair them with no further special-casing."""
    existing_names = {f.get("name") for f in existing_functions if f.get("name")}
    purposes = {i.get("id"): i.get("purpose", "") for i in ids}
    synthesized = []
    for b in compute_event_bindings(ids):
        purpose = purposes.get(b["id"], "")
        for event_name, handler_name in b["events"]:
            if handler_name in existing_names:
                continue
            if b["element"] == "canvas":
                desc = (
                    f"Called on pointer '{event_name}' over the '{b['id']}' canvas ({purpose}). "
                    "x and y are ALREADY canvas-relative pixel coordinates, unified for both mouse and "
                    "touch input by the deterministic wiring in setupEventListeners() — do NOT read "
                    "event.offsetX/offsetY or event.touches yourself. Implement the actual drawing/"
                    "interaction logic (e.g. begin/continue/end a stroke), updating whatever shared state "
                    "this app uses to track the current interaction."
                )
                params = ["x", "y", "event"]
            else:
                desc = (
                    f"Handles a click on the '{b['id']}' button ({purpose}). Call whatever business-logic "
                    "function(s) elsewhere in this file actually perform the action, then persist state "
                    "(e.g. call saveState()) if this app defines one."
                )
                params = []
            synthesized.append({"name": handler_name, "params": params, "description": desc})
            existing_names.add(handler_name)
    return synthesized


def find_ids_missing_event_listener(code: str, ids: list[dict]) -> list[str]:
    """Cross-checks every button/canvas id against the actual file: does
    its DOM variable appear as the target of an `addEventListener(` call
    anywhere? This is the safety net behind the deterministic wiring in
    `build_js_skeleton` — it exists so that if a later PATCH revision
    accidentally clobbers `setupEventListeners()`, review catches the
    regression instead of silently shipping an unresponsive control
    again, which is the "Agent fails to ... bind event listeners" failure
    mode this whole v8 batch responds to."""
    id_var_map = compute_id_var_map(ids)
    masked = _mask_js_comments(code)
    missing = []
    for item in ids:
        if (item.get("element") or "").lower() not in INTERACTIVE_LISTENER_ELEMENTS:
            continue
        var = id_var_map.get(item.get("id", ""))
        if var and not re.search(rf"{re.escape(var)}\.addEventListener\(", masked):
            missing.append(item["id"])
    return missing


def find_invalid_dom_property_access(code: str, ids: list[dict]) -> list[str]:
    """Flags two concrete DOM-misuse patterns confirmed in a real run:
      - `.content` accessed on a variable whose manifest element is NOT a
        <template> (e.g. `.content.cloneNode()` on a plain <li> — only a
        real <template> element exposes a `.content` DocumentFragment;
        every other element's `.content` is undefined).
      - `.value` assigned/read on a variable whose manifest element is a
        plain container/text element (div, span, ul, li, p, headings,
        canvas, ...) rather than an actual form control
        (input/textarea/select) — non-form elements have no `.value`.
    Both are syntactically perfect JS, so nothing before this in the
    pipeline could ever have caught them. Searched on the comment-masked
    copy; only flags unambiguous element-type mismatches straight from
    the manifest, never a stylistic guess."""
    id_var_map = compute_id_var_map(ids)
    masked = _mask_js_comments(code)
    issues = []
    for item in ids:
        var = id_var_map.get(item.get("id", ""))
        element = (item.get("element") or "").lower()
        if not var or not element:
            continue
        if element not in _TEMPLATE_LIKE_ELEMENTS and re.search(rf"\b{re.escape(var)}\.content\b", masked):
            issues.append(
                f"'{var}.content' is used, but '{var}' is a <{element}> per the manifest, not a "
                "<template> — only real <template> elements have a `.content` DocumentFragment; this will "
                "be undefined and the next call on it (e.g. .cloneNode) will throw."
            )
        if (element not in _VALUE_BEARING_ELEMENTS and element not in _TEMPLATE_LIKE_ELEMENTS
                and re.search(rf"\b{re.escape(var)}\.value\b", masked)):
            issues.append(
                f"'{var}.value' is used, but '{var}' is a <{element}> per the manifest, which has no "
                "`.value` property — only input/textarea/select elements do. Use `.textContent` or "
                "`.innerHTML` instead."
            )
    return issues


_BARE_CALL_RE = re.compile(r"(?<![.\w$])([A-Za-z_$][\w$]*)\s*\(")
_JS_CONTROL_KEYWORDS = {
    "if", "for", "while", "switch", "catch", "function", "return", "typeof", "new", "in", "of",
    "do", "else", "try", "finally", "void", "delete", "instanceof", "yield", "await", "async",
    "with", "throw", "let", "const", "var",
}
_JS_BUILTIN_CALLS = {
    "parseInt", "parseFloat", "isNaN", "isFinite", "setTimeout", "setInterval", "clearInterval",
    "clearTimeout", "alert", "confirm", "prompt", "Number", "String", "Boolean", "Array", "Object",
    "Date", "Map", "Set", "Symbol", "Promise", "RegExp", "encodeURIComponent", "decodeURIComponent",
    "requestAnimationFrame", "cancelAnimationFrame", "structuredClone", "fetch", "Error", "TypeError",
    "RangeError", "console",
}


def find_declared_js_function_names(code: str) -> set:
    """Every callable actually declared in this file: `function name(...)`
    as well as `const name = (...) => ...` and `const name = function`
    arrow/expression forms. Searched on the comment-masked copy for the
    same reason as everywhere else here — a commented-out declaration
    must never count as real."""
    masked = _mask_js_comments(code)
    names = set(re.findall(r"function\s+([A-Za-z_$][\w$]*)\s*\(", masked))
    names |= set(re.findall(
        r"(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:\([^)]*\)|[A-Za-z_$][\w$]*)\s*=>", masked
    ))
    names |= set(re.findall(r"(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*function\b", masked))
    return names


def find_undefined_function_calls(code: str, ids: list[dict]) -> list[str]:
    """Flags a bare `someName(...)` call — deliberately excluding anything
    preceded by a `.`, which rules out the vast majority of builtin/DOM
    METHOD calls (`.forEach(`, `.push(`, `.addEventListener(`, ...) since
    those are always invoked via dot-notation — where `someName` is
    neither a JS/DOM builtin, a keyword, a DOM reference variable, nor any
    function actually declared in this file.
    This is exactly the bug seen in a real run: `deleteTask()` ended with
    a call to `renderTaskList(updatedTasks)` — a plausible-sounding name
    that was never defined anywhere (the real function is `renderTasks`)
    — a dead-end call that throws `ReferenceError` the moment a user
    deletes a task."""
    masked = _mask_js_comments(code)
    declared = find_declared_js_function_names(code)
    dom_vars = set(compute_id_var_map(ids).values())
    known = declared | dom_vars | _JS_BUILTIN_CALLS | _JS_CONTROL_KEYWORDS
    return sorted({m.group(1) for m in _BARE_CALL_RE.finditer(masked) if m.group(1) not in known})


_TOP_LEVEL_DECL_RE = re.compile(r"^(?:const|let|var)\s+([A-Za-z_$][\w$]*)\b", re.MULTILINE)


def find_undeclared_state_variables(code: str) -> list[str]:
    """Flags a name that's used with a "shared mutable state" signature
    (`.push(`, `.findIndex(`, `.filter(`, `typeof X === 'undefined'`,
    `X === null`/`X !== null`, `X++`/`X--`) inside TWO OR MORE different
    functions, but is never declared with `let`/`const`/`var` anywhere at
    the top level of the file.
    This is exactly the bug seen in a real run: `intervalId` was declared
    with `let intervalId = null;` INSIDE `initializeTimer()` only — a
    local variable that vanishes the moment that function returns — while
    `startTimer()`/`pauseTimer()` both read and reassign a bare
    `intervalId` as if it were shared global state; `tasks` had the same
    problem across `addTask`/`renderTasks`/`toggleTaskCompletion`/
    `deleteTask`. Requiring TWO OR MORE functions to share the same
    "looks global" usage (rather than flagging any local variable that
    happens to match one pattern) is what keeps this from misfiring on an
    ordinary variable that's declared and used correctly within one
    function."""
    masked = _mask_js_comments(code)
    top_level_declared = set(_TOP_LEVEL_DECL_RE.findall(masked))
    param_names = set()
    for m in re.finditer(r"function\s+[A-Za-z_$][\w$]*\s*\(([^)]*)\)", masked):
        param_names |= {p.strip().split("=")[0].strip() for p in m.group(1).split(",") if p.strip()}

    usage_by_name: dict[str, set] = {}
    for fname in find_declared_js_function_names(code):
        span = locate_js_function(code, fname)
        if not span:
            continue
        body = masked[span[0]:span[1]]
        found_here = set()
        for pattern in (
            r"\b([A-Za-z_$][\w$]*)\.push\(",
            r"\b([A-Za-z_$][\w$]*)\.findIndex\(",
            r"\b([A-Za-z_$][\w$]*)\.filter\(\s*[\w$]",
            r"typeof\s+([A-Za-z_$][\w$]*)\s*===?\s*['\"]undefined['\"]",
            r"\b([A-Za-z_$][\w$]*)\s*===?\s*null\b",
            r"\b([A-Za-z_$][\w$]*)\s*!==?\s*null\b",
            r"\b([A-Za-z_$][\w$]*)\+\+",
            r"\b([A-Za-z_$][\w$]*)--",
        ):
            found_here.update(re.findall(pattern, body))
        for name in found_here:
            usage_by_name.setdefault(name, set()).add(fname)

    ignore = {"self", "window", "document", "e", "event", "err", "error"} | _JS_BUILTIN_CALLS
    return sorted(
        name for name, funcs in usage_by_name.items()
        if len(funcs) >= 2 and name not in top_level_declared and name not in param_names and name not in ignore
    )


_LS_KEY_RE = re.compile(r"""localStorage\.(?:setItem|getItem)\(\s*['"]([^'"]+)['"]""")


def find_localstorage_schema_conflicts(code: str) -> list[str]:
    """Flags a file where data going through `localStorage` is treated as
    BOTH an array (`.push(`, `.forEach(`, `.map(`, `.filter(`) AND a
    plain key-value dictionary (`obj[dynamicKey] =`, `Object.keys(...)`,
    `delete obj[...]`) — the exact "alternating between arrays of objects
    and key-value dictionaries" inconsistency seen in a real run, where
    `loadState` treated persisted tasks as a plain array of strings while
    every task-mutating function assumed an array of `{id, description,
    completed}` objects instead.
    Deliberately coarse (a whole-file signal per key, not a precise
    per-read/write pairing) — tuned to catch a real shape split in a
    small, single-purpose app.js, not to be a real JSON-schema checker."""
    masked = _mask_js_comments(code)
    keys = _LS_KEY_RE.findall(masked)
    if not keys:
        return []
    array_signals = re.search(r"\.push\(|\.forEach\(|\.map\(|\.filter\(", masked)
    dict_signals = re.search(r"\[\s*[A-Za-z_$][\w$]*\s*\]\s*=(?!=)|Object\.keys\(|delete\s+[A-Za-z_$][\w$]*\[",
                              masked)
    if array_signals and dict_signals:
        return [
            f"localStorage key '{keys[0]}' (and possibly others) looks like it's read/written inconsistently "
            "— this file has BOTH array-style operations (.push/.forEach/.map/.filter) AND dictionary-style "
            "bracket-key operations on persisted data. Pick ONE shape (an array of objects, e.g. "
            "[{id, ...}], is usually simplest) and use it everywhere this data is read or written."
        ]
    return []


def find_placeholder_logic_functions(code: str, functions: list[dict]) -> list[str]:
    """Flags a manifest function that IS present (real declaration, no
    leftover <PLACEHOLDER> marker — so it already passed every earlier
    check) but is really a dead-end mock: it ignores every parameter it
    declared and just returns one hardcoded literal, or contains a loop
    with a completely empty body. This is the "incomplete business logic"
    failure mode — code that LOOKS finished but does nothing useful, e.g.
    countdown math that always returns the same number regardless of
    input."""
    masked = _mask_js_comments(code)
    flagged = []
    for f in functions:
        name, params = f.get("name"), f.get("params") or []
        if not name or not params:
            continue  # nothing to "ignore" if the function takes no args
        span = locate_js_function(code, name)
        if not span:
            continue
        body = masked[span[0]:span[1]]
        inner = body[body.find("{") + 1: body.rfind("}")].strip()
        single_return = re.fullmatch(
            r"return\s+(?:['\"][^'\"]*['\"]|-?\d+(?:\.\d+)?|true|false|null)\s*;?", inner
        )
        params_used = any(re.search(rf"\b{re.escape(p)}\b", inner) for p in params)
        if single_return and not params_used:
            flagged.append(name)
        elif re.search(r"(?:for|while)\s*\([^)]*\)\s*\{\s*\}", inner):
            flagged.append(name)
    return flagged


def extract_html_ids(html_code: str) -> list:
    """Every id attribute value ACTUALLY present in generated HTML, in
    order of first appearance, deduped. This is the real ground truth for
    'what ids exist in the DOM' — more complete than the manifest's ids
    list, since the Coder can (and reasonably does) add extra structural
    ids the Architect never planned for, e.g. a wrapper around a
    dynamically-populated list. See `merged_app_js_ids` for why this
    matters."""
    seen, ids = set(), []
    for m in re.finditer(r'''\bid\s*=\s*["\']([^"\']+)["\']''', html_code):
        val = m.group(1)
        if val and val not in seen:
            seen.add(val)
            ids.append(val)
    return ids


def merged_app_js_ids(manifest_ids: list, html_code: str) -> list:
    """manifest_ids UNION any extra ids actually present in the generated
    index.html (as synthetic entries).

    This closes a real bug: a manifest declared `item-row-template` (the
    template for ONE row) but no id at all for the container that holds
    every row — the Architect's ids prompt only really thinks in terms of
    individual interactive controls, not wrapper/list elements. The HTML
    Coder reasonably added one anyway (`id="item-list-container"`), but
    because it was never in the manifest, every later app.js check and
    prompt only knew about the manifest's ids — so `item-list-container`
    was WRONGLY flagged as a bad id even though it's real, while the
    genuinely wrong guesses elsewhere in the same file (`invoice-items-
    list`, `item-list`) had nothing correct to fuzzy-match against, since
    the one real answer wasn't in the candidate pool at all. 3 patch
    attempts across 2 different real runs never converged, because no
    single attempt was ever told what the right id actually was.
    Once index.html exists, it's the real ground truth for what ids exist
    in the DOM — every app.js check/prompt from here on is built against
    THIS, not the manifest alone."""
    known = {i.get("id") for i in manifest_ids if i.get("id")}
    extra = [eid for eid in extract_html_ids(html_code) if eid and eid not in known]
    return list(manifest_ids) + [
        {"id": eid, "element": "unknown",
         "purpose": "(structural id present in the generated HTML; not originally in the manifest)"}
        for eid in extra
    ]


def extract_html_classes(html_code: str) -> set:
    """Every class token actually used in the HTML: class="a b c" -> {a,b,c}."""
    classes = set()
    for m in re.finditer(r'''class\s*=\s*["\']([^"\']*)["\']''', html_code):
        classes.update(c for c in m.group(1).split() if c)
    return classes


def extract_css_class_selectors(css_code: str) -> set:
    """Every class name CSS defines at least one rule for. A light regex
    over selectors, not a full CSS parser — enough to catch 'most of the
    stylesheet targets classes the HTML doesn't have', not meant to
    validate combinators or pseudo-classes precisely."""
    masked = re.sub(r"/\*.*?\*/", " ", css_code, flags=re.DOTALL)
    return set(re.findall(r"\.([a-zA-Z_][\w-]*)", masked))


def find_css_html_mismatch(html_code: str, css_code: str, min_orphan_ratio: float = 0.5) -> Optional[str]:
    """Flags when most of the HTML's classes have no matching CSS rule at
    all. This is the check for a failure pattern confirmed in a real run:
    style.css is generated from the abstract 'layout' manifest section
    ALONE — it never sees the actual index.html — so the HTML Coder and
    CSS Coder independently invent their own class vocabulary and
    predictably diverge. In that run, the HTML wrapped everything in
    `id="invoice-app"` while CSS styled a `.invoice-container` CLASS that
    existed nowhere in the page (so the whole grid layout silently never
    applied), and buttons/sections styled as `.btn-add-item`,
    `.invoice-totals-section`, `.items-table`, etc. matched nothing
    either — 10 of 11 classes in the stylesheet were orphaned. That's
    "broken CSS" from the user's report, not a one-off typo.
    Deliberately coarse (a ratio threshold, not per-class) — it's tuned to
    catch a substantially disconnected stylesheet, not flag one stray
    unused class in an otherwise-matching file."""
    html_classes = extract_html_classes(html_code)
    if not html_classes:
        return None
    css_classes = extract_css_class_selectors(css_code)
    orphaned = html_classes - css_classes
    if len(orphaned) / len(html_classes) >= min_orphan_ratio:
        sample = ", ".join(sorted(orphaned)[:6])
        return (f"{len(orphaned)} of {len(html_classes)} classes used in index.html have no matching CSS rule "
                f"(e.g. {sample}) — style.css looks like it was written without seeing the actual HTML markup.")
    return None


def find_all_function_spans(code: str, name: str) -> list[tuple[int, int, bool]]:
    """Find EVERY top-level `function name(...) { ... }` span via brace
    counting (robust to nested braces, unlike a regex) — searched on a
    comment-masked copy so a commented-out declaration can never be
    mistaken for a real one, then sliced out of the ORIGINAL `code`.
    Each span is (start, end, truncated) — truncated=True means it opened
    but the file ran out before the matching '}'."""
    masked = _mask_js_comments(code)
    spans = []
    cursor = 0
    while True:
        m = re.search(rf'function\s+{re.escape(name)}\s*\([^)]*\)\s*\{{', masked[cursor:])
        if not m:
            break
        abs_start = cursor + m.start()
        open_pos = cursor + m.end() - 1
        depth, end, truncated = 0, None, True
        for j in range(open_pos, len(masked)):
            if masked[j] == "{":
                depth += 1
            elif masked[j] == "}":
                depth -= 1
                if depth == 0:
                    end, truncated = j + 1, False
                    break
        if end is None:
            end = len(code)
        spans.append((abs_start, end, truncated))
        if end <= abs_start:  # safety valve against a pathological zero-width match
            break
        cursor = end
    return spans


def locate_js_function(code: str, name: str) -> Optional[tuple[int, int, bool]]:
    """The first span for `name`, or None if it isn't declared at all."""
    spans = find_all_function_spans(code, name)
    return spans[0] if spans else None


def splice_js_function(code: str, name: str, new_impl: str) -> str:
    """Replace exactly one function's definition in `code`, leaving every
    other line byte-for-byte untouched. If the function is missing or was
    truncated mid-declaration, this repairs/inserts it in place instead of
    regenerating anything around it."""
    new_impl = new_impl.strip()
    span = locate_js_function(code, name)
    if span is None:
        return code.rstrip() + "\n\n" + new_impl + "\n"
    start, end, _truncated = span
    return code[:start] + new_impl + code[end:]


def placeholder_pattern(name: str) -> re.Pattern:
    return re.compile(rf'//\s*<PLACEHOLDER[^>]*\b{re.escape(name)}\b[^>]*/?>', re.IGNORECASE)


def remaining_placeholders(code: str, functions: list[dict]) -> list[dict]:
    """Which manifest functions still have an unfilled `<PLACEHOLDER>`
    marker in `code`? Used right after chunked generation to self-heal
    before the file ever reaches the Reviewer."""
    return [f for f in functions if placeholder_pattern(f["name"]).search(code)]


def find_duplicate_function_names(code: str) -> list[str]:
    """Which function names are declared more than once? This is exactly
    the corruption pattern observed in practice: a real implementation
    followed by its own leftover empty stub. Searched on the comment-
    masked copy — see `_mask_js_comments` — so a commented-out mention of
    a function name never counts as a second declaration."""
    seen, dupes = set(), []
    for n in re.findall(r"function\s+(\w+)\s*\(", _mask_js_comments(code)):
        if n in seen and n not in dupes:
            dupes.append(n)
        seen.add(n)
    return dupes


def _is_stub_function_body(body: str) -> bool:
    """A function body with no real statement inside it — either the
    classic 'Implementation goes here' placeholder comment, or literally
    nothing once comments are stripped.

    Deliberately NOT a raw length check. That was tried and is what
    produced a real bug: `len(body) < 40` misclassified a genuine,
    correct one-liner (e.g. `{ return 1; }`, 29 chars) as a stub, so on a
    tie the dedup step kept a longer, comment-padded FAKE stub instead of
    the short real implementation — the exact opposite of what dedup is
    for. Checking for actual executable content is length-independent and
    doesn't have that failure mode."""
    inner = body[body.find("{") + 1: body.rfind("}")]
    return "Implementation goes here" in body or _mask_js_comments(inner).strip() == ""


def dedupe_js_functions(code: str) -> tuple[str, list[str]]:
    """Deterministically collapse duplicate `function name(...) {...}`
    blocks down to a single, best copy — no LLM involved. Keeps whichever
    occurrence is a real (non-stub, non-truncated) implementation; on a tie
    keeps the longer one. Run unconditionally after every app.js
    generation/repair step so duplicates essentially never survive to reach
    the Reviewer."""
    removed = []
    for name in find_duplicate_function_names(code):
        spans = find_all_function_spans(code, name)
        if len(spans) <= 1:
            continue

        def score(span):
            s, e, truncated = span
            if truncated:
                return (-1, 0)
            body = code[s:e]
            is_stub = _is_stub_function_body(body)
            return (0 if is_stub else 1, len(body))

        best = max(spans, key=score)
        for span in sorted(spans, key=lambda sp: sp[0], reverse=True):
            if span is best:
                continue
            s, e, _ = span
            code = code[:s] + code[e:]
            removed.append(name)
    return code, removed


def guess_broken_function(code: str, functions: list[dict], ids: Optional[list[dict]] = None) -> Optional[str]:
    """Deterministic triage for "which function should the revision target?"
    — tried BEFORE trusting an LLM-supplied target, in this priority order:
      1. a function that opened but never closed (truncation).
      2. a function whose <PLACEHOLDER> marker is still sitting unfilled.
      3. a function that calls getElementById with an id not in the
         manifest (see find_bad_getelementbyid_ids) — pinpoints exactly
         which function has the bad reference, so the fix is a precise
         single-function patch instead of a generic full-file rewrite.
      4. a function the manifest calls for that isn't declared anywhere.
    Returns None if nothing obviously matches a single function (e.g. the
    issue spans multiple functions, or it's a layout/id mismatch).
    """
    names = [f["name"] for f in functions]
    for name in names:
        span = locate_js_function(code, name)
        if span and span[2]:
            return name
    for name in names:
        if placeholder_pattern(name).search(code):
            return name
    if ids:
        valid_ids = {i.get("id") for i in ids if i.get("id")}
        bad_ids = set(find_bad_getelementbyid_ids(code, valid_ids))
        if bad_ids:
            masked = _mask_js_comments(code)
            for name in names:
                span = locate_js_function(code, name)
                if span:
                    body = masked[span[0]:span[1]]
                    if any(f"'{bid}'" in body or f'"{bid}"' in body for bid in bad_ids):
                        return name
        if find_ids_missing_event_listener(code, ids) and locate_js_function(code, "setupEventListeners"):
            return "setupEventListeners"
        dom_prop_issues = find_invalid_dom_property_access(code, ids)
        if dom_prop_issues:
            # Match the SPECIFIC flagged 'var.content'/'var.value' pair, not
            # just any use of .content/.value anywhere — otherwise a function
            # with an unrelated, perfectly valid `.value` use (e.g. reading
            # a real input) would be targeted instead of the actual offender.
            flagged_patterns = re.findall(r"'([\w$]+\.(?:content|value))'", " ".join(dom_prop_issues))
            masked = _mask_js_comments(code)
            for name in names:
                span = locate_js_function(code, name)
                if span:
                    body = masked[span[0]:span[1]]
                    if any(pat in body for pat in flagged_patterns):
                        return name
    undefined_calls = set(find_undefined_function_calls(code, ids or []))
    if undefined_calls:
        masked = _mask_js_comments(code)
        for name in names:
            span = locate_js_function(code, name)
            if span:
                body = masked[span[0]:span[1]]
                if any(re.search(rf"(?<![.\w$]){re.escape(uc)}\s*\(", body) for uc in undefined_calls):
                    return name
    placeholder_logic = set(find_placeholder_logic_functions(code, functions))
    if placeholder_logic:
        for name in names:
            if name in placeholder_logic:
                return name
    for name in names:
        if locate_js_function(code, name) is None and not re.search(rf'\b{re.escape(name)}\s*\(', code):
            return name
    return None


_RESERVED_JS = {
    "class", "function", "const", "let", "var", "return", "if", "else", "for", "while",
    "new", "delete", "typeof", "instanceof", "in", "of", "default", "case", "switch",
    "break", "continue", "this", "null", "true", "false", "void", "yield", "await",
    "async", "import", "export", "extends", "super", "try", "catch", "finally", "throw",
    "do", "with", "static", "get", "set",
}


def id_to_var_name(id_str: str) -> str:
    """Deterministically turn an HTML id (e.g. 'btn-add', '2nd-total') into
    a valid camelCase JS identifier.

    This is done in plain Python, NEVER left to the LLM, because of a bug
    observed in practice: asked to "declare DOM references using the given
    ids", a small model wrote `const btn-add = document.getElementById(...)`
    — a hard JS syntax error, since '-' is the subtraction operator and
    isn't legal inside an identifier. No amount of prompt wording reliably
    fixes this on a weak model; removing the judgment call entirely does.
    """
    parts = [p for p in re.split(r"[^a-zA-Z0-9]+", id_str.strip()) if p]
    if not parts:
        return "_el"
    first, rest = parts[0], parts[1:]
    name = first[:1].lower() + first[1:] if first[:1].isalpha() else "_" + first
    for p in rest:
        name += p[:1].upper() + p[1:]
    if not name or name[0].isdigit():
        name = "_" + name
    if name in _RESERVED_JS:
        name += "El"
    return name


def compute_id_var_map(ids: list[dict]) -> dict[str, str]:
    """id -> unique JS variable name, for every id in the manifest's `ids`
    section. Shared by the skeleton builder and every prompt that needs to
    tell the model which variable already points at which element."""
    id_var_map: dict[str, str] = {}
    for item in ids:
        el_id = item.get("id", "")
        if not el_id:
            continue
        var = id_to_var_name(el_id)
        base_var, n = var, 1
        while var in id_var_map.values():  # two ids collided to the same name — disambiguate
            n += 1
            var = f"{base_var}{n}"
        id_var_map[el_id] = var
    return id_var_map


def build_js_skeleton(ids: list[dict], functions: list[dict]) -> tuple[str, dict[str, str]]:
    """Build the entire app.js scaffold — DOM references AND function
    placeholders — with ZERO LLM calls. This replaces what used to be an
    LLM-authored "skeleton" step, and closes two failure modes seen in a
    real run:
      1. invalid identifiers from hyphenated ids (see `id_to_var_name`).
      2. a model paraphrasing the required `// <PLACEHOLDER id="name"/>`
         marker into some other comment style, which silently defeats the
         self-heal pass — it has nothing to search for if the exact
         marker was never written. Generating it in code means the exact
         marker is now guaranteed to exist for every manifest function,
         every time.
    Returns (skeleton_code, id_to_varname_map); the map is threaded through
    every later prompt so the model always has the exact, correct variable
    names and never has to invent — or mis-invent — them itself.

    v8 addition: also deterministically writes `setupEventListeners()`
    (wiring a real `addEventListener` to every button/canvas id — see
    `compute_event_bindings`) and a `DOMContentLoaded` entry point that
    calls `loadState()` (when that function exists) and
    `setupEventListeners()`. This is the "Agent fails to generate an
    initialization routine or bind event listeners" failure mode closed
    at the harness level: no model call is needed to remember to do this,
    and it can't be silently skipped."""
    id_var_map = compute_id_var_map(ids)
    lines = ["// DOM references (deterministically generated from the manifest's `ids`)"]
    for el_id, var in id_var_map.items():
        lines.append(f"const {var} = document.getElementById('{el_id}');")
    lines.append("")
    lines.append("// Function implementations (filled in below)")
    known_function_names = set()
    for f in functions:
        name = f.get("name")
        if name:
            lines.append(f'// <PLACEHOLDER id="{name}"/>')
            known_function_names.add(name)

    bindings = compute_event_bindings(ids)
    lines.append("")
    lines.append("// Event wiring (deterministically generated — do not remove)")
    lines.append("function setupEventListeners() {")
    for b in bindings:
        var = b["var"]
        if b["element"] == "canvas":
            lines.append(f"    {var}.style.touchAction = 'none';")
        for event_name, handler_name in b["events"]:
            if handler_name not in known_function_names:
                continue  # architect_agent always adds these; skip defensively if it somehow didn't
            if b["element"] == "canvas":
                # Pointer Events already unify mouse + touch; converting to
                # canvas-relative coordinates HERE (not inside the handler)
                # is what keeps the handler function from ever needing to
                # touch event.offsetX/offsetY/touches itself.
                lines.append(f"    {var}.addEventListener('{event_name}', (e) => {{")
                lines.append(f"        const rect = {var}.getBoundingClientRect();")
                lines.append(f"        {handler_name}(e.clientX - rect.left, e.clientY - rect.top, e);")
                lines.append("    });")
            else:
                lines.append(f"    {var}.addEventListener('{event_name}', {handler_name});")
    lines.append("}")
    lines.append("")
    lines.append("// Application entry point (deterministically generated — do not remove)")
    lines.append("document.addEventListener('DOMContentLoaded', () => {")
    if "loadState" in known_function_names:
        lines.append("    loadState();")
    lines.append("    setupEventListeners();")
    lines.append("});")
    return "\n".join(lines) + "\n", id_var_map


# ==========================================
# 6. GENERIC PATCH HELPERS (for html/css and JS issues that aren't one function)
# ==========================================
PATCH_BLOCK_RE = re.compile(
    r"<{3,}\s*SEARCH\s*\r?\n(.*?)\r?\n={3,}\s*\r?\n(.*?)\r?\n>{3,}\s*REPLACE",
    re.DOTALL,
)


def apply_patches(original: str, patch_text: str) -> tuple[str, list[str]]:
    """Apply one or more SEARCH/REPLACE blocks against `original`. Every
    block that matches gets applied; every block that doesn't is reported
    back (truncated) so the caller can decide on a fallback — nothing here
    ever falls back to regenerating the whole file itself.
    """
    blocks = PATCH_BLOCK_RE.findall(patch_text)
    if not blocks:
        return original, ["model returned no SEARCH/REPLACE blocks"]

    code = original
    failures = []
    for search, replace in blocks:
        search, replace = search.strip("\n"), replace.strip("\n")
        if not search:
            continue
        if code.count(search) == 1:
            code = code.replace(search, replace, 1)
            continue
        # Tolerant retry: match ignoring trailing whitespace per line, since
        # small models sometimes drop/add a trailing space that shouldn't
        # matter for locating the block.
        lines = code.split("\n")
        norm_lines = [ln.rstrip() for ln in lines]
        search_lines = [ln.rstrip() for ln in search.split("\n")]
        matches = [
            i for i in range(len(norm_lines) - len(search_lines) + 1)
            if norm_lines[i:i + len(search_lines)] == search_lines
        ]
        if len(matches) == 1:
            i = matches[0]
            lines = lines[:i] + replace.split("\n") + lines[i + len(search_lines):]
            code = "\n".join(lines)
            continue
        failures.append(search[:80].replace("\n", " ⏎ "))
    return code, failures


# ==========================================
# 7. HEURISTICS (free, deterministic pre-checks before spending an LLM call)
# ==========================================
def node_syntax_check(code: str) -> Optional[str]:
    """Best-effort REAL syntax check via `node --check`. Deterministic and
    catches things brace/paren counting structurally cannot — e.g.
    `const btn-add = ...` parses as valid brace/paren-balanced text but is
    a hard syntax error. Silently skipped (returns None) if Node isn't on
    PATH — this tool must keep working with only Ollama + Python
    installed; Node is a bonus check, never a hard requirement."""
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False, encoding="utf-8") as tf:
            tf.write(code)
            tmp_path = tf.name
        result = subprocess.run(["node", "--check", tmp_path], capture_output=True, text=True, timeout=10)
        if result.returncode != 0:
            return f"JavaScript syntax error (node --check): {result.stderr.strip()[:300]}"
    except FileNotFoundError:
        return None  # Node not installed — this check is a bonus, not a requirement
    except Exception:
        return None  # never let a broken bonus check block the pipeline
    finally:
        if tmp_path:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
    return None


def heuristic_precheck(
    filename: str, code: str, functions: Optional[list[dict]] = None, ids: Optional[list[dict]] = None,
    html_code: Optional[str] = None,
) -> Optional[str]:
    """Catch the most common small-model failure modes for free. Returns a
    feedback string if something is obviously wrong, else None.

    `functions` and `ids` (the manifest's sections) are optional so
    existing html/css call sites keep working unchanged, but app.js checks
    are meaningfully stronger when both are supplied — `functions` for the
    "declared but not really implemented" check, `ids` for the
    getElementById cross-check (see find_bad_getelementbyid_ids; pass the
    MERGED list from `merged_app_js_ids`, not the raw manifest, or a real
    structural id the HTML added will be wrongly flagged as fake).
    `html_code` is style.css-specific: the actual generated index.html, so
    the CSS/HTML class mismatch check (see find_css_html_mismatch) has
    something real to compare against — without it that check is skipped."""
    if not code.strip():
        return "File is empty."
    if filename.endswith(".js"):
        if "PLACEHOLDER" in code:
            return "A '<PLACEHOLDER .../>' marker is still present — a function was never implemented."
        dupes = find_duplicate_function_names(code)
        if dupes:
            return f"Duplicate function declaration(s): {', '.join(dupes)} — defined more than once."
        bad_ident = re.search(r"\b(?:const|let|var)\s+[A-Za-z_$][\w$]*-[\w$-]*\s*=", code)
        if bad_ident:
            return (f"Invalid JS identifier '{bad_ident.group(0).strip(' =')}' — hyphens aren't legal in "
                     "variable names (a hyphen is the subtraction operator).")
        if functions:
            missing = [f["name"] for f in functions if f.get("name") and locate_js_function(code, f["name"]) is None]
            if missing:
                return (f"Required function(s) not actually implemented: {', '.join(missing)} — declared in the "
                        "manifest but no real (non-comment) function definition was found for them.")
        if ids:
            valid_ids = {i.get("id") for i in ids if i.get("id")}
            bad_ids = find_bad_getelementbyid_ids(code, valid_ids)
            if bad_ids:
                return (f"getElementById() called with id(s) not found anywhere (manifest or actual HTML): "
                        f"{', '.join(bad_ids)} — this always returns null and the next line to use it will "
                        "throw. Reuse the existing top-level DOM reference variable instead of calling "
                        "getElementById again.")
            unbound = find_ids_missing_event_listener(code, ids)
            if unbound:
                return (f"Interactive element(s) with no addEventListener bound anywhere in this file: "
                        f"{', '.join(unbound)} — these controls will do nothing when clicked/touched. Wire "
                        "each one up inside setupEventListeners().")
            dom_prop_issues = find_invalid_dom_property_access(code, ids)
            if dom_prop_issues:
                return dom_prop_issues[0]
        undefined_calls = find_undefined_function_calls(code, ids or [])
        if undefined_calls:
            return (f"Call(s) to function(s) that are never defined anywhere in this file: "
                    f"{', '.join(undefined_calls)} — this throws ReferenceError the moment that code path "
                    "runs. Either implement the missing function or call the correct existing one.")
        state_issues = find_undeclared_state_variables(code)
        if state_issues:
            return (f"Variable(s) used as shared state across multiple functions but never declared at the "
                    f"top level of the file: {', '.join(state_issues)} — declare them once at the top "
                    "(e.g. `let tasks = [];`) instead of letting each function assume they already exist.")
        storage_issues = find_localstorage_schema_conflicts(code)
        if storage_issues:
            return storage_issues[0]
        if functions:
            placeholder_logic = find_placeholder_logic_functions(code, functions)
            if placeholder_logic:
                return (f"Function(s) look like dead-end placeholder logic — they ignore their parameters "
                        f"and just return a hardcoded value, or contain an empty loop: "
                        f"{', '.join(placeholder_logic)}. Implement the real logic instead.")
    if filename == "style.css" and html_code:
        mismatch = find_css_html_mismatch(html_code, code)
        if mismatch:
            return mismatch
    opens, closes = code.count("{"), code.count("}")
    if opens != closes:
        return f"Unbalanced braces ({opens} '{{' vs {closes} '}}') — file looks truncated."
    if filename.endswith(".js"):
        p_opens, p_closes = code.count("("), code.count(")")
        if p_opens != p_closes:
            return f"Unbalanced parentheses ({p_opens} '(' vs {p_closes} ')') — file looks truncated."
        node_issue = node_syntax_check(code)
        if node_issue:
            return node_issue
    if filename.endswith(".html") and ("<html" not in code.lower() or "</html>" not in code.lower()):
        return "Missing a complete <html>...</html> root — file looks truncated."
    return None


def guard_against_regression(
    run_dir: Path, filename: str, old_code: str, new_code: str, mode: str,
    functions: list[dict], ids: Optional[list[dict]] = None, html_code: Optional[str] = None,
) -> tuple[str, str]:
    """The 'never make it worse' safety net for REVISIONS. Never called on
    a true first-time generation (there's no old_code to protect there).
    Runs the same free heuristic the Reviewer uses on both versions; if the
    new version is empty or introduces a problem the old version didn't
    have, the old version is kept. This is what stops an empty or
    corrupted LLM response from ever overwriting a good file on disk."""
    if filename == "app.js" and new_code.strip():
        new_code, removed = dedupe_js_functions(new_code)
        if removed:
            write_log(run_dir, f"Coder (dedupe) - {filename}",
                      f"Collapsed duplicate definitions: {', '.join(sorted(set(removed)))}")
            mode = f"{mode}+dedupe"
        if ids:
            new_code, id_fixes = autofix_getelementbyid_ids(new_code, compute_id_var_map(ids))
            if id_fixes:
                write_log(run_dir, f"Coder (id autofix) - {filename}", "\n".join(id_fixes))
                mode = f"{mode}+idfix"

    old_issue = heuristic_precheck(filename, old_code, functions, ids, html_code)
    new_issue = heuristic_precheck(filename, new_code, functions, ids, html_code)

    if not new_code.strip() and old_code.strip():
        write_log(run_dir, f"Coder (patch rejected) - {filename}",
                  "Model returned empty output; keeping the previous version untouched.")
        return old_code, f"{mode}_rejected_empty"

    if new_issue and not old_issue:
        write_log(run_dir, f"Coder (patch rejected) - {filename}",
                  f"New version introduced a new problem ('{new_issue}') the previous version "
                  "didn't have; keeping the previous version.")
        return old_code, f"{mode}_rejected_regression"

    return new_code, mode


# ==========================================
# 8. SHARED LLM-CALL BUILDERS
# ==========================================
def implement_single_function(
    brief: str, func_meta: dict, extra_note: str = "", id_var_map: Optional[dict] = None
) -> str:
    """Generate exactly ONE JS function. Used both for self-healing a
    silently-skipped placeholder and for patch-revising a single broken
    function — the output is small on purpose, which is what keeps a weak
    model from truncating it.

    `id_var_map` (id -> variable name, from `compute_id_var_map`) is passed
    through so the model references the SAME deterministic DOM variable
    names the skeleton already declared, instead of guessing its own
    (potentially invalid, e.g. hyphenated) names for them."""
    note = f"\nISSUE TO FIX: {extra_note}" if extra_note else ""
    var_note = (
        f"\nExisting DOM reference variables — use these EXACT names, do not redeclare them: "
        f"{json.dumps(id_var_map, indent=2)}" if id_var_map else ""
    )
    prompt = (
        f"{CODER_PERSONA}\n"
        f"PROJECT: {brief}\n"
        f"Implement exactly this ONE JavaScript function, nothing else:\n"
        f"{json.dumps(func_meta, indent=2)}{note}{var_note}\n\n"
        "RULES:\n"
        "1. Assume the DOM element references at the top of app.js already exist — reuse them, don't redeclare.\n"
        "2. Use template literals (backticks) for any multi-line string.\n"
        "3. Output ONLY the function body, inside a ``` block. No explanation, "
        "no other functions.\n"
    )
    return extract_code(invoke_text(llm, prompt))


def request_patch(filename: str, brief: str, ctx_str: str, issue: str, instruction: str, current_code: str) -> str:
    """Ask for minimal SEARCH/REPLACE blocks instead of a full file rewrite."""
    prompt = (
        f"{CODER_PERSONA}\n"
        f"PROJECT: {brief}\n"
        f"RELEVANT CONTEXT: {ctx_str}\n\n"
        f"ISSUE with `{filename}`: {issue}\n"
        f"FIX INSTRUCTION: {instruction}\n\n"
        f"CURRENT `{filename}`:\n```\n{current_code}\n```\n\n"
        f"{PATCH_FORMAT_NOTE}\n"
    )
    return invoke_text(llm, prompt)


def full_rewrite(filename: str, brief: str, ctx_str: str, issue: str, instruction: str, current_code: str) -> str:
    """Last-resort-only safety net (final attempt of a file). Regenerates
    the whole file in one shot. As of v3 this can no longer destroy a good
    file even if the model returns garbage/empty — guard_against_regression
    rejects a worse result and keeps the previous version on disk."""
    prompt = (
        f"{CODER_PERSONA}\n"
        f"Fix `{filename}` based on reviewer feedback. Keep everything that "
        "already works — only change what the feedback calls out.\n\n"
        f"RELEVANT CONTEXT: {ctx_str}\n"
        f"ISSUE: {issue}\n"
        f"INSTRUCTION: {instruction}\n"
        f"CURRENT CODE:\n```\n{current_code}\n```\n"
        "Output the entire fixed file. Output ONLY code inside a ``` block.\n"
    )
    return extract_code(invoke_text(llm, prompt))


# ==========================================
# 8b. EVALUATION (DeepEval LLM-as-judge scores + a human-readable report)
# ==========================================
# This whole section is best-effort. The pipeline's actual quality gate is
# still the deterministic heuristics + Reviewer loop above — this section
# only adds a SCORE on top of a build that already finished, for humans to
# read. If deepeval isn't installed, every function here degrades to
# "skip the LLM-judge part, still write the readable report" rather than
# breaking the run.
if DEEPEVAL_AVAILABLE:
    class OllamaEvalModel(DeepEvalBaseLLM):
        """Wraps the SAME local Ollama model already used for every other
        agent, so DeepEval's GEval (LLM-as-judge) metrics also run fully
        offline — no OpenAI key, no network call, no second model to pull."""

        def __init__(self, chat_model: ChatOllama, name: str):
            self._chat = chat_model
            self._name = name

        def load_model(self):
            return self._chat

        def generate(self, prompt: str) -> str:
            return invoke_text(self._chat, prompt)

        async def a_generate(self, prompt: str) -> str:
            return self.generate(prompt)

        def get_model_name(self) -> str:
            return self._name


def _build_deepeval_metrics() -> list:
    """Two G-Eval (LLM-as-judge) metrics, scored 0.0-1.0 by the SAME local
    model doing everything else in this pipeline. G-Eval works by asking
    the judge model to reason step-by-step against the given criteria, so
    each metric costs a handful of extra LLM calls — that's inherent to
    the technique, not a bug; it's why this whole stage is optional and
    only runs once at the end, not per revision attempt."""
    judge = OllamaEvalModel(llm, MODEL_NAME)
    return [
        GEval(
            name="Correctness",
            criteria=(
                "The ACTUAL_OUTPUT is a generated code file. Using the requirements and manifest given in "
                "INPUT as ground truth: does every document.getElementById(...) call use an id that is "
                "actually listed under the manifest's ids? Does every required function's logic plausibly "
                "match its described purpose? Flag any obvious runtime bug (null references, wrong variable "
                "or id names, mismatched types)."
            ),
            evaluation_params=[LLMTestCaseParams.INPUT, LLMTestCaseParams.ACTUAL_OUTPUT],
            model=judge,
            threshold=0.6,
        ),
        GEval(
            name="Completeness",
            criteria=(
                "Using the requirements and manifest given in INPUT as the spec, does ACTUAL_OUTPUT actually "
                "implement every required id/function with real logic — not left as a comment, a TODO, or an "
                "empty stub?"
            ),
            evaluation_params=[LLMTestCaseParams.INPUT, LLMTestCaseParams.ACTUAL_OUTPUT],
            model=judge,
            threshold=0.6,
        ),
    ]


def deepeval_score_file(filename: str, code: str, ctx: dict, requirements: str, metrics: list) -> Optional[dict]:
    """Score one finished file with a pre-built list of GEval metrics.
    Returns None outright if deepeval isn't installed. Per-metric failures
    (a bad model response, a version mismatch in the installed deepeval,
    anything) degrade to a None score with the exception text as the
    reason, rather than losing the whole evaluation stage over one metric.

    `metrics` is built ONCE by the caller and reused across all 3 files —
    building fresh GEval objects per file was wasteful: G-Eval generates
    its chain-of-thought rubric via an extra LLM call the first time each
    metric is used, so rebuilding it per file meant ~12 LLM calls for a
    3-file app instead of ~9."""
    if not DEEPEVAL_AVAILABLE or not code.strip():
        return None
    test_case = LLMTestCase(
        input=f"REQUIREMENTS:\n{requirements}\n\nRELEVANT MANIFEST:\n{json.dumps(ctx, indent=2)}",
        actual_output=code,
    )
    results = {}
    for metric in metrics:
        try:
            metric.measure(test_case)
            score = round(metric.score, 2) if metric.score is not None else None
            results[metric.name] = {"score": score, "reason": metric.reason}
        except Exception as e:
            results[metric.name] = {"score": None, "reason": f"DeepEval metric failed: {e}"}
    return results


def compute_custom_score(entry: dict) -> Optional[float]:
    """A deterministic, non-LLM quality score (0.0-1.0), as a trustworthy
    counterweight to DeepEval's LLM-as-judge score.

    Why this exists: in two real runs, app.js FAILED review after 3
    attempts for a reproducible, confirmed bug (getElementById calls that
    always return null) — and DeepEval's GEval scored that same file
    1.0/1.0 on BOTH Correctness and Completeness, in both runs. The judge
    is the SAME small local model that made the mistake in the first
    place, so it shares the model's blind spots rather than catching them
    — a known weakness of same-model-as-judge setups, not a DeepEval bug.
    This score only counts what the harness itself actually verified:
      - 0.0 if the file never passed review (status != PASS) — no matter
        what any LLM judge said about it.
      - 1.0 if it passed on the very first attempt.
      - Proportionally less for each extra attempt it needed, down to a
        floor of 0.25 at MAX_ATTEMPTS, since it still shipped a working
        file — it just took the harness longer to get there.
    When this and the DeepEval score disagree, trust this one — it's
    grounded in an actual passing check, not a separate opinion from a
    model with the same weaknesses as the one being graded."""
    if entry.get("status") != "PASS":
        return 0.0
    attempts = entry.get("attempts", 1)
    return round(max(0.25, 1.0 - 0.25 * (attempts - 1)), 2)


def extract_review_history(run_dir: Path, filename: str) -> list[str]:
    """Pull every Reviewer verdict recorded for this file out of the
    durable execution log, in order — reusing the log as the source of
    truth (same principle as disk-is-the-source-of-truth for code) instead
    of threading a parallel history structure through graph state. Lets
    the human-readable report show the FAIL -> FAIL -> PASS story for a
    file, not just its final status."""
    log_path = run_dir / "execution_log.txt"
    if not log_path.exists():
        return []
    text = log_path.read_text(encoding="utf-8")
    pattern = re.compile(
        rf"=== REVIEWER[^=\n]*-\s*{re.escape(filename.upper())}\s*===\n(.*?)\n-{{10,}}", re.DOTALL
    )
    return [m.strip() for m in pattern.findall(text)]


def render_evaluation_markdown(overall: dict, report: dict) -> str:
    """The human-readable counterpart to evaluation.json. A raw JSON dump
    of attempts/status/chars is fine for tooling but tells a person little
    about WHAT went wrong along the way or WHY a score landed where it
    did — this renders the same data as a report a person can actually
    read in one pass."""
    lines = ["# Evaluation Report", "", f"**Files passed:** {overall['files_passed']}"]
    lines.append(f"**Average custom (harness-verified) score:** {overall['custom_score_avg']} / 1.0")
    if "deepeval_avg_score" in overall:
        lines.append(f"**Average DeepEval score:** {overall['deepeval_avg_score']} / 1.0")
    if not overall["deepeval_available"]:
        lines.append("\n_DeepEval isn't installed (`pip install deepeval`) — showing deterministic results only._")
    lines.append("")

    for filename, data in report.items():
        lines.append(f"## {filename}")
        lines.append(
            f"- Status: **{data.get('status', '?')}** "
            f"(attempts: {data.get('attempts', '?')}, {data.get('chars', '?')} chars, "
            f"last action: `{data.get('last_action', '?')}`)"
        )
        lines.append(f"- Custom score (harness-verified): **{data.get('custom_score')}**")
        history = data.get("review_history") or []
        if len(history) > 1:
            lines.append(f"- Review history ({len(history)} pass(es)):")
            for h in history:
                lines.append(f"  - {h}")
        deval = data.get("deepeval")
        if deval:
            lines.append("- DeepEval scores:")
            for name, res in deval.items():
                score_str = res["score"] if res["score"] is not None else "n/a"
                lines.append(f"  - **{name}**: {score_str} — {res['reason']}")
            deval_scores = [m["score"] for m in deval.values() if m.get("score") is not None]
            if deval_scores and data.get("custom_score") is not None:
                deval_avg = sum(deval_scores) / len(deval_scores)
                if abs(deval_avg - data["custom_score"]) >= 0.4:
                    lines.append(
                        f"  - ⚠️ **Disagreement**: DeepEval averages {deval_avg:.2f} but the harness-verified "
                        f"score is {data['custom_score']:.2f} — trust the custom score here (see "
                        "`compute_custom_score`'s docstring for why)."
                    )
        lines.append("")
    return "\n".join(lines)


# ==========================================
# 8c. CROSS-RUN BENCHMARK TRACKING
# ==========================================
# Deliberately separate from evaluation.json/.md above: those live INSIDE
# one run's own SDLC_Workspace/<timestamp>/ folder and describe that run
# only. This lives next to the SCRIPT ITSELF and accumulates across every
# run ever made, so you can tell whether a harness change (or a model
# swap) is actually moving quality over time, not just how one run went.
def benchmark_history_path() -> Path:
    return Path(__file__).resolve().parent / "benchmark_history.jsonl"


def load_benchmark_history() -> list:
    """JSONL — one JSON object per line. A corrupt/partial line (e.g. the
    process was killed mid-write) is skipped rather than failing the
    whole load, since this file is only ever appended to, never rewritten
    wholesale — a bad line can't cascade into losing every prior run."""
    path = benchmark_history_path()
    if not path.exists():
        return []
    records = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            records.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return records


def append_benchmark_record(record: dict) -> list:
    """Append one run's summary and return the full updated history.
    Append-only by design (open in 'a' mode) — never a read-modify-write
    of the whole file just to add one run."""
    with open(benchmark_history_path(), "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")
    return load_benchmark_history()


def render_benchmark_svg(records: list) -> str:
    """Self-contained SVG line chart, two series (DeepEval avg vs. custom
    harness-verified avg) across every tracked run — no charting library,
    no CDN fetch (this has to keep working fully offline), just plain SVG
    text built in Python. X axis = run index, Y axis = score 0-1."""
    W, H, PAD = 640, 260, 42
    n = len(records)
    if n == 0:
        return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="120">'
                f'<text x="20" y="60" font-family="sans-serif" font-size="13">'
                f'No runs tracked yet.</text></svg>')

    def x_for(i):
        return PAD + (i / max(n - 1, 1)) * (W - 2 * PAD)

    def y_for(s):
        return H - PAD - s * (H - 2 * PAD)

    def series_svg(key: str, color: str):
        pts = [(i, r[key]) for i, r in enumerate(records) if r.get(key) is not None]
        if not pts:
            return "", None
        poly = " ".join(f"{x_for(i):.1f},{y_for(s):.1f}" for i, s in pts)
        dots = "".join(
            f'<circle cx="{x_for(i):.1f}" cy="{y_for(s):.1f}" r="3" fill="{color}">'
            f'<title>run {i + 1}: {s:.2f}</title></circle>'
            for i, s in pts
        )
        avg = sum(s for _, s in pts) / len(pts)
        return f'<polyline points="{poly}" fill="none" stroke="{color}" stroke-width="2"/>{dots}', avg

    deepeval_svg, deepeval_avg = series_svg("deepeval_avg_score", "#2563eb")
    custom_svg, custom_avg = series_svg("custom_score_avg", "#16a34a")

    gridlines = "".join(
        f'<line x1="{PAD}" y1="{y_for(g):.1f}" x2="{W - PAD}" y2="{y_for(g):.1f}" stroke="#e5e7eb" stroke-width="1"/>'
        f'<text x="4" y="{y_for(g) + 4:.1f}" font-size="10" fill="#6b7280">{g:.1f}</text>'
        for g in (0.0, 0.25, 0.5, 0.75, 1.0)
    )
    legend = (
        f'<circle cx="{PAD}" cy="16" r="4" fill="#2563eb"/><text x="{PAD + 10}" y="20" font-size="11" fill="#374151">'
        f'DeepEval avg{f" ({deepeval_avg:.2f})" if deepeval_avg is not None else ""}</text>'
        f'<circle cx="{PAD + 160}" cy="16" r="4" fill="#16a34a"/>'
        f'<text x="{PAD + 170}" y="20" font-size="11" fill="#374151">'
        f'Custom avg{f" ({custom_avg:.2f})" if custom_avg is not None else ""}</text>'
    )
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" font-family="sans-serif">
<rect width="{W}" height="{H}" fill="white"/>
{gridlines}
{deepeval_svg}
{custom_svg}
{legend}
<text x="{PAD}" y="{H - 8}" font-size="11" fill="#374151">Run 1</text>
<text x="{W - PAD - 40}" y="{H - 8}" font-size="11" fill="#374151">Run {n}</text>
</svg>'''


def render_benchmark_html(records: list) -> str:
    """Standalone report: the SVG trend chart above plus a table of every
    tracked run's config and scores. One file, no external resources —
    opens directly in any browser, no server, no network."""
    scored_deepeval = [r["deepeval_avg_score"] for r in records if r.get("deepeval_avg_score") is not None]
    scored_custom = [r["custom_score_avg"] for r in records if r.get("custom_score_avg") is not None]
    all_time_deepeval = round(sum(scored_deepeval) / len(scored_deepeval), 2) if scored_deepeval else "n/a"
    all_time_custom = round(sum(scored_custom) / len(scored_custom), 2) if scored_custom else "n/a"

    rows = []
    for i, r in enumerate(records):
        cfg = r.get("llm_config", {})
        rows.append(
            f"<tr><td>{i + 1}</td><td>{r.get('timestamp', '')}</td>"
            f"<td>{cfg.get('model', '')}</td><td>{cfg.get('num_ctx', '')}</td>"
            f"<td>{r.get('app_brief', '')[:60]}</td>"
            f"<td>{r.get('files_passed', '')}</td>"
            f"<td>{r.get('custom_score_avg', 'n/a')}</td>"
            f"<td>{r.get('deepeval_avg_score', 'n/a')}</td></tr>"
        )
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Agentic SDLC — Benchmark History</title>
<style>
body {{ font-family: system-ui, sans-serif; margin: 2rem; color: #111827; max-width: 900px; }}
table {{ border-collapse: collapse; margin-top: 1rem; width: 100%; }}
th, td {{ border: 1px solid #e5e7eb; padding: 6px 10px; text-align: left; font-size: 13px; }}
th {{ background: #f9fafb; }}
</style></head>
<body>
<h1>Benchmark History</h1>
<p>{len(records)} run(s) tracked — all-time avg custom score: <b>{all_time_custom}</b>
&nbsp;|&nbsp; all-time avg DeepEval score: <b>{all_time_deepeval}</b></p>
{render_benchmark_svg(records)}
<table>
<tr><th>#</th><th>Timestamp</th><th>Model</th><th>num_ctx</th><th>App</th>
<th>Files passed</th><th>Custom avg</th><th>DeepEval avg</th></tr>
{"".join(rows)}
</table>
</body></html>"""


# ==========================================
# 9. AGENT NODES
# ==========================================
def requirement_agent(state: AgentState):
    """Agent 1 — Scoper. Turns the one-line ask into a concrete, bulleted
    functional spec, AND keeps the one-line ask itself as the reusable
    `project_brief` every other agent will use instead of the full spec."""
    print("\n📝 [Agent 1: Scoper] Drafting requirements...")
    prompt = f"""
{SCOPER_PERSONA}

Analyze this request: "{state['user_input']}"
First, provide a clear **Project Name** and a brief **Project Description** at the very top of your response. 
Then, Draft a concise, bulleted functional requirements list: what interfaces (UI
elements) it needs, and what functionality/behaviour it must have. Ignore
non-functional fluff (performance, security, deployment). Keep it short and
concrete enough that a small local model can build from it.
"""
    reqs = invoke_text(llm, prompt).strip()
    save_artifact(state["run_dir"], "requirements.txt", reqs)
    write_log(state["run_dir"], "Requirements", reqs)
    if len(reqs) < 40 or reqs.lower().startswith(("please provide", "i am ready", "i need more")):
        # Seen in practice: with a blank/near-blank user_input, the model
        # answered with a meta-response asking FOR the request instead of
        # drafting one, and the pipeline cascaded that straight into an
        # empty manifest and a trivial "passing" app. Surface it here too,
        # not just at the manifest stage, so it's obvious which stage the
        # degenerate input entered at.
        msg = f"Requirements draft looks empty/refusal-shaped ({len(reqs)} chars) — check that the app idea wasn't blank."
        print(f"   ⚠️  {msg}")
        write_log(state["run_dir"], "Requirements (WARNING)", msg)
    # The brief is deliberately NOT another LLM call — the user's original
    # one-line ask already IS the concise project description; reusing it
    # keeps every downstream prompt cheap.
    return {"requirements": reqs, "project_brief": state["user_input"].strip()}


def architect_agent(state: AgentState):
    """Agent 2 — Architect/Planner. Produces the 3-section manifest and
    builds the Coder's task stack (one task per output file). This is the
    ONLY agent that reads the full requirements.txt — everyone downstream
    gets the distilled manifest section(s) instead."""
    print("📐 [Agent 2: Architect] Building manifest & task stack...")
    reqs = state["requirements"]

    # Each section is generated independently, with its own retry budget,
    # so a bad JSON parse in one section never wastes the other two calls.
    layout = {}
    for _ in range(MAX_ATTEMPTS):
        p = (
            f"{ARCHITECT_PERSONA}\nReqs: {reqs}\n"
            'Output JSON for the CSS layout strategy only. Format: '
            '{"layout": {"container": "grid/flex rule", "notes": "short layout notes"}}'
        )
        layout = extract_json(invoke_text(llm_json, p))
        if layout.get("layout"):
            break

    ids = {}
    for _ in range(MAX_ATTEMPTS):
        p = (
            f"{ARCHITECT_PERSONA}\nReqs: {reqs}\n"
            "Output JSON listing every interactive HTML element AND every container/wrapper element that "
            "will hold dynamically added or repeated content (e.g. a list or table body that rows get "
            "appended into) — not just buttons and inputs. If the requirements describe adding/removing "
            "items, include an id for the element they get added to. "
            'Format: {"ids": [{"id": "btn-submit", "element": "button", "purpose": "submits the form"}, '
            '{"id": "item-list", "element": "div", "purpose": "container that item rows are appended into"}]}'
        )
        ids = extract_json(invoke_text(llm_json, p))
        if ids.get("ids"):
            break

    functions = {}
    for _ in range(MAX_ATTEMPTS):
        p = (
            f"{ARCHITECT_PERSONA}\nReqs: {reqs}\n"
            "Output JSON listing every JS function needed. "
            'Format: {"functions": [{"name": "calculateTotal", "params": ["a", "b"], "description": "adds a and b"}]}'
        )
        functions = extract_json(invoke_text(llm_json, p))
        if functions.get("functions"):
            break

    manifest = {
        "layout": layout.get("layout", {}),
        "ids": ids.get("ids", []),
        "functions": functions.get("functions", []),
    }

    # v8: deterministically synthesize a click/pointer handler function
    # for every button/canvas id (see compute_event_bindings) and fold it
    # into the SAME functions list — this guarantees every interactive
    # control ends up wired to a real event listener (build_js_skeleton
    # generates the actual addEventListener calls), without asking the
    # small model to remember to write an init routine itself.
    handler_functions = synthesize_event_handler_functions(manifest["ids"], manifest["functions"])
    if handler_functions:
        manifest["functions"] = manifest["functions"] + handler_functions
        write_log(state["run_dir"], "Architect (event wiring synthesized)",
                  f"Added {len(handler_functions)} deterministic event-handler function(s) to the manifest: "
                  f"{', '.join(f['name'] for f in handler_functions)}")

    save_artifact(state["run_dir"], "manifest.json", json.dumps(manifest, indent=2))
    write_log(state["run_dir"], "Manifest", json.dumps(manifest, indent=2))

    if not manifest["ids"] and not manifest["functions"]:
        # This is exactly what happened in a real run: requirements.txt was
        # itself degenerate (the model asked "please provide the project
        # request" back), the manifest came back empty, and the pipeline
        # went on to build — and PASS — a near-empty app, because an empty
        # spec is trivially satisfied. An empty manifest is never a real
        # PASS-worthy outcome; surface it loudly instead of cascading silently.
        msg = ("Manifest has no ids and no functions after retries — the requirements this was "
               "built from were likely empty or degenerate. The generated app will be trivial.")
        print(f"   ⚠️  {msg}")
        write_log(state["run_dir"], "Architect (WARNING)", msg)

    # Planner's execution queue — one task per file, each declaring exactly
    # which manifest section(s) it's allowed to see, plus a short static
    # purpose note (no extra LLM call needed for this — it's the same for
    # every run) that keeps the Coder/Reviewer prompts focused.
    task_stack = [
        {"file": "index.html", "context_keys": ["layout", "ids"],
         "purpose": "Build the DOM structure using exactly these ids and this layout."},
        {"file": "style.css", "context_keys": ["layout"],
         "purpose": "Style the layout below; must visually support every id's element type."},
        {"file": "app.js", "context_keys": ["ids", "functions"],
         "purpose": "Implement exactly these functions and wire them to exactly these ids."},
    ]

    return {"manifest": manifest, "task_stack": task_stack, "validation_errors": {}, "eval_matrix": {}}


def _generate_app_js(run_dir: Path, brief: str, ctx: dict) -> str:
    """Initial app.js build: DETERMINISTIC skeleton (no LLM call — see
    `build_js_skeleton`), then implement functions in small chunks, then
    self-heal anything the chunk pass silently missed, then dedupe — all
    BEFORE this file is ever handed to the Reviewer.

    v4 change: the skeleton used to be LLM-authored ("declare DOM refs
    using the given ids" + "write exactly `// <PLACEHOLDER .../>`"). In a
    real run the model instead wrote `const btn-add = ...` (invalid JS —
    see `id_to_var_name`) AND paraphrased the placeholder marker into a
    commented-out pseudo-implementation instead of the literal tag —
    which silently defeated the self-heal step below (it searches for the
    exact tag) and left every required function unimplemented while still
    passing review. Removing the LLM from this specific step removes both
    failure modes at the source."""
    funcs = ctx.get("functions", [])
    ids = ctx.get("ids", [])

    print("   ↳ generating skeleton (deterministic — no LLM call)...")
    skeleton, id_var_map = build_js_skeleton(ids, funcs)
    save_artifact(run_dir, "app.js", skeleton)  # persist skeleton before filling it in
    write_log(run_dir, "Coder (deterministic skeleton)",
              f"{skeleton}\n\nid -> variable map: {json.dumps(id_var_map, indent=2)}")

    print("   ↳ implementing functions in chunks...")
    var_map_note = (
        f"\nExisting DOM reference variables — use these EXACT names, do not redeclare them: "
        f"{json.dumps(id_var_map, indent=2)}\n"
    )
    for i in range(0, len(funcs), CHUNK_SIZE):
        chunk = funcs[i:i + CHUNK_SIZE]
        impl_prompt = (
            f"{CODER_PERSONA}\nImplement exactly these functions: {json.dumps(chunk, indent=2)}\n"
            f"{var_map_note}\n"
            "CRITICAL: use template literals (backticks) for any multi-line string, "
            "never double quotes for multi-line strings.\n\n"
            f"{IMPL_FORMAT_NOTE}\n"
        )
        impl_resp = invoke_text(llm, impl_prompt)
        matched_any = False
        for f in chunk:
            name = f["name"]
            pattern = rf'<IMPL\s+id=["\']?{re.escape(name)}["\']?\s*>\s*(.*?)\s*</IMPL>'
            m = re.search(pattern, impl_resp, re.DOTALL | re.IGNORECASE)
            if m:
                matched_any = True
                skeleton = placeholder_pattern(name).sub(
                    lambda _mo: m.group(1).strip().replace("\\", "\\\\"), skeleton
                )
        if not matched_any:
            write_log(run_dir, "Coder (chunk raw — no IMPL match)", impl_resp)
        save_artifact(run_dir, "app.js", skeleton)  # persist after every chunk, not just at the end

    print("   ↳ self-healing any missed functions...")
    for f in remaining_placeholders(skeleton, funcs):
        new_impl = implement_single_function(
            brief, f, "This function was never filled in — implement it now.", id_var_map
        )
        if new_impl.strip():
            skeleton = placeholder_pattern(f["name"]).sub(lambda _mo: new_impl.replace("\\", "\\\\"), skeleton, count=1)
            save_artifact(run_dir, "app.js", skeleton)
            write_log(run_dir, f"Coder (self-heal) - {f['name']}", new_impl)
        else:
            write_log(run_dir, f"Coder (self-heal FAILED) - {f['name']}",
                      "Model returned nothing even for a single function; left as a placeholder for the Reviewer/revision loop to pick up.")

    skeleton, removed = dedupe_js_functions(skeleton)
    if removed:
        write_log(run_dir, "Coder (dedupe)", f"Collapsed duplicate definitions: {', '.join(sorted(set(removed)))}")
        save_artifact(run_dir, "app.js", skeleton)

    print("   ↳ auto-fixing any wrong-id getElementById() calls...")
    skeleton, id_fixes = autofix_getelementbyid_ids(skeleton, id_var_map)
    if id_fixes:
        write_log(run_dir, "Coder (id autofix)", "\n".join(id_fixes))
        save_artifact(run_dir, "app.js", skeleton)

    return skeleton


def coder_agent(state: AgentState):
    """Agent 3 — Coder. Generates (initial) or patches (revision) the
    current file, then immediately persists it to disk. A revision is
    ALWAYS scoped to what the Reviewer flagged, and is ALWAYS run through
    guard_against_regression before it's allowed to touch disk.

    Two cross-file dependencies, both fixes from real runs where the file
    "passed" but the app didn't work:
      - style.css is given the ACTUAL generated index.html, not just the
        abstract layout manifest section — see the v7 changelog for why
        generating it "blind" produced a stylesheet that styled classes
        the HTML didn't have.
      - app.js's id pool is the manifest's ids MERGED with whatever ids
        actually ended up in index.html (`merged_app_js_ids`), not the
        manifest alone — a Coder reasonably adding a structural id (a list
        wrapper) the Architect never planned for shouldn't make every
        later app.js check treat that id as fake."""
    run_dir = state["run_dir"]
    task = state["task_stack"][0]
    filename = task["file"]
    attempts = state["attempts"]
    is_revision = attempts > 0
    is_last_attempt = attempts + 1 >= MAX_ATTEMPTS
    manifest = state["manifest"]
    ctx = focused_context(manifest, task["context_keys"])
    html_code = load_artifact(run_dir, "index.html") if filename in ("style.css", "app.js") else ""
    effective_ids = manifest.get("ids", [])

    if filename == "app.js":
        effective_ids = merged_app_js_ids(manifest.get("ids", []), html_code)
        # Give every app.js prompt the exact, already-correct variable names
        # instead of leaving the model to invent (and potentially mis-invent,
        # e.g. with hyphens, or a structural id it was never told about) its
        # own — see id_to_var_name / compute_id_var_map.
        ctx = dict(ctx)
        ctx["ids"] = effective_ids
        ctx["dom_variable_names"] = compute_id_var_map(effective_ids)
    ctx_str = json.dumps(ctx, indent=2)
    brief = state["project_brief"]

    print(f"\n💻 [Agent 3: Coder] {'Revising' if is_revision else 'Writing'} "
          f"{filename} (attempt {attempts + 1}/{MAX_ATTEMPTS})...")

    if not is_revision:
        if filename == "app.js":
            code = _generate_app_js(run_dir, brief, ctx)
        elif filename == "style.css":
            prompt = (
                f"{CODER_PERSONA}\nWrite `{filename}`.\n"
                f"PROJECT: {brief}\n"
                f"TASK: {task['purpose']}\n"
                f"RELEVANT CONTEXT (layout notes): {ctx_str}\n\n"
                f"THE ACTUAL HTML YOU ARE STYLING — use EXACTLY these classes and ids, do not invent your "
                f"own class names:\n```html\n{html_code}\n```\n\n"
                "RULES:\n"
                "- Every selector you write must target a class or id that actually appears in the HTML above.\n"
                "- Output ONLY raw CSS inside a ``` block.\n"
            )
            code = extract_code(invoke_text(llm, prompt))
        else:
            prompt = (
                f"{CODER_PERSONA}\nWrite `{filename}`.\n"
                f"PROJECT: {brief}\n"
                f"TASK: {task['purpose']}\n"
                f"RELEVANT CONTEXT: {ctx_str}\n\n"
                "RULES:\n"
                "- If HTML: link style.css and app.js, no inline styles or scripts.\n"
                "- Output ONLY raw code inside a ``` block.\n"
            )
            code = extract_code(invoke_text(llm, prompt))
        mode = "initial"

    else:
        current_code = load_artifact(run_dir, filename)
        fb = state["feedback"]  # {"issue": ..., "instruction": ..., "target": ...}
        issue, instruction = fb.get("issue", ""), fb.get("instruction", "")
        target = None

        if filename == "app.js":
            target = fb.get("target") or None
            if target not in [f["name"] for f in manifest.get("functions", [])]:
                target = guess_broken_function(current_code, manifest.get("functions", []), effective_ids)

        if target:
            print(f"   ↳ targeted function patch: {target}()")
            func_meta = next((f for f in manifest["functions"] if f["name"] == target), {"name": target})
            id_var_map = compute_id_var_map(effective_ids)
            new_impl = implement_single_function(brief, func_meta, instruction or issue, id_var_map)
            code = splice_js_function(current_code, target, new_impl) if new_impl.strip() else current_code
            mode = f"function_patch:{target}"
        elif issue or instruction:
            print("   ↳ requesting scoped SEARCH/REPLACE patch...")
            patch_prompt_ctx = ctx_str
            if filename == "style.css":
                patch_prompt_ctx = f"{ctx_str}\n\nTHE ACTUAL HTML BEING STYLED:\n```html\n{html_code}\n```"
            patch_text = request_patch(filename, brief, patch_prompt_ctx, issue, instruction, current_code)
            code, failures = apply_patches(current_code, patch_text)
            if not failures:
                mode = "search_replace"
            elif is_last_attempt:
                print("   ↳ patch failed to apply and this is the final attempt — "
                      "trying a full rewrite (guarded — cannot make things worse).")
                code = full_rewrite(filename, brief, patch_prompt_ctx, issue, instruction, current_code)
                mode = "last_resort_full_rewrite"
            else:
                write_log(run_dir, f"Coder (patch — unmatched blocks) - {filename}", "\n".join(failures))
                code, mode = current_code, "search_replace_partial_noop"
        else:
            # No target AND no actionable issue/instruction text — this is
            # what an empty/degenerate Reviewer response looks like. Rather
            # than send the Coder off to "fix" an unspecified problem (that
            # speculative-edit path is exactly what produced duplicated
            # functions previously), leave the file untouched and let the
            # attempt counter do its job.
            print("   ↳ no actionable feedback from the Reviewer — leaving the file unchanged.")
            write_log(run_dir, f"Coder (no actionable feedback) - {filename}",
                      "Reviewer FAILed the file but gave no issue/instruction/target; skipping this "
                      "revision rather than editing speculatively.")
            code, mode = current_code, "skipped_no_feedback"

        code, mode = guard_against_regression(
            run_dir, filename, current_code, code, mode, manifest.get("functions", []), effective_ids, html_code
        )

    save_artifact(run_dir, filename, code)
    write_log(run_dir, f"Coder ({mode}) - {filename}", code)
    return {"last_revision_mode": mode}


def reviewer_agent(state: AgentState):
    """Agent 4 — Reviewer. Always audits the durable on-disk copy. Runs a
    free heuristic pass first; only calls the LLM if that pass is clean.
    Feedback is structured (issue + instruction + best-guess target) so the
    Coder can patch precisely instead of guessing from one vague sentence.

    If the LLM review comes back empty/unparseable even after a retry (the
    context-overflow symptom this run's bug report showed), that is NOT
    treated as a confident FAIL with blank feedback — it falls back to
    trusting the heuristic pass that already succeeded, rather than
    kicking off a speculative, potentially destructive revision."""
    run_dir = state["run_dir"]
    task = state["task_stack"][0]
    filename = task["file"]
    attempts = state["attempts"]
    code = load_artifact(run_dir, filename)
    functions = state["manifest"].get("functions", [])
    ids = state["manifest"].get("ids", [])
    html_code = load_artifact(run_dir, "index.html") if filename in ("style.css", "app.js") else ""
    if filename == "app.js":
        ids = merged_app_js_ids(ids, html_code)  # see coder_agent's docstring for why

    print(f"🔎 [Agent 4: Reviewer] Auditing {filename}...")

    heuristic_issue = heuristic_precheck(filename, code, functions, ids, html_code)
    if heuristic_issue:
        status = "FAIL"
        target = guess_broken_function(code, functions, ids) if filename == "app.js" else None
        fb = {"issue": heuristic_issue, "instruction": "Fix exactly this, nothing else.", "target": target}
        write_log(run_dir, f"Reviewer (heuristic) - {filename}", f"{heuristic_issue} | target={target}")
    else:
        ctx = focused_context(state["manifest"], task["context_keys"])
        prompt = (
            f"{REVIEWER_PERSONA}\n\n"
            f"Review `{filename}` against the relevant spec below.\n"
            f"PROJECT: {state['project_brief']}\n"
            f"RELEVANT MANIFEST SECTION(S): {json.dumps(ctx, indent=2)}\n\n"
            f"CODE:\n```\n{code}\n```\n\n"
            "Fail it if ANY of these are true:\n"
            "1. It ends abruptly / has unclosed tags or brackets (truncation).\n"
            "2. It drifts from the manifest above (wrong ids, missing/extra functions, wrong layout).\n"
            "3. There's an obvious syntax or logic bug.\n\n"
            "Respond with ONLY this JSON, nothing else:\n"
            '{"status": "PASS", "issue": "", "instruction": "", "target": ""}\n'
            "or\n"
            '{"status": "FAIL", "issue": "<what is wrong>", '
            '"instruction": "<one specific, actionable sentence on what to fix>", '
            '"target": "<function name at fault, or empty if not one specific function>"}\n'
        )
        raw = invoke_text(llm_json, prompt, retries=1)
        if not raw.strip():
            # Even the retry came back empty — almost certainly a
            # context-window overflow on this (possibly large) file rather
            # than a real verdict. Trust the heuristic pass that already
            # succeeded instead of fabricating a FAIL with nothing
            # actionable in it.
            status = "PASS"
            fb = {"issue": "", "instruction": "", "target": None}
            write_log(run_dir, f"Reviewer (LLM empty — trusting heuristic) - {filename}",
                      "No verdict after retry (likely context-window overflow); "
                      "accepted on the strength of the heuristic pass alone.")
        else:
            parsed = extract_json(raw)
            status = str(parsed.get("status", "")).upper()
            if status not in ("PASS", "FAIL"):
                status = "PASS" if "PASS" in raw[:30].upper() else "FAIL"
            fb = {
                "issue": parsed.get("issue", "") or ("" if status == "PASS" else raw.strip()[:200]),
                "instruction": parsed.get("instruction", ""),
                "target": parsed.get("target") or None,
            }
            write_log(run_dir, f"Reviewer (LLM) - {filename}", f"{status}: {fb['issue']} | target={fb['target']}")

    finished = status == "PASS" or (attempts + 1 >= MAX_ATTEMPTS)

    if finished:
        ok = status == "PASS"
        print(f"   {'✅' if ok else '⚠️ '} {filename}: {'PASS' if ok else 'FAIL (max attempts reached)'}")
        eval_entry = {filename: {
            "attempts": attempts + 1,
            "status": status,
            "chars": len(code),
            "last_action": state.get("last_revision_mode", "initial"),
        }}
        errors = {} if ok else {filename: fb["issue"]}
        return {
            "feedback": {},
            "attempts": 0,
            "task_stack": state["task_stack"][1:],   # pop — move to next file
            "validation_errors": errors,
            "eval_matrix": eval_entry,
        }

    print(f"   ❌ Issues found: {fb['issue'][:80]}")
    return {"feedback": fb, "attempts": attempts + 1}


def evaluator_agent(state: AgentState):
    """Agent 5 — Evaluator. Runs once, after the task stack is empty
    (every file has either passed or exhausted its attempts). Writes:
      - evaluation.json / evaluation.md — THIS run's report (unchanged
        purpose from v5, now also carrying the custom score).
      - benchmark_history.jsonl / .html — appends this run's summary +
        the LLM config it ran with to a log that lives next to the
        SCRIPT and accumulates across every run ever made (see section
        8c), so quality can be tracked over time, not just per-run."""
    run_dir = state["run_dir"]
    manifest = state["manifest"]
    print("\n📊 [Agent 5: Evaluator] Scoring the finished app...")

    files = ["index.html", "style.css", "app.js"]
    ctx_by_file = {
        "index.html": focused_context(manifest, ["layout", "ids"]),
        "style.css": focused_context(manifest, ["layout"]),
        "app.js": focused_context(manifest, ["ids", "functions"]),
    }
    # Built once, reused for all 3 files — see deepeval_score_file's
    # docstring for why rebuilding per-file was wasteful.
    deepeval_metrics = _build_deepeval_metrics() if DEEPEVAL_AVAILABLE else []

    report = {}
    for filename in files:
        code = load_artifact(run_dir, filename)
        entry = dict(state["eval_matrix"].get(filename, {}))
        entry["review_history"] = extract_review_history(run_dir, filename)
        entry["custom_score"] = compute_custom_score(entry)
        entry["deepeval"] = deepeval_score_file(filename, code, ctx_by_file[filename], state["requirements"],
                                                 deepeval_metrics)
        report[filename] = entry

    pass_count = sum(1 for f in report.values() if f.get("status") == "PASS")
    custom_scores = [f["custom_score"] for f in report.values() if f.get("custom_score") is not None]
    overall = {
        "files_passed": f"{pass_count}/{len(files)}",
        "deepeval_available": DEEPEVAL_AVAILABLE,
        "custom_score_avg": round(sum(custom_scores) / len(custom_scores), 2) if custom_scores else 0.0,
    }
    deepeval_all_scores = [
        m["score"] for f in report.values() if f.get("deepeval")
        for m in f["deepeval"].values() if m and m.get("score") is not None
    ]
    if deepeval_all_scores:
        overall["deepeval_avg_score"] = round(sum(deepeval_all_scores) / len(deepeval_all_scores), 2)

    save_artifact(run_dir, "evaluation.json", json.dumps({"overall": overall, "files": report}, indent=2))
    save_artifact(run_dir, "evaluation.md", render_evaluation_markdown(overall, report))
    write_log(run_dir, "Evaluator", json.dumps(overall, indent=2))

    # --- cross-run benchmark tracking (section 8c) ---
    benchmark_record = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "run_dir": str(run_dir),
        "app_brief": state.get("project_brief", "")[:200],
        "llm_config": {
            "model": MODEL_NAME,
            "num_ctx": NUM_CTX,
            "num_predict_text": NUM_PREDICT_TEXT,
            "num_predict_json": NUM_PREDICT_JSON,
            "max_attempts": MAX_ATTEMPTS,
            "chunk_size": CHUNK_SIZE,
        },
        "files_passed": overall["files_passed"],
        "custom_score_avg": overall["custom_score_avg"],
        "deepeval_available": DEEPEVAL_AVAILABLE,
        "deepeval_avg_score": overall.get("deepeval_avg_score"),
        "per_file": {fn: {"status": d.get("status"), "attempts": d.get("attempts")} for fn, d in report.items()},
    }
    history = append_benchmark_record(benchmark_record)
    # benchmark_history.html lives next to the SCRIPT, not in run_dir, so
    # this writes directly rather than through save_artifact (which always
    # targets run_dir).
    (benchmark_history_path().parent / "benchmark_history.html").write_text(
        render_benchmark_html(history), encoding="utf-8"
    )

    score_note = (f" | avg DeepEval score: {overall['deepeval_avg_score']}/1.0" if "deepeval_avg_score" in overall
                  else " | DeepEval not installed — deterministic results only")
    print(f"   Files passed: {overall['files_passed']} | custom score: {overall['custom_score_avg']}/1.0{score_note}")
    print(f"   📈 Benchmark: {len(history)} run(s) tracked — see {benchmark_history_path().name} / "
          f"benchmark_history.html")
    return {}


# ==========================================
# 10. ORCHESTRATION & GRAPH ROUTING
# ==========================================
def route_review(state: AgentState):
    if not state["feedback"]:
        return "coder" if state["task_stack"] else "end"
    return "coder"


workflow = StateGraph(AgentState)
workflow.add_node("scoper", requirement_agent)
workflow.add_node("architect", architect_agent)
workflow.add_node("coder", coder_agent)
workflow.add_node("reviewer", reviewer_agent)
workflow.add_node("evaluator", evaluator_agent)

workflow.set_entry_point("scoper")
workflow.add_edge("scoper", "architect")
workflow.add_edge("architect", "coder")
workflow.add_edge("coder", "reviewer")
workflow.add_conditional_edges("reviewer", route_review, {"coder": "coder", "end": "evaluator"})
workflow.add_edge("evaluator", END)

app = workflow.compile()


# ==========================================
# 11. EXECUTION BOOTSTRAP
# ==========================================
if __name__ == "__main__":
    print("=" * 70)
    print("  Offline Agentic SDLC — Vanilla Web App Generator (Ollama)")
    print("=" * 70)
    user_input = input("\nWhat web application do you want to build?\n> ").strip()
    while not user_input:
        # A blank submission here is what produced a run with an empty
        # manifest and a trivial-but-"passing" app in practice — refuse to
        # proceed instead of letting it cascade silently downstream.
        print("Please describe the app you want to build — it can't be empty.")
        user_input = input("> ").strip()

    run_dir = Path.cwd() / "SDLC_Workspace" / datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir.mkdir(parents=True, exist_ok=True)
    print(f"\n🚀 Workspace: {run_dir}")

    final_state = app.invoke({
        "user_input": user_input,
        "run_dir": run_dir,
        "attempts": 0,
        "feedback": {},
        "last_revision_mode": "initial",
        "validation_errors": {},
        "eval_matrix": {},
    })

    eval_matrix = final_state.get("eval_matrix", {})
    errors = final_state.get("validation_errors", {})
    # evaluation.json / evaluation.md are written by evaluator_agent itself,
    # as the last node in the graph — nothing left to do here but report
    # where they ended up.

    print("\n" + "=" * 70)
    if errors:
        print(f"⚠️  Done — {len(errors)} file(s) still failing after {MAX_ATTEMPTS} attempts:")
        for f, msg in errors.items():
            print(f"   - {f}: {msg[:100]}")
    else:
        print("🎉 All files passed review.")
    print(f"📁 Output dir:     {run_dir}")
    print(f"📊 Evaluation:     {run_dir / 'evaluation.md'}  (human-readable)")
    print(f"                   {run_dir / 'evaluation.json'}  (raw, for tooling)")
    print(f"📈 Benchmark:      {benchmark_history_path().parent / 'benchmark_history.html'}  (trend across all runs)")
    print(f"🧾 Full log:       {run_dir / 'execution_log.txt'}")
    print("=" * 70)
