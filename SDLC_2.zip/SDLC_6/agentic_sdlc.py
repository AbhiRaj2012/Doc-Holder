"""
Offline Agentic SDLC — Vanilla Web App Generator (v2)
=======================================================
Runs entirely against a local Ollama server (no network calls at all).
Builds a 3-file vanilla web app (index.html / style.css / app.js) using
four cooperating agents orchestrated with LangGraph:

    User input
        |
        v
    Agent 1  Scoper      -> writes requirements.txt + a 1-line project brief
        |
        v
    Agent 2  Architect   -> writes manifest.json (layout / ids / functions)
        |                   + builds the Coder's task stack
        v
    Agent 3  Coder    <-------------------+
        |                                 |
        v                                 | FAIL (loop back, same file,
    Agent 4  Reviewer  -------------------+   PATCH — never a full rewrite)
        |
        | PASS -> pop file, next task in stack
        v
    task_stack empty? -> END

Why this is a v2, not just a cleanup
-------------------------------------
The previous run's own artifacts (execution_log.txt / evaluation.json) show
the actual failure mode this rewrite targets:

  1. app.js's skeleton was generated, then all 14 functions were supposed to
     be filled in via chunked `<IMPL>` calls — but EVERY SINGLE placeholder
     was still present afterwards (the reviewer's heuristic pass caught
     "PLACEHOLDER still present" on the very first review). The chunk loop
     had no fallback and no logging of the raw model output when a match
     failed, so the failure was silent and total.
  2. Once that FAILED review kicked off a "revision", the old coder_agent
     asked the model to "output the entire fixed file" for app.js — i.e. a
     ~90-line, 14-function file in one shot. That's exactly the kind of
     output a small local model is bad at: the log shows attempt 2 truncate
     mid-function (`addClient`) and attempt 3 truncate again a few lines
     later (`deleteClient`), ending on the "19 '{' vs 18 '}'" failure that's
     still sitting in evaluation.json. Revision was silently *undoing* the
     one thing (chunking) that made the file tractable for the model in the
     first place.

Both problems are fixed here, and the fix is the same shape as the design
notes: a revision must only touch the part that's broken and leave
everything else byte-for-byte identical — never regenerate a whole file.

1. LIGHTWEIGHT — only langgraph + langchain-ollama. No vector DBs, no
   heavy eval frameworks (see EVALUATION below for why DeepEval etc. is
   deliberately not pulled in). Everything else is stdlib.
2. CONTEXT ECONOMY — two separate cuts, not one:
     a) VERTICAL — the Architect is the only agent that ever sees the full
        multi-paragraph requirements.txt. Every other agent gets the
        one-line project brief instead: enough to stay on-topic, far
        cheaper than re-reading the whole spec on every call.
     b) HORIZONTAL — the manifest has 3 independent sections
        (layout / ids / functions). Every prompt only receives the
        section(s) that file actually needs (`focused_context`), never the
        whole manifest.
   Together these are what let a tiny model (2B-4B class) stay precise
   instead of drowning in irrelevant context.
3. DISK IS THE SOURCE OF TRUTH — no generated file ever lives only in
   LangGraph state / RAM. The instant the Coder (or a self-heal / patch
   step) produces new bytes, they're flushed to disk; the Reviewer always
   re-reads the durable copy; a revision always re-reads and patches the
   durable copy. A crash mid-run never loses work, and graph state stays
   tiny (paths + short metadata, not multi-KB code blobs).
4. SELF-HEALING GENERATION — after app.js's chunked implementation pass,
   any function whose `<PLACEHOLDER>` marker is still standing (i.e. the
   IMPL-tag extraction silently missed it) gets one immediate, individually
   targeted retry before the file is ever handed to the Reviewer. This is
   what turns last run's "all 14 placeholders survived, unnoticed" into a
   self-correcting step instead of a wasted review cycle.
5. PATCH, NEVER REWRITE — a revision is scoped to exactly what the
   Reviewer flagged:
     - app.js: the broken/missing function is located deterministically
       (brace-counting, not regex-guessing) and only THAT function is
       regenerated and spliced back in.
     - any file: if no single function is identifiable, the Coder is asked
       for minimal SEARCH/REPLACE blocks (copy-exact-then-swap), which are
       applied against the on-disk file in code, not by re-emitting it.
     - a full single-shot rewrite is kept only as a last-resort safety net
       on the FINAL attempt of a file, and is always clearly logged as
       `last_resort_full_rewrite` in evaluation.json rather than being the
       silent default.
6. HARNESS OVER MODEL — free, deterministic heuristic checks (brace
   balance, leftover placeholders, missing root tags) run before any
   review LLM call, and Ollama's native `format="json"` mode is used for
   every structured (manifest / verdict) call so a small model's output is
   at least syntactically valid JSON before we ever try to parse it.
7. OBSERVABILITY — every agent step, every self-heal, and every patch
   attempt (success or failure) is appended to execution_log.txt, and a
   final evaluation.json scores each file (attempts / pass-fail / size /
   which repair strategy actually fixed it) so a run's quality can be
   inspected without re-reading the whole log.
"""

import os
import re
import json
import operator
from pathlib import Path
from datetime import datetime
from typing import TypedDict, Annotated, Optional

from langgraph.graph import StateGraph, END
from langchain_ollama import ChatOllama

# ==========================================
# 1. INITIALIZATION & CONFIGURATION
# ==========================================
# Check `ollama list` for the exact tag you have pulled locally and adjust —
# Gemma's small "effective parameter" variants are usually tagged
# "gemma3n:e2b" / "gemma3n:e4b" rather than "gemma4:e2b"; verify before running.
MODEL_NAME = "gemma4:e2b"          # small/quantized instruction model
OLLAMA_URL = "http://localhost:11434"
MAX_ATTEMPTS = 3                   # coder<->reviewer retries per file
CHUNK_SIZE = 3                     # functions implemented per LLM call

llm = ChatOllama(
    model=MODEL_NAME,
    base_url=OLLAMA_URL,
    num_predict=2000,
    temperature=0.1,
)

# A second handle using Ollama's native structured-output mode. Every call
# that expects JSON back (manifest sections, reviewer verdicts) goes through
# this one instead of `llm` — it costs nothing extra and meaningfully cuts
# down on "small model wrapped its JSON in prose" parse failures. Drop the
# `format="json"` kwarg if your installed langchain-ollama predates it.
llm_json = ChatOllama(
    model=MODEL_NAME,
    base_url=OLLAMA_URL,
    num_predict=1200,
    temperature=0.1,
    format="json",
)


# ==========================================
# 2. STATE DEFINITION
# ==========================================
class AgentState(TypedDict):
    user_input: str
    run_dir: Path
    project_brief: str                                    # short, concise — used by Coder/Reviewer
    requirements: str                                      # full spec — Architect-only
    manifest: dict
    task_stack: list[dict]                                 # Planner's execution queue
    feedback: dict                                         # reviewer -> coder, {} means clean
    attempts: int                                          # attempts on the CURRENT file
    last_revision_mode: str                                # how the current file was (re)built
    validation_errors: Annotated[dict, operator.ior]       # files still failing at max attempts
    eval_matrix: Annotated[dict, operator.ior]             # per-file quality metrics


# ==========================================
# 3. PERSONAS
# ==========================================
SCOPER_PERSONA = (
    "You are a professional project requirement analyst who scopes small "
    "vanilla-JS web apps precisely and concisely."
)
ARCHITECT_PERSONA = (
    "You are a professional software architect who plans small vanilla "
    "HTML/CSS/JS apps and outputs strict, minimal JSON."
)
CODER_PERSONA = (
    "You are a professional front-end engineer who writes clean, stable, "
    "bug-free vanilla HTML/CSS/JS."
)
REVIEWER_PERSONA = (
    "You are a meticulous code reviewer and QA engineer who checks "
    "front-end code against a spec and flags UI/logic/syntax flaws."
)

# Plain (non f-string) template fragments that contain a lot of literal
# `{ }` — kept separate and concatenated in, rather than escaped inline,
# so nothing here has to double up braces to survive an f-string.
IMPL_FORMAT_NOTE = """Format EACH function exactly like this, one block per function:
<IMPL id="functionName">
function functionName(args) {
    // actual logic here
}
</IMPL>"""

PATCH_FORMAT_NOTE = """Output ONLY one or more SEARCH/REPLACE blocks that fix the issue above.
Do NOT rewrite the whole file — only the minimal lines that must change.
Copy the SEARCH text EXACTLY as it appears in CURRENT CODE below (same
whitespace, same characters). Keep each block as short as possible — just
enough lines to uniquely locate the spot. You may repeat the block for
multiple separate fixes.

<<<<<<< SEARCH
<exact lines to find>
=======
<replacement lines>
>>>>>>> REPLACE"""


# ==========================================
# 4. PERSISTENCE & PARSING HELPERS
# ==========================================
def write_log(run_dir: Path, step: str, details: str) -> None:
    """Append-only execution log so a run can be audited after the fact."""
    log_file = run_dir / "execution_log.txt"
    timestamp = datetime.now().strftime("%H:%M:%S")
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"\n[{timestamp}] === {step.upper()} ===\n")
        f.write(str(details) + "\n")
        f.write("-" * 80 + "\n")


def save_artifact(run_dir: Path, filename: str, content: str) -> str:
    """Flush content to disk immediately. Nothing in this workflow is ever
    allowed to exist ONLY in RAM/state — this is called the instant any
    artifact (requirements, manifest, a code file, a self-heal, a patch)
    is produced."""
    (run_dir / filename).write_text(content, encoding="utf-8")
    return content


def load_artifact(run_dir: Path, filename: str) -> str:
    """Read the current durable copy of a file. The Coder and Reviewer both
    use this instead of trusting in-memory state, so a revision is always
    built on top of exactly what's on disk."""
    path = run_dir / filename
    return path.read_text(encoding="utf-8") if path.exists() else ""


def extract_json(text: str) -> dict:
    """Salvage a JSON object from a small model's output. Even with
    format="json" this stays as a defensive fallback (older Ollama/lib
    versions, or a model that still wraps its answer in prose)."""
    clean = re.sub(r"```(?:json)?", "", text, flags=re.IGNORECASE).replace("```", "")
    start, end = clean.find("{"), clean.rfind("}")
    if start == -1 or end == -1:
        return {}
    try:
        return json.loads(clean[start:end + 1], strict=False)
    except Exception as e:
        print(f"   [!] JSON parse error: {e}")
        return {}


def extract_code(response_text: str) -> str:
    """Pull code out of a ``` fence. Falls back gracefully if the model
    truncates output and never closes the fence (common on small models)."""
    match = re.search(r"```(?:[a-zA-Z]*)\n?(.*?)\n?```", response_text, re.DOTALL)
    if match:
        return match.group(1).strip()
    match = re.search(r"```(?:[a-zA-Z]*)\n?(.*)", response_text, re.DOTALL)
    return match.group(1).strip() if match else response_text.strip()


def focused_context(manifest: dict, keys: list[str]) -> dict:
    """Slice the manifest down to only the section(s) a given file needs.
    This is the core of the horizontal context-economy principle:
    index.html never sees `functions`, app.js never sees `layout`, etc."""
    return {k: manifest.get(k, {}) for k in keys}


# ==========================================
# 5. JS STRUCTURAL HELPERS (deterministic, no LLM)
# ==========================================
def locate_js_function(code: str, name: str) -> Optional[tuple[int, int, bool]]:
    """Find a top-level `function name(...) { ... }` span via brace
    counting (robust to nested braces, unlike a regex).

    Returns (start, end, truncated):
      - truncated=False -> a clean, fully-closed function; `code[start:end]`
        is the whole definition.
      - truncated=True   -> the function opened but the file ran out before
        the matching '}' — this is exactly last run's failure mode.
    Returns None if `name` isn't declared in `code` at all.
    """
    m = re.search(rf'function\s+{re.escape(name)}\s*\([^)]*\)\s*\{{', code)
    if not m:
        return None
    depth = 0
    for j in range(m.end() - 1, len(code)):
        if code[j] == "{":
            depth += 1
        elif code[j] == "}":
            depth -= 1
            if depth == 0:
                return (m.start(), j + 1, False)
    return (m.start(), len(code), True)


def splice_js_function(code: str, name: str, new_impl: str) -> str:
    """Replace exactly one function's definition in `code`, leaving every
    other line byte-for-byte untouched. If the function is missing or was
    truncated mid-declaration, this repairs/inserts it in place instead of
    regenerating anything around it."""
    new_impl = new_impl.strip()
    span = locate_js_function(code, name)
    if span is None:
        return code.rstrip() + "\n\n" + new_impl + "\n"
    start, end, _truncated = span
    return code[:start] + new_impl + code[end:]


def placeholder_pattern(name: str) -> re.Pattern:
    return re.compile(rf'//\s*<PLACEHOLDER[^>]*\b{re.escape(name)}\b[^>]*/?>', re.IGNORECASE)


def remaining_placeholders(code: str, functions: list[dict]) -> list[dict]:
    """Which manifest functions still have an unfilled `<PLACEHOLDER>`
    marker in `code`? Used right after chunked generation to self-heal
    before the file ever reaches the Reviewer."""
    return [f for f in functions if placeholder_pattern(f["name"]).search(code)]


def guess_broken_function(code: str, functions: list[dict]) -> Optional[str]:
    """Deterministic triage for "which function should the revision target?"
    — tried BEFORE trusting an LLM-supplied target, in this priority order:
      1. a function that opened but never closed (truncation — the most
         urgent and most unambiguous failure).
      2. a function whose <PLACEHOLDER> marker is still sitting unfilled.
      3. a function the manifest calls for that isn't declared anywhere.
    Returns None if nothing obviously matches (e.g. the bug spans multiple
    functions, or it's a layout/id mismatch rather than a single function).
    """
    names = [f["name"] for f in functions]
    for name in names:
        span = locate_js_function(code, name)
        if span and span[2]:
            return name
    for name in names:
        if placeholder_pattern(name).search(code):
            return name
    for name in names:
        if locate_js_function(code, name) is None and not re.search(rf'\b{re.escape(name)}\s*\(', code):
            return name
    return None


# ==========================================
# 6. GENERIC PATCH HELPERS (for html/css and JS issues that aren't one function)
# ==========================================
PATCH_BLOCK_RE = re.compile(
    r"<{3,}\s*SEARCH\s*\r?\n(.*?)\r?\n={3,}\s*\r?\n(.*?)\r?\n>{3,}\s*REPLACE",
    re.DOTALL,
)


def apply_patches(original: str, patch_text: str) -> tuple[str, list[str]]:
    """Apply one or more SEARCH/REPLACE blocks against `original`. Every
    block that matches gets applied; every block that doesn't is reported
    back (truncated) so the caller can decide on a fallback — nothing here
    ever falls back to regenerating the whole file itself.
    """
    blocks = PATCH_BLOCK_RE.findall(patch_text)
    if not blocks:
        return original, ["model returned no SEARCH/REPLACE blocks"]

    code = original
    failures = []
    for search, replace in blocks:
        search, replace = search.strip("\n"), replace.strip("\n")
        if not search:
            continue
        if code.count(search) == 1:
            code = code.replace(search, replace, 1)
            continue
        # Tolerant retry: match ignoring trailing whitespace per line, since
        # small models sometimes drop/add a trailing space that shouldn't
        # matter for locating the block.
        lines = code.split("\n")
        norm_lines = [ln.rstrip() for ln in lines]
        search_lines = [ln.rstrip() for ln in search.split("\n")]
        matches = [
            i for i in range(len(norm_lines) - len(search_lines) + 1)
            if norm_lines[i:i + len(search_lines)] == search_lines
        ]
        if len(matches) == 1:
            i = matches[0]
            lines = lines[:i] + replace.split("\n") + lines[i + len(search_lines):]
            code = "\n".join(lines)
            continue
        failures.append(search[:80].replace("\n", " ⏎ "))
    return code, failures


# ==========================================
# 7. HEURISTICS (free, deterministic pre-checks before spending an LLM call)
# ==========================================
def heuristic_precheck(filename: str, code: str) -> Optional[str]:
    """Catch the most common small-model failure modes for free. Returns a
    feedback string if something is obviously wrong, else None."""
    if not code.strip():
        return "File is empty."
    if filename.endswith(".js") and "PLACEHOLDER" in code:
        return "A '<PLACEHOLDER .../>' marker is still present — a function was never implemented."
    opens, closes = code.count("{"), code.count("}")
    if opens != closes:
        return f"Unbalanced braces ({opens} '{{' vs {closes} '}}') — file looks truncated."
    if filename.endswith(".js"):
        p_opens, p_closes = code.count("("), code.count(")")
        if p_opens != p_closes:
            return f"Unbalanced parentheses ({p_opens} '(' vs {p_closes} ')') — file looks truncated."
    if filename.endswith(".html") and ("<html" not in code.lower() or "</html>" not in code.lower()):
        return "Missing a complete <html>...</html> root — file looks truncated."
    return None


# ==========================================
# 8. SHARED LLM-CALL BUILDERS
# ==========================================
def implement_single_function(brief: str, func_meta: dict, extra_note: str = "") -> str:
    """Generate exactly ONE JS function. Used both for self-healing a
    silently-skipped placeholder and for patch-revising a single broken
    function — the output is small on purpose, which is what keeps a weak
    model from truncating it."""
    note = f"\nISSUE TO FIX: {extra_note}" if extra_note else ""
    prompt = (
        f"{CODER_PERSONA}\n"
        f"PROJECT: {brief}\n"
        f"Implement exactly this ONE JavaScript function, nothing else:\n"
        f"{json.dumps(func_meta, indent=2)}{note}\n\n"
        "RULES:\n"
        "1. Assume the DOM element references at the top of app.js already exist.\n"
        "2. Use template literals (backticks) for any multi-line string.\n"
        "3. Output ONLY the function body, inside a ``` block. No explanation, "
        "no other functions.\n"
    )
    return extract_code(llm.invoke(prompt).content)


def request_patch(filename: str, brief: str, ctx_str: str, issue: str, instruction: str, current_code: str) -> str:
    """Ask for minimal SEARCH/REPLACE blocks instead of a full file rewrite."""
    prompt = (
        f"{CODER_PERSONA}\n"
        f"PROJECT: {brief}\n"
        f"RELEVANT CONTEXT: {ctx_str}\n\n"
        f"ISSUE with `{filename}`: {issue}\n"
        f"FIX INSTRUCTION: {instruction}\n\n"
        f"CURRENT `{filename}`:\n```\n{current_code}\n```\n\n"
        f"{PATCH_FORMAT_NOTE}\n"
    )
    return llm.invoke(prompt).content


def full_rewrite(filename: str, brief: str, ctx_str: str, issue: str, instruction: str, current_code: str) -> str:
    """Last-resort-only safety net (final attempt of a file). Regenerates
    the whole file in one shot — the exact behaviour that caused last run's
    repeated app.js truncation, so this must stay rare and always logged
    as such, never the default revision path."""
    prompt = (
        f"{CODER_PERSONA}\n"
        f"Fix `{filename}` based on reviewer feedback. Keep everything that "
        "already works — only change what the feedback calls out.\n\n"
        f"RELEVANT CONTEXT: {ctx_str}\n"
        f"ISSUE: {issue}\n"
        f"INSTRUCTION: {instruction}\n"
        f"CURRENT CODE:\n```\n{current_code}\n```\n"
        "Output the entire fixed file. Output ONLY code inside a ``` block.\n"
    )
    return extract_code(llm.invoke(prompt).content)


# ==========================================
# 9. AGENT NODES
# ==========================================
def requirement_agent(state: AgentState):
    """Agent 1 — Scoper. Turns the one-line ask into a concrete, bulleted
    functional spec, AND keeps the one-line ask itself as the reusable
    `project_brief` every other agent will use instead of the full spec."""
    print("\n📝 [Agent 1: Scoper] Drafting requirements...")
    prompt = f"""
{SCOPER_PERSONA}

Analyze this request: "{state['user_input']}"

Draft a concise, bulleted functional requirements list: what interfaces (UI
elements) it needs, and what functionality/behaviour it must have. Ignore
non-functional fluff (performance, security, deployment). Keep it short and
concrete enough that a small local model can build from it.
"""
    reqs = llm.invoke(prompt).content.strip()
    save_artifact(state["run_dir"], "requirements.txt", reqs)
    write_log(state["run_dir"], "Requirements", reqs)
    # The brief is deliberately NOT another LLM call — the user's original
    # one-line ask already IS the concise project description; reusing it
    # keeps every downstream prompt cheap.
    return {"requirements": reqs, "project_brief": state["user_input"].strip()}


def architect_agent(state: AgentState):
    """Agent 2 — Architect/Planner. Produces the 3-section manifest and
    builds the Coder's task stack (one task per output file). This is the
    ONLY agent that reads the full requirements.txt — everyone downstream
    gets the distilled manifest section(s) instead."""
    print("📐 [Agent 2: Architect] Building manifest & task stack...")
    reqs = state["requirements"]

    # Each section is generated independently, with its own retry budget,
    # so a bad JSON parse in one section never wastes the other two calls.
    layout = {}
    for _ in range(MAX_ATTEMPTS):
        p = (
            f"{ARCHITECT_PERSONA}\nReqs: {reqs}\n"
            'Output JSON for the CSS layout strategy only. Format: '
            '{"layout": {"container": "grid/flex rule", "notes": "short layout notes"}}'
        )
        layout = extract_json(llm_json.invoke(p).content)
        if layout.get("layout"):
            break

    ids = {}
    for _ in range(MAX_ATTEMPTS):
        p = (
            f"{ARCHITECT_PERSONA}\nReqs: {reqs}\n"
            "Output JSON listing every interactive HTML element and what it does. "
            'Format: {"ids": [{"id": "btn-submit", "element": "button", "purpose": "submits the form"}]}'
        )
        ids = extract_json(llm_json.invoke(p).content)
        if ids.get("ids"):
            break

    functions = {}
    for _ in range(MAX_ATTEMPTS):
        p = (
            f"{ARCHITECT_PERSONA}\nReqs: {reqs}\n"
            "Output JSON listing every JS function needed. "
            'Format: {"functions": [{"name": "calculateTotal", "params": ["a", "b"], "description": "adds a and b"}]}'
        )
        functions = extract_json(llm_json.invoke(p).content)
        if functions.get("functions"):
            break

    manifest = {
        "layout": layout.get("layout", {}),
        "ids": ids.get("ids", []),
        "functions": functions.get("functions", []),
    }
    save_artifact(state["run_dir"], "manifest.json", json.dumps(manifest, indent=2))
    write_log(state["run_dir"], "Manifest", json.dumps(manifest, indent=2))

    # Planner's execution queue — one task per file, each declaring exactly
    # which manifest section(s) it's allowed to see, plus a short static
    # purpose note (no extra LLM call needed for this — it's the same for
    # every run) that keeps the Coder/Reviewer prompts focused.
    task_stack = [
        {"file": "index.html", "context_keys": ["layout", "ids"],
         "purpose": "Build the DOM structure using exactly these ids and this layout."},
        {"file": "style.css", "context_keys": ["layout"],
         "purpose": "Style the layout below; must visually support every id's element type."},
        {"file": "app.js", "context_keys": ["ids", "functions"],
         "purpose": "Implement exactly these functions and wire them to exactly these ids."},
    ]

    return {"manifest": manifest, "task_stack": task_stack, "validation_errors": {}, "eval_matrix": {}}


def _generate_app_js(run_dir: Path, brief: str, ctx: dict) -> str:
    """Initial app.js build: skeleton first, then implement functions in
    small chunks, then self-heal anything the chunk pass silently missed —
    all BEFORE this file is ever handed to the Reviewer."""
    ctx_str = json.dumps(ctx, indent=2)
    funcs = ctx.get("functions", [])

    print("   ↳ generating skeleton...")
    skel_prompt = (
        f"{CODER_PERSONA}\nWrite a JS skeleton only.\nCONTEXT: {ctx_str}\n"
        "RULES:\n"
        "1. Declare globals and DOM references using the given ids.\n"
        "2. Do NOT write any function bodies.\n"
        '3. For every required function, write exactly this on its own line:\n'
        '   // <PLACEHOLDER id="functionName"/>\n'
        "Output ONLY javascript inside a ``` block.\n"
    )
    skeleton = extract_code(llm.invoke(skel_prompt).content)
    save_artifact(run_dir, "app.js", skeleton)  # persist skeleton before filling it in

    print("   ↳ implementing functions in chunks...")
    for i in range(0, len(funcs), CHUNK_SIZE):
        chunk = funcs[i:i + CHUNK_SIZE]
        impl_prompt = (
            f"{CODER_PERSONA}\nImplement exactly these functions: {json.dumps(chunk, indent=2)}\n\n"
            "CRITICAL: use template literals (backticks) for any multi-line string, "
            "never double quotes for multi-line strings.\n\n"
            f"{IMPL_FORMAT_NOTE}\n"
        )
        impl_resp = llm.invoke(impl_prompt).content
        matched_any = False
        for f in chunk:
            name = f["name"]
            pattern = rf'<IMPL\s+id=["\']?{re.escape(name)}["\']?\s*>\s*(.*?)\s*</IMPL>'
            m = re.search(pattern, impl_resp, re.DOTALL | re.IGNORECASE)
            if m:
                matched_any = True
                skeleton = placeholder_pattern(name).sub(
                    lambda _mo: m.group(1).strip().replace("\\", "\\\\"), skeleton
                )
        if not matched_any:
            # This is exactly the failure last run hit silently 14/14 times —
            # log the raw response so it's actually diagnosable next time.
            write_log(run_dir, "Coder (chunk raw — no IMPL match)", impl_resp)
        save_artifact(run_dir, "app.js", skeleton)  # persist after every chunk, not just at the end

    print("   ↳ self-healing any missed functions...")
    for f in remaining_placeholders(skeleton, funcs):
        new_impl = implement_single_function(brief, f, "This function was never filled in — implement it now.")
        skeleton = placeholder_pattern(f["name"]).sub(lambda _mo: new_impl.replace("\\", "\\\\"), skeleton, count=1)
        save_artifact(run_dir, "app.js", skeleton)  # persist after every self-heal too
        write_log(run_dir, f"Coder (self-heal) - {f['name']}", new_impl)

    return skeleton


def coder_agent(state: AgentState):
    """Agent 3 — Coder. Generates (initial) or patches (revision) the
    current file, then immediately persists it to disk. A revision is
    ALWAYS scoped to what the Reviewer flagged — see module docstring
    point 5 ("PATCH, NEVER REWRITE") for why."""
    run_dir = state["run_dir"]
    task = state["task_stack"][0]
    filename = task["file"]
    attempts = state["attempts"]
    is_revision = attempts > 0
    is_last_attempt = attempts + 1 >= MAX_ATTEMPTS
    manifest = state["manifest"]
    ctx = focused_context(manifest, task["context_keys"])
    ctx_str = json.dumps(ctx, indent=2)
    brief = state["project_brief"]

    print(f"\n💻 [Agent 3: Coder] {'Revising' if is_revision else 'Writing'} "
          f"{filename} (attempt {attempts + 1}/{MAX_ATTEMPTS})...")

    if not is_revision:
        if filename == "app.js":
            code = _generate_app_js(run_dir, brief, ctx)
        else:
            prompt = (
                f"{CODER_PERSONA}\nWrite `{filename}`.\n"
                f"PROJECT: {brief}\n"
                f"TASK: {task['purpose']}\n"
                f"RELEVANT CONTEXT: {ctx_str}\n\n"
                "RULES:\n"
                "- If HTML: link style.css and app.js, no inline styles or scripts.\n"
                "- Output ONLY raw code inside a ``` block.\n"
            )
            code = extract_code(llm.invoke(prompt).content)
        mode = "initial"

    else:
        current_code = load_artifact(run_dir, filename)
        fb = state["feedback"]  # {"issue": ..., "instruction": ..., "target": ...}
        issue, instruction = fb.get("issue", ""), fb.get("instruction", "")
        target = None

        if filename == "app.js":
            target = fb.get("target") or None
            if target not in [f["name"] for f in manifest.get("functions", [])]:
                target = guess_broken_function(current_code, manifest.get("functions", []))

        if target:
            print(f"   ↳ targeted function patch: {target}()")
            func_meta = next((f for f in manifest["functions"] if f["name"] == target), {"name": target})
            new_impl = implement_single_function(brief, func_meta, instruction or issue)
            code = splice_js_function(current_code, target, new_impl)
            mode = f"function_patch:{target}"
        else:
            print("   ↳ requesting scoped SEARCH/REPLACE patch...")
            patch_text = request_patch(filename, brief, ctx_str, issue, instruction, current_code)
            code, failures = apply_patches(current_code, patch_text)
            if not failures:
                mode = "search_replace"
            elif is_last_attempt:
                print("   ↳ patch failed to apply and this is the final attempt — "
                      "falling back to a full rewrite (last resort).")
                code = full_rewrite(filename, brief, ctx_str, issue, instruction, current_code)
                mode = "last_resort_full_rewrite"
            else:
                # Keep whatever DID apply; anything that didn't stays flagged
                # and the Reviewer will catch it again next loop — we never
                # silently discard a partially-successful patch.
                write_log(run_dir, f"Coder (patch — unmatched blocks) - {filename}",
                          "\n".join(failures))
                mode = "search_replace_partial"

    save_artifact(run_dir, filename, code)
    write_log(run_dir, f"Coder ({mode}) - {filename}", code)
    return {"last_revision_mode": mode}


def reviewer_agent(state: AgentState):
    """Agent 4 — Reviewer. Always audits the durable on-disk copy. Runs a
    free heuristic pass first; only calls the LLM if that pass is clean.
    Feedback is structured (issue + instruction + best-guess target) so the
    Coder can patch precisely instead of guessing from one vague sentence."""
    run_dir = state["run_dir"]
    task = state["task_stack"][0]
    filename = task["file"]
    attempts = state["attempts"]
    code = load_artifact(run_dir, filename)
    functions = state["manifest"].get("functions", [])

    print(f"🔎 [Agent 4: Reviewer] Auditing {filename}...")

    heuristic_issue = heuristic_precheck(filename, code)
    if heuristic_issue:
        status = "FAIL"
        target = guess_broken_function(code, functions) if filename == "app.js" else None
        fb = {"issue": heuristic_issue, "instruction": "Fix exactly this, nothing else.", "target": target}
        write_log(run_dir, f"Reviewer (heuristic) - {filename}", f"{heuristic_issue} | target={target}")
    else:
        ctx = focused_context(state["manifest"], task["context_keys"])
        prompt = (
            f"{REVIEWER_PERSONA}\n\n"
            f"Review `{filename}` against the relevant spec below.\n"
            f"PROJECT: {state['project_brief']}\n"
            f"RELEVANT MANIFEST SECTION(S): {json.dumps(ctx, indent=2)}\n\n"
            f"CODE:\n```\n{code}\n```\n\n"
            "Fail it if ANY of these are true:\n"
            "1. It ends abruptly / has unclosed tags or brackets (truncation).\n"
            "2. It drifts from the manifest above (wrong ids, missing/extra functions, wrong layout).\n"
            "3. There's an obvious syntax or logic bug.\n\n"
            "Respond with ONLY this JSON, nothing else:\n"
            '{"status": "PASS", "issue": "", "instruction": "", "target": ""}\n'
            "or\n"
            '{"status": "FAIL", "issue": "<what is wrong>", '
            '"instruction": "<one specific, actionable sentence on what to fix>", '
            '"target": "<function name at fault, or empty if not one specific function>"}\n'
        )
        raw = llm_json.invoke(prompt).content
        parsed = extract_json(raw)
        status = str(parsed.get("status", "")).upper()
        if status not in ("PASS", "FAIL"):
            # small-model fallback if it didn't return clean JSON
            status = "PASS" if "PASS" in raw[:30].upper() else "FAIL"
        fb = {
            "issue": parsed.get("issue", "") or ("" if status == "PASS" else raw.strip()[:200]),
            "instruction": parsed.get("instruction", ""),
            "target": parsed.get("target") or None,
        }
        write_log(run_dir, f"Reviewer (LLM) - {filename}", f"{status}: {fb['issue']} | target={fb['target']}")

    finished = status == "PASS" or (attempts + 1 >= MAX_ATTEMPTS)

    if finished:
        ok = status == "PASS"
        print(f"   {'✅' if ok else '⚠️ '} {filename}: {'PASS' if ok else 'FAIL (max attempts reached)'}")
        eval_entry = {filename: {
            "attempts": attempts + 1,
            "status": status,
            "chars": len(code),
            "last_action": state.get("last_revision_mode", "initial"),
        }}
        errors = {} if ok else {filename: fb["issue"]}
        return {
            "feedback": {},
            "attempts": 0,
            "task_stack": state["task_stack"][1:],   # pop — move to next file
            "validation_errors": errors,
            "eval_matrix": eval_entry,
        }

    print(f"   ❌ Issues found: {fb['issue'][:80]}")
    return {"feedback": fb, "attempts": attempts + 1}


# ==========================================
# 10. ORCHESTRATION & GRAPH ROUTING
# ==========================================
def route_review(state: AgentState):
    if not state["feedback"]:
        return "coder" if state["task_stack"] else "end"
    return "coder"


workflow = StateGraph(AgentState)
workflow.add_node("scoper", requirement_agent)
workflow.add_node("architect", architect_agent)
workflow.add_node("coder", coder_agent)
workflow.add_node("reviewer", reviewer_agent)

workflow.set_entry_point("scoper")
workflow.add_edge("scoper", "architect")
workflow.add_edge("architect", "coder")
workflow.add_edge("coder", "reviewer")
workflow.add_conditional_edges("reviewer", route_review, {"coder": "coder", "end": END})

app = workflow.compile()


# ==========================================
# 11. EXECUTION BOOTSTRAP
# ==========================================
if __name__ == "__main__":
    print("=" * 70)
    print("  Offline Agentic SDLC — Vanilla Web App Generator (Ollama)")
    print("=" * 70)
    user_input = input("\nWhat web application do you want to build?\n> ").strip()

    run_dir = Path.cwd() / "SDLC_Workspace" / datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir.mkdir(parents=True, exist_ok=True)
    print(f"\n🚀 Workspace: {run_dir}")

    final_state = app.invoke({
        "user_input": user_input,
        "run_dir": run_dir,
        "attempts": 0,
        "feedback": {},
        "last_revision_mode": "initial",
        "validation_errors": {},
        "eval_matrix": {},
    })

    eval_matrix = final_state.get("eval_matrix", {})
    errors = final_state.get("validation_errors", {})
    save_artifact(run_dir, "evaluation.json", json.dumps({"files": eval_matrix, "unresolved": errors}, indent=2))

    print("\n" + "=" * 70)
    if errors:
        print(f"⚠️  Done — {len(errors)} file(s) still failing after {MAX_ATTEMPTS} attempts:")
        for f, msg in errors.items():
            print(f"   - {f}: {msg[:100]}")
    else:
        print("🎉 All files passed review.")
    print(f"📁 Output dir:   {run_dir}")
    print(f"📊 Evaluation:   {run_dir / 'evaluation.json'}")
    print(f"🧾 Full log:     {run_dir / 'execution_log.txt'}")
    print("=" * 70)
