"""
Offline Agentic SDLC — Vanilla Web App Generator
==================================================
Runs entirely against a local Ollama server (no network calls at all).
Builds a 3-file vanilla web app (index.html / style.css / app.js) using
four cooperating agents orchestrated with LangGraph.
"""

import os
import re
import json
import operator
from pathlib import Path
from datetime import datetime
from typing import TypedDict, Annotated, Optional

from langgraph.graph import StateGraph, END
from langchain_ollama import ChatOllama

# ==========================================
# 1. INITIALIZATION & CONFIGURATION
# ==========================================
MODEL_NAME = "gemma4:e2b"  # small/quantized instruction model
OLLAMA_URL = "http://localhost:11434"
MAX_ATTEMPTS = 3  # coder<->reviewer retries per file
CHUNK_SIZE = 3  # functions implemented per LLM call

llm = ChatOllama(
    model=MODEL_NAME,
    base_url=OLLAMA_URL,
    num_predict=2000,
    temperature=0.1,
)

llm_json = ChatOllama(
    model=MODEL_NAME,
    base_url=OLLAMA_URL,
    num_predict=1200,
    temperature=0.1,
    format="json",
)


# ==========================================
# 2. STATE DEFINITION
# ==========================================
class AgentState(TypedDict):
    user_input: str
    run_dir: Path
    project_brief: str
    requirements: str
    manifest: dict
    task_stack: list[dict]
    feedback: dict
    attempts: int
    last_revision_mode: str
    validation_errors: Annotated[dict, operator.ior]
    eval_matrix: Annotated[dict, operator.ior]


# ==========================================
# 3. PERSONAS & PROMPTS
# ==========================================
SCOPER_PERSONA = "You are a professional project requirement analyst who scopes small vanilla-JS web apps precisely and concisely."
ARCHITECT_PERSONA = "You are a professional software architect who plans small vanilla HTML/CSS/JS apps and outputs strict, minimal JSON."
CODER_PERSONA = "You are a professional front-end engineer who writes clean, stable, bug-free vanilla HTML/CSS/JS."
REVIEWER_PERSONA = "You are a meticulous code reviewer and QA engineer who checks front-end code against a spec and flags UI/logic/syntax flaws."

IMPL_FORMAT_NOTE = """Format EACH function exactly like this, one block per function:
<IMPL id="functionName">
function functionName(args) {
    // actual logic here
}
</IMPL>"""

PATCH_FORMAT_NOTE = """Output ONLY one or more SEARCH/REPLACE blocks that fix the issue above.
Do NOT rewrite the whole file — only the minimal lines that must change.
Copy the SEARCH text EXACTLY as it appears in CURRENT CODE below.

<<<<<<< SEARCH
<exact lines to find>
=======
<replacement lines>
>>>>>>> REPLACE"""


# ==========================================
# 4. PERSISTENCE & PARSING HELPERS
# ==========================================
def write_log(run_dir: Path, step: str, details: str) -> None:
    log_file = run_dir / "execution_log.txt"
    timestamp = datetime.now().strftime("%H:%M:%S")
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"\n[{timestamp}] === {step.upper()} ===\n")
        f.write(str(details) + "\n")
        f.write("-" * 80 + "\n")


def save_artifact(run_dir: Path, filename: str, content: str) -> str:
    (run_dir / filename).write_text(content, encoding="utf-8")
    return content


def load_artifact(run_dir: Path, filename: str) -> str:
    path = run_dir / filename
    return path.read_text(encoding="utf-8") if path.exists() else ""


def extract_json(text: str) -> dict:
    clean = re.sub(r"```(?:json)?", "", text, flags=re.IGNORECASE).replace("```", "")
    start, end = clean.find("{"), clean.rfind("}")
    if start == -1 or end == -1:
        return {}
    try:
        return json.loads(clean[start:end + 1], strict=False)
    except Exception as e:
        print(f"   [!] JSON parse error: {e}")
        return {}


def extract_code(response_text: str) -> str:
    match = re.search(r"```(?:[a-zA-Z]*)\n?(.*?)\n?```", response_text, re.DOTALL)
    if match:
        return match.group(1).strip()
    match = re.search(r"```(?:[a-zA-Z]*)\n?(.*)", response_text, re.DOTALL)
    return match.group(1).strip() if match else response_text.strip()


def focused_context(manifest: dict, keys: list[str]) -> dict:
    return {k: manifest.get(k, {}) for k in keys}


# ==========================================
# 5. JS STRUCTURAL HELPERS
# ==========================================
def locate_js_function(code: str, name: str) -> Optional[tuple[int, int, bool]]:
    m = re.search(rf'function\s+{re.escape(name)}\s*\([^)]*\)\s*\{{', code)
    if not m:
        return None
    depth = 0
    for j in range(m.end() - 1, len(code)):
        if code[j] == "{":
            depth += 1
        elif code[j] == "}":
            depth -= 1
            if depth == 0:
                return (m.start(), j + 1, False)
    return (m.start(), len(code), True)


def splice_js_function(code: str, name: str, new_impl: str) -> str:
    new_impl = new_impl.strip()
    span = locate_js_function(code, name)
    if span is None:
        return code.rstrip() + "\n\n" + new_impl + "\n"
    start, end, _truncated = span
    return code[:start] + new_impl + code[end:]


def placeholder_pattern(name: str) -> re.Pattern:
    return re.compile(rf'//\s*<PLACEHOLDER[^>]*\b{re.escape(name)}\b[^>]*/?>', re.IGNORECASE)


def remaining_placeholders(code: str, functions: list[dict]) -> list[dict]:
    return [f for f in functions if placeholder_pattern(f["name"]).search(code)]


def guess_broken_function(code: str, functions: list[dict]) -> Optional[str]:
    names = [f["name"] for f in functions]
    for name in names:
        span = locate_js_function(code, name)
        if span and span[2]:
            return name
    for name in names:
        if placeholder_pattern(name).search(code):
            return name
    for name in names:
        if locate_js_function(code, name) is None and not re.search(rf'\b{re.escape(name)}\s*\(', code):
            return name
    return None


# ==========================================
# 6. GENERIC PATCH HELPERS
# ==========================================
PATCH_BLOCK_RE = re.compile(r"<{3,}\s*SEARCH\s*\r?\n(.*?)\r?\n={3,}\s*\r?\n(.*?)\r?\n>{3,}\s*REPLACE", re.DOTALL)


def apply_patches(original: str, patch_text: str) -> tuple[str, list[str]]:
    blocks = PATCH_BLOCK_RE.findall(patch_text)
    if not blocks:
        return original, ["model returned no SEARCH/REPLACE blocks"]

    code = original
    failures = []
    for search, replace in blocks:
        search, replace = search.strip("\n"), replace.strip("\n")
        if not search:
            continue
        if code.count(search) == 1:
            code = code.replace(search, replace, 1)
            continue
        lines = code.split("\n")
        norm_lines = [ln.rstrip() for ln in lines]
        search_lines = [ln.rstrip() for ln in search.split("\n")]
        matches = [
            i for i in range(len(norm_lines) - len(search_lines) + 1)
            if norm_lines[i:i + len(search_lines)] == search_lines
        ]
        if len(matches) == 1:
            i = matches[0]
            lines = lines[:i] + replace.split("\n") + lines[i + len(search_lines):]
            code = "\n".join(lines)
            continue
        failures.append(search[:80].replace("\n", " ⏎ "))
    return code, failures


# ==========================================
# 7. HEURISTICS
# ==========================================
def heuristic_precheck(filename: str, code: str) -> Optional[str]:
    if not code.strip():
        return "File is empty."
    if filename.endswith(".js") and "PLACEHOLDER" in code:
        return "A '<PLACEHOLDER .../>' marker is still present — a function was never implemented."
    opens, closes = code.count("{"), code.count("}")
    if opens != closes:
        return f"Unbalanced braces ({opens} '{{' vs {closes} '}}') — file looks truncated."
    if filename.endswith(".js"):
        p_opens, p_closes = code.count("("), code.count(")")
        if p_opens != p_closes:
            return f"Unbalanced parentheses ({p_opens} '(' vs {p_closes} ')') — file looks truncated."
    if filename.endswith(".html") and ("<html" not in code.lower() or "</html>" not in code.lower()):
        return "Missing a complete <html>...</html> root — file looks truncated."
    return None


# ==========================================
# 8. SHARED LLM-CALL BUILDERS
# ==========================================
def implement_single_function(brief: str, func_meta: dict, extra_note: str = "") -> str:
    note = f"\nISSUE TO FIX: {extra_note}" if extra_note else ""
    prompt = (
        f"{CODER_PERSONA}\nPROJECT: {brief}\n"
        f"Implement exactly this ONE JavaScript function, nothing else:\n"
        f"{json.dumps(func_meta, indent=2)}{note}\n\n"
        "RULES:\n"
        "1. Assume DOM references already exist.\n"
        "2. Use template literals (backticks) for multi-line strings.\n"
        "3. Output ONLY the function body, inside a ``` block.\n"
    )
    return extract_code(llm.invoke(prompt).content)


def request_patch(filename: str, brief: str, ctx_str: str, issue: str, instruction: str, current_code: str) -> str:
    prompt = (
        f"{CODER_PERSONA}\nPROJECT: {brief}\nRELEVANT CONTEXT: {ctx_str}\n\n"
        f"ISSUE with `{filename}`: {issue}\nFIX INSTRUCTION: {instruction}\n\n"
        f"CURRENT `{filename}`:\n```\n{current_code}\n```\n\n{PATCH_FORMAT_NOTE}\n"
    )
    return llm.invoke(prompt).content


def full_rewrite(filename: str, brief: str, ctx_str: str, issue: str, instruction: str, current_code: str) -> str:
    prompt = (
        f"{CODER_PERSONA}\nFix `{filename}` based on reviewer feedback.\n\n"
        f"RELEVANT CONTEXT: {ctx_str}\nISSUE: {issue}\nINSTRUCTION: {instruction}\n"
        f"CURRENT CODE:\n```\n{current_code}\n```\n"
        "Output the entire fixed file inside a ``` block.\n"
    )
    return extract_code(llm.invoke(prompt).content)


# ==========================================
# 9. AGENT NODES
# ==========================================
def requirement_agent(state: AgentState):
    print("\n📝 [Agent 1: Scoper] Drafting requirements...")
    prompt = f"{SCOPER_PERSONA}\nAnalyze this request: \"{state['user_input']}\"\nDraft a concise, bulleted functional requirements list."
    reqs = llm.invoke(prompt).content.strip()
    save_artifact(state["run_dir"], "requirements.txt", reqs)
    write_log(state["run_dir"], "Requirements", reqs)
    return {"requirements": reqs, "project_brief": state["user_input"].strip()}


def architect_agent(state: AgentState):
    print("📐 [Agent 2: Architect] Building manifest & task stack...")
    reqs = state["requirements"]

    layout = {}
    for _ in range(MAX_ATTEMPTS):
        p = f'{ARCHITECT_PERSONA}\nReqs: {reqs}\nOutput JSON for the CSS layout strategy only. Format: {{"layout": {{"container": "grid/flex rule", "notes": "short layout notes"}}}}'
        layout = extract_json(llm_json.invoke(p).content)
        if layout.get("layout"): break

    ids = {}
    for _ in range(MAX_ATTEMPTS):
        p = f'{ARCHITECT_PERSONA}\nReqs: {reqs}\nOutput JSON listing interactive HTML elements. Format: {{"ids": [{{"id": "btn-submit", "element": "button", "purpose": "submits the form"}}]}}'
        ids = extract_json(llm_json.invoke(p).content)
        if ids.get("ids"): break

    functions = {}
    for _ in range(MAX_ATTEMPTS):
        p = f'{ARCHITECT_PERSONA}\nReqs: {reqs}\nOutput JSON listing every JS function needed. Format: {{"functions": [{{"name": "calculateTotal", "params": ["a", "b"], "description": "adds a and b"}}]}}'
        functions = extract_json(llm_json.invoke(p).content)
        if functions.get("functions"): break

    manifest = {"layout": layout.get("layout", {}), "ids": ids.get("ids", []),
                "functions": functions.get("functions", [])}
    save_artifact(state["run_dir"], "manifest.json", json.dumps(manifest, indent=2))
    write_log(state["run_dir"], "Manifest", json.dumps(manifest, indent=2))

    task_stack = [
        {"file": "index.html", "context_keys": ["layout", "ids"], "purpose": "Build the DOM structure."},
        {"file": "style.css", "context_keys": ["layout"], "purpose": "Style the layout."},
        {"file": "app.js", "context_keys": ["ids", "functions"], "purpose": "Implement exactly these functions."},
    ]
    return {"manifest": manifest, "task_stack": task_stack, "validation_errors": {}, "eval_matrix": {}}


def _generate_app_js(run_dir: Path, brief: str, ctx: dict) -> str:
    ctx_str = json.dumps(ctx, indent=2)
    funcs = ctx.get("functions", [])

    print("   ↳ generating skeleton (deterministic)...")
    skel_prompt = (
        f"{CODER_PERSONA}\nWrite a JS setup only.\nCONTEXT: {ctx_str}\n"
        "RULES:\n1. Declare globals and DOM references using the given ids.\n"
        "2. STOP THERE. Do NOT write any functions. NO `function` keyword.\n"
        "Output ONLY javascript inside a ``` block.\n"
    )
    skeleton = extract_code(llm.invoke(skel_prompt).content)

    # FIX 1: Python deterministically appends the placeholders to prevent model hallucination
    for f in funcs:
        skeleton += f"\n// <PLACEHOLDER id=\"{f['name']}\"/>\n"

    save_artifact(run_dir, "app.js", skeleton)

    print("   ↳ implementing functions in chunks...")
    for i in range(0, len(funcs), CHUNK_SIZE):
        chunk = funcs[i:i + CHUNK_SIZE]
        impl_prompt = (
            f"{CODER_PERSONA}\nImplement exactly these functions: {json.dumps(chunk, indent=2)}\n\n"
            "CRITICAL: use template literals (backticks) for multi-line strings.\n\n"
            f"{IMPL_FORMAT_NOTE}\n"
        )
        impl_resp = llm.invoke(impl_prompt).content
        for f in chunk:
            name = f["name"]
            pattern = rf'<IMPL\s+id=["\']?{re.escape(name)}["\']?\s*>\s*(.*?)\s*</IMPL>'
            m = re.search(pattern, impl_resp, re.DOTALL | re.IGNORECASE)
            if m:
                skeleton = placeholder_pattern(name).sub(
                    lambda _mo: m.group(1).strip().replace("\\", "\\\\"), skeleton
                )
        save_artifact(run_dir, "app.js", skeleton)

    print("   ↳ self-healing any missed functions...")
    for f in remaining_placeholders(skeleton, funcs):
        new_impl = implement_single_function(brief, f, "This function was never filled in — implement it now.")
        skeleton = placeholder_pattern(f["name"]).sub(lambda _mo: new_impl.replace("\\", "\\\\"), skeleton, count=1)
        save_artifact(run_dir, "app.js", skeleton)
        write_log(run_dir, f"Coder (self-heal) - {f['name']}", new_impl)

    return skeleton


def coder_agent(state: AgentState):
    run_dir = state["run_dir"]
    task = state["task_stack"][0]
    filename = task["file"]
    attempts = state["attempts"]
    is_revision = attempts > 0
    is_last_attempt = attempts + 1 >= MAX_ATTEMPTS
    manifest = state["manifest"]
    ctx = focused_context(manifest, task["context_keys"])
    ctx_str = json.dumps(ctx, indent=2)
    brief = state["project_brief"]

    print(
        f"\n💻 [Agent 3: Coder] {'Revising' if is_revision else 'Writing'} {filename} (attempt {attempts + 1}/{MAX_ATTEMPTS})...")

    if not is_revision:
        if filename == "app.js":
            code = _generate_app_js(run_dir, brief, ctx)
        else:
            prompt = f"{CODER_PERSONA}\nWrite `{filename}`.\nPROJECT: {brief}\nTASK: {task['purpose']}\nRELEVANT CONTEXT: {ctx_str}\nRULES:\n- If HTML: link style.css and app.js.\n- Output ONLY raw code inside a ``` block.\n"
            code = extract_code(llm.invoke(prompt).content)
        mode = "initial"

    else:
        current_code = load_artifact(run_dir, filename)
        fb = state["feedback"]
        issue, instruction = fb.get("issue", ""), fb.get("instruction", "")
        target = None

        if filename == "app.js":
            target = fb.get("target") or None
            if target not in [f["name"] for f in manifest.get("functions", [])]:
                target = guess_broken_function(current_code, manifest.get("functions", []))

        if target:
            print(f"   ↳ targeted function patch: {target}()")
            func_meta = next((f for f in manifest["functions"] if f["name"] == target), {"name": target})
            new_impl = implement_single_function(brief, func_meta, instruction or issue)
            code = splice_js_function(current_code, target, new_impl)
            mode = f"function_patch:{target}"
        else:
            print("   ↳ requesting scoped SEARCH/REPLACE patch...")
            patch_text = request_patch(filename, brief, ctx_str, issue, instruction, current_code)
            code, failures = apply_patches(current_code, patch_text)
            if not failures:
                mode = "search_replace"
            elif is_last_attempt:
                print("   ↳ patch failed to apply and this is the final attempt — falling back to a full rewrite.")
                # FIX 2: Never do a monolithic rewrite for app.js; restart the chunking instead.
                if filename == "app.js":
                    code = _generate_app_js(run_dir, brief, ctx)
                else:
                    code = full_rewrite(filename, brief, ctx_str, issue, instruction, current_code)
                mode = "last_resort_full_rewrite"
            else:
                write_log(run_dir, f"Coder (patch — unmatched blocks) - {filename}", "\n".join(failures))
                mode = "search_replace_partial"

    save_artifact(run_dir, filename, code)
    write_log(run_dir, f"Coder ({mode}) - {filename}", code)
    return {"last_revision_mode": mode}


def reviewer_agent(state: AgentState):
    run_dir = state["run_dir"]
    current_task = state["task_stack"][0]
    current_file = current_task["file"]
    attempts = state["attempts"]
    code = load_artifact(run_dir, current_file)
    functions = state["manifest"].get("functions", [])

    print(f"🔎 [Agent 4: Reviewer] Auditing {current_file}...")

    heuristic_issue = heuristic_precheck(current_file, code)
    if heuristic_issue:
        status = "FAIL"
        target = guess_broken_function(code, functions) if current_file == "app.js" else None
        fb = {"issue": heuristic_issue, "instruction": "Fix exactly this, nothing else.", "target": target}
        write_log(run_dir, f"Reviewer (heuristic) - {current_file}", f"{heuristic_issue} | target={target}")
    else:
        ctx = focused_context(state["manifest"], current_task["context_keys"])
        prompt = (
            f"{REVIEWER_PERSONA}\n\nReview `{current_file}` against the spec.\n"
            f"PROJECT: {state['project_brief']}\nRELEVANT MANIFEST: {json.dumps(ctx, indent=2)}\n\n"
            f"CODE:\n```\n{code}\n```\n\n"
            "Fail it if ANY are true: 1. Truncation 2. Drifts from manifest 3. Syntax/logic bug.\n"
            'Respond ONLY with JSON:\n{"status": "PASS/FAIL", "issue": "what is wrong", "instruction": "how to fix", "target": "function name"}'
        )
        raw = llm_json.invoke(prompt).content
        parsed = extract_json(raw)
        status = str(parsed.get("status", "")).upper()

        if status not in ("PASS", "FAIL"):
            status = "PASS" if "PASS" in raw[:30].upper() else "FAIL"

        # FIX 3: Failsafe if Reviewer outputs empty issue string
        issue_text = parsed.get("issue", "")
        if not issue_text and status == "FAIL":
            issue_text = "The reviewer marked this as FAIL but provided no details. Check for truncation or missing logic."

        fb = {
            "issue": issue_text,
            "instruction": parsed.get("instruction", "Fix the file to match the manifest."),
            "target": parsed.get("target") or None,
        }
        write_log(run_dir, f"Reviewer (LLM) - {current_file}", f"{status}: {fb['issue']} | target={fb['target']}")

    finished = status == "PASS" or (attempts + 1 >= MAX_ATTEMPTS)

    if finished:
        ok = status == "PASS"
        print(f"   {'✅' if ok else '⚠️ '} {current_file}: {'PASS' if ok else 'FAIL (max attempts reached)'}")
        eval_entry = {current_file: {"attempts": attempts + 1, "status": status, "chars": len(code),
                                     "last_action": state.get("last_revision_mode", "initial")}}
        errors = {} if ok else {current_file: fb["issue"]}
        return {
            "feedback": {},
            "attempts": 0,
            "task_stack": state["task_stack"][1:],
            "validation_errors": errors,
            "eval_matrix": eval_entry,
        }

    print(f"   ❌ Issues found: {fb['issue'][:80]}")
    return {"feedback": fb, "attempts": attempts + 1}


# ==========================================
# 10. ORCHESTRATION & GRAPH ROUTING
# ==========================================
def route_review(state: AgentState):
    if not state["feedback"]:
        return "coder" if state["task_stack"] else "end"
    return "coder"


workflow = StateGraph(AgentState)
workflow.add_node("scoper", requirement_agent)
workflow.add_node("architect", architect_agent)
workflow.add_node("coder", coder_agent)
workflow.add_node("reviewer", reviewer_agent)

workflow.set_entry_point("scoper")
workflow.add_edge("scoper", "architect")
workflow.add_edge("architect", "coder")
workflow.add_edge("coder", "reviewer")
workflow.add_conditional_edges("reviewer", route_review, {"coder": "coder", "end": END})

app = workflow.compile()

# ==========================================
# 11. EXECUTION BOOTSTRAP
# ==========================================
if __name__ == "__main__":
    print("=" * 70)
    print("  Offline Agentic SDLC — Vanilla Web App Generator (Ollama)")
    print("=" * 70)
    user_input = input("\nWhat web application do you want to build?\n> ").strip()

    run_dir = Path.cwd() / "SDLC_Workspace" / datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir.mkdir(parents=True, exist_ok=True)
    print(f"\n🚀 Workspace: {run_dir}")

    final_state = app.invoke({
        "user_input": user_input,
        "run_dir": run_dir,
        "attempts": 0,
        "feedback": {},
        "last_revision_mode": "initial",
        "validation_errors": {},
        "eval_matrix": {},
    })

    eval_matrix = final_state.get("eval_matrix", {})
    errors = final_state.get("validation_errors", {})
    save_artifact(run_dir, "evaluation.json", json.dumps({"files": eval_matrix, "unresolved": errors}, indent=2))

    print("\n" + "=" * 70)
    if errors:
        print(f"⚠️  Done — {len(errors)} file(s) still failing after {MAX_ATTEMPTS} attempts:")
        for f, msg in errors.items():
            print(f"   - {f}: {msg[:100]}")
    else:
        print("🎉 All files passed review.")
    print(f"📁 Output dir:   {run_dir}")
    print("=" * 70)