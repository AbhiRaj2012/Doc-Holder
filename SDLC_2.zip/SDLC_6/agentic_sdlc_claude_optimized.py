"""
Offline Agentic SDLC — Vanilla Web App Generator (v3)
=======================================================
Runs entirely against a local Ollama server (no network calls at all).
Builds a 3-file vanilla web app (index.html / style.css / app.js) using
four cooperating agents orchestrated with LangGraph:

    User input
        |
        v
    Agent 1  Scoper      -> writes requirements.txt + a 1-line project brief
        |
        v
    Agent 2  Architect   -> writes manifest.json (layout / ids / functions)
        |                   + builds the Coder's task stack
        v
    Agent 3  Coder    <-------------------+
        |                                 |
        v                                 | FAIL (loop back, same file,
    Agent 4  Reviewer  -------------------+   PATCH — never a full rewrite)
        |
        | PASS -> pop file, next task in stack
        v
    task_stack empty? -> END

v3 changelog — what broke and why
-----------------------------------
The v2 run's own artifacts showed a NEW failure mode, worse than v1's: the
Reviewer twice returned a verdict with a completely EMPTY `issue` field
("FAIL:  | target=None"), the Coder's resulting "fix" duplicated several
functions (a full implementation immediately followed by its own empty
`{ // Implementation goes here }` stub — `renderInvoicePreview`, `addItem`,
`removeItem`, `saveInvoice` all appear twice), and the run finally died with
`app.js` overwritten by a genuinely EMPTY file (evaluation.json: "chars": 0,
"File is empty."). That's a regression from v1 — v1 at least left a
truncated-but-substantial file behind; v3's predecessor destroyed a mostly-
working ~150-line file entirely.

Root cause: neither `ChatOllama` client set `num_ctx`. Ollama's default
context window (2048-4096 tokens depending on version/model) is easily
exceeded once app.js itself is ~150+ lines and gets embedded whole into
every review/patch/rewrite prompt alongside the persona, manifest section,
and instructions. Once the prompt alone approaches the context limit, there
is no room left to generate ANY output tokens, and Ollama returns an empty
completion. That single empty completion then cascades: an empty review
gives the Coder no real issue to fix, so it patches speculatively (which is
what produced the duplicated functions); the file gets longer as a result,
making the NEXT review even more likely to overflow context and come back
empty too; eventually the final attempt's full-rewrite ALSO comes back
empty, and the old code (until now) had no protection against being
overwritten by that emptiness.

Three independent fixes, in order of how much they matter:

1. ROOT CAUSE — both `ChatOllama` clients now set `num_ctx` explicitly
   (see NUM_CTX below) to a much larger window than Ollama's default, and
   every LLM call for code/JSON goes through `invoke_text()`, which retries
   once on a genuinely empty response before giving up. This alone should
   prevent the empty-response cascade from ever starting.
2. NEVER MAKE IT WORSE (new safety net) — `guard_against_regression()` runs
   after every REVISION (patch / function-splice / last-resort rewrite,
   never after a true first-time generation) and compares the new code to
   the old code with the same free heuristic checks the Reviewer uses. If
   the new version is empty, or introduces a problem the old version didn't
   have, the old version is kept and the attempt is logged as rejected —
   disk is only ever updated with a version that is at least as sound as
   what was already there. This is what would have stopped app.js from
   ever being overwritten with an empty file, independent of whatever LLM
   hiccup causes the empty output next time.
3. DETERMINISTIC DEDUP (new, no LLM involved) — `dedupe_js_functions()` is
   run on app.js after every generation/repair step. If the same function
   name ends up declared twice (exactly what happened here), it keeps
   whichever copy is the real implementation (not a stub, not truncated)
   and deletes the other — the harness-over-model principle applied to a
   corruption pattern that's now been observed in practice rather than
   just anticipated.

Everything from v1/v2 that already worked is unchanged: self-healing
chunked generation for app.js, patch-not-rewrite revisions, vertical +
horizontal context economy (brief vs. full requirements; manifest section
slicing), disk-as-source-of-truth, and free heuristics before any LLM
review call.

v4 changelog — three runs all logged "PASS" and all shipped broken apps
--------------------------------------------------------------------------
v3's NUM_CTX/guard/dedupe fixes worked as designed — nothing was truncated
or overwritten with garbage. But three separate runs still shipped an app
whose app.js could never actually run, and the Reviewer said PASS every
time. Reading the *content* of what got built (not just whether the run
completed) turned up two real bugs the v3 harness had no way to catch:

1. A commented-out declaration was indistinguishable from a real one.
   One run's "finished" app.js had every required function only as a
   comment (`// function handleNumberInput(value) {`) — never a real
   `function handleNumberInput(value) { ... }`. That happened because the
   model paraphrased the required `// <PLACEHOLDER id="name"/>` marker
   into its own comment style instead of using it verbatim, which meant
   the self-heal pass (which searches for that exact marker) found
   nothing to heal — it wasn't broken, it correctly saw zero placeholders,
   because none existed in the format it knew how to look for. Worse: the
   OLD `find_all_function_spans` used a plain regex over the raw string,
   so it matched "function handleNumberInput(value) {" *inside that very
   comment* and reported the function as present. Every downstream check
   built on that function — self-heal, dedupe, the reviewer's own
   sanity checks — inherited the same false confidence.
   Fix: `_mask_js_comments()` blanks out comment text (same length, same
   offsets) before any structural search runs, so a commented-out
   declaration is now invisible to `find_all_function_spans`,
   `find_duplicate_function_names`, and everything built on them.

2. The skeleton step still asked the model to invent DOM variable names
   from ids, and it produced `const btn-add = document.getElementById(...)`
   — a hard JS syntax error, since '-' is the subtraction operator and
   isn't legal inside an identifier. This is a request no amount of
   rewording reliably fixes on a weak model; it's a mechanical
   transformation with one right answer, which is exactly the kind of
   step that belongs in Python, not in a prompt.
   Fix: `build_js_skeleton()` / `id_to_var_name()` / `compute_id_var_map()`
   generate the ENTIRE DOM-reference block and every `<PLACEHOLDER>`
   marker deterministically — zero LLM calls, zero chance of an invalid
   identifier or a paraphrased marker — and the resulting id->variable
   map is threaded through every later prompt (chunk implementation,
   self-heal, targeted patches, full rewrites) so the model is only ever
   asked to write function BODIES, never to invent variable names again.

Two more checks close the gap between "looks structurally fine" and
"is actually the app that was asked for", independent of whether the
small review LLM notices:

3. `heuristic_precheck` now takes the manifest's `functions` list and
   fails a file where a required function isn't found as a real
   (comment-masked) declaration — this is the check that would have
   caught the bug in point 1 even if the placeholder-marker fix above
   hadn't existed, and it also fails on invalid hyphenated identifiers as
   a second line of defense against the bug in point 2 surviving into a
   later hand-authored revision.
4. `node_syntax_check()` shells out to `node --check` (best-effort — silently
   skipped if Node isn't installed) as a real, deterministic parse instead
   of brace/paren counting. This is what would have caught
   `const btn-add = ...` immediately, with zero LLM involvement and zero
   ambiguity, on any machine that has Node.

Finally, two silent-cascade guards: one run's requirements.txt was the
model asking "please provide the project request" back (the app
description was left blank), which flowed into an empty manifest, which
flowed into a trivial app that trivially "passed" because there was
nothing in the spec to fail it against. `requirement_agent` now flags a
suspiciously short/refusal-shaped draft, `architect_agent` now flags a
manifest with no ids and no functions, and the CLI now refuses to start
a run on a blank app description — so a degenerate run is loud instead of
silently shipping something that looks like a completed, passing build.

1. LIGHTWEIGHT — only langgraph + langchain-ollama. No vector DBs, no
   heavy eval frameworks (see evaluation.json below for why DeepEval etc.
   is deliberately not pulled in). Everything else is stdlib.
2. CONTEXT ECONOMY — two separate cuts:
     a) VERTICAL — the Architect is the only agent that ever sees the full
        multi-paragraph requirements.txt. Every other agent gets the
        one-line project brief instead.
     b) HORIZONTAL — the manifest has 3 independent sections
        (layout / ids / functions). Every prompt only receives the
        section(s) that file actually needs (`focused_context`).
   Together these are what let a tiny model (2B-4B class) stay precise —
   see NUM_CTX above for the third piece of context economy: making sure
   the window itself is big enough for what these two cuts still leave in.
3. DISK IS THE SOURCE OF TRUTH — no generated file ever lives only in
   LangGraph state / RAM, AND (new in v3) disk is never overwritten with
   something worse than what was already durable there.
4. SELF-HEALING GENERATION — after app.js's chunked implementation pass,
   any function whose `<PLACEHOLDER>` marker is still standing gets one
   immediate, individually targeted retry before the file is ever handed
   to the Reviewer.
5. PATCH, NEVER REWRITE — a revision is scoped to exactly what the
   Reviewer flagged: a single spliced function for app.js when one can be
   identified, minimal SEARCH/REPLACE blocks otherwise, and a full
   single-shot rewrite only as a last resort on the final attempt — which,
   as of v3, can never actually destroy a good file (see fix #2 above).
6. HARNESS OVER MODEL — free, deterministic heuristic checks (brace/paren
   balance, leftover placeholders, duplicate declarations, missing root
   tags) run before any review LLM call, and Ollama's native
   `format="json"` mode is used for structured calls.
7. OBSERVABILITY — every agent step, self-heal, dedup, and patch attempt
   (success, partial, or rejected) is appended to execution_log.txt, and a
   final evaluation.json scores each file.
"""

import os
import re
import json
import operator
import subprocess
import tempfile
from pathlib import Path
from datetime import datetime
from typing import TypedDict, Annotated, Optional

from langgraph.graph import StateGraph, END
from langchain_ollama import ChatOllama

# ==========================================
# 1. INITIALIZATION & CONFIGURATION
# ==========================================
# Check `ollama list` for the exact tag you have pulled locally and adjust —
# Gemma's small "effective parameter" variants are usually tagged
# "gemma3n:e2b" / "gemma3n:e4b" rather than "gemma4:e2b"; verify before running.
MODEL_NAME = "gemma4:e2b"          # small/quantized instruction model
OLLAMA_URL = "http://localhost:11434"
MAX_ATTEMPTS = 3                   # coder<->reviewer retries per file
CHUNK_SIZE = 3                     # functions implemented per LLM call

# THIS IS THE FIX FOR THE EMPTY-RESPONSE CASCADE DESCRIBED ABOVE. Ollama's
# default context window is much smaller than a persona + manifest section +
# a ~150-line app.js all embedded in one prompt. If you're building an app
# with a much larger manifest and still see empty completions in
# execution_log.txt, raise this further (memory permitting).
NUM_CTX = 8192

llm = ChatOllama(
    model=MODEL_NAME,
    base_url=OLLAMA_URL,
    num_predict=3000,
    num_ctx=NUM_CTX,
    temperature=0.1,
)

# A second handle using Ollama's native structured-output mode. Every call
# that expects JSON back (manifest sections, reviewer verdicts) goes through
# this one instead of `llm` — it costs nothing extra and meaningfully cuts
# down on "small model wrapped its JSON in prose" parse failures. Drop the
# `format="json"` kwarg if your installed langchain-ollama predates it.
llm_json = ChatOllama(
    model=MODEL_NAME,
    base_url=OLLAMA_URL,
    num_predict=1200,
    num_ctx=NUM_CTX,
    temperature=0.1,
    format="json",
)


def invoke_text(client: ChatOllama, prompt: str, retries: int = 1) -> str:
    """Call an LLM and retry (once, by default) if it comes back genuinely
    empty. Local models occasionally return nothing under context pressure
    or transient load; a bare retry is cheap and often succeeds. Callers
    still need to handle a persistently empty result — this only removes
    the common transient case."""
    content = ""
    for _ in range(retries + 1):
        content = client.invoke(prompt).content
        if content and content.strip():
            return content
    return content


# ==========================================
# 2. STATE DEFINITION
# ==========================================
class AgentState(TypedDict):
    user_input: str
    run_dir: Path
    project_brief: str                                    # short, concise — used by Coder/Reviewer
    requirements: str                                      # full spec — Architect-only
    manifest: dict
    task_stack: list[dict]                                 # Planner's execution queue
    feedback: dict                                         # reviewer -> coder, {} means clean
    attempts: int                                          # attempts on the CURRENT file
    last_revision_mode: str                                # how the current file was (re)built
    validation_errors: Annotated[dict, operator.ior]       # files still failing at max attempts
    eval_matrix: Annotated[dict, operator.ior]             # per-file quality metrics


# ==========================================
# 3. PERSONAS
# ==========================================
SCOPER_PERSONA = (
    "You are a professional project requirement analyst who scopes small "
    "vanilla-JS web apps precisely and concisely."
)
ARCHITECT_PERSONA = (
    "You are a professional software architect who plans small vanilla "
    "HTML/CSS/JS apps and outputs strict, minimal JSON."
)
CODER_PERSONA = (
    "You are a professional front-end engineer who writes clean, stable, "
    "bug-free vanilla HTML/CSS/JS."
)
REVIEWER_PERSONA = (
    "You are a meticulous code reviewer and QA engineer who checks "
    "front-end code against a spec and flags UI/logic/syntax flaws."
)

# Plain (non f-string) template fragments that contain a lot of literal
# `{ }` — kept separate and concatenated in, rather than escaped inline,
# so nothing here has to double up braces to survive an f-string.
IMPL_FORMAT_NOTE = """Format EACH function exactly like this, one block per function:
<IMPL id="functionName">
function functionName(args) {
    // actual logic here
}
</IMPL>"""

PATCH_FORMAT_NOTE = """Output ONLY one or more SEARCH/REPLACE blocks that fix the issue above.
Do NOT rewrite the whole file — only the minimal lines that must change.
Copy the SEARCH text EXACTLY as it appears in CURRENT CODE below (same
whitespace, same characters). Keep each block as short as possible — just
enough lines to uniquely locate the spot. You may repeat the block for
multiple separate fixes.

<<<<<<< SEARCH
<exact lines to find>
=======
<replacement lines>
>>>>>>> REPLACE"""


# ==========================================
# 4. PERSISTENCE & PARSING HELPERS
# ==========================================
def write_log(run_dir: Path, step: str, details: str) -> None:
    """Append-only execution log so a run can be audited after the fact."""
    log_file = run_dir / "execution_log.txt"
    timestamp = datetime.now().strftime("%H:%M:%S")
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"\n[{timestamp}] === {step.upper()} ===\n")
        f.write(str(details) + "\n")
        f.write("-" * 80 + "\n")


def save_artifact(run_dir: Path, filename: str, content: str) -> str:
    """Flush content to disk immediately. Nothing in this workflow is ever
    allowed to exist ONLY in RAM/state — this is called the instant any
    artifact (requirements, manifest, a code file, a self-heal, a patch)
    is produced."""
    (run_dir / filename).write_text(content, encoding="utf-8")
    return content


def load_artifact(run_dir: Path, filename: str) -> str:
    """Read the current durable copy of a file. The Coder and Reviewer both
    use this instead of trusting in-memory state, so a revision is always
    built on top of exactly what's on disk."""
    path = run_dir / filename
    return path.read_text(encoding="utf-8") if path.exists() else ""


def extract_json(text: str) -> dict:
    """Salvage a JSON object from a small model's output. Even with
    format="json" this stays as a defensive fallback (older Ollama/lib
    versions, or a model that still wraps its answer in prose)."""
    clean = re.sub(r"```(?:json)?", "", text, flags=re.IGNORECASE).replace("```", "")
    start, end = clean.find("{"), clean.rfind("}")
    if start == -1 or end == -1:
        return {}
    try:
        return json.loads(clean[start:end + 1], strict=False)
    except Exception as e:
        print(f"   [!] JSON parse error: {e}")
        return {}


def extract_code(response_text: str) -> str:
    """Pull code out of a ``` fence. Falls back gracefully if the model
    truncates output and never closes the fence (common on small models)."""
    if not response_text:
        return ""
    match = re.search(r"```(?:[a-zA-Z]*)\n?(.*?)\n?```", response_text, re.DOTALL)
    if match:
        return match.group(1).strip()
    match = re.search(r"```(?:[a-zA-Z]*)\n?(.*)", response_text, re.DOTALL)
    return match.group(1).strip() if match else response_text.strip()


def focused_context(manifest: dict, keys: list[str]) -> dict:
    """Slice the manifest down to only the section(s) a given file needs.
    This is the core of the horizontal context-economy principle:
    index.html never sees `functions`, app.js never sees `layout`, etc."""
    return {k: manifest.get(k, {}) for k in keys}


# ==========================================
# 5. JS STRUCTURAL HELPERS (deterministic, no LLM)
# ==========================================
def _mask_js_comments(code: str) -> str:
    """Same-length copy of `code` with `//` and `/* */` comment contents
    blanked to spaces (newlines kept, so line numbers still line up).
    Every index still matches the original string 1:1, so callers can
    search this masked copy for real code structure and then slice the
    ORIGINAL `code` using the offsets they find.

    This exists because of a bug observed in practice: a model wrote
        // handleNumberInput(value)
        // function handleNumberInput(value) {
        //     // Implementation goes here
        // }
    instead of a real implementation, and the OLD span-finder (a plain
    regex over the raw string) matched "function handleNumberInput(value) {"
    inside that comment as if it were a genuine declaration — so every
    downstream check (placeholder self-heal, dedupe, the reviewer's
    "is this function real" check) was fooled into thinking the function
    existed. Searching the masked copy instead means a commented-out
    declaration is invisible to all of them.

    Limitation: this is a lightweight masker, not a full JS tokenizer — a
    literal `//` or `/*` inside a string/template literal (e.g. a URL)
    would be mis-masked. That's an accepted trade-off for a dependency-free
    heuristic; `node_syntax_check` below is the authoritative check when
    Node is available and doesn't share this limitation.
    """
    out = list(code)
    i, n = 0, len(code)
    while i < n:
        if code[i] == "/" and i + 1 < n and code[i + 1] == "/":
            while i < n and code[i] != "\n":
                out[i] = " "
                i += 1
        elif code[i] == "/" and i + 1 < n and code[i + 1] == "*":
            out[i] = out[i + 1] = " "
            i += 2
            while i < n and not (code[i] == "*" and i + 1 < n and code[i + 1] == "/"):
                if code[i] != "\n":
                    out[i] = " "
                i += 1
            if i < n:
                out[i] = out[i + 1] = " "
                i += 2
        else:
            i += 1
    return "".join(out)


def find_all_function_spans(code: str, name: str) -> list[tuple[int, int, bool]]:
    """Find EVERY top-level `function name(...) { ... }` span via brace
    counting (robust to nested braces, unlike a regex) — searched on a
    comment-masked copy so a commented-out declaration can never be
    mistaken for a real one, then sliced out of the ORIGINAL `code`.
    Each span is (start, end, truncated) — truncated=True means it opened
    but the file ran out before the matching '}'."""
    masked = _mask_js_comments(code)
    spans = []
    cursor = 0
    while True:
        m = re.search(rf'function\s+{re.escape(name)}\s*\([^)]*\)\s*\{{', masked[cursor:])
        if not m:
            break
        abs_start = cursor + m.start()
        open_pos = cursor + m.end() - 1
        depth, end, truncated = 0, None, True
        for j in range(open_pos, len(masked)):
            if masked[j] == "{":
                depth += 1
            elif masked[j] == "}":
                depth -= 1
                if depth == 0:
                    end, truncated = j + 1, False
                    break
        if end is None:
            end = len(code)
        spans.append((abs_start, end, truncated))
        if end <= abs_start:  # safety valve against a pathological zero-width match
            break
        cursor = end
    return spans


def locate_js_function(code: str, name: str) -> Optional[tuple[int, int, bool]]:
    """The first span for `name`, or None if it isn't declared at all."""
    spans = find_all_function_spans(code, name)
    return spans[0] if spans else None


def splice_js_function(code: str, name: str, new_impl: str) -> str:
    """Replace exactly one function's definition in `code`, leaving every
    other line byte-for-byte untouched. If the function is missing or was
    truncated mid-declaration, this repairs/inserts it in place instead of
    regenerating anything around it."""
    new_impl = new_impl.strip()
    span = locate_js_function(code, name)
    if span is None:
        return code.rstrip() + "\n\n" + new_impl + "\n"
    start, end, _truncated = span
    return code[:start] + new_impl + code[end:]


def placeholder_pattern(name: str) -> re.Pattern:
    return re.compile(rf'//\s*<PLACEHOLDER[^>]*\b{re.escape(name)}\b[^>]*/?>', re.IGNORECASE)


def remaining_placeholders(code: str, functions: list[dict]) -> list[dict]:
    """Which manifest functions still have an unfilled `<PLACEHOLDER>`
    marker in `code`? Used right after chunked generation to self-heal
    before the file ever reaches the Reviewer."""
    return [f for f in functions if placeholder_pattern(f["name"]).search(code)]


def find_duplicate_function_names(code: str) -> list[str]:
    """Which function names are declared more than once? This is exactly
    the corruption pattern observed in practice: a real implementation
    followed by its own leftover empty stub. Searched on the comment-
    masked copy — see `_mask_js_comments` — so a commented-out mention of
    a function name never counts as a second declaration."""
    seen, dupes = set(), []
    for n in re.findall(r"function\s+(\w+)\s*\(", _mask_js_comments(code)):
        if n in seen and n not in dupes:
            dupes.append(n)
        seen.add(n)
    return dupes


def _is_stub_function_body(body: str) -> bool:
    """A function body with no real statement inside it — either the
    classic 'Implementation goes here' placeholder comment, or literally
    nothing once comments are stripped.

    Deliberately NOT a raw length check. That was tried and is what
    produced a real bug: `len(body) < 40` misclassified a genuine,
    correct one-liner (e.g. `{ return 1; }`, 29 chars) as a stub, so on a
    tie the dedup step kept a longer, comment-padded FAKE stub instead of
    the short real implementation — the exact opposite of what dedup is
    for. Checking for actual executable content is length-independent and
    doesn't have that failure mode."""
    inner = body[body.find("{") + 1: body.rfind("}")]
    return "Implementation goes here" in body or _mask_js_comments(inner).strip() == ""


def dedupe_js_functions(code: str) -> tuple[str, list[str]]:
    """Deterministically collapse duplicate `function name(...) {...}`
    blocks down to a single, best copy — no LLM involved. Keeps whichever
    occurrence is a real (non-stub, non-truncated) implementation; on a tie
    keeps the longer one. Run unconditionally after every app.js
    generation/repair step so duplicates essentially never survive to reach
    the Reviewer."""
    removed = []
    for name in find_duplicate_function_names(code):
        spans = find_all_function_spans(code, name)
        if len(spans) <= 1:
            continue

        def score(span):
            s, e, truncated = span
            if truncated:
                return (-1, 0)
            body = code[s:e]
            is_stub = _is_stub_function_body(body)
            return (0 if is_stub else 1, len(body))

        best = max(spans, key=score)
        for span in sorted(spans, key=lambda sp: sp[0], reverse=True):
            if span is best:
                continue
            s, e, _ = span
            code = code[:s] + code[e:]
            removed.append(name)
    return code, removed


def guess_broken_function(code: str, functions: list[dict]) -> Optional[str]:
    """Deterministic triage for "which function should the revision target?"
    — tried BEFORE trusting an LLM-supplied target, in this priority order:
      1. a function that opened but never closed (truncation).
      2. a function whose <PLACEHOLDER> marker is still sitting unfilled.
      3. a function the manifest calls for that isn't declared anywhere.
    Returns None if nothing obviously matches a single function (e.g. the
    issue spans multiple functions, or it's a layout/id mismatch).
    """
    names = [f["name"] for f in functions]
    for name in names:
        span = locate_js_function(code, name)
        if span and span[2]:
            return name
    for name in names:
        if placeholder_pattern(name).search(code):
            return name
    for name in names:
        if locate_js_function(code, name) is None and not re.search(rf'\b{re.escape(name)}\s*\(', code):
            return name
    return None


_RESERVED_JS = {
    "class", "function", "const", "let", "var", "return", "if", "else", "for", "while",
    "new", "delete", "typeof", "instanceof", "in", "of", "default", "case", "switch",
    "break", "continue", "this", "null", "true", "false", "void", "yield", "await",
    "async", "import", "export", "extends", "super", "try", "catch", "finally", "throw",
    "do", "with", "static", "get", "set",
}


def id_to_var_name(id_str: str) -> str:
    """Deterministically turn an HTML id (e.g. 'btn-add', '2nd-total') into
    a valid camelCase JS identifier.

    This is done in plain Python, NEVER left to the LLM, because of a bug
    observed in practice: asked to "declare DOM references using the given
    ids", a small model wrote `const btn-add = document.getElementById(...)`
    — a hard JS syntax error, since '-' is the subtraction operator and
    isn't legal inside an identifier. No amount of prompt wording reliably
    fixes this on a weak model; removing the judgment call entirely does.
    """
    parts = [p for p in re.split(r"[^a-zA-Z0-9]+", id_str.strip()) if p]
    if not parts:
        return "_el"
    first, rest = parts[0], parts[1:]
    name = first[:1].lower() + first[1:] if first[:1].isalpha() else "_" + first
    for p in rest:
        name += p[:1].upper() + p[1:]
    if not name or name[0].isdigit():
        name = "_" + name
    if name in _RESERVED_JS:
        name += "El"
    return name


def compute_id_var_map(ids: list[dict]) -> dict[str, str]:
    """id -> unique JS variable name, for every id in the manifest's `ids`
    section. Shared by the skeleton builder and every prompt that needs to
    tell the model which variable already points at which element."""
    id_var_map: dict[str, str] = {}
    for item in ids:
        el_id = item.get("id", "")
        if not el_id:
            continue
        var = id_to_var_name(el_id)
        base_var, n = var, 1
        while var in id_var_map.values():  # two ids collided to the same name — disambiguate
            n += 1
            var = f"{base_var}{n}"
        id_var_map[el_id] = var
    return id_var_map


def build_js_skeleton(ids: list[dict], functions: list[dict]) -> tuple[str, dict[str, str]]:
    """Build the entire app.js scaffold — DOM references AND function
    placeholders — with ZERO LLM calls. This replaces what used to be an
    LLM-authored "skeleton" step, and closes two failure modes seen in a
    real run:
      1. invalid identifiers from hyphenated ids (see `id_to_var_name`).
      2. a model paraphrasing the required `// <PLACEHOLDER id="name"/>`
         marker into some other comment style, which silently defeats the
         self-heal pass — it has nothing to search for if the exact
         marker was never written. Generating it in code means the exact
         marker is now guaranteed to exist for every manifest function,
         every time.
    Returns (skeleton_code, id_to_varname_map); the map is threaded through
    every later prompt so the model always has the exact, correct variable
    names and never has to invent — or mis-invent — them itself.
    """
    id_var_map = compute_id_var_map(ids)
    lines = ["// DOM references (deterministically generated from the manifest's `ids`)"]
    for el_id, var in id_var_map.items():
        lines.append(f"const {var} = document.getElementById('{el_id}');")
    lines.append("")
    lines.append("// Function implementations (filled in below)")
    for f in functions:
        name = f.get("name")
        if name:
            lines.append(f'// <PLACEHOLDER id="{name}"/>')
    return "\n".join(lines) + "\n", id_var_map


# ==========================================
# 6. GENERIC PATCH HELPERS (for html/css and JS issues that aren't one function)
# ==========================================
PATCH_BLOCK_RE = re.compile(
    r"<{3,}\s*SEARCH\s*\r?\n(.*?)\r?\n={3,}\s*\r?\n(.*?)\r?\n>{3,}\s*REPLACE",
    re.DOTALL,
)


def apply_patches(original: str, patch_text: str) -> tuple[str, list[str]]:
    """Apply one or more SEARCH/REPLACE blocks against `original`. Every
    block that matches gets applied; every block that doesn't is reported
    back (truncated) so the caller can decide on a fallback — nothing here
    ever falls back to regenerating the whole file itself.
    """
    blocks = PATCH_BLOCK_RE.findall(patch_text)
    if not blocks:
        return original, ["model returned no SEARCH/REPLACE blocks"]

    code = original
    failures = []
    for search, replace in blocks:
        search, replace = search.strip("\n"), replace.strip("\n")
        if not search:
            continue
        if code.count(search) == 1:
            code = code.replace(search, replace, 1)
            continue
        # Tolerant retry: match ignoring trailing whitespace per line, since
        # small models sometimes drop/add a trailing space that shouldn't
        # matter for locating the block.
        lines = code.split("\n")
        norm_lines = [ln.rstrip() for ln in lines]
        search_lines = [ln.rstrip() for ln in search.split("\n")]
        matches = [
            i for i in range(len(norm_lines) - len(search_lines) + 1)
            if norm_lines[i:i + len(search_lines)] == search_lines
        ]
        if len(matches) == 1:
            i = matches[0]
            lines = lines[:i] + replace.split("\n") + lines[i + len(search_lines):]
            code = "\n".join(lines)
            continue
        failures.append(search[:80].replace("\n", " ⏎ "))
    return code, failures


# ==========================================
# 7. HEURISTICS (free, deterministic pre-checks before spending an LLM call)
# ==========================================
def node_syntax_check(code: str) -> Optional[str]:
    """Best-effort REAL syntax check via `node --check`. Deterministic and
    catches things brace/paren counting structurally cannot — e.g.
    `const btn-add = ...` parses as valid brace/paren-balanced text but is
    a hard syntax error. Silently skipped (returns None) if Node isn't on
    PATH — this tool must keep working with only Ollama + Python
    installed; Node is a bonus check, never a hard requirement."""
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False, encoding="utf-8") as tf:
            tf.write(code)
            tmp_path = tf.name
        result = subprocess.run(["node", "--check", tmp_path], capture_output=True, text=True, timeout=10)
        if result.returncode != 0:
            return f"JavaScript syntax error (node --check): {result.stderr.strip()[:300]}"
    except FileNotFoundError:
        return None  # Node not installed — this check is a bonus, not a requirement
    except Exception:
        return None  # never let a broken bonus check block the pipeline
    finally:
        if tmp_path:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
    return None


def heuristic_precheck(filename: str, code: str, functions: Optional[list[dict]] = None) -> Optional[str]:
    """Catch the most common small-model failure modes for free. Returns a
    feedback string if something is obviously wrong, else None.

    `functions` (the manifest's function list) is optional so existing
    call sites for html/css keep working unchanged, but app.js checks are
    meaningfully stronger when it's supplied — see the "declared but not
    really implemented" check below, which is what should have caught a
    real run where every required function existed only as a comment."""
    if not code.strip():
        return "File is empty."
    if filename.endswith(".js"):
        if "PLACEHOLDER" in code:
            return "A '<PLACEHOLDER .../>' marker is still present — a function was never implemented."
        dupes = find_duplicate_function_names(code)
        if dupes:
            return f"Duplicate function declaration(s): {', '.join(dupes)} — defined more than once."
        bad_ident = re.search(r"\b(?:const|let|var)\s+[A-Za-z_$][\w$]*-[\w$-]*\s*=", code)
        if bad_ident:
            return (f"Invalid JS identifier '{bad_ident.group(0).strip(' =')}' — hyphens aren't legal in "
                     "variable names (a hyphen is the subtraction operator).")
        if functions:
            missing = [f["name"] for f in functions if f.get("name") and locate_js_function(code, f["name"]) is None]
            if missing:
                return (f"Required function(s) not actually implemented: {', '.join(missing)} — declared in the "
                        "manifest but no real (non-comment) function definition was found for them.")
    opens, closes = code.count("{"), code.count("}")
    if opens != closes:
        return f"Unbalanced braces ({opens} '{{' vs {closes} '}}') — file looks truncated."
    if filename.endswith(".js"):
        p_opens, p_closes = code.count("("), code.count(")")
        if p_opens != p_closes:
            return f"Unbalanced parentheses ({p_opens} '(' vs {p_closes} ')') — file looks truncated."
        node_issue = node_syntax_check(code)
        if node_issue:
            return node_issue
    if filename.endswith(".html") and ("<html" not in code.lower() or "</html>" not in code.lower()):
        return "Missing a complete <html>...</html> root — file looks truncated."
    return None


def guard_against_regression(
    run_dir: Path, filename: str, old_code: str, new_code: str, mode: str, functions: list[dict]
) -> tuple[str, str]:
    """The 'never make it worse' safety net for REVISIONS. Never called on
    a true first-time generation (there's no old_code to protect there).
    Runs the same free heuristic the Reviewer uses on both versions; if the
    new version is empty or introduces a problem the old version didn't
    have, the old version is kept. This is what stops an empty or
    corrupted LLM response from ever overwriting a good file on disk."""
    if filename == "app.js" and new_code.strip():
        new_code, removed = dedupe_js_functions(new_code)
        if removed:
            write_log(run_dir, f"Coder (dedupe) - {filename}",
                      f"Collapsed duplicate definitions: {', '.join(sorted(set(removed)))}")
            mode = f"{mode}+dedupe"

    old_issue = heuristic_precheck(filename, old_code, functions)
    new_issue = heuristic_precheck(filename, new_code, functions)

    if not new_code.strip() and old_code.strip():
        write_log(run_dir, f"Coder (patch rejected) - {filename}",
                  "Model returned empty output; keeping the previous version untouched.")
        return old_code, f"{mode}_rejected_empty"

    if new_issue and not old_issue:
        write_log(run_dir, f"Coder (patch rejected) - {filename}",
                  f"New version introduced a new problem ('{new_issue}') the previous version "
                  "didn't have; keeping the previous version.")
        return old_code, f"{mode}_rejected_regression"

    return new_code, mode


# ==========================================
# 8. SHARED LLM-CALL BUILDERS
# ==========================================
def implement_single_function(
    brief: str, func_meta: dict, extra_note: str = "", id_var_map: Optional[dict] = None
) -> str:
    """Generate exactly ONE JS function. Used both for self-healing a
    silently-skipped placeholder and for patch-revising a single broken
    function — the output is small on purpose, which is what keeps a weak
    model from truncating it.

    `id_var_map` (id -> variable name, from `compute_id_var_map`) is passed
    through so the model references the SAME deterministic DOM variable
    names the skeleton already declared, instead of guessing its own
    (potentially invalid, e.g. hyphenated) names for them."""
    note = f"\nISSUE TO FIX: {extra_note}" if extra_note else ""
    var_note = (
        f"\nExisting DOM reference variables — use these EXACT names, do not redeclare them: "
        f"{json.dumps(id_var_map, indent=2)}" if id_var_map else ""
    )
    prompt = (
        f"{CODER_PERSONA}\n"
        f"PROJECT: {brief}\n"
        f"Implement exactly this ONE JavaScript function, nothing else:\n"
        f"{json.dumps(func_meta, indent=2)}{note}{var_note}\n\n"
        "RULES:\n"
        "1. Assume the DOM element references at the top of app.js already exist — reuse them, don't redeclare.\n"
        "2. Use template literals (backticks) for any multi-line string.\n"
        "3. Output ONLY the function body, inside a ``` block. No explanation, "
        "no other functions.\n"
    )
    return extract_code(invoke_text(llm, prompt))


def request_patch(filename: str, brief: str, ctx_str: str, issue: str, instruction: str, current_code: str) -> str:
    """Ask for minimal SEARCH/REPLACE blocks instead of a full file rewrite."""
    prompt = (
        f"{CODER_PERSONA}\n"
        f"PROJECT: {brief}\n"
        f"RELEVANT CONTEXT: {ctx_str}\n\n"
        f"ISSUE with `{filename}`: {issue}\n"
        f"FIX INSTRUCTION: {instruction}\n\n"
        f"CURRENT `{filename}`:\n```\n{current_code}\n```\n\n"
        f"{PATCH_FORMAT_NOTE}\n"
    )
    return invoke_text(llm, prompt)


def full_rewrite(filename: str, brief: str, ctx_str: str, issue: str, instruction: str, current_code: str) -> str:
    """Last-resort-only safety net (final attempt of a file). Regenerates
    the whole file in one shot. As of v3 this can no longer destroy a good
    file even if the model returns garbage/empty — guard_against_regression
    rejects a worse result and keeps the previous version on disk."""
    prompt = (
        f"{CODER_PERSONA}\n"
        f"Fix `{filename}` based on reviewer feedback. Keep everything that "
        "already works — only change what the feedback calls out.\n\n"
        f"RELEVANT CONTEXT: {ctx_str}\n"
        f"ISSUE: {issue}\n"
        f"INSTRUCTION: {instruction}\n"
        f"CURRENT CODE:\n```\n{current_code}\n```\n"
        "Output the entire fixed file. Output ONLY code inside a ``` block.\n"
    )
    return extract_code(invoke_text(llm, prompt))


# ==========================================
# 9. AGENT NODES
# ==========================================
def requirement_agent(state: AgentState):
    """Agent 1 — Scoper. Turns the one-line ask into a concrete, bulleted
    functional spec, AND keeps the one-line ask itself as the reusable
    `project_brief` every other agent will use instead of the full spec."""
    print("\n📝 [Agent 1: Scoper] Drafting requirements...")
    prompt = f"""
{SCOPER_PERSONA}

Analyze this request: "{state['user_input']}"
First, provide a clear **Project Name** and a brief **Project Description** at the very top of your response. 
Then, Draft a concise, bulleted functional requirements list: what interfaces (UI
elements) it needs, and what functionality/behaviour it must have. Ignore
non-functional fluff (performance, security, deployment). Keep it short and
concrete enough that a small local model can build from it.
"""
    reqs = invoke_text(llm, prompt).strip()
    save_artifact(state["run_dir"], "requirements.txt", reqs)
    write_log(state["run_dir"], "Requirements", reqs)
    if len(reqs) < 40 or reqs.lower().startswith(("please provide", "i am ready", "i need more")):
        # Seen in practice: with a blank/near-blank user_input, the model
        # answered with a meta-response asking FOR the request instead of
        # drafting one, and the pipeline cascaded that straight into an
        # empty manifest and a trivial "passing" app. Surface it here too,
        # not just at the manifest stage, so it's obvious which stage the
        # degenerate input entered at.
        msg = f"Requirements draft looks empty/refusal-shaped ({len(reqs)} chars) — check that the app idea wasn't blank."
        print(f"   ⚠️  {msg}")
        write_log(state["run_dir"], "Requirements (WARNING)", msg)
    # The brief is deliberately NOT another LLM call — the user's original
    # one-line ask already IS the concise project description; reusing it
    # keeps every downstream prompt cheap.
    return {"requirements": reqs, "project_brief": state["user_input"].strip()}


def architect_agent(state: AgentState):
    """Agent 2 — Architect/Planner. Produces the 3-section manifest and
    builds the Coder's task stack (one task per output file). This is the
    ONLY agent that reads the full requirements.txt — everyone downstream
    gets the distilled manifest section(s) instead."""
    print("📐 [Agent 2: Architect] Building manifest & task stack...")
    reqs = state["requirements"]

    # Each section is generated independently, with its own retry budget,
    # so a bad JSON parse in one section never wastes the other two calls.
    layout = {}
    for _ in range(MAX_ATTEMPTS):
        p = (
            f"{ARCHITECT_PERSONA}\nReqs: {reqs}\n"
            'Output JSON for the CSS layout strategy only. Format: '
            '{"layout": {"container": "grid/flex rule", "notes": "short layout notes"}}'
        )
        layout = extract_json(invoke_text(llm_json, p))
        if layout.get("layout"):
            break

    ids = {}
    for _ in range(MAX_ATTEMPTS):
        p = (
            f"{ARCHITECT_PERSONA}\nReqs: {reqs}\n"
            "Output JSON listing every interactive HTML element and what it does. "
            'Format: {"ids": [{"id": "btn-submit", "element": "button", "purpose": "submits the form"}]}'
        )
        ids = extract_json(invoke_text(llm_json, p))
        if ids.get("ids"):
            break

    functions = {}
    for _ in range(MAX_ATTEMPTS):
        p = (
            f"{ARCHITECT_PERSONA}\nReqs: {reqs}\n"
            "Output JSON listing every JS function needed. "
            'Format: {"functions": [{"name": "calculateTotal", "params": ["a", "b"], "description": "adds a and b"}]}'
        )
        functions = extract_json(invoke_text(llm_json, p))
        if functions.get("functions"):
            break

    manifest = {
        "layout": layout.get("layout", {}),
        "ids": ids.get("ids", []),
        "functions": functions.get("functions", []),
    }
    save_artifact(state["run_dir"], "manifest.json", json.dumps(manifest, indent=2))
    write_log(state["run_dir"], "Manifest", json.dumps(manifest, indent=2))

    if not manifest["ids"] and not manifest["functions"]:
        # This is exactly what happened in a real run: requirements.txt was
        # itself degenerate (the model asked "please provide the project
        # request" back), the manifest came back empty, and the pipeline
        # went on to build — and PASS — a near-empty app, because an empty
        # spec is trivially satisfied. An empty manifest is never a real
        # PASS-worthy outcome; surface it loudly instead of cascading silently.
        msg = ("Manifest has no ids and no functions after retries — the requirements this was "
               "built from were likely empty or degenerate. The generated app will be trivial.")
        print(f"   ⚠️  {msg}")
        write_log(state["run_dir"], "Architect (WARNING)", msg)

    # Planner's execution queue — one task per file, each declaring exactly
    # which manifest section(s) it's allowed to see, plus a short static
    # purpose note (no extra LLM call needed for this — it's the same for
    # every run) that keeps the Coder/Reviewer prompts focused.
    task_stack = [
        {"file": "index.html", "context_keys": ["layout", "ids"],
         "purpose": "Build the DOM structure using exactly these ids and this layout."},
        {"file": "style.css", "context_keys": ["layout"],
         "purpose": "Style the layout below; must visually support every id's element type."},
        {"file": "app.js", "context_keys": ["ids", "functions"],
         "purpose": "Implement exactly these functions and wire them to exactly these ids."},
    ]

    return {"manifest": manifest, "task_stack": task_stack, "validation_errors": {}, "eval_matrix": {}}


def _generate_app_js(run_dir: Path, brief: str, ctx: dict) -> str:
    """Initial app.js build: DETERMINISTIC skeleton (no LLM call — see
    `build_js_skeleton`), then implement functions in small chunks, then
    self-heal anything the chunk pass silently missed, then dedupe — all
    BEFORE this file is ever handed to the Reviewer.

    v4 change: the skeleton used to be LLM-authored ("declare DOM refs
    using the given ids" + "write exactly `// <PLACEHOLDER .../>`"). In a
    real run the model instead wrote `const btn-add = ...` (invalid JS —
    see `id_to_var_name`) AND paraphrased the placeholder marker into a
    commented-out pseudo-implementation instead of the literal tag —
    which silently defeated the self-heal step below (it searches for the
    exact tag) and left every required function unimplemented while still
    passing review. Removing the LLM from this specific step removes both
    failure modes at the source."""
    funcs = ctx.get("functions", [])
    ids = ctx.get("ids", [])

    print("   ↳ generating skeleton (deterministic — no LLM call)...")
    skeleton, id_var_map = build_js_skeleton(ids, funcs)
    save_artifact(run_dir, "app.js", skeleton)  # persist skeleton before filling it in
    write_log(run_dir, "Coder (deterministic skeleton)",
              f"{skeleton}\n\nid -> variable map: {json.dumps(id_var_map, indent=2)}")

    print("   ↳ implementing functions in chunks...")
    var_map_note = (
        f"\nExisting DOM reference variables — use these EXACT names, do not redeclare them: "
        f"{json.dumps(id_var_map, indent=2)}\n"
    )
    for i in range(0, len(funcs), CHUNK_SIZE):
        chunk = funcs[i:i + CHUNK_SIZE]
        impl_prompt = (
            f"{CODER_PERSONA}\nImplement exactly these functions: {json.dumps(chunk, indent=2)}\n"
            f"{var_map_note}\n"
            "CRITICAL: use template literals (backticks) for any multi-line string, "
            "never double quotes for multi-line strings.\n\n"
            f"{IMPL_FORMAT_NOTE}\n"
        )
        impl_resp = invoke_text(llm, impl_prompt)
        matched_any = False
        for f in chunk:
            name = f["name"]
            pattern = rf'<IMPL\s+id=["\']?{re.escape(name)}["\']?\s*>\s*(.*?)\s*</IMPL>'
            m = re.search(pattern, impl_resp, re.DOTALL | re.IGNORECASE)
            if m:
                matched_any = True
                skeleton = placeholder_pattern(name).sub(
                    lambda _mo: m.group(1).strip().replace("\\", "\\\\"), skeleton
                )
        if not matched_any:
            write_log(run_dir, "Coder (chunk raw — no IMPL match)", impl_resp)
        save_artifact(run_dir, "app.js", skeleton)  # persist after every chunk, not just at the end

    print("   ↳ self-healing any missed functions...")
    for f in remaining_placeholders(skeleton, funcs):
        new_impl = implement_single_function(
            brief, f, "This function was never filled in — implement it now.", id_var_map
        )
        if new_impl.strip():
            skeleton = placeholder_pattern(f["name"]).sub(lambda _mo: new_impl.replace("\\", "\\\\"), skeleton, count=1)
            save_artifact(run_dir, "app.js", skeleton)
            write_log(run_dir, f"Coder (self-heal) - {f['name']}", new_impl)
        else:
            write_log(run_dir, f"Coder (self-heal FAILED) - {f['name']}",
                      "Model returned nothing even for a single function; left as a placeholder for the Reviewer/revision loop to pick up.")

    skeleton, removed = dedupe_js_functions(skeleton)
    if removed:
        write_log(run_dir, "Coder (dedupe)", f"Collapsed duplicate definitions: {', '.join(sorted(set(removed)))}")
        save_artifact(run_dir, "app.js", skeleton)

    return skeleton


def coder_agent(state: AgentState):
    """Agent 3 — Coder. Generates (initial) or patches (revision) the
    current file, then immediately persists it to disk. A revision is
    ALWAYS scoped to what the Reviewer flagged, and is ALWAYS run through
    guard_against_regression before it's allowed to touch disk."""
    run_dir = state["run_dir"]
    task = state["task_stack"][0]
    filename = task["file"]
    attempts = state["attempts"]
    is_revision = attempts > 0
    is_last_attempt = attempts + 1 >= MAX_ATTEMPTS
    manifest = state["manifest"]
    ctx = focused_context(manifest, task["context_keys"])
    if filename == "app.js":
        # Give every app.js prompt the exact, already-correct variable names
        # instead of leaving the model to invent (and potentially mis-invent,
        # e.g. with hyphens) its own — see id_to_var_name / compute_id_var_map.
        ctx = dict(ctx)
        ctx["dom_variable_names"] = compute_id_var_map(manifest.get("ids", []))
    ctx_str = json.dumps(ctx, indent=2)
    brief = state["project_brief"]

    print(f"\n💻 [Agent 3: Coder] {'Revising' if is_revision else 'Writing'} "
          f"{filename} (attempt {attempts + 1}/{MAX_ATTEMPTS})...")

    if not is_revision:
        if filename == "app.js":
            code = _generate_app_js(run_dir, brief, ctx)
        else:
            prompt = (
                f"{CODER_PERSONA}\nWrite `{filename}`.\n"
                f"PROJECT: {brief}\n"
                f"TASK: {task['purpose']}\n"
                f"RELEVANT CONTEXT: {ctx_str}\n\n"
                "RULES:\n"
                "- If HTML: link style.css and app.js, no inline styles or scripts.\n"
                "- Output ONLY raw code inside a ``` block.\n"
            )
            code = extract_code(invoke_text(llm, prompt))
        mode = "initial"

    else:
        current_code = load_artifact(run_dir, filename)
        fb = state["feedback"]  # {"issue": ..., "instruction": ..., "target": ...}
        issue, instruction = fb.get("issue", ""), fb.get("instruction", "")
        target = None

        if filename == "app.js":
            target = fb.get("target") or None
            if target not in [f["name"] for f in manifest.get("functions", [])]:
                target = guess_broken_function(current_code, manifest.get("functions", []))

        if target:
            print(f"   ↳ targeted function patch: {target}()")
            func_meta = next((f for f in manifest["functions"] if f["name"] == target), {"name": target})
            id_var_map = compute_id_var_map(manifest.get("ids", []))
            new_impl = implement_single_function(brief, func_meta, instruction or issue, id_var_map)
            code = splice_js_function(current_code, target, new_impl) if new_impl.strip() else current_code
            mode = f"function_patch:{target}"
        elif issue or instruction:
            print("   ↳ requesting scoped SEARCH/REPLACE patch...")
            patch_text = request_patch(filename, brief, ctx_str, issue, instruction, current_code)
            code, failures = apply_patches(current_code, patch_text)
            if not failures:
                mode = "search_replace"
            elif is_last_attempt:
                print("   ↳ patch failed to apply and this is the final attempt — "
                      "trying a full rewrite (guarded — cannot make things worse).")
                code = full_rewrite(filename, brief, ctx_str, issue, instruction, current_code)
                mode = "last_resort_full_rewrite"
            else:
                write_log(run_dir, f"Coder (patch — unmatched blocks) - {filename}", "\n".join(failures))
                code, mode = current_code, "search_replace_partial_noop"
        else:
            # No target AND no actionable issue/instruction text — this is
            # what an empty/degenerate Reviewer response looks like. Rather
            # than send the Coder off to "fix" an unspecified problem (that
            # speculative-edit path is exactly what produced duplicated
            # functions previously), leave the file untouched and let the
            # attempt counter do its job.
            print("   ↳ no actionable feedback from the Reviewer — leaving the file unchanged.")
            write_log(run_dir, f"Coder (no actionable feedback) - {filename}",
                      "Reviewer FAILed the file but gave no issue/instruction/target; skipping this "
                      "revision rather than editing speculatively.")
            code, mode = current_code, "skipped_no_feedback"

        code, mode = guard_against_regression(run_dir, filename, current_code, code, mode, manifest.get("functions", []))

    save_artifact(run_dir, filename, code)
    write_log(run_dir, f"Coder ({mode}) - {filename}", code)
    return {"last_revision_mode": mode}


def reviewer_agent(state: AgentState):
    """Agent 4 — Reviewer. Always audits the durable on-disk copy. Runs a
    free heuristic pass first; only calls the LLM if that pass is clean.
    Feedback is structured (issue + instruction + best-guess target) so the
    Coder can patch precisely instead of guessing from one vague sentence.

    If the LLM review comes back empty/unparseable even after a retry (the
    context-overflow symptom this run's bug report showed), that is NOT
    treated as a confident FAIL with blank feedback — it falls back to
    trusting the heuristic pass that already succeeded, rather than
    kicking off a speculative, potentially destructive revision."""
    run_dir = state["run_dir"]
    task = state["task_stack"][0]
    filename = task["file"]
    attempts = state["attempts"]
    code = load_artifact(run_dir, filename)
    functions = state["manifest"].get("functions", [])

    print(f"🔎 [Agent 4: Reviewer] Auditing {filename}...")

    heuristic_issue = heuristic_precheck(filename, code, functions)
    if heuristic_issue:
        status = "FAIL"
        target = guess_broken_function(code, functions) if filename == "app.js" else None
        fb = {"issue": heuristic_issue, "instruction": "Fix exactly this, nothing else.", "target": target}
        write_log(run_dir, f"Reviewer (heuristic) - {filename}", f"{heuristic_issue} | target={target}")
    else:
        ctx = focused_context(state["manifest"], task["context_keys"])
        prompt = (
            f"{REVIEWER_PERSONA}\n\n"
            f"Review `{filename}` against the relevant spec below.\n"
            f"PROJECT: {state['project_brief']}\n"
            f"RELEVANT MANIFEST SECTION(S): {json.dumps(ctx, indent=2)}\n\n"
            f"CODE:\n```\n{code}\n```\n\n"
            "Fail it if ANY of these are true:\n"
            "1. It ends abruptly / has unclosed tags or brackets (truncation).\n"
            "2. It drifts from the manifest above (wrong ids, missing/extra functions, wrong layout).\n"
            "3. There's an obvious syntax or logic bug.\n\n"
            "Respond with ONLY this JSON, nothing else:\n"
            '{"status": "PASS", "issue": "", "instruction": "", "target": ""}\n'
            "or\n"
            '{"status": "FAIL", "issue": "<what is wrong>", '
            '"instruction": "<one specific, actionable sentence on what to fix>", '
            '"target": "<function name at fault, or empty if not one specific function>"}\n'
        )
        raw = invoke_text(llm_json, prompt, retries=1)
        if not raw.strip():
            # Even the retry came back empty — almost certainly a
            # context-window overflow on this (possibly large) file rather
            # than a real verdict. Trust the heuristic pass that already
            # succeeded instead of fabricating a FAIL with nothing
            # actionable in it.
            status = "PASS"
            fb = {"issue": "", "instruction": "", "target": None}
            write_log(run_dir, f"Reviewer (LLM empty — trusting heuristic) - {filename}",
                      "No verdict after retry (likely context-window overflow); "
                      "accepted on the strength of the heuristic pass alone.")
        else:
            parsed = extract_json(raw)
            status = str(parsed.get("status", "")).upper()
            if status not in ("PASS", "FAIL"):
                status = "PASS" if "PASS" in raw[:30].upper() else "FAIL"
            fb = {
                "issue": parsed.get("issue", "") or ("" if status == "PASS" else raw.strip()[:200]),
                "instruction": parsed.get("instruction", ""),
                "target": parsed.get("target") or None,
            }
            write_log(run_dir, f"Reviewer (LLM) - {filename}", f"{status}: {fb['issue']} | target={fb['target']}")

    finished = status == "PASS" or (attempts + 1 >= MAX_ATTEMPTS)

    if finished:
        ok = status == "PASS"
        print(f"   {'✅' if ok else '⚠️ '} {filename}: {'PASS' if ok else 'FAIL (max attempts reached)'}")
        eval_entry = {filename: {
            "attempts": attempts + 1,
            "status": status,
            "chars": len(code),
            "last_action": state.get("last_revision_mode", "initial"),
        }}
        errors = {} if ok else {filename: fb["issue"]}
        return {
            "feedback": {},
            "attempts": 0,
            "task_stack": state["task_stack"][1:],   # pop — move to next file
            "validation_errors": errors,
            "eval_matrix": eval_entry,
        }

    print(f"   ❌ Issues found: {fb['issue'][:80]}")
    return {"feedback": fb, "attempts": attempts + 1}


# ==========================================
# 10. ORCHESTRATION & GRAPH ROUTING
# ==========================================
def route_review(state: AgentState):
    if not state["feedback"]:
        return "coder" if state["task_stack"] else "end"
    return "coder"


workflow = StateGraph(AgentState)
workflow.add_node("scoper", requirement_agent)
workflow.add_node("architect", architect_agent)
workflow.add_node("coder", coder_agent)
workflow.add_node("reviewer", reviewer_agent)

workflow.set_entry_point("scoper")
workflow.add_edge("scoper", "architect")
workflow.add_edge("architect", "coder")
workflow.add_edge("coder", "reviewer")
workflow.add_conditional_edges("reviewer", route_review, {"coder": "coder", "end": END})

app = workflow.compile()


# ==========================================
# 11. EXECUTION BOOTSTRAP
# ==========================================
if __name__ == "__main__":
    print("=" * 70)
    print("  Offline Agentic SDLC — Vanilla Web App Generator (Ollama)")
    print("=" * 70)
    user_input = input("\nWhat web application do you want to build?\n> ").strip()
    while not user_input:
        # A blank submission here is what produced a run with an empty
        # manifest and a trivial-but-"passing" app in practice — refuse to
        # proceed instead of letting it cascade silently downstream.
        print("Please describe the app you want to build — it can't be empty.")
        user_input = input("> ").strip()

    run_dir = Path.cwd() / "SDLC_Workspace" / datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir.mkdir(parents=True, exist_ok=True)
    print(f"\n🚀 Workspace: {run_dir}")

    final_state = app.invoke({
        "user_input": user_input,
        "run_dir": run_dir,
        "attempts": 0,
        "feedback": {},
        "last_revision_mode": "initial",
        "validation_errors": {},
        "eval_matrix": {},
    })

    eval_matrix = final_state.get("eval_matrix", {})
    errors = final_state.get("validation_errors", {})
    save_artifact(run_dir, "evaluation.json", json.dumps({"files": eval_matrix, "unresolved": errors}, indent=2))

    print("\n" + "=" * 70)
    if errors:
        print(f"⚠️  Done — {len(errors)} file(s) still failing after {MAX_ATTEMPTS} attempts:")
        for f, msg in errors.items():
            print(f"   - {f}: {msg[:100]}")
    else:
        print("🎉 All files passed review.")
    print(f"📁 Output dir:   {run_dir}")
    print(f"📊 Evaluation:   {run_dir / 'evaluation.json'}")
    print(f"🧾 Full log:     {run_dir / 'execution_log.txt'}")
    print("=" * 70)
