import os
import re
import json
import operator
from pathlib import Path
from datetime import datetime
from typing import TypedDict, Annotated

from langgraph.graph import StateGraph, END
from langchain_ollama import ChatOllama

# ==========================================
# 1. INITIALIZATION & CONFIGURATION
# ==========================================
llm = ChatOllama(
    model="gemma4:e2b",
    base_url="http://localhost:11434",
    num_predict=3000,
    temperature=0.1
)


# ==========================================
# 2. STATE & MEMORY MANAGEMENT
# ==========================================
class AgentState(TypedDict):
    user_input: str
    run_dir: Path
    requirements: str
    manifest: dict
    file_system: dict
    task_stack: list[dict]
    current_task: dict
    feedback: str
    attempts: int
    validation_errors: Annotated[dict, operator.ior]


def write_log(run_dir: Path, step: str, details: str):
    """Keeps the log of execution to track down/monitor working flow & failure."""
    log_file = run_dir / "execution_log.txt"
    timestamp = datetime.now().strftime("%H:%M:%S")
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"\n[{timestamp}] === {step.upper()} ===\n")
        f.write(str(details) + "\n")
        f.write("-" * 80 + "\n")


def extract_json(text: str) -> dict:
    """Helper to salvage JSON from small models."""
    clean_text = re.sub(r"```(?:json)?", "", text, flags=re.IGNORECASE).replace("```", "")
    start = clean_text.find('{')
    end = clean_text.rfind('}')
    if start != -1 and end != -1:
        try:
            return json.loads(clean_text[start:end + 1], strict=False)
        except Exception as e:
            print(f"   [!] JSON Parse Error: {e}")
            return {}
    return {}


# ==========================================
# 3. AGENT NODES
# ==========================================

def requirement_agent(state: AgentState):
    print("\n📝 [Agent 1: Scoper] Analyzing Requirements...")
    persona = "You are a professional Project Requirement Analyzer, who evaluates the user's request and drafts a detailed functional requirements document, and have a great experience in scoping Vanilla JS web apps."

    prompt = f"""
    {persona}

    Analyze this request: "{state['user_input']}"
    Draft a concise, bulleted list of functional requirements (what interfaces, and what functionality the software should be capable of).
    Ignore non-functional fluff. Keep it simple and focused.
    """
    reqs = llm.invoke(prompt).content.strip()
    write_log(state["run_dir"], "Requirements", reqs)
    (state["run_dir"] / "req.txt").write_text(reqs, encoding="utf-8")

    return {"requirements": reqs}


def architect_agent(state: AgentState):
    print("📐 [Agent 2: Architect] Building Manifest & Task Stack...")
    persona = "You are a professional Project Architect/Planner, who structures the application blueprint and creates a strict JSON manifest, and have a great experience in scalable web architecture."

    # FIX 1: Robust Retry Loops for all Manifest Sections
    layout_data = {}
    for _ in range(3):
        p_layout = f"{persona}\nReqs: {state['requirements']}\nOutput JSON for CSS layout strategy. Format: {{\"layout\": {{\"container\": \"grid/flex rule\"}}}}"
        layout_data = extract_json(llm.invoke(p_layout).content)
        if layout_data.get("layout"): break

    id_data = {}
    for _ in range(3):
        p_ids = f"{persona}\nReqs: {state['requirements']}\nOutput JSON for required HTML IDs. Format: {{\"ids\": [\"btn-submit\", \"input-name\"]}}"
        id_data = extract_json(llm.invoke(p_ids).content)
        if id_data.get("ids"): break

    func_data = {}
    for _ in range(3):
        p_funcs = f"{persona}\nReqs: {state['requirements']}\nOutput JSON for JS functions. Format: {{\"functions\": [{{\"name\": \"calc\", \"description\": \"does math\"}}]}}"
        func_data = extract_json(llm.invoke(p_funcs).content)
        if func_data.get("functions"): break

    manifest = {
        "layout": layout_data.get("layout", {}),
        "ids": id_data.get("ids", []),
        "functions": func_data.get("functions", [])
    }

    manifest_json = json.dumps(manifest, indent=2)
    write_log(state["run_dir"], "Manifest", manifest_json)
    (state["run_dir"] / "manifest.json").write_text(manifest_json, encoding="utf-8")

    task_stack = [
        {"file": "index.html", "context_keys": ["layout", "ids"]},
        {"file": "style.css", "context_keys": ["layout"]},
        {"file": "app.js", "context_keys": ["ids", "functions"]}
    ]

    return {
        "manifest": manifest,
        "task_stack": task_stack,
        "file_system": {"index.html": "", "style.css": "", "app.js": ""},
        "validation_errors": {}
    }


def coder_agent(state: AgentState):
    current_task = state["task_stack"][0]
    current_file = current_task["file"]
    is_revision = state["attempts"] > 0
    manifest = state["manifest"]

    persona = "You are a professional Coder, who writes highly optimized Vanilla HTML/CSS/JS, and have a great experience in building stable web apps with clean, bug-free code."

    print(f"\n💻 [Agent 3: Coder] Writing {current_file} (Attempt {state['attempts'] + 1}/3)...")

    focused_context = {key: manifest[key] for key in current_task["context_keys"]}
    context_str = json.dumps(focused_context, indent=2)

    if is_revision:
        prompt = f"""
        {persona}
        Fix `{current_file}` based on Reviewer feedback.
        RELEVANT CONTEXT: {context_str}
        FEEDBACK: {state['feedback']}
        CURRENT CODE:
        ```
        {state['file_system'][current_file]}
        ```
        Output the entirely fixed file. Output ONLY code inside ``` blocks.
        """
        response = llm.invoke(prompt).content

    elif current_file == "app.js":
        print("   ↳ Generating JS Skeleton...")
        # FIX 2: Root-Level Placeholders to prevent JS "Inception"
        skel_prompt = f"""
        {persona}
        Write a JS skeleton. 
        CONTEXT: {context_str}
        RULES:
        1. Set up global variables and DOM references using the provided IDs.
        2. DO NOT write any function wrappers or logic.
        3. For every required function, just write this exactly on a new line: // <PLACEHOLDER id="functionName"/>
        Output ONLY javascript inside ``` blocks.
        """
        skeleton_resp = llm.invoke(skel_prompt).content
        skel_match = re.search(r"```(?:javascript|js)?\n?(.*?)\n?```", skeleton_resp, re.DOTALL)
        skeleton = skel_match.group(1).strip() if skel_match else skeleton_resp.strip()

        print("   ↳ Implementing functions in chunks...")
        funcs = manifest["functions"]
        for i in range(0, len(funcs), 3):
            chunk = funcs[i:i + 3]
            names = [f["name"] for f in chunk]

            # FIX 3: Enforcing ES6 Template Literals
            impl_prompt = f"""
            {persona}
            Implement these functions: {json.dumps(chunk, indent=2)}.

            CRITICAL RULES:
            1. You MUST use Template Literals (backticks `) for ANY multi-line strings. NEVER use double quotes (") for multi-line strings to avoid SyntaxErrors.

            Format each function exactly like this:
            <IMPL id="functionName">
            function functionName(args) {{
                // actual logic here
            }}
            </IMPL>
            """
            impl_resp = llm.invoke(impl_prompt).content

            for name in names:
                pattern = rf'<IMPL id="{name}">\s*(.*?)\s*</IMPL>'
                impl_match = re.search(pattern, impl_resp, re.DOTALL | re.IGNORECASE)
                if impl_match:
                    func_code = impl_match.group(1).strip()
                    # Replaces the entire root placeholder with the completed function block
                    skeleton = re.sub(rf'//\s*<PLACEHOLDER id=["\']?{name}["\']?\s*/>', func_code, skeleton,
                                      flags=re.IGNORECASE)

        response = f"```javascript\n{skeleton}\n```"

    else:
        prompt = f"""
        {persona}
        Write `{current_file}`.
        PROJECT REQS: {state['requirements']}
        FOCUSED CONTEXT: {context_str}

        CRITICAL RULES:
        - If HTML, link `style.css` and `app.js`. DO NOT write inline styles or scripts.
        - Output ONLY raw code inside ``` blocks.
        """
        response = llm.invoke(prompt).content

    match = re.search(r"```(?:[a-zA-Z]+)?\n?(.*?)\n?```", response, re.DOTALL)
    clean_code = match.group(1).strip() if match else response.strip()

    fs = state["file_system"].copy()
    fs[current_file] = clean_code
    write_log(state["run_dir"], f"Coder Output - {current_file}", clean_code)

    return {"file_system": fs}


def reviewer_agent(state: AgentState):
    current_task = state["task_stack"][0]
    current_file = current_task["file"]
    code = state["file_system"][current_file]
    attempts = state["attempts"] + 1

    persona = "You are a professional Code Reviewer and QA Bug Finder, who evaluates written code against strict requirements, and have a great experience in finding UI/logic flaws and syntax errors."

    print(f"🔎 [Agent 4: Reviewer] Auditing {current_file}...")

    focused_context = {key: state["manifest"][key] for key in current_task["context_keys"]}

    # FIX 4: Hostile Anti-Truncation Rules
    prompt = f"""
    {persona}

    Review this code for `{current_file}`. 
    It must strictly follow this RELEVANT CONTEXT: {json.dumps(focused_context, indent=2)}

    CODE:
    ```
    {code}
    ```
    CRITICAL CHECKS (FAIL IF ANY ARE TRUE):
    1. Truncation (HTML): Does the file end without `</html>` or `</body>`? (FAIL IT)
    2. Truncation (CSS): Does the file end with an unclosed bracket `}}` or incomplete property? (FAIL IT)
    3. Leftover Stubs (JS): Search the code for the exact word "PLACEHOLDER". If `// <PLACEHOLDER` exists anywhere in the code, it means the coder missed it. (FAIL IT)
    4. Syntax (JS): Look specifically for unterminated string literals (multi-line strings using " instead of `). (FAIL IT)
    5. Illegal Blocks (HTML): Are there `<style>` or `<script>` blocks with logic inside them? HTML must ONLY contain structure and links to external files. (FAIL IT)

    If 100% perfect, output ONLY the word "PASS".
    If there is an issue, return what the problem is, the line/part, and what to do with it. Do not say PASS.
    """
    feedback = llm.invoke(prompt).content.strip()
    write_log(state["run_dir"], f"Reviewer Feedback - {current_file}", feedback)

    # Failsafe for truncated or empty LLM feedback
    if not feedback:
        feedback = "FAIL: The Reviewer failed to generate an analysis. The code is likely truncated or severely malformed. Rewrite the file completely."

    if "PASS" in feedback[:15].upper() or attempts >= 3:
        print(f"   ✅ {current_file} Passed (or max retries hit)!")

        file_path = state["run_dir"] / current_file
        file_path.write_text(code, encoding="utf-8")

        if "PASS" not in feedback[:15].upper():
            state["validation_errors"][current_file] = feedback

        return {
            "feedback": "",
            "attempts": 0,
            "task_stack": state["task_stack"][1:]
        }

    print(f"   ❌ Issues found: {feedback[:60]}...")
    return {"feedback": feedback, "attempts": attempts}


# ==========================================
# 4. ORCHESTRATION & GRAPH ROUTING
# ==========================================
def route_review(state: AgentState):
    if state["feedback"] == "":
        if len(state["task_stack"]) > 0:
            return "coder"
        return "end"
    return "coder"


workflow = StateGraph(AgentState)
workflow.add_node("scoper", requirement_agent)
workflow.add_node("architect", architect_agent)
workflow.add_node("coder", coder_agent)
workflow.add_node("reviewer", reviewer_agent)

workflow.set_entry_point("scoper")
workflow.add_edge("scoper", "architect")
workflow.add_edge("architect", "coder")
workflow.add_edge("coder", "reviewer")
workflow.add_conditional_edges("reviewer", route_review, {
    "coder": "coder",
    "end": END
})

app = workflow.compile()

# ==========================================
# 5. EXECUTION BOOTSTRAP
# ==========================================
if __name__ == "__main__":
    user_input = input("\nWhat web application do you want to build?\n> ")

    run_dir = Path.cwd() / "SDLC_Workspace" / datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n🚀 Workspace created: {run_dir}")

    final_state = app.invoke({
        "user_input": user_input,
        "run_dir": run_dir,
        "attempts": 0,
        "feedback": "",
        "validation_errors": {}
    })

    errors = final_state.get("validation_errors", {})
    if errors:
        (run_dir / "validation.json").write_text(json.dumps(errors, indent=2), encoding="utf-8")
        print(f"\n⚠️ Workflow complete with {len(errors)} unresolved files (saved to validation.json).")
    else:
        print(f"\n🎉 Workflow Complete! Files perfectly saved to {run_dir}")