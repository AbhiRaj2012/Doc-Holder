import re
from pathlib import Path
from datetime import datetime
from typing import TypedDict, Annotated
import operator

from langgraph.graph import StateGraph, END
from langchain_ollama import ChatOllama

# Initialize LLM for local execution
llm = ChatOllama(
    model="gemma4:e2b",
    num_predict=2048,
    num_ctx=4096,
    temperature=0.1
)


# ==========================================
# 1. LOGGER UTILITY
# ==========================================
def write_log(run_dir: Path, step: str, details: str):
    log_file = run_dir / "execution_log.txt"
    timestamp = datetime.now().strftime("%H:%M:%S")
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"\n[{timestamp}] === {step.upper()} ===\n")
        f.write(str(details) + "\n")
        f.write("-" * 80 + "\n")


# ==========================================
# 2. ENHANCED STATE DEFINITION
# ==========================================
class AgentState(TypedDict):
    user_input: str
    requirements: str
    project_manifest: str  # Global contract for IDs, Classes, and Data schemas
    run_dir: Path
    file_system: Annotated[dict, operator.ior]
    pending_files: list[str]
    feedback: str  # Feedback string from the Code Reviewer
    review_attempts: int  # Loop protection counter
    iterations: int


# ==========================================
# 3. NODES
# ==========================================
def requirement_node(state: AgentState):
    print("🔍 Generating requirements...")
    prompt = f"""
    Convert this request into concise requirements for a simple web app.
    Use ONLY HTML, CSS, and Vanilla JavaScript across separate files.
    REQUEST: {state['user_input']}
    """
    write_log(state["run_dir"], "Requirement Node - PROMPT", prompt)

    requirements = ""
    for chunk in llm.stream(prompt):
        requirements += chunk.content
    requirements = requirements.strip()

    write_log(state["run_dir"], "Requirement Node - OUTPUT", requirements)
    (state["run_dir"] / "requirements.txt").write_text(requirements, encoding="utf-8")
    return {"requirements": requirements}


def architect_node(state: AgentState):
    print("\n📐 [Architect] Creating Project Manifest & Scaffolding...")

    # Prompt the LLM to design a lightweight contract ensuring structural alignment
    manifest_prompt = f"""
    Based on these requirements, create a technical contract (Manifest) specifying:
    1. DOM Element IDs and Classes that HTML, CSS, and JS must share.
    2. Data structure if localStorage is used.

    REQUIREMENTS:
    {state['requirements']}
    """
    manifest = llm.invoke(manifest_prompt).content.strip()
    write_log(state["run_dir"], "Architect Node - MANIFEST", manifest)

    initial_files = {
        "index.html": "<!DOCTYPE html>\n<html lang='en'>\n<head>\n  <meta charset='UTF-8'>\n  <title>App</title>\n  <link rel='stylesheet' href='style.css'>\n</head>\n<body>\n  <div id='app'></div>\n  <script src='script.js'></script>\n</body>\n</html>",
        "style.css": "/* Global Styles */\nbody { font-family: sans-serif; padding: 20px; }",
        "script.js": "// Main Logic"
    }

    return {
        "project_manifest": manifest,
        "file_system": initial_files,
        "pending_files": ["index.html", "style.css", "script.js"],
        "review_attempts": 0,
        "feedback": "",
        "iterations": 0
    }


def editor_node(state: AgentState):
    current_file = state["pending_files"][0]
    base_code = state["file_system"][current_file]

    print(f"\n💻 [Editor] Drafting {current_file} (Streaming)...")

    # Bundle project context so files don't mismatch
    project_context = "".join([f"\n--- {f.upper()} ---\n{c}\n" for f, c in state["file_system"].items()])

    prompt = f"""
        You are an expert web developer. Write or fix the code for {current_file}.

        PROJECT MANIFEST (Contract):
        {state['project_manifest']}

        CURRENT PROJECT FILES:
        {project_context}

        CRITICAL INSTRUCTION: 
        Do not guess DOM IDs or Classes. You MUST strictly cross-reference the CURRENT PROJECT FILES above. Ensure every JavaScript event listener exactly matches the IDs already established in the HTML.

        PREVIOUS REVIEWER FEEDBACK (Fix these issues if any):
        {state['feedback']}

        Provide ONLY the complete code for {current_file}. No markdown code fences, no explanations.
        """
    write_log(state["run_dir"], f"Editor Node [{current_file}] - PROMPT", prompt)

    raw_output = ""
    try:
        for chunk in llm.stream(prompt):
            raw_output += chunk.content
            print(chunk.content, end="", flush=True)
    except Exception as e:
        print(f"\n   [!] Streaming interrupted: {e}")

    raw_output = raw_output.strip()
    print("\n")

    fence_match = re.search(r"```(?:[a-zA-Z]+)?\n?(.*?)\n?```", raw_output, re.DOTALL)
    clean_code = fence_match.group(1).strip() if fence_match else raw_output.strip()

    updated_fs = state["file_system"].copy()
    if len(clean_code) > 10:
        updated_fs[current_file] = clean_code

    return {
        "file_system": updated_fs,
        "iterations": state["iterations"] + 1
    }


def reviewer_node(state: AgentState):
    current_file = state["pending_files"][0]
    file_code = state["file_system"][current_file]

    print(f"\n🔎 [Reviewer] Auditing {current_file}...")

    # Bundle project context so the reviewer can cross-reference files
    project_context = "".join([f"\n--- {f.upper()} ---\n{c}\n" for f, c in state["file_system"].items()])

    prompt = f"""
        Review this code for {current_file} against the project manifest and requirements. 
        Look for functional bugs, broken DOM IDs, missing CSS classes, event listener mismatches, or syntax errors.

        REQUIREMENTS: {state['requirements']}
        MANIFEST: {state['project_manifest']}

        FULL PROJECT CONTEXT (Cross-reference these files to ensure IDs match):
        {project_context}

        CODE TO REVIEW:
        {file_code}

        If the code is correct and follows the manifest, reply with ONLY the word "PASS". 
        If there are bugs or structural mismatches, briefly explain what needs fixing.
        """

    review_output = llm.invoke(prompt).content.strip()
    write_log(state["run_dir"], f"Reviewer Node [{current_file}]", review_output)

    if "PASS" in review_output.upper() or state["review_attempts"] >= 2:
        print(f"   ✅ {current_file} passed review.")
        return {
            "pending_files": state["pending_files"][1:],
            "feedback": "",
            "review_attempts": 0
        }
    else:
        print(f"   ❌ Issues found in {current_file}. Routing back to Editor.")
        return {
            "feedback": review_output,
            "review_attempts": state["review_attempts"] + 1
        }


def saver_node(state: AgentState):
    print("\n💾 [Saver] Writing verified files to disk...")
    for filename, content in state["file_system"].items():
        file_path = state["run_dir"] / filename
        file_path.write_text(content, encoding="utf-8")
        print(f"   💾 Saved: {file_path}")
    return {}


# ==========================================
# 4. CONDITIONAL ROUTER & GRAPH
# ==========================================
def should_continue(state: AgentState):
    if len(state["pending_files"]) > 0:
        # If the reviewer rejected the file, loop back to editor; otherwise move to next file
        return "continue"
    return "save"


workflow = StateGraph(AgentState)
workflow.add_node("requirements", requirement_node)
workflow.add_node("architect", architect_node)
workflow.add_node("editor", editor_node)
workflow.add_node("reviewer", reviewer_node)
workflow.add_node("saver", saver_node)

workflow.set_entry_point("requirements")
workflow.add_edge("requirements", "architect")
workflow.add_edge("architect", "editor")
workflow.add_edge("editor", "reviewer")

# Conditional loop routes back to editor if file failed review, or proceeds to next file/saver
workflow.add_conditional_edges(
    "reviewer",
    should_continue,
    {
        "continue": "editor",
        "save": "saver"
    }
)

workflow.add_edge("saver", END)
app = workflow.compile()

# ==========================================
# 5. EXECUTION
# ==========================================
if __name__ == "__main__":
    user_input = input("\nWhat application do you want to build?\n> ")

    base_dir = Path.cwd() / "SDLC_Runs"
    run_dir = base_dir / datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir.mkdir(parents=True, exist_ok=True)

    write_log(run_dir, "SYSTEM", f"Starting build for: '{user_input}'\nModel: gemma4:12b")

    print(f"\n🚀 Starting build in: {run_dir}")
    app.invoke({"user_input": user_input, "run_dir": run_dir})
    print(f"\n🎉 Build Complete! Check execution_log.txt in {run_dir}")