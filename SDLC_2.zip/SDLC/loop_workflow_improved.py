import os
import re
import json
from pathlib import Path
from datetime import datetime
from typing import TypedDict, Annotated, Optional
import operator

from langgraph.graph import StateGraph, END
from langchain_ollama import ChatOllama

# ==========================================
# 0. SETUP & UTILITIES
# ==========================================
# Increased num_ctx to prevent context overflow cascades
llm = ChatOllama(
    model="gemma4:e2b",
    num_predict=2048,
    num_ctx=24576,
    temperature=0.1
)


def invoke_text(client: ChatOllama, prompt: str, retries: int = 1) -> str:
    """Retry on genuinely empty responses to prevent empty-file cascades."""
    content = ""
    for _ in range(retries + 1):
        content = client.invoke(prompt).content
        if content and content.strip():
            return content
    return content


def write_log(run_dir: Path, step: str, details: str):
    log_file = run_dir / "execution_log.txt"
    timestamp = datetime.now().strftime("%H:%M:%S")
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"\n[{timestamp}] === {step.upper()} ===\n")
        f.write(str(details) + "\n")
        f.write("-" * 80 + "\n")


# ==========================================
# 1. HEURISTICS & PATCHING
# ==========================================
def heuristic_precheck(filename: str, code: str) -> Optional[str]:
    """Free, deterministic checks to run before spending an LLM call."""
    if not code.strip():
        return "File is empty."
    opens, closes = code.count("{"), code.count("}")
    if opens != closes:
        return f"Unbalanced braces ({opens} '{{' vs {closes} '}}') — file looks truncated."
    if filename.endswith(".js"):
        p_opens, p_closes = code.count("("), code.count(")")
        if p_opens != p_closes:
            return f"Unbalanced parentheses ({p_opens} '(' vs {p_closes} ')') — file looks truncated."
    if filename.endswith(".html") and ("<html" not in code.lower() or "</html>" not in code.lower()):
        return "Missing a complete <html>...</html> root — file looks truncated."
    return None


PATCH_BLOCK_RE = re.compile(
    r"<{3,}\s*SEARCH\s*\r?\n(.*?)\r?\n={3,}\s*\r?\n(.*?)\r?\n>{3,}\s*REPLACE",
    re.DOTALL,
)


def apply_patches(original: str, patch_text: str) -> tuple[str, list[str]]:
    """Applies SEARCH/REPLACE blocks to avoid full file rewrites."""
    blocks = PATCH_BLOCK_RE.findall(patch_text)
    if not blocks:
        return original, ["No SEARCH/REPLACE blocks found."]

    code = original
    failures = []
    for search, replace in blocks:
        search, replace = search.strip("\n"), replace.strip("\n")
        if not search:
            continue
        if code.count(search) == 1:
            code = code.replace(search, replace, 1)
            continue

        # Tolerant fallback logic for whitespace mismatches
        lines, search_lines = code.split("\n"), search.split("\n")
        norm_lines, norm_search = [ln.rstrip() for ln in lines], [ln.rstrip() for ln in search_lines]
        matches = [i for i in range(len(norm_lines) - len(norm_search) + 1) if
                   norm_lines[i:i + len(norm_search)] == norm_search]

        if len(matches) == 1:
            i = matches[0]
            lines = lines[:i] + replace.split("\n") + lines[i + len(search_lines):]
            code = "\n".join(lines)
            continue
        failures.append(search[:80].replace("\n", " ⏎ "))
    return code, failures


# ==========================================
# 2. STATE DEFINITION
# ==========================================
class AgentState(TypedDict):
    user_input: str
    requirements: str
    project_manifest: str
    run_dir: Path
    file_system: Annotated[dict, operator.ior]
    pending_files: list[str]
    feedback: str
    review_attempts: int
    iterations: int


# ==========================================
# 3. NODES
# ==========================================
def requirement_node(state: AgentState):
    print("🔍 Generating requirements...")
    prompt = f"""
    Convert this request into concise requirements for a simple web app.
    Use ONLY HTML, CSS, and Vanilla JavaScript across separate files.
    REQUEST: {state['user_input']}
    """
    requirements = invoke_text(llm, prompt).strip()
    write_log(state["run_dir"], "Requirement Node", requirements)
    (state["run_dir"] / "requirements.txt").write_text(requirements, encoding="utf-8")
    return {"requirements": requirements}


def architect_node(state: AgentState):
    print("\n📐 [Architect] Creating Project Manifest & Scaffolding...")
    manifest_prompt = f"""
    Based on these requirements, create a strict technical contract (Manifest).
    You MUST output:
    1. LAYOUT STRUCTURE: Define the exact wrapper classes needed.
    2. DOM IDs: A dictionary of exact DOM Element IDs that HTML and JS will strictly share.
    3. DATA: The exact JSON data structure for the localStorage ledger.

    REQUIREMENTS:
    {state['requirements']}
    """
    manifest = invoke_text(llm, manifest_prompt).strip()
    write_log(state["run_dir"], "Architect Node - MANIFEST", manifest)
    (state["run_dir"] / "manifest.txt").write_text(manifest, encoding="utf-8")

    initial_files = {
        "index.html": "<!DOCTYPE html>\n<html lang='en'>\n<head>\n  <meta charset='UTF-8'>\n  <title>App</title>\n  <link rel='stylesheet' href='style.css'>\n</head>\n<body>\n  <div id='app'></div>\n  <script src='script.js'></script>\n</body>\n</html>",
        "style.css": "/* Global Styles */\nbody { font-family: sans-serif; padding: 20px; }",
        "script.js": "// Main Logic"
    }

    return {
        "project_manifest": manifest,
        "file_system": initial_files,
        "pending_files": ["index.html", "style.css", "script.js"],
        "review_attempts": 0,
        "feedback": "",
        "iterations": 0
    }


def editor_node(state: AgentState):
    current_file = state["pending_files"][0]
    is_revision = state["review_attempts"] > 0
    old_code = state["file_system"][current_file]

    print(f"\n💻 [Editor] {'Revising' if is_revision else 'Drafting'} {current_file}...")

    # Context Economy: Only provide HTML to CSS/JS to avoid overwhelming the LLM
    context_str = f"MANIFEST:\n{state['project_manifest']}\n"
    if current_file in ["style.css", "script.js"]:
        html_code = state["file_system"].get("index.html", "")
        context_str += f"\nACTUAL HTML (Use EXACTLY these IDs and Classes):\n```html\n{html_code}\n```"

    if not is_revision:
        prompt = f"""
        You are an expert web developer writing {current_file} from scratch.
        {context_str}
        Provide ONLY the complete code inside a ``` block. No explanations.
        """
        raw_output = invoke_text(llm, prompt)
        fence_match = re.search(r"```(?:[a-zA-Z]+)?\n?(.*?)\n?```", raw_output, re.DOTALL)
        clean_code = fence_match.group(1).strip() if fence_match else raw_output.strip()
    else:
        prompt = f"""
        Fix `{current_file}` based on reviewer feedback. 
        {context_str}
        FEEDBACK TO FIX: {state['feedback']}

        CURRENT CODE:
        ```
        {old_code}
        ```

        Output ONLY SEARCH/REPLACE blocks to fix the issue. Keep blocks as short as possible.
        FORMAT:
        <<<<<<< SEARCH
        <exact lines to find>
        =======
        <replacement lines>
        >>>>>>> REPLACE
        """
        patch_text = invoke_text(llm, prompt)
        clean_code, failures = apply_patches(old_code, patch_text)
        if failures:
            write_log(state["run_dir"], f"Editor Patch Failures - {current_file}", "\n".join(failures))

    # Guard Against Regression (Never overwrite with a worse file)
    old_issue = heuristic_precheck(current_file, old_code)
    new_issue = heuristic_precheck(current_file, clean_code)

    if not clean_code.strip() and old_code.strip():
        write_log(state["run_dir"], "Editor Guard", f"Model returned empty output. Kept old {current_file}.")
        clean_code = old_code
    elif new_issue and not old_issue:
        write_log(state["run_dir"], "Editor Guard", f"New issue ({new_issue}) introduced. Kept old {current_file}.")
        clean_code = old_code

    updated_fs = state["file_system"].copy()
    updated_fs[current_file] = clean_code

    return {"file_system": updated_fs, "iterations": state["iterations"] + 1}


def reviewer_node(state: AgentState):
    current_file = state["pending_files"][0]
    file_code = state["file_system"][current_file]

    print(f"\n🔎 [Reviewer] Auditing {current_file}...")

    # 1. Free Deterministic Pre-check
    heuristic_issue = heuristic_precheck(current_file, file_code)
    if heuristic_issue:
        print(f"   ❌ Heuristic Issue: {heuristic_issue}")
        write_log(state["run_dir"], f"Reviewer (Heuristic) [{current_file}]", heuristic_issue)
        return {"feedback": heuristic_issue, "review_attempts": state["review_attempts"] + 1}

    # 2. Context-Aware LLM Review
    context_str = f"MANIFEST:\n{state['project_manifest']}\n"
    if current_file in ["style.css", "script.js"]:
        html_code = state["file_system"].get("index.html", "")
        context_str += f"\nACTUAL HTML TO CROSS-REFERENCE:\n```html\n{html_code}\n```"

    prompt = f"""
    Perform a strict Syntax, DOM, and Functionality Audit on {current_file}.
    {context_str}

    CODE TO REVIEW ({current_file}):
    ```
    {file_code}
    ```

    CRITICAL CHECKS:
    1. DOM BINDING: Do the IDs/Classes exactly match the Manifest/HTML?
    2. LOGIC: Are there runtime errors, missing variables, or unimplemented functions?

    If the code is 100% correct, reply with ONLY the word "PASS". 
    If there are errors, describe EXACTLY what needs to change.
    """
    review_output = invoke_text(llm, prompt).strip()
    write_log(state["run_dir"], f"Reviewer Node [{current_file}]", review_output)

    if "PASS" in review_output.upper() or state["review_attempts"] >= 3:
        print(f"   ✅ {current_file} passed review.")
        return {"feedback": "", "review_attempts": 0}
    else:
        print(f"   ❌ Issues found. Routing back to Editor.")
        return {"feedback": review_output, "review_attempts": state["review_attempts"] + 1}


def save_file_node(state: AgentState):
    current_file = state["pending_files"][0]
    content = state["file_system"][current_file]

    file_path = state["run_dir"] / current_file
    file_path.write_text(content, encoding="utf-8")
    print(f"   💾 Saved verified file: {file_path}")
    return {"pending_files": state["pending_files"][1:]}


# ==========================================
# 4. CONDITIONAL ROUTERS & GRAPH
# ==========================================
def route_review(state: AgentState):
    if state["feedback"] == "":
        return "pass"
    return "fail"


def route_next_file(state: AgentState):
    if len(state["pending_files"]) > 0:
        return "continue"
    return "done"


workflow = StateGraph(AgentState)
workflow.add_node("requirements", requirement_node)
workflow.add_node("architect", architect_node)
workflow.add_node("editor", editor_node)
workflow.add_node("reviewer", reviewer_node)
workflow.add_node("save_file", save_file_node)

# DeepEval node can easily be appended here as workflow.add_node("evaluator", evaluator_node) if desired.

workflow.set_entry_point("requirements")
workflow.add_edge("requirements", "architect")
workflow.add_edge("architect", "editor")
workflow.add_edge("editor", "reviewer")

workflow.add_conditional_edges("reviewer", route_review, {"fail": "editor", "pass": "save_file"})
workflow.add_conditional_edges("save_file", route_next_file, {"continue": "editor", "done": END})

app = workflow.compile()

# ==========================================
# 5. EXECUTION
# ==========================================
if __name__ == "__main__":
    user_input = input("\nWhat application do you want to build?\n> ")

    base_dir = Path.cwd() / "SDLC_Runs"
    run_dir = base_dir / datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir.mkdir(parents=True, exist_ok=True)

    write_log(run_dir, "SYSTEM", f"Starting build for: '{user_input}'")

    print(f"\n🚀 Starting build in: {run_dir}")
    app.invoke({"user_input": user_input, "run_dir": run_dir})
    print(f"\n🎉 Build Complete! Check execution_log.txt in {run_dir}")