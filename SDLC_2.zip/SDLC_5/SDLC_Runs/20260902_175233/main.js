// Global State
let invoices_data = [];
let current_invoice = {};
let line_items = [];
let client_details = {};
let invoice_display_html = '';

// DOM Element References
const invoiceInputForm = document.getElementById('invoice_input_form');
const lineItemInputGroup = document.getElementById('line_item_input_group');
const clientVendorDetails = document.getElementById('client_vendor_details');
const calculateTotalsSection = document.getElementById('calculate_totals_section');
const invoicePreview = document.getElementById('invoice_preview');
const invoiceListView = document.getElementById('invoice_list_view');
const invoiceDetailView = document.getElementById('invoice_detail_view');
const exportButton = document.getElementById('export_button');
const printButton = document.getElementById('print_button');

// Event Listeners Setup (Conceptual)
// invoiceInputForm.addEventListener('submit', handleFormSubmit);
// exportButton.addEventListener('click', exportInvoiceAsText);
// printButton.addEventListener('click', printInvoice);

// Function Definitions
function addInvoiceLineItem() {
    // This function simulates adding a new line item and updating the running subtotal.
    // In a real application, this would interact with a state object (e.g., invoice.items).

    // Mock implementation assuming an existing invoice structure
    if (!window.invoiceData) {
        window.invoiceData = { items: [], subtotal: 0 };
    }

    const newItem = {
        description: "New Item",
        quantity: 1,
        unitPrice: 0.00
    };

    // Add the new item
    window.invoiceData.items.push(newItem);

    // Update the running subtotal
    const lineTotal = newItem.quantity * newItem.unitPrice;
    window.invoiceData.subtotal += lineTotal;

    console.log("Line item added. Current Subtotal:", window.invoiceData.subtotal);
}
function calculateTotals() {
    // This function calculates the final totals based on all line items, taxes, and discounts.

    if (!window.invoiceData || window.invoiceData.items.length === 0) {
        window.invoiceData.subtotal = 0;
        window.invoiceData.tax = 0;
        window.invoiceData.discount = 0;
        window.invoiceData.grandTotal = 0;
        return;
    }

    let subtotal = 0;
    const items = window.invoiceData.items;

    // 1. Calculate Subtotal
    items.forEach(item => {
        subtotal += item.quantity * item.unitPrice;
    });

    window.invoiceData.subtotal = subtotal;

    // 2. Apply Taxes (Mock tax rate of 10%)
    const taxRate = 0.10;
    const taxAmount = subtotal * taxRate;
    window.invoiceData.tax = taxAmount;

    // 3. Apply Discounts (Mock discount of 5%)
    const discountRate = 0.05;
    const discountAmount = subtotal * discountRate;
    window.invoiceData.discount = discountAmount;

    // 4. Calculate Grand Total
    const finalTotal = subtotal + taxAmount - discountAmount;
    window.invoiceData.grandTotal = finalTotal;

    console.log("Totals calculated. Grand Total:", window.invoiceData.grandTotal);
}
function saveClientVendorDetails() {
    // This function saves the selected client and vendor details associated with the current invoice session.
    // In a real scenario, this would retrieve data from form inputs and store it in the invoice object.

    // Mock implementation: Assume we are saving placeholder data
    const clientDetails = {
        name: "Acme Corp",
        address: "123 Main St",
        id: "C1001"
    };
    const vendorDetails = {
        name: "Supplier Inc.",
        contact: "contact@supplier.com"
    };

    if (!window.invoiceData) {
        window.invoiceData = {};
    }

    window.invoiceData.client = clientDetails;
    window.invoiceData.vendor = vendorDetails;

    console.log("Client and Vendor details saved.");
}
function generateInvoiceData() {
    // This function compiles all line items, totals, client/vendor details, and metadata into a structured object.

    if (!window.invoiceData) {
        throw new Error("Invoice data is not initialized. Please add line items first.");
    }

    // Ensure totals are calculated before generation
    if (window.invoiceData.subtotal === undefined) {
        calculateTotals();
    }

    const finalInvoice = {
        metadata: {
            date: new Date().toISOString(),
            status: "Draft"
        },
        client: window.invoiceData.client,
        vendor: window.invoiceData.vendor,
        lineItems: window.invoiceData.items,
        totals: {
            subtotal: window.invoiceData.subtotal,
            tax: window.invoiceData.tax,
            discount: window.invoiceData.discount,
            grandTotal: window.invoiceData.grandTotal
        }
    };

    return finalInvoice;
}
function saveInvoiceLocally() {
    // This function saves the complete invoice data structure into the browser's LocalStorage for persistence.

    if (!window.invoiceData) {
        console.error("No invoice data found to save.");
        return;
    }

    try {
        const invoiceToSave = generateInvoiceData();
        
        // Save the structured data to LocalStorage
        localStorage.setItem('currentInvoice', JSON.stringify(invoiceToSave));
        
        console.log("Invoice successfully saved to LocalStorage.");
    } catch (error) {
        console.error("Error saving invoice locally:", error);
    }
}
function loadInvoicesFromStorage() {
    // Simulate retrieving data from LocalStorage
    const invoicesJSON = localStorage.getItem('invoices');
    
    if (invoicesJSON) {
        const invoices = JSON.parse(invoicesJSON);
        // In a real application, this data would populate the UI list.
        console.log("Invoices loaded successfully:", invoices);
        return invoices;
    } else {
        // Initialize an empty list if nothing is found
        console.log("No invoices found in storage. Initializing empty list.");
        return [];
    }
}
function viewInvoiceDetails(invoiceId) {
    // Simulate retrieving a specific invoice from LocalStorage
    const invoicesJSON = localStorage.getItem('invoices');
    if (!invoicesJSON) {
        console.error("Error: No invoice data available.");
        return null;
    }
    
    const invoices = JSON.parse(invoicesJSON);
    const invoice = invoices.find(inv => inv.id === parseInt(invoiceId));

    if (invoice) {
        // Simulate displaying the full details
        console.log(`Displaying details for Invoice ID: ${invoice.id}`);
        console.log("--- Invoice Details ---");
        console.log(`Client/Vendor: ${invoice.clientName}`);
        console.log(`Total Amount: $${invoice.total}`);
        console.log("Line Items:", invoice.items);
        // In a real application, this would update the DOM elements.
        return invoice;
    } else {
        console.error(`Error: Invoice with ID ${invoiceId} not found.`);
        return null;
    }
}
function printInvoice() {
    // Triggers the browser's native print dialog.
    // This assumes the current view is the formatted invoice ready for printing.
    console.log("Triggering browser print dialog...");
    window.print();
}
function exportInvoiceAsText(invoiceData) {
    // 1. Format the data into a plain text string
    let text = "========================================
";
    text += "          INVOICE
";
    text += "========================================
";
    text += `Client/Vendor: ${invoiceData.clientName}
`;
    text += `Invoice ID: ${invoiceData.id}
`;
    text += "----------------------------------------
";
    text += "Line Items:
";
    
    invoiceData.items.forEach(item => {
        text += `- ${item.description}: $${item.amount}
`;
    });
    
    text += "----------------------------------------
";
    text += `TOTAL AMOUNT: $${invoiceData.total}
`;
    text += "========================================
";

    // 2. Prompt the user to download the file (using a Blob)
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `invoice_${invoiceData.id}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    
    console.log("Invoice successfully exported as plain text.");
}
function exportInvoiceAsPDF(invoiceData) {
    // In a real environment, this function would utilize a library like jsPDF 
    // to handle complex formatting and PDF generation.
    
    console.log("Starting PDF generation process for Invoice ID:", invoiceData.id);
    
    // --- Simulation of PDF Conversion ---
    // In a real scenario, we would use:
    // const { jsPDF } = window.jspdf;
    // const doc = new jsPDF();
    // doc.text(invoiceData.clientName, 10, 10);
    // ... add line items and totals ...
    
    // Since we cannot run external libraries, we simulate the download trigger.
    
    // 1. Create a dummy PDF content (simulated)
    const pdfContent = `[PDF Content for Invoice ${invoiceData.id} - Client: ${invoiceData.clientName}]
Total: ${invoiceData.total}`;
    
    // 2. Trigger the download
    const blob = new Blob([pdfContent], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `invoice_${invoiceData.id}.pdf`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    
    console.log("Invoice successfully exported as PDF.");
}