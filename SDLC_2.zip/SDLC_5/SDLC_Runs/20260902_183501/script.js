function loadInvoices() {
    const invoices = JSON.parse(localStorage.getItem('invoices')) || [];
    renderInvoiceList(invoices);
}

function saveInvoice(invoiceData) {
    const invoices = JSON.parse(localStorage.getItem('invoices')) || [];
    
    if (invoiceData.id) {
        // Update existing invoice
        const index = invoices.findIndex(inv => inv.id === invoiceData.id);
        if (index !== -1) {
            invoices[index] = invoiceData;
        }
    } else {
        // Add new invoice
        invoiceData.id = Date.now().toString(); // Simple unique ID generation
        invoices.push(invoiceData);
    }

    localStorage.setItem('invoices', JSON.stringify(invoices));
    loadInvoices(); // Refresh the list after saving
}

function renderInvoiceList() {
    const listContainer = document.getElementById('invoice_list');
    listContainer.innerHTML = '';

    const invoices = JSON.parse(localStorage.getItem('invoices')) || [];

    if (invoices.length === 0) {
        listContainer.innerHTML = '<p>No invoices found.</p>';
        return;
    }

    invoices.forEach(invoice => {
        const item = document.createElement('div');
        item.className = 'invoice-item';
        item.innerHTML = `
            <div class="invoice-details">
                <strong>ID:</strong> ${invoice.id}<br>
                <strong>Client:</strong> ${invoice.client_name}<br>
                <strong>Item:</strong> ${invoice.item_name} (${invoice.quantity} x ${invoice.rate})<br>
                <strong>Total:</strong> $${(invoice.quantity * invoice.rate).toFixed(2)}
            </div>
            <button class="delete-btn" data-id="${invoice.id}">Delete</button>
        `;
        listContainer.appendChild(item);
    });

    // Attach event listeners for delete buttons
    document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', (e) => {
            deleteInvoice(e.target.dataset.id);
        });
    });
}

function generateInvoiceHTML(invoice) {
    const template = document.getElementById('invoice_template_print');
    template.innerHTML = `
        <h2>Invoice #${invoice.id}</h2>
        <p><strong>Client:</strong> ${invoice.client_name}</p>
        <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
            <thead>
                <tr style="border-bottom: 2px solid #000;">
                    <th>Item</th>
                    <th>Quantity</th>
                    <th>Rate</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>${invoice.item_name}</td>
                    <td>${invoice.quantity}</td>
                    <td>$${invoice.rate.toFixed(2)}</td>
                    <td>$${(invoice.quantity * invoice.rate).toFixed(2)}</td>
                </tr>
            </tbody>
        </table>
        <p style="margin-top: 30px; font-weight: bold;">Total: $${(invoice.quantity * invoice.rate).toFixed(2)}</p>
    `;
}

function handleFormSubmit(event) {
    event.preventDefault();

    const invoiceId = document.getElementById('invoice_id_input').value.trim();
    const clientName = document.getElementById('client_name_input').value.trim();
    const itemName = document.getElementById('item_name_input').value.trim();
    const quantity = parseFloat(document.getElementById('quantity_input').value);
    const rate = parseFloat(document.getElementById('rate_input').value);

    // FR6.0: Input Validation
    if (!invoiceId || !clientName || !itemName || isNaN(quantity) || isNaN(rate) || quantity <= 0 || rate <= 0) {
        alert('Please fill in all fields correctly. Quantity and Rate must be positive numbers.');
        return;
    }

    const newInvoice = {
        id: invoiceId,
        client_name: clientName,
        item_name: itemName,
        quantity: quantity,
        rate: rate
    };

    saveInvoice(newInvoice);
    
    // Clear form
    document.getElementById('invoice_form_form').reset();
}

function deleteInvoice(invoiceId) {
    let invoices = JSON.parse(localStorage.getItem('invoices')) || [];
    invoices = invoices.filter(invoice => invoice.id !== invoiceId);
    localStorage.setItem('invoices', JSON.stringify(invoices));
    renderInvoiceList(); // Re-render the list
}

function printInvoice(invoiceId) {
    const invoices = JSON.parse(localStorage.getItem('invoices')) || [];
    const invoiceToPrint = invoices.find(inv => inv.id === invoiceId);

    if (invoiceToPrint) {
        generateInvoiceHTML(invoiceToPrint);
        window.print();
    } else {
        alert('Invoice not found.');
    }
}

// Initialization
document.addEventListener('DOMContentLoaded', () => {
    loadInvoices();
});