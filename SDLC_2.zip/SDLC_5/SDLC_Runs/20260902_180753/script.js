let invoices = [];
let currentInvoiceId = null;

// --- Utility Functions ---

/**
 * Retrieves all invoices from Local Storage.
 * @returns {Array} Array of invoice objects.
 */
function loadInvoices() {
    const data = localStorage.getItem('invoices');
    if (data) {
        invoices = JSON.parse(data);
    } else {
        invoices = [];
    }
    return invoices;
}

/**
 * Saves the current array of invoices to Local Storage.
 */
function saveInvoices() {
    localStorage.setItem('invoices', JSON.stringify(invoices));
}

/**
 * Generates a unique ID for a new invoice.
 * @returns {string} A unique ID.
 */
function generateId() {
    return Date.now().toString();
}

/**
 * Performs client-side validation on form inputs.
 * @param {object} data - The invoice data object.
 * @returns {boolean} True if validation passes, false otherwise.
 */
function validateInput(data) {
    if (!data.invoiceNumber || !data.clientName || !data.itemDescription || !data.itemQuantity || !data.unitPrice || !data.taxRate) {
        alert("Please fill in all required fields.");
        return false;
    }
    if (isNaN(data.itemQuantity) || isNaN(data.unitPrice) || isNaN(data.taxRate)) {
        alert("Quantity, Price, and Tax Rate must be valid numbers.");
        return false;
    }
    return true;
}

/**
 * Calculates subtotal and total amount.
 * @param {number} quantity
 * @param {number} price
 * @param {number} taxRate
 * @returns {object} Calculated totals.
 */
function calculateTotals(quantity, price, taxRate) {
    const subtotal = quantity * price;
    const taxAmount = subtotal * (taxRate / 100);
    const totalAmount = subtotal + taxAmount;
    return { subtotal: subtotal.toFixed(2), total: totalAmount.toFixed(2) };
}

// --- Data Persistence Functions ---

/**
 * Saves a new or updated invoice object to Local Storage.
 * @param {object} invoiceData - The invoice object to save.
 */
function saveInvoice(invoiceData) {
    const id = invoiceData.id || generateId();
    
    // Check if updating existing
    const index = invoices.findIndex(inv => inv.id === id);
    if (index !== -1) {
        invoices[index] = invoiceData;
    } else {
        invoices.push(invoiceData);
    }

    saveInvoices();
}

/**
 * Removes a specific invoice record from Local Storage.
 * @param {string} invoiceId - The ID of the invoice to delete.
 */
function deleteInvoice(invoiceId) {
    invoices = invoices.filter(inv => inv.id !== invoiceId);
    saveInvoices();
}

// --- Rendering Functions ---

/**
 * Dynamically generates the list of invoices on the UI.
 */
function renderInvoiceList() {
    const container = document.getElementById('invoiceListContainer');
    container.innerHTML = '';

    if (invoices.length === 0) {
        document.getElementById('noInvoicesMessage').style.display = 'block';
        return;
    }
    document.getElementById('noInvoicesMessage').style.display = 'none';

    invoices.forEach(invoice => {
        const card = document.createElement('div');
        card.className = 'invoice-card';
        card.setAttribute('data-id', invoice.id);
        
        const formattedDate = new Date(invoice.date).toLocaleDateString();
        const formattedTotal = `$${parseFloat(invoice.total).toFixed(2)}`;

        card.innerHTML = `
            <h3>Invoice #${invoice.invoiceNumber}</h3>
            <p>Client: ${invoice.clientName}</p>
            <p>Date: ${formattedDate}</p>
            <p>Total: ${formattedTotal}</p>
        `;
        
        card.addEventListener('click', () => displayInvoiceDetails(invoice.id));
        container.appendChild(card);
    });
}

/**
 * Loads and displays the full details of a selected invoice.
 * @param {string} invoiceId - The ID of the invoice to display.
 */
function displayInvoiceDetails(invoiceId) {
    const invoice = invoices.find(inv => inv.id === invoiceId);
    if (!invoice) {
        document.getElementById('invoiceDetailView').innerHTML = '<p>Invoice not found.</p>';
        return;
    }

    const totals = calculateTotals(
        parseFloat(invoice.itemQuantity), 
        parseFloat(invoice.unitPrice), 
        parseFloat(invoice.taxRate)
    );

    const detailHTML = `
        <h2>Invoice Details: ${invoice.invoiceNumber}</h2>
        <p><strong>Client:</strong> ${invoice.clientName}</p>
        <p><strong>Date:</strong> ${invoice.date}</p>
        <hr>
        <h3>Items:</h3>
        <p>Description: ${invoice.itemDescription}</p>
        <p>Quantity: ${invoice.itemQuantity}</p>
        <p>Unit Price: $${parseFloat(invoice.unitPrice).toFixed(2)}</p>
        <p>Tax Rate: ${invoice.taxRate}%</p>
        <hr>
        <h3>Summary:</h3>
        <p>Subtotal: $${totals.subtotal}</p>
        <p>Tax Amount: $${(parseFloat(totals.subtotal) * (parseFloat(invoice.taxRate) / 100)).toFixed(2)}</p>
        <p><strong>Total Amount: $${totals.total}</strong></p>
    `;

    document.getElementById('invoiceDetailView').innerHTML = detailHTML;
    
    // Update action buttons
    document.getElementById('backToListButton').onclick = () => {
        document.getElementById('invoiceDetailSection').classList.add('hidden');
        document.getElementById('invoiceListSection').classList.remove('hidden');