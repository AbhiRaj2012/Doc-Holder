import os
import re
import json
import operator
from pathlib import Path
from datetime import datetime
from typing import TypedDict, Annotated

from langgraph.graph import StateGraph, END
from langchain_ollama import ChatOllama

# Initialize LLM (Ensure tag matches your local model)
llm = ChatOllama(
    model="gemma4:e2b",
    num_predict=3000,
    num_ctx=8192,
    temperature=0.1
)


# ==========================================
# 1. UTILITIES & STATE
# ==========================================
def write_log(run_dir: Path, step: str, details: str):
    """Writes execution details to a timestamped log file."""
    log_file = run_dir / "execution_log.txt"
    timestamp = datetime.now().strftime("%H:%M:%S")
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"\n[{timestamp}] === {step.upper()} ===\n")
        f.write(str(details) + "\n")
        f.write("-" * 80 + "\n")


def extract_json(text: str) -> dict:
    """Aggressive JSON extraction."""
    clean_text = re.sub(r"```(?:json)?", "", text, flags=re.IGNORECASE).replace("```", "")
    start = clean_text.find('{')
    end = clean_text.rfind('}')
    if start != -1 and end != -1:
        try:
            return json.loads(clean_text[start:end + 1], strict=False)
        except Exception as e:
            print(f"   [!] JSON Parse Error: {e}")
            return {}
    return {}


class AgentState(TypedDict):
    user_input: str
    requirements: str
    project_manifest: str
    run_dir: Path
    file_system: Annotated[dict, operator.ior]
    pending_files: list[str]
    feedback: str
    review_attempts: int
    validation_errors: Annotated[dict, operator.ior]


# ==========================================
# 2. NODES
# ==========================================

def requirement_node(state: AgentState):
    print("\n📝 [Scoper] Extracting Functional Requirements...")
    prompt = f"""
    You are a professional Analyser. The user wants to build: '{state['user_input']}'

    Convert this request into concise requirements for a simple web app.
    Use ONLY HTML, CSS, and Vanilla JavaScript across separate files.

    RULES:
    1. List ONLY Functional Requirements (what the app must DO, features, modules).
    2. IGNORE non-functional requirements (load times, maintainability, etc.).
    3. Be specific and practical.
    """
    requirements = llm.invoke(prompt).content.strip()
    write_log(state["run_dir"], "Requirements", requirements)

    # Save to disk
    (state["run_dir"] / "req.txt").write_text(requirements, encoding="utf-8")
    return {"requirements": requirements}


def architect_node(state: AgentState):
    print("\n📐 [Architect] Building Manifest Section-by-Section...")

    reqs = state['requirements']

    # --- Part 1: Layout ---
    print("   ↳ Designing Layout & CSS Structure...")
    p1 = f"Based on these requirements: {reqs}\nOutput JSON detailing the CSS layout strategy. Format: {{\"layout_schema\": {{\"container_name\": \"CSS Grid/Flex rule\", ...}}}}"
    layout_data = extract_json(llm.invoke(p1).content)

    # --- Part 2: Elements & State ---
    print("   ↳ Mapping DOM IDs & Global State...")
    p2 = f"Based on these requirements: {reqs}\nOutput JSON for DOM IDs and JS variables. Format: {{\"element_ids\": [{{\"id\": \"...\", \"description\": \"...\"}}], \"global_state\": [{{\"name\": \"...\", \"description\": \"...\"}}]}}"
    state_data = extract_json(llm.invoke(p2).content)

    # --- Part 3: Functions ---
    print("   ↳ Defining JS Functions...")
    p3 = f"Based on these requirements: {reqs}\nOutput JSON for JavaScript functions. Format: {{\"functions\": [{{\"name\": \"...\", \"triggered_by\": \"...\", \"description\": \"...\"}}]}}"

    # SAFETY NET: Retry up to 3 times if JSON parsing fails
    func_data = {}
    for attempt in range(3):
        func_data = extract_json(llm.invoke(p3).content)
        if func_data.get("functions"):
            break
        print(f"   [!] Function extraction failed. Retrying... ({attempt + 1}/3)")

    # Merge Manifest
    manifest_dict = {
        "project_files": ["index.html", "style.css", "main.js"],
        "layout_schema": layout_data.get("layout_schema", {}),
        "element_ids": state_data.get("element_ids", []),
        "global_state": state_data.get("global_state", []),
        "functions": func_data.get("functions", [])
    }

    manifest_str = json.dumps(manifest_dict, indent=2)
    write_log(state["run_dir"], "Manifest", manifest_str)
    (state["run_dir"] / "manifest.json").write_text(manifest_str, encoding="utf-8")

    initial_files = {
        "index.html": "<!DOCTYPE html>\n<html lang='en'>\n<head>\n  <meta charset='UTF-8'>\n  <title>App</title>\n  <link rel='stylesheet' href='style.css'>\n</head>\n<body>\n  <div id='app'></div>\n  <script src='main.js'></script>\n</body>\n</html>",
        "style.css": "/* CSS */",
        "main.js": "/* JS */"
    }

    return {
        "project_manifest": manifest_str,
        "file_system": initial_files,
        "pending_files": ["index.html", "style.css", "main.js"],
        "review_attempts": 0,
        "feedback": "",
        "validation_errors": {}
    }


def editor_node(state: AgentState):
    current_file = state["pending_files"][0]
    base_code = state["file_system"][current_file]
    manifest_dict = json.loads(state["project_manifest"])
    is_revision = state["review_attempts"] > 0

    print(f"\n💻 [Editor] Drafting {current_file} (Attempt {state['review_attempts'] + 1}/3)...")

    # --- REVISION LOGIC ---
    if is_revision:
        prompt = f"""
        You are a professional web developer. Fix `{current_file}` based on Reviewer feedback.
        REVIEWER FEEDBACK: {state['feedback']}

        CURRENT CODE:
        ```
        {base_code}
        ```
        CRITICAL: Output the ENTIRE fixed file inside triple backticks. Do not use placeholders.
        """
        response = llm.invoke(prompt).content
        match = re.search(r"```(?:[a-zA-Z]+)?\n?(.*?)\n?```", response, re.DOTALL)
        new_code = match.group(1).strip() if match else response.strip()
        return {"file_system": {current_file: new_code}}

    # --- CHUNKED GENERATION LOGIC (For main.js) ---
    if current_file == "main.js":
        print("   ↳ Building JS Skeleton...")
        skel_prompt = f"""
                Write the skeleton for `main.js`.
                STATE: {manifest_dict['global_state']}
                IDs: {manifest_dict['element_ids']}

                RULES:
                1. Declare all global state variables.
                2. Set up document.getElementById references and event listeners.
                3. For EVERY function in this list: {manifest_dict['functions']}, DO NOT WRITE THE LOGIC. Instead, write exactly: 
                   // <PLACEHOLDER id="functionName"/>

                Output ONLY raw javascript inside ``` blocks.
                """

        skel_resp = llm.invoke(skel_prompt).content
        skel_match = re.search(r"```(?:javascript|js)?\n?(.*?)\n?```", skel_resp, re.DOTALL)
        skeleton = skel_match.group(1).strip() if skel_match else skel_resp.strip()

        funcs = manifest_dict['functions']
        chunk_size = 5

        for i in range(0, len(funcs), chunk_size):
            chunk = funcs[i:i + chunk_size]
            names = [f["name"] for f in chunk]
            print(f"   ↳ Implementing JS chunk: {names}...")

            impl_prompt = f"""
            Implement the following JavaScript functions strictly based on their descriptions:
            {json.dumps(chunk, indent=2)}

            OUTPUT FORMAT:
            For each function, wrap the code exactly like this:
            <IMPL id="functionName">
            function functionName() {{
                // code here
            }}
            </IMPL>
            """
            impl_resp = llm.invoke(impl_prompt).content

            # Inject implementations into skeleton
            for func_name in names:
                pattern = rf'<IMPL id="{func_name}">\s*(.*?)\s*</IMPL>'
                impl_match = re.search(pattern, impl_resp, re.DOTALL | re.IGNORECASE)
                if impl_match:
                    func_code = impl_match.group(1).strip()
                    # Updated regex to match the comment slashes
                    skeleton = re.sub(rf'//\s*<PLACEHOLDER id="["\']?{func_name}["\']?\s*"/>', func_code, skeleton,
                                      flags=re.IGNORECASE)

        new_code = skeleton

    # --- STANDARD GENERATION (For HTML/CSS) ---
    else:
        focus = ""
        if current_file == "index.html":
            focus = f"Focus strictly on elements: {manifest_dict['element_ids']} and layout: {manifest_dict['layout_schema']}. MUST link style.css and main.js."
        elif current_file == "style.css":
            focus = f"Focus strictly on layout: {manifest_dict['layout_schema']}. Keep CSS simple and light."

        prompt = f"""
        You are a professional web developer. Write the complete code for `{current_file}`.
        REQUIREMENTS: {state['requirements']}
        {focus}
        Output ONLY the raw code inside ``` blocks.
        """
        response = llm.invoke(prompt).content
        match = re.search(r"```(?:[a-zA-Z]+)?\n?(.*?)\n?```", response, re.DOTALL)
        new_code = match.group(1).strip() if match else response.strip()

    write_log(state["run_dir"], f"Editor Output [{current_file}]", new_code)
    return {"file_system": {current_file: new_code}}


def reviewer_node(state: AgentState):
    current_file = state["pending_files"][0]
    file_code = state["file_system"][current_file]
    attempts = state["review_attempts"] + 1

    print(f"\n🔎 [Reviewer] Auditing {current_file}...")

    project_context = "".join([f"\n--- {f.upper()} ---\n{c}\n" for f, c in state["file_system"].items()])

    prompt = f"""
    You are a strict code reviewer. Review `{current_file}` against this MANIFEST: {state['project_manifest']}
    FULL PROJECT CONTEXT: {project_context}

    CRITICAL CHECKS:
    1. SYNTAX: Any mismatched quotes, unclosed tags, or missing brackets?
    2. DOM BINDING: Do the IDs exactly match the Manifest?
    3. FUNCTIONS (JS only): Are there any empty stubs or missing logic?

    Code:
    ```
    {file_code}
    ```

    If the code is 100% correct, reply with ONLY the word "PASS". 
    If there are errors, explain exactly what is wrong.
    """
    review_output = llm.invoke(prompt).content.strip()
    write_log(state["run_dir"], f"Reviewer Node [{current_file}]", review_output)

    # Check for PASS
    if "PASS" in review_output[:10].upper():
        print(f"   ✅ {current_file} passed review.")
        return {"feedback": "", "review_attempts": 0}

    print(f"   ❌ Issues found. Feedback: {review_output[:80]}...")

    # 3-Strike Rule Logic
    if attempts >= 3:
        print(f"   ⚠️ Strike 3. Marking {current_file} as incomplete. Moving to next file.")
        return {
            "feedback": "",  # Setting feedback empty routes graph to save_file_node
            "review_attempts": 0,
            "validation_errors": {current_file: review_output}
        }

    return {"feedback": review_output, "review_attempts": attempts}


def save_file_node(state: AgentState):
    current_file = state["pending_files"][0]
    content = state["file_system"][current_file]

    file_path = state["run_dir"] / current_file
    file_path.write_text(content, encoding="utf-8")
    print(f"   💾 Saved verified file: {file_path}")

    return {"pending_files": state["pending_files"][1:]}


# ==========================================
# 3. ROUTERS & GRAPH
# ==========================================
def route_review(state: AgentState):
    # If feedback is empty (either passed, or hit max strikes), move on.
    if state["feedback"] == "":
        return "pass"
    return "fail"


def route_next_file(state: AgentState):
    if len(state["pending_files"]) > 0:
        return "continue"
    return "done"


workflow = StateGraph(AgentState)
workflow.add_node("requirements", requirement_node)
workflow.add_node("architect", architect_node)
workflow.add_node("editor", editor_node)
workflow.add_node("reviewer", reviewer_node)
workflow.add_node("save_file", save_file_node)

workflow.set_entry_point("requirements")
workflow.add_edge("requirements", "architect")
workflow.add_edge("architect", "editor")
workflow.add_edge("editor", "reviewer")

workflow.add_conditional_edges("reviewer", route_review, {"fail": "editor", "pass": "save_file"})
workflow.add_conditional_edges("save_file", route_next_file, {"continue": "editor", "done": END})

app = workflow.compile()

# ==========================================
# 4. EXECUTION
# ==========================================
if __name__ == "__main__":
    user_input = input("\nWhat application do you want to build?\n> ")

    base_dir = Path.cwd() / "SDLC_Runs"
    run_dir = base_dir / datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n🚀 Starting build in: {run_dir}")

    final_state = app.invoke({
        "user_input": user_input,
        "run_dir": run_dir,
        "review_attempts": 0,
        "validation_errors": {}
    })

    # Final Validation Ledger Export
    errors = final_state.get("validation_errors", {})
    if errors:
        (run_dir / "validation.json").write_text(json.dumps(errors, indent=2), encoding="utf-8")
        print(f"\n⚠️ Build finished with {len(errors)} unresolved files. Check validation.json for details.")
    else:
        print(f"\n🎉 Build Complete! Zero validation errors.")