import re
from pathlib import Path
from datetime import datetime
from typing import TypedDict, Annotated
import operator

from langgraph.graph import StateGraph, END
from langchain_ollama import ChatOllama

# Initialize LLM
llm = ChatOllama(
    model="gemma4:e2b",  # Ensure you are using the most capable tag for coding
    num_predict=4096,
    num_ctx=10192,
    temperature=0.1
)


# ==========================================
# 1. LOGGER UTILITY
# ==========================================
def write_log(run_dir: Path, step: str, details: str):
    log_file = run_dir / "execution_log.txt"
    timestamp = datetime.now().strftime("%H:%M:%S")
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"\n[{timestamp}] === {step.upper()} ===\n")
        f.write(str(details) + "\n")
        f.write("-" * 80 + "\n")


# ==========================================
# 2. ENHANCED STATE DEFINITION
# ==========================================
class AgentState(TypedDict):
    user_input: str
    requirements: str
    project_manifest: str
    run_dir: Path
    file_system: Annotated[dict, operator.ior]
    pending_files: list[str]
    feedback: str
    review_attempts: int
    iterations: int


# ==========================================
# 3. NODES
# ==========================================
def requirement_node(state: AgentState):
    print("🔍 Generating requirements...")
    prompt = f"""
    You are a professional Analyser, who analyses the users software product request and create the list of requirements of it.
    REQUEST: {state['user_input']}
    Convert this user's request into concise requirements for a simple web app.
    Use ONLY HTML, CSS, and Vanilla JavaScript across separate files.
    """
    write_log(state["run_dir"], "Requirement Node - PROMPT", prompt)

    requirements = ""
    for chunk in llm.stream(prompt):
        requirements += chunk.content
    requirements = requirements.strip()

    write_log(state["run_dir"], "Requirement Node - OUTPUT", requirements)
    (state["run_dir"] / "requirements.txt").write_text(requirements, encoding="utf-8")
    return {"requirements": requirements}


def architect_node(state: AgentState):
    print("\n📐 [Architect] Creating Project Manifest & Scaffolding...")

    # UPGRADE: Force a layout structure to prevent full-width stacking
    manifest_prompt = f"""
    You are a professional project architect, who analyses the project and its requirements and based on this creates a
    manifest.json file for it.
    The manifest file contains:
    1. Project name and its description (what it is and what it does).
    2. Layout section: this section contains the data of layout how the particular file's html will be structured, (like
       the layout nav/grid/flex/etc) and proper component tags, so CSS can implement a Grid/Flexbox properly.
    3. IDs section: A dictionary of exact IDs of the components (button, inputfield, nav, etc),that HTML and JS will
       strictly share.
    3. Function section: this section contains the list of all required functions for js , the section holds the
       function's exact declaration,arg and what they do.
    4. The project will be build in minimum 3 files (index.html, style.css, app.js), Also keep the file names strictly
       defined so that they don't get changed. if files are interconnected then mention it in the layout section.

    REQUIREMENTS:
    {state['requirements']}
    """
    manifest = llm.invoke(manifest_prompt).content.strip()
    write_log(state["run_dir"], "Architect Node - MANIFEST", manifest)

    # Save the manifest immediately
    (state["run_dir"] / "manifest.txt").write_text(manifest, encoding="utf-8")

    initial_files = {
        "index.html": "<!DOCTYPE html>\n<html lang='en'>\n<head>\n  <meta charset='UTF-8'>\n  <title>App</title>\n  <link rel='stylesheet' href='style.css'>\n</head>\n<body>\n  <div id='app'></div>\n  <script src='script.js'></script>\n</body>\n</html>",
        "style.css": "/* Global Styles */\nbody { font-family: sans-serif; padding: 20px; }",
        "script.js": "// Main Logic"
    }

    return {
        "project_manifest": manifest,
        "file_system": initial_files,
        "pending_files": ["index.html", "style.css", "script.js"],
        "review_attempts": 0,
        "feedback": "",
        "iterations": 0
    }


def editor_node(state: AgentState):
    current_file = state["pending_files"][0]
    base_code = state["file_system"][current_file]

    print(f"\n💻 [Editor] Drafting {current_file} (Streaming)...")

    project_context = "".join([f"\n--- {f.upper()} ---\n{c}\n" for f, c in state["file_system"].items()])

    # UPGRADE: Strict diff-style instructions
    prompt = f"""
    You are a professional web developer, who has a long experience and knowledge of the web application development in
    HTML/CSS/JS. You are currently working on this project: {state['project_manifest']}\n
    and\n
    CURRENT PROJECT FILES:
    {project_context}\n
    
    Work over this file : {current_file}.\n

    PREVIOUS REVIEWER FEEDBACK:
    {state['feedback']}

    CRITICAL INSTRUCTION: 
    If there is feedback, you MUST ONLY change the exact lines mentioned. DO NOT refactor or rewrite the rest of the file.
    You MUST return the ENTIRE updated file content so it can be saved, but leave the un-flagged code exactly as it was.
    Provide ONLY the complete code for {current_file}. No markdown code fences, no explanations.
    
    1. Do not merge html/css/js in one single script (keep them separate).
    2. If working over html file then focus on the layout and id section of the manifest.
    3. if working over css file then focus on the layout section of the manifest for correct component tags (also don't
       make the css so heavy, keep it light and simple).
    4. if working over js file then focus on the function and id section of the manifest for correct function 
       implementation and exact names (IDs).
    """
    write_log(state["run_dir"], f"Editor Node [{current_file}] - PROMPT", prompt)

    raw_output = ""
    try:
        for chunk in llm.stream(prompt):
            raw_output += chunk.content
            print(chunk.content, end="", flush=True)
    except Exception as e:
        print(f"\n   [!] Streaming interrupted: {e}")

    raw_output = raw_output.strip()
    print("\n")

    fence_match = re.search(r"```(?:[a-zA-Z]+)?\n?(.*?)\n?```", raw_output, re.DOTALL)
    clean_code = fence_match.group(1).strip() if fence_match else raw_output.strip()

    updated_fs = state["file_system"].copy()
    if len(clean_code) > 10:
        updated_fs[current_file] = clean_code

    return {
        "file_system": updated_fs,
        "iterations": state["iterations"] + 1
    }


def reviewer_node(state: AgentState):
    current_file = state["pending_files"][0]
    file_code = state["file_system"][current_file]

    print(f"\n🔎 [Reviewer] Auditing {current_file}...")

    project_context = "".join([f"\n--- {f.upper()} ---\n{c}\n" for f, c in state["file_system"].items()])

    # UPGRADE: Added Syntax Linter and structured Replace/With feedback
    prompt = f"""
    You are a professional code reviewer, who has a long experience and knowledge of the web application and there bugs/issues.
    Perform a strict Analysis Audit over the current provided code.

    with respect to the data in MANIFEST: {state['project_manifest']}
    FULL PROJECT CONTEXT: {project_context}
    CODE TO REVIEW ({current_file}):
    {file_code}

    CRITICAL CHECKS:
    1. SYNTAX LINTING: Are there any mismatched quotes (e.g. id='btn">), unclosed tags, or missing brackets?
    2. DOM BINDING: Do the IDs/Classes exactly match the Manifest?
    3. UI LAYOUT: Does the CSS implement a proper Grid or Flexbox matching the HTML wrappers?
    
    4. If working over html file then focus on the layout and id section of the manifest.
    5. if working over css file then focus on the layout section of the manifest for correct component tags (also don't
       make the css so heavy, keep it light and simple).
    6. if working over js file then focus on the function and id section of the manifest for correct function 
       implementation and exact names (IDs).

    If the code is 100% correct, reply with ONLY the word "PASS". 
    If there are errors, identify the specific mistake and provide SURGICAL feedback in this exact format:
    "Replace: [bad code line]
    With: [corrected code line]"
    """

    review_output = llm.invoke(prompt).content.strip()
    write_log(state["run_dir"], f"Reviewer Node [{current_file}]", review_output)

    if "PASS" in review_output.upper() or state["review_attempts"] >= 3:  # Increased allowance to 3 attempts
        print(f"   ✅ {current_file} passed review.\nFeedback: {review_output}")
        return {
            "feedback": "",
            "review_attempts": 0
        }
    else:
        print(f"   ❌ Issues found in {current_file}. Routing back to Editor for surgical fix.\nFeedback: {review_output}\nReview attempts: {state['review_attempts']}")
        return {
            "feedback": review_output,
            "review_attempts": state["review_attempts"] + 1
        }


def save_file_node(state: AgentState):
    current_file = state["pending_files"][0]
    content = state["file_system"][current_file]

    # Save the individual file immediately upon passing
    file_path = state["run_dir"] / current_file
    file_path.write_text(content, encoding="utf-8")
    print(f"   💾 Saved verified file: {file_path}")

    # Pop the completed file from the queue
    return {"pending_files": state["pending_files"][1:]}


# ==========================================
# 4. CONDITIONAL ROUTERS & GRAPH
# ==========================================
def route_review(state: AgentState):
    if state["feedback"] == "":
        return "pass"
    return "fail"


def route_next_file(state: AgentState):
    if len(state["pending_files"]) > 0:
        return "continue"
    return "done"


workflow = StateGraph(AgentState)
workflow.add_node("requirements", requirement_node)
workflow.add_node("architect", architect_node)
workflow.add_node("editor", editor_node)
workflow.add_node("reviewer", reviewer_node)
workflow.add_node("save_file", save_file_node)

workflow.set_entry_point("requirements")
workflow.add_edge("requirements", "architect")
workflow.add_edge("architect", "editor")
workflow.add_edge("editor", "reviewer")

workflow.add_conditional_edges("reviewer", route_review, {"fail": "editor", "pass": "save_file"})
workflow.add_conditional_edges("save_file", route_next_file, {"continue": "editor", "done": END})

app = workflow.compile()

# ==========================================
# 5. EXECUTION
# ==========================================
if __name__ == "__main__":
    user_input = input("\nWhat application do you want to build?\n> ")

    base_dir = Path.cwd() / "SDLC_Runs"
    run_dir = base_dir / datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir.mkdir(parents=True, exist_ok=True)

    write_log(run_dir, "SYSTEM", f"Starting build for: '{user_input}'")

    print(f"\n🚀 Starting build in: {run_dir}")
    app.invoke({"user_input": user_input, "run_dir": run_dir})
    print(f"\n🎉 Build Complete! Check execution_log.txt in {run_dir}")
